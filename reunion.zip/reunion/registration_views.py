from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages

def register_view(request):
    """用戶註冊視圖"""
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'帳戶 {username} 已成功創建！')
            login(request, user)
            return redirect('home')  # 重定向到首頁
    else:
        form = UserCreationForm()
    
    return render(request, 'registration/register.html', {'form': form})
