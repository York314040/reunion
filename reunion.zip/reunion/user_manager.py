#!/usr/bin/env python3
"""
Django 用戶管理控制台
一個美觀的命令行用戶管理工具
"""

import os
import sys
import django
from datetime import datetime, timedelta

# 設定Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.contrib.auth.models import User
from django.conf import settings

class Colors:
    """ANSI顏色代碼"""
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    END = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def print_header():
    """列印標題"""
    print(Colors.BLUE + "=" * 80 + Colors.END)
    print(Colors.BOLD + Colors.HEADER + "                    Django 用戶管理控制台" + Colors.END)
    print(Colors.BLUE + "=" * 80 + Colors.END)

def print_db_info():
    """列印資料庫資訊"""
    db_config = settings.DATABASES['default']
    print(f"{Colors.GREEN}📁 資料庫類型:{Colors.END} {db_config['ENGINE'].split('.')[-1].upper()}")
    print(f"{Colors.GREEN}📁 資料庫位置:{Colors.END} {db_config['NAME']}")
    
    if os.path.exists(db_config['NAME']):
        file_size = os.path.getsize(db_config['NAME'])
        print(f"{Colors.GREEN}📁 檔案大小:{Colors.END} {file_size:,} bytes ({file_size/1024:.1f} KB)")

def get_permission_badge(user):
    """獲取用戶權限標籤"""
    badges = []
    if user.is_superuser:
        badges.append(f"{Colors.RED}🔴 超級用戶{Colors.END}")
    if user.is_staff:
        badges.append(f"{Colors.YELLOW}🟡 管理員{Colors.END}")
    if not user.is_active:
        badges.append("⚫ 已停用")
    
    if not badges:
        badges.append(f"{Colors.GREEN}🟢 一般用戶{Colors.END}")
    
    return " | ".join(badges)

def get_last_login_info(user):
    """獲取最後登入資訊"""
    if not user.last_login:
        return f"{Colors.YELLOW}從未登入{Colors.END}"
    
    now = datetime.now(user.last_login.tzinfo)
    diff = now - user.last_login
    
    if diff.days == 0:
        if diff.seconds < 3600:
            return f"{Colors.GREEN}{diff.seconds//60} 分鐘前{Colors.END}"
        else:
            return f"{Colors.GREEN}{diff.seconds//3600} 小時前{Colors.END}"
    elif diff.days == 1:
        return f"{Colors.YELLOW}昨天{Colors.END}"
    elif diff.days <= 7:
        return f"{Colors.YELLOW}{diff.days} 天前{Colors.END}"
    else:
        return f"{Colors.RED}{user.last_login.strftime('%Y年%m月%d日')}{Colors.END}"

def print_user_list():
    """列印用戶列表"""
    print(f"\n{Colors.BLUE}{'=' * 80}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.HEADER}                        所有用戶資料{Colors.END}")
    print(f"{Colors.BLUE}{'=' * 80}{Colors.END}")
    
    users = User.objects.all().order_by('id')
    
    if not users:
        print(f"{Colors.YELLOW}⚠️  目前沒有任何用戶{Colors.END}")
        return
    
    for i, user in enumerate(users, 1):
        # 用戶卡片邊框
        print(f"\n{Colors.BLUE}┌─ 👤 用戶 #{user.id} ──────────────────────────────────────{Colors.END}")
        print(f"{Colors.BLUE}│{Colors.END} {Colors.BOLD}用戶名稱:{Colors.END} {user.username}")
        print(f"{Colors.BLUE}│{Colors.END} {Colors.BOLD}真實姓名:{Colors.END} {user.get_full_name() or '未設定'}")
        print(f"{Colors.BLUE}│{Colors.END} {Colors.BOLD}電子信箱:{Colors.END} {user.email or '未設定'}")
        print(f"{Colors.BLUE}│{Colors.END} {Colors.BOLD}權限狀態:{Colors.END} {get_permission_badge(user)}")
        print(f"{Colors.BLUE}│{Colors.END} {Colors.BOLD}註冊時間:{Colors.END} {user.date_joined.strftime('%Y年%m月%d日 %H:%M:%S')}")
        print(f"{Colors.BLUE}│{Colors.END} {Colors.BOLD}最後登入:{Colors.END} {get_last_login_info(user)}")
        
        # 用戶相關資料
        events_count = user.event_set.count() if hasattr(user, 'event_set') else 0
        if events_count > 0:
            print(f"{Colors.BLUE}│{Colors.END} {Colors.BOLD}發布活動:{Colors.END} {Colors.GREEN}{events_count} 個{Colors.END}")
        else:
            print(f"{Colors.BLUE}│{Colors.END} {Colors.BOLD}發布活動:{Colors.END} 0 個")
        
        print(f"{Colors.BLUE}└──────────────────────────────────────────────────────────{Colors.END}")

def print_statistics():
    """列印統計資訊"""
    print(f"\n{Colors.BLUE}{'=' * 80}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.HEADER}                          統計摘要{Colors.END}")
    print(f"{Colors.BLUE}{'=' * 80}{Colors.END}")
    
    total_users = User.objects.count()
    
    if total_users == 0:
        print(f"{Colors.YELLOW}⚠️  目前沒有任何用戶{Colors.END}")
        return
    
    superusers = User.objects.filter(is_superuser=True).count()
    staff_users = User.objects.filter(is_staff=True).count()
    active_users = User.objects.filter(is_active=True).count()
    
    print(f"📊 {Colors.BOLD}總用戶數量:{Colors.END} {Colors.BLUE}{total_users:>3} 人{Colors.END}")
    print(f"🔴 {Colors.BOLD}超級用戶數:{Colors.END} {Colors.RED}{superusers:>3} 人{Colors.END} ({superusers/total_users*100:.1f}%)")
    print(f"🟡 {Colors.BOLD}管理員數量:{Colors.END} {Colors.YELLOW}{staff_users:>3} 人{Colors.END} ({staff_users/total_users*100:.1f}%)")
    print(f"🟢 {Colors.BOLD}啟用用戶數:{Colors.END} {Colors.GREEN}{active_users:>3} 人{Colors.END} ({active_users/total_users*100:.1f}%)")
    print(f"⚫ {Colors.BOLD}停用用戶數:{Colors.END} {total_users-active_users:>3} 人 ({(total_users-active_users)/total_users*100:.1f}%)")

def print_quick_links():
    """列印快速連結"""
    print(f"\n{Colors.BLUE}{'=' * 80}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.HEADER}                     快速操作指南{Colors.END}")
    print(f"{Colors.BLUE}{'=' * 80}{Colors.END}")
    print(f"🔧 {Colors.BOLD}用戶管理頁面:{Colors.END} {Colors.UNDERLINE}http://127.0.0.1:8000/management/users/{Colors.END}")
    print(f"⚙️  {Colors.BOLD}Django管理後台:{Colors.END} {Colors.UNDERLINE}http://127.0.0.1:8000/admin/{Colors.END}")
    print(f"🏠 {Colors.BOLD}前台首頁:{Colors.END} {Colors.UNDERLINE}http://127.0.0.1:8000/{Colors.END}")
    print(f"{Colors.BLUE}{'=' * 80}{Colors.END}")

def main():
    """主函數"""
    try:
        print_header()
        print_db_info()
        print_user_list()
        print_statistics()
        print_quick_links()
        
        print(f"\n{Colors.GREEN}✅ 用戶資料查看完成！{Colors.END}")
        
    except Exception as e:
        print(f"\n{Colors.RED}❌ 錯誤: {e}{Colors.END}")
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
