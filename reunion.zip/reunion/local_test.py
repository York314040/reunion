#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
本地開發環境測試腳本 - PAPA COLLEGE B2B聚會派對媒合平台
"""

import requests
import time
import sys
from datetime import datetime
from bs4 import BeautifulSoup
import os

def test_server_connection():
    """測試服務器連接"""
    print("🔗 測試本地服務器連接...")
    
    try:
        response = requests.get("http://127.0.0.1:8000/", timeout=10)
        if response.status_code == 200:
            print("✅ 本地服務器連接成功！")
            return True
        else:
            print(f"❌ 服務器響應錯誤: {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print("❌ 無法連接到本地服務器")
        print("請確保 Django 服務器正在運行：python manage.py runserver")
        return False
    except Exception as e:
        print(f"❌ 連接測試失敗: {str(e)}")
        return False

def test_main_pages():
    """測試主要頁面"""
    print("\n📄 測試主要頁面...")
    
    pages = {
        "首頁": "http://127.0.0.1:8000/",
        "探索需求": "http://127.0.0.1:8000/",
        "各式廠商": "http://127.0.0.1:8000/suppliers/",
        "熱門DJ": "http://127.0.0.1:8000/dj/popular/",
        "DJ列表": "http://127.0.0.1:8000/dj/",
        "用戶註冊": "http://127.0.0.1:8000/users/register/",
        "用戶登入": "http://127.0.0.1:8000/accounts/login/",
        "管理後台": "http://127.0.0.1:8000/admin/"
    }
    
    results = {}
    
    for name, url in pages.items():
        try:
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                print(f"  ✅ {name}: 正常")
                results[name] = "✅ 正常"
            elif response.status_code == 302:
                print(f"  🔄 {name}: 重定向 (正常)")
                results[name] = "🔄 重定向"
            else:
                print(f"  ❌ {name}: 錯誤 {response.status_code}")
                results[name] = f"❌ 錯誤 {response.status_code}"
        except Exception as e:
            print(f"  ❌ {name}: 異常 - {str(e)}")
            results[name] = f"❌ 異常"
    
    return results

def test_database_connection():
    """測試資料庫連接"""
    print("\n🗄️ 測試資料庫連接...")
    
    try:
        # 檢查資料庫文件是否存在
        db_file = "db.sqlite3"
        if os.path.exists(db_file):
            print(f"  ✅ SQLite 資料庫文件存在: {db_file}")
            
            # 嘗試訪問需要資料庫的頁面
            response = requests.get("http://127.0.0.1:8000/admin/", timeout=5)
            if response.status_code in [200, 302]:
                print("  ✅ 資料庫連接正常")
                return True
            else:
                print(f"  ❌ 資料庫連接異常: {response.status_code}")
                return False
        else:
            print(f"  ❌ 資料庫文件不存在: {db_file}")
            return False
    except Exception as e:
        print(f"  ❌ 資料庫測試失敗: {str(e)}")
        return False

def test_static_files():
    """測試靜態文件"""
    print("\n🎨 測試靜態文件...")
    
    static_files = [
        "http://127.0.0.1:8000/static/css/style.css",
        "http://127.0.0.1:8000/static/js/main.js"
    ]
    
    # 檢查首頁是否包含CSS和JS
    try:
        response = requests.get("http://127.0.0.1:8000/", timeout=5)
        if response.status_code == 200:
            content = response.text
            
            # 檢查Bootstrap CSS
            if "bootstrap" in content.lower():
                print("  ✅ Bootstrap CSS 已載入")
            else:
                print("  ⚠️ Bootstrap CSS 可能未載入")
            
            # 檢查Font Awesome
            if "font-awesome" in content.lower() or "fas fa-" in content:
                print("  ✅ Font Awesome 已載入")
            else:
                print("  ⚠️ Font Awesome 可能未載入")
            
            # 檢查jQuery
            if "jquery" in content.lower():
                print("  ✅ jQuery 已載入")
            else:
                print("  ⚠️ jQuery 可能未載入")
            
            return True
        else:
            print("  ❌ 無法檢查靜態文件")
            return False
    except Exception as e:
        print(f"  ❌ 靜態文件測試失敗: {str(e)}")
        return False

def test_performance():
    """測試網站性能"""
    print("\n⚡ 測試網站性能...")
    
    urls = [
        "http://127.0.0.1:8000/",
        "http://127.0.0.1:8000/suppliers/",
        "http://127.0.0.1:8000/dj/popular/"
    ]
    
    total_time = 0
    success_count = 0
    
    for url in urls:
        try:
            start_time = time.time()
            response = requests.get(url, timeout=10)
            end_time = time.time()
            
            response_time = (end_time - start_time) * 1000  # 轉換為毫秒
            
            if response.status_code == 200:
                print(f"  ✅ {url}: {response_time:.0f}ms")
                total_time += response_time
                success_count += 1
            else:
                print(f"  ❌ {url}: 錯誤 {response.status_code}")
        except Exception as e:
            print(f"  ❌ {url}: 異常 - {str(e)}")
    
    if success_count > 0:
        avg_time = total_time / success_count
        print(f"\n  📊 平均響應時間: {avg_time:.0f}ms")
        
        if avg_time < 100:
            print("  🚀 性能優秀！")
        elif avg_time < 500:
            print("  👍 性能良好")
        else:
            print("  ⚠️ 性能需要優化")
        
        return avg_time
    else:
        print("  ❌ 無法測試性能")
        return None

def test_forms():
    """測試表單功能"""
    print("\n📝 測試表單功能...")
    
    try:
        # 測試註冊頁面表單
        response = requests.get("http://127.0.0.1:8000/users/register/", timeout=5)
        if response.status_code == 200:
            soup = BeautifulSoup(response.content, 'html.parser')
            forms = soup.find_all('form')
            
            if forms:
                print(f"  ✅ 註冊頁面表單正常 (找到 {len(forms)} 個表單)")
                
                # 檢查CSRF token
                csrf_token = soup.find('input', {'name': 'csrfmiddlewaretoken'})
                if csrf_token:
                    print("  ✅ CSRF 保護已啟用")
                else:
                    print("  ⚠️ CSRF 保護可能未啟用")
            else:
                print("  ❌ 註冊頁面表單異常")
        else:
            print(f"  ❌ 無法訪問註冊頁面: {response.status_code}")
        
        # 測試登入頁面表單
        response = requests.get("http://127.0.0.1:8000/accounts/login/", timeout=5)
        if response.status_code == 200:
            soup = BeautifulSoup(response.content, 'html.parser')
            forms = soup.find_all('form')
            
            if forms:
                print(f"  ✅ 登入頁面表單正常 (找到 {len(forms)} 個表單)")
            else:
                print("  ❌ 登入頁面表單異常")
        else:
            print(f"  ❌ 無法訪問登入頁面: {response.status_code}")
        
        return True
    except Exception as e:
        print(f"  ❌ 表單測試失敗: {str(e)}")
        return False

def check_migrations():
    """檢查資料庫遷移狀態"""
    print("\n🔄 檢查資料庫遷移狀態...")
    
    try:
        # 這裡我們無法直接運行 Django 命令，所以檢查關鍵表是否存在
        response = requests.get("http://127.0.0.1:8000/admin/", timeout=5)
        if response.status_code in [200, 302]:
            print("  ✅ 基本表結構正常")
            return True
        else:
            print("  ❌ 表結構可能有問題")
            return False
    except Exception as e:
        print(f"  ❌ 遷移檢查失敗: {str(e)}")
        return False

def generate_test_report():
    """生成測試報告"""
    print("\n" + "="*60)
    print("📋 本地開發環境測試報告")
    print("="*60)
    print(f"⏰ 測試時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # 執行所有測試
    test_results = {}
    
    test_results['server'] = test_server_connection()
    if not test_results['server']:
        print("\n❌ 服務器未啟動，無法繼續測試")
        return
    
    test_results['pages'] = test_main_pages()
    test_results['database'] = test_database_connection()
    test_results['static'] = test_static_files()
    test_results['performance'] = test_performance()
    test_results['forms'] = test_forms()
    test_results['migrations'] = check_migrations()
    
    # 統計結果
    print("\n" + "="*60)
    print("📊 測試結果總結")
    print("="*60)
    
    if test_results['server']:
        print("✅ 服務器連接: 正常")
    else:
        print("❌ 服務器連接: 異常")
    
    if test_results['database']:
        print("✅ 資料庫連接: 正常")
    else:
        print("❌ 資料庫連接: 異常")
    
    if test_results['static']:
        print("✅ 靜態文件: 正常")
    else:
        print("❌ 靜態文件: 異常")
    
    if test_results['forms']:
        print("✅ 表單功能: 正常")
    else:
        print("❌ 表單功能: 異常")
    
    if test_results['migrations']:
        print("✅ 資料庫遷移: 正常")
    else:
        print("❌ 資料庫遷移: 異常")
    
    # 頁面測試結果
    print("\n📄 頁面測試結果:")
    if isinstance(test_results['pages'], dict):
        for page, status in test_results['pages'].items():
            print(f"  {page}: {status}")
    
    # 性能測試結果
    if test_results['performance']:
        print(f"\n⚡ 平均響應時間: {test_results['performance']:.0f}ms")
    
    print("\n" + "="*60)
    print("🎯 建議")
    print("="*60)
    
    print("✅ 本地開發環境已準備就緒！")
    print("🌐 訪問網址: http://127.0.0.1:8000/")
    print("⚙️ 管理後台: http://127.0.0.1:8000/admin/")
    print("📱 測試響應式設計: 使用瀏覽器開發者工具")
    print("🔧 如需創建管理員: python manage.py createsuperuser")
    
    print(f"\n⏰ 測試完成時間: {datetime.now().strftime('%H:%M:%S')}")

if __name__ == "__main__":
    print("🚀 PAPA COLLEGE - 本地開發環境測試")
    print("="*60)
    
    try:
        generate_test_report()
    except KeyboardInterrupt:
        print("\n⏹️ 用戶中斷測試")
    except Exception as e:
        print(f"\n❌ 測試過程中發生錯誤: {str(e)}")
