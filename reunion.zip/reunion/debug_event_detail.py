#!/usr/bin/env python
"""
診斷活動詳情頁面404錯誤
"""
import os
import django
import sys

# 設置Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from events.models import Event, EventType
from django.contrib.auth.models import User

def debug_event_detail():
    """診斷活動詳情問題"""
    print("🔍 診斷活動詳情頁面...")
    
    try:
        # 1. 檢查Event資料
        print("\n1. 檢查Event資料:")
        total_events = Event.objects.count()
        approved_events = Event.objects.filter(status='approved').count()
        pending_events = Event.objects.filter(status='pending').count()
        
        print(f"   總活動數: {total_events}")
        print(f"   已審核活動數: {approved_events}")
        print(f"   待審核活動數: {pending_events}")
        
        # 顯示前5個活動的詳情
        events = Event.objects.all()[:5]
        for event in events:
            print(f"   - ID {event.id}: {event.title} (狀態: {event.status})")
        
        # 2. 檢查URL路徑
        print("\n2. 檢查URL路徑:")
        if approved_events > 0:
            test_event = Event.objects.filter(status='approved').first()
            print(f"   測試URL: /events/{test_event.id}/")
            print(f"   活動標題: {test_event.title}")
        else:
            print("   ❌ 沒有已審核的活動可供測試")
        
        # 3. 檢查EventType資料
        print("\n3. 檢查EventType資料:")
        event_types = EventType.objects.count()
        print(f"   活動類型數量: {event_types}")
        
        # 4. 檢查User資料
        print("\n4. 檢查User資料:")
        users = User.objects.count()
        print(f"   用戶數量: {users}")
        
        # 5. 嘗試創建測試活動（如果沒有）
        if total_events == 0:
            print("\n5. 創建測試活動:")
            try:
                # 檢查是否有EventType
                event_type = EventType.objects.first()
                if not event_type:
                    event_type = EventType.objects.create(name="測試活動類型")
                    print(f"   創建活動類型: {event_type.name}")
                
                # 檢查是否有User
                user = User.objects.first()
                if not user:
                    user = User.objects.create_user(
                        username='testuser',
                        email='test@example.com',
                        password='testpass123'
                    )
                    print(f"   創建測試用戶: {user.username}")
                
                # 創建測試活動
                from datetime import datetime, timedelta
                test_event = Event.objects.create(
                    title="測試活動需求",
                    description="這是一個測試活動需求",
                    event_type=event_type,
                    organizer=user,
                    event_date=datetime.now() + timedelta(days=7),
                    location="台北市",
                    expected_attendees=50,
                    budget_min=10000,
                    budget_max=50000,
                    requirements="需要音響設備",
                    contact_person="測試聯絡人",
                    contact_phone="0912345678",
                    contact_email="contact@test.com",
                    status='approved'  # 設為已審核
                )
                print(f"   ✅ 創建測試活動: {test_event.title} (ID: {test_event.id})")
                print(f"   測試URL: /events/{test_event.id}/")
                
            except Exception as e:
                print(f"   ❌ 創建測試活動失敗: {e}")
        
        print("\n✅ 診斷完成")
        
    except Exception as e:
        print(f"❌ 診斷失敗: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    debug_event_detail()
