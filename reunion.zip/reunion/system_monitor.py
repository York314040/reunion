#!/usr/bin/env python
"""
實時系統監控和通知系統
提供系統健康監控、性能追蹤和智能通知
"""

import os
import sys
import time
import json
from datetime import datetime, timedelta
from typing import Dict, Any, List

# 條件導入可選模組
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

try:
    import smtplib
    from email.mime.text import MimeText
    from email.mime.multipart import MimeMultipart
    EMAIL_AVAILABLE = True
except ImportError:
    EMAIL_AVAILABLE = False

# 設定 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')

import django
django.setup()

from django.db import connection
from django.core.cache import cache


class SystemMonitor:
    """系統監控器"""
    
    def __init__(self):
        self.monitoring_data = []
        self.alert_thresholds = {
            'cpu_percent': 80.0,
            'memory_percent': 85.0,
            'disk_percent': 90.0,
            'response_time': 2.0,  # 秒
            'error_rate': 5.0      # 百分比
        }
        
    def get_system_metrics(self) -> Dict[str, Any]:
        """獲取系統指標"""
        if not PSUTIL_AVAILABLE:
            return {
                'error': 'psutil 模組不可用',
                'timestamp': datetime.now().isoformat(),
                'cpu_percent': 0,
                'memory_percent': 0,
                'disk_percent': 0
            }
        
        try:
            # CPU 使用率
            cpu_percent = psutil.cpu_percent(interval=1)
            
            # 內存使用率
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            
            # 磁盤使用率
            disk = psutil.disk_usage('/')
            disk_percent = disk.percent
            
            # 網絡統計
            network = psutil.net_io_counters()
            
            # 進程數
            process_count = len(psutil.pids())
            
            return {
                'timestamp': datetime.now().isoformat(),
                'cpu_percent': cpu_percent,
                'memory_percent': memory_percent,
                'memory_total_gb': round(memory.total / (1024**3), 2),
                'memory_used_gb': round(memory.used / (1024**3), 2),
                'disk_percent': disk_percent,
                'disk_total_gb': round(disk.total / (1024**3), 2),
                'disk_used_gb': round(disk.used / (1024**3), 2),
                'network_sent_mb': round(network.bytes_sent / (1024**2), 2),
                'network_recv_mb': round(network.bytes_recv / (1024**2), 2),
                'process_count': process_count
            }
            
        except Exception as e:
            return {'error': str(e), 'timestamp': datetime.now().isoformat()}
    
    def get_django_metrics(self) -> Dict[str, Any]:
        """獲取 Django 應用指標"""
        try:
            from django.contrib.auth.models import User
            from events.models import Event
            from suppliers.models import SupplierProfile
            from dj_management.models import DJProfile
            from messaging.models import Conversation
            
            # 數據庫連接測試
            start_time = time.time()
            with connection.cursor() as cursor:
                cursor.execute("SELECT 1")
                cursor.fetchone()
            db_response_time = time.time() - start_time
            
            # 用戶統計
            user_count = User.objects.count()
            active_users = User.objects.filter(last_login__gte=datetime.now() - timedelta(days=30)).count()
            
            # 內容統計
            event_count = Event.objects.count()
            supplier_count = SupplierProfile.objects.count()
            dj_count = DJProfile.objects.count()
            conversation_count = Conversation.objects.count()
            
            # 今日新增統計
            today = datetime.now().date()
            today_events = Event.objects.filter(created_at__date=today).count()
            today_conversations = Conversation.objects.filter(created_at__date=today).count()
            
            return {
                'timestamp': datetime.now().isoformat(),
                'database_response_time': round(db_response_time, 3),
                'users': {
                    'total': user_count,
                    'active_30d': active_users,
                    'active_rate': round((active_users / user_count * 100) if user_count > 0 else 0, 2)
                },
                'content': {
                    'events': event_count,
                    'suppliers': supplier_count,
                    'djs': dj_count,
                    'conversations': conversation_count
                },
                'today_activity': {
                    'new_events': today_events,
                    'new_conversations': today_conversations
                }
            }
            
        except Exception as e:
            return {'error': str(e), 'timestamp': datetime.now().isoformat()}
    
    def test_application_health(self) -> Dict[str, Any]:
        """測試應用健康狀況"""
        try:
            from django.test import Client
            
            client = Client()
            test_results = {}
            
            # 測試關鍵頁面
            test_pages = {
                'home': '/',
                'events': '/events/',
                'suppliers': '/suppliers/',
                'dj_list': '/dj/',
                'admin': '/admin/'
            }
            
            for name, url in test_pages.items():
                start_time = time.time()
                try:
                    response = client.get(url)
                    response_time = time.time() - start_time
                    
                    test_results[name] = {
                        'status_code': response.status_code,
                        'response_time': round(response_time, 3),
                        'success': response.status_code in [200, 302, 401]  # 401 for admin is OK
                    }
                except Exception as e:
                    test_results[name] = {
                        'error': str(e),
                        'success': False,
                        'response_time': time.time() - start_time
                    }
            
            # 計算整體健康分數
            successful_tests = sum(1 for result in test_results.values() if result.get('success', False))
            health_score = (successful_tests / len(test_pages)) * 100
            
            return {
                'timestamp': datetime.now().isoformat(),
                'test_results': test_results,
                'health_score': round(health_score, 2),
                'status': 'healthy' if health_score >= 80 else 'degraded' if health_score >= 60 else 'unhealthy'
            }
            
        except Exception as e:
            return {'error': str(e), 'timestamp': datetime.now().isoformat()}
    
    def check_alerts(self, metrics: Dict[str, Any]) -> List[Dict[str, Any]]:
        """檢查告警條件"""
        alerts = []
        
        # CPU 告警
        if 'cpu_percent' in metrics and metrics['cpu_percent'] > self.alert_thresholds['cpu_percent']:
            alerts.append({
                'type': 'cpu_high',
                'severity': 'warning',
                'message': f"CPU使用率過高: {metrics['cpu_percent']:.1f}%",
                'value': metrics['cpu_percent'],
                'threshold': self.alert_thresholds['cpu_percent']
            })
        
        # 內存告警
        if 'memory_percent' in metrics and metrics['memory_percent'] > self.alert_thresholds['memory_percent']:
            alerts.append({
                'type': 'memory_high',
                'severity': 'warning',
                'message': f"內存使用率過高: {metrics['memory_percent']:.1f}%",
                'value': metrics['memory_percent'],
                'threshold': self.alert_thresholds['memory_percent']
            })
        
        # 磁盤告警
        if 'disk_percent' in metrics and metrics['disk_percent'] > self.alert_thresholds['disk_percent']:
            alerts.append({
                'type': 'disk_high',
                'severity': 'critical',
                'message': f"磁盤使用率過高: {metrics['disk_percent']:.1f}%",
                'value': metrics['disk_percent'],
                'threshold': self.alert_thresholds['disk_percent']
            })
        
        return alerts
    
    def save_monitoring_data(self, data: Dict[str, Any]):
        """保存監控數據"""
        try:
            # 保存到文件
            monitoring_file = 'monitoring_data.json'
            
            if os.path.exists(monitoring_file):
                with open(monitoring_file, 'r', encoding='utf-8') as f:
                    monitoring_history = json.load(f)
            else:
                monitoring_history = []
            
            monitoring_history.append(data)
            
            # 保持最近1000條記錄
            monitoring_history = monitoring_history[-1000:]
            
            with open(monitoring_file, 'w', encoding='utf-8') as f:
                json.dump(monitoring_history, f, ensure_ascii=False, indent=2)
                
        except Exception as e:
            print(f"保存監控數據失敗: {str(e)}")
    
    def generate_monitoring_report(self) -> Dict[str, Any]:
        """生成監控報告"""
        print("📊 生成系統監控報告...")
        
        # 獲取系統指標
        system_metrics = self.get_system_metrics()
        
        # 獲取 Django 指標
        django_metrics = self.get_django_metrics()
        
        # 獲取應用健康狀況
        health_check = self.test_application_health()
        
        # 檢查告警
        alerts = self.check_alerts(system_metrics)
        
        report = {
            'report_time': datetime.now().isoformat(),
            'system_metrics': system_metrics,
            'django_metrics': django_metrics,
            'health_check': health_check,
            'alerts': alerts,
            'summary': {
                'overall_status': 'healthy' if not alerts else 'warning' if any(a['severity'] == 'warning' for a in alerts) else 'critical',
                'alert_count': len(alerts),
                'health_score': health_check.get('health_score', 0)
            }
        }
        
        # 保存監控數據
        self.save_monitoring_data(report)
        
        return report
    
    def run_continuous_monitoring(self, interval_minutes: int = 5):
        """運行連續監控"""
        print(f"🔄 開始連續監控 (間隔: {interval_minutes} 分鐘)")
        print("按 Ctrl+C 停止監控")
        
        try:
            while True:
                # 生成報告
                report = self.generate_monitoring_report()
                
                # 顯示摘要
                status = report['summary']['overall_status']
                health_score = report['summary']['health_score']
                alert_count = report['summary']['alert_count']
                
                print(f"\n[{datetime.now().strftime('%H:%M:%S')}] "
                      f"狀態: {status} | "
                      f"健康分數: {health_score:.1f}% | "
                      f"告警: {alert_count}")
                
                # 如果有告警，顯示詳情
                if alert_count > 0:
                    for alert in report['alerts']:
                        print(f"  ⚠️ {alert['message']}")
                
                # 等待下次檢查
                time.sleep(interval_minutes * 60)
                
        except KeyboardInterrupt:
            print("\n📊 監控已停止")


class NotificationManager:
    """通知管理器"""
    
    def __init__(self):
        self.notification_settings = {
            'email_enabled': False,
            'email_smtp_server': 'smtp.gmail.com',
            'email_smtp_port': 587,
            'email_username': '',
            'email_password': '',
            'email_recipients': []
        }
    
    def send_email_alert(self, subject: str, message: str, recipients: List[str] = None) -> bool:
        """發送郵件告警"""
        if not EMAIL_AVAILABLE:
            print("📧 郵件模組不可用")
            return False
            
        if not self.notification_settings['email_enabled']:
            print("📧 郵件通知未啟用")
            return False
        
        try:
            recipients = recipients or self.notification_settings['email_recipients']
            if not recipients:
                print("📧 沒有設置收件人")
                return False
            
            # 創建郵件
            msg = MimeMultipart()
            msg['From'] = self.notification_settings['email_username']
            msg['To'] = ', '.join(recipients)
            msg['Subject'] = f"[PAPA COLLEGE 系統告警] {subject}"
            
            # 郵件內容
            body = f"""
系統告警通知

{message}

告警時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
系統: PAPA COLLEGE B2B聚會派對媒合平台

請及時檢查系統狀況。
"""
            
            msg.attach(MimeText(body, 'plain', 'utf-8'))
            
            # 發送郵件
            server = smtplib.SMTP(self.notification_settings['email_smtp_server'], 
                                self.notification_settings['email_smtp_port'])
            server.starttls()
            server.login(self.notification_settings['email_username'], 
                        self.notification_settings['email_password'])
            
            text = msg.as_string()
            server.sendmail(self.notification_settings['email_username'], recipients, text)
            server.quit()
            
            print(f"📧 告警郵件已發送給: {', '.join(recipients)}")
            return True
            
        except Exception as e:
            print(f"📧 發送郵件失敗: {str(e)}")
            return False
    
    def send_system_report(self, report: Dict[str, Any]):
        """發送系統報告"""
        if report['summary']['alert_count'] > 0:
            # 有告警時發送通知
            alert_messages = [alert['message'] for alert in report['alerts']]
            message = "檢測到以下系統告警:\n\n" + "\n".join(f"• {msg}" for msg in alert_messages)
            
            self.send_email_alert("系統告警", message)


def main():
    """主函數"""
    import argparse
    
    parser = argparse.ArgumentParser(description='系統監控工具')
    parser.add_argument('action', choices=['report', 'monitor'], 
                       help='執行的操作')
    parser.add_argument('--interval', type=int, default=5,
                       help='監控間隔 (分鐘)')
    
    args = parser.parse_args()
    
    monitor = SystemMonitor()
    
    if args.action == 'report':
        report = monitor.generate_monitoring_report()
        
        print("\n📊 系統監控報告")
        print("="*50)
        
        # 系統指標
        if 'system_metrics' in report and 'error' not in report['system_metrics']:
            metrics = report['system_metrics']
            print(f"\n💻 系統指標:")
            print(f"  • CPU: {metrics['cpu_percent']:.1f}%")
            print(f"  • 內存: {metrics['memory_percent']:.1f}% ({metrics['memory_used_gb']:.1f}GB / {metrics['memory_total_gb']:.1f}GB)")
            print(f"  • 磁盤: {metrics['disk_percent']:.1f}% ({metrics['disk_used_gb']:.1f}GB / {metrics['disk_total_gb']:.1f}GB)")
            print(f"  • 進程數: {metrics['process_count']}")
        
        # Django 指標
        if 'django_metrics' in report and 'error' not in report['django_metrics']:
            django = report['django_metrics']
            print(f"\n🐍 Django 指標:")
            print(f"  • 數據庫響應時間: {django['database_response_time']:.3f}s")
            print(f"  • 用戶總數: {django['users']['total']}")
            print(f"  • 活躍用戶: {django['users']['active_30d']} ({django['users']['active_rate']:.1f}%)")
            print(f"  • 今日新活動: {django['today_activity']['new_events']}")
        
        # 健康檢查
        if 'health_check' in report and 'error' not in report['health_check']:
            health = report['health_check']
            print(f"\n❤️ 健康檢查:")
            print(f"  • 健康分數: {health['health_score']:.1f}%")
            print(f"  • 狀態: {health['status']}")
        
        # 告警
        if report['alerts']:
            print(f"\n⚠️ 告警 ({len(report['alerts'])} 個):")
            for alert in report['alerts']:
                print(f"  • {alert['message']}")
        else:
            print(f"\n✅ 無告警")
        
        print(f"\n📊 整體狀態: {report['summary']['overall_status'].upper()}")
        
    elif args.action == 'monitor':
        monitor.run_continuous_monitoring(args.interval)


if __name__ == "__main__":
    main()
