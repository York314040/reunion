#!/usr/bin/env python
"""
測試工程師 - 最終工作版本測試
使用正確的模型字段和方法
"""

import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')

import django
django.setup()

from django.test import Client
from django.contrib.auth.models import User
from events.models import Event, EventType
from suppliers.models import Supplier, ServiceCategory
from messaging.models import Conversation
from dj_management.models import DJ, DJCategory

def final_working_test():
    """最終工作測試"""
    client = Client()
    
    print("🎯 最終工作測試開始")
    
    # 測試關鍵頁面
    test_urls = [
        ('/', '首頁'),
        ('/events/', '活動列表'),
        ('/suppliers/', '供應商列表'),
        ('/dj/', 'DJ列表'),
        ('/messaging/', '訊息系統'),
        ('/admin/', '管理後台')
    ]
    
    passed = 0
    total = len(test_urls)
    
    for url, name in test_urls:
        try:
            response = client.get(url)
            if response.status_code in [200, 302]:
                print(f"✅ {name} - 正常")
                passed += 1
            else:
                print(f"❌ {name} - 狀態碼: {response.status_code}")
        except Exception as e:
            print(f"❌ {name} - 錯誤: {str(e)}")
    
    success_rate = (passed / total * 100)
    print(f"\n📊 測試結果: {passed}/{total} ({success_rate:.1f}%)")
    
    if success_rate >= 90:
        print("🎉 網站運行狀態: 優秀！")
    elif success_rate >= 80:
        print("✅ 網站運行狀態: 良好！")
    else:
        print("⚠️ 網站運行狀態: 需要改進")
    
    return success_rate >= 80

if __name__ == "__main__":
    success = final_working_test()
    print(f"\n{'🎉 測試通過！' if success else '⚠️ 需要進一步修復'}")
