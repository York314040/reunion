#!/usr/bin/env python
"""
全面系統測試腳本 - 測試工程師版本
專門測試 DJ 聚會平台的所有功能和潛在 bug
"""
import os
import sys
import django
import traceback
from datetime import datetime

# 設置 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.contrib.auth.models import User
from django.test import Client
from django.urls import reverse, NoReverseMatch
from django.core.exceptions import ValidationError
from django.db import IntegrityError

class SystemTester:
    def __init__(self):
        self.client = Client()
        self.test_results = []
        self.bugs_found = []
        
    def log_test(self, test_name, result, details=""):
        """記錄測試結果"""
        status = "✅ PASS" if result else "❌ FAIL"
        self.test_results.append({
            'test': test_name,
            'result': result,
            'details': details,
            'timestamp': datetime.now()
        })
        print(f"{status} - {test_name}")
        if details:
            print(f"    詳情: {details}")
        if not result:
            self.bugs_found.append(f"{test_name}: {details}")
    
    def test_user_authentication(self):
        """測試用戶認證系統"""
        print("\n=== 測試用戶認證系統 ===")
        
        # 測試 1: 檢查僅存的用戶
        try:
            users = User.objects.all()
            self.log_test("用戶數量檢查", users.count() == 1, f"當前用戶數: {users.count()}")
            
            york_user = User.objects.filter(username='York').first()
            self.log_test("York 用戶存在", york_user is not None)
            
            if york_user:
                self.log_test("York 超級用戶權限", york_user.is_superuser)
                self.log_test("York 職員權限", york_user.is_staff)
                self.log_test("York 帳號啟用", york_user.is_active)
        except Exception as e:
            self.log_test("用戶基礎檢查", False, str(e))
    
    def test_url_patterns(self):
        """測試所有 URL 路由"""
        print("\n=== 測試 URL 路由 ===")
        
        # 測試主要 URL
        test_urls = [
            ('events:home', {}),
            ('events:event_list', {}),
            ('events:register', {}),
            ('events:login', {}),
            ('events:user_management_new', {}),
        ]
        
        for url_name, kwargs in test_urls:
            try:
                url = reverse(url_name, kwargs=kwargs)
                self.log_test(f"URL 解析: {url_name}", True, f"解析為: {url}")
            except NoReverseMatch as e:
                self.log_test(f"URL 解析: {url_name}", False, str(e))
    
    def test_page_accessibility(self):
        """測試頁面可訪問性"""
        print("\n=== 測試頁面可訪問性 ===")
        
        # 測試公開頁面
        public_pages = [
            ('/', '首頁'),
            ('/events/', '活動列表'),
            ('/events/register/', '註冊頁面'),
            ('/events/login/', '登入頁面'),
        ]
        
        for url, name in public_pages:
            try:
                response = self.client.get(url)
                success = response.status_code in [200, 302]
                self.log_test(f"頁面訪問: {name}", success, f"狀態碼: {response.status_code}")
            except Exception as e:
                self.log_test(f"頁面訪問: {name}", False, str(e))
    
    def test_user_management_system(self):
        """測試用戶管理系統"""
        print("\n=== 測試用戶管理系統 ===")
        
        # 創建測試用戶來驗證系統
        try:
            test_user = User.objects.create_user(
                username='test_user_for_deletion',
                email='test@example.com',
                password='testpass123'
            )
            self.log_test("創建測試用戶", True, f"用戶 ID: {test_user.id}")
            
            # 測試用戶管理頁面（需要超級用戶登入）
            york_user = User.objects.get(username='York')
            
            # 嘗試設定 York 的密碼用於測試
            york_user.set_password('york123')
            york_user.save()
            
            login_success = self.client.login(username='York', password='york123')
            self.log_test("超級用戶登入", login_success)
            
            if login_success:
                # 測試用戶管理頁面
                response = self.client.get('/manage/users/')
                self.log_test("用戶管理頁面訪問", response.status_code == 200, f"狀態碼: {response.status_code}")
                
                # 測試刪除功能
                delete_url = f'/manage/users/{test_user.id}/delete/'
                response = self.client.post(delete_url, {
                    'csrfmiddlewaretoken': self.client.cookies.get('csrftoken', 'test').value
                })
                
                if response.status_code == 200:
                    # 檢查用戶是否被刪除
                    user_exists = User.objects.filter(id=test_user.id).exists()
                    self.log_test("用戶刪除功能", not user_exists, "測試用戶已被刪除")
                else:
                    self.log_test("用戶刪除功能", False, f"刪除請求失敗，狀態碼: {response.status_code}")
            
        except Exception as e:
            self.log_test("用戶管理系統測試", False, str(e))
    
    def test_dj_management_system(self):
        """測試 DJ 管理系統"""
        print("\n=== 測試 DJ 管理系統 ===")
        
        try:
            # 檢查 DJ 管理模型是否正常
            from dj_management.models import DJ, Rating, Booking, Playlist
            
            self.log_test("DJ 模型導入", True)
            
            # 測試創建 DJ
            dj_count_before = DJ.objects.count()
            test_dj = DJ.objects.create(
                name="測試DJ",
                email="testdj@example.com",
                phone="0912345678",
                hourly_rate=2000,
                description="測試DJ描述",
                is_featured=True
            )
            dj_count_after = DJ.objects.count()
            
            self.log_test("創建 DJ", dj_count_after > dj_count_before, f"DJ ID: {test_dj.id}")
            
            # 測試 DJ 頁面
            response = self.client.get('/dj/')
            self.log_test("DJ 列表頁面", response.status_code == 200, f"狀態碼: {response.status_code}")
            
            # 清理測試數據
            test_dj.delete()
            
        except ImportError as e:
            self.log_test("DJ 模組導入", False, f"無法導入 DJ 模組: {e}")
        except Exception as e:
            self.log_test("DJ 管理系統", False, str(e))
    
    def test_database_integrity(self):
        """測試資料庫完整性"""
        print("\n=== 測試資料庫完整性 ===")
        
        try:
            # 測試外鍵約束
            from events.models import Event, EventType
            
            # 檢查是否有活動類型
            event_types = EventType.objects.all()
            self.log_test("活動類型存在", event_types.exists(), f"活動類型數量: {event_types.count()}")
            
            # 測試創建活動（如果有活動類型）
            if event_types.exists():
                event_type = event_types.first()
                york_user = User.objects.get(username='York')
                
                test_event = Event.objects.create(
                    title="測試活動",
                    description="測試活動描述",
                    event_type=event_type,
                    organizer=york_user,
                    budget=10000,
                    location="測試地點"
                )
                self.log_test("創建測試活動", True, f"活動 ID: {test_event.id}")
                
                # 清理測試數據
                test_event.delete()
            
        except Exception as e:
            self.log_test("資料庫完整性", False, str(e))
    
    def test_template_rendering(self):
        """測試模板渲染"""
        print("\n=== 測試模板渲染 ===")
        
        # 測試主要模板
        try:
            response = self.client.get('/')
            self.log_test("首頁模板渲染", response.status_code == 200 and b'<!DOCTYPE html>' in response.content)
            
            response = self.client.get('/events/')
            self.log_test("活動列表模板渲染", response.status_code == 200 and b'<!DOCTYPE html>' in response.content)
            
        except Exception as e:
            self.log_test("模板渲染", False, str(e))
    
    def test_security_measures(self):
        """測試安全措施"""
        print("\n=== 測試安全措施 ===")
        
        try:
            # 測試未授權訪問用戶管理
            self.client.logout()
            response = self.client.get('/manage/users/')
            unauthorized_blocked = response.status_code in [302, 403, 404]
            self.log_test("未授權訪問阻擋", unauthorized_blocked, f"狀態碼: {response.status_code}")
            
            # 測試 CSRF 保護
            response = self.client.post('/manage/users/999/delete/', {})
            csrf_protected = response.status_code in [403, 404]
            self.log_test("CSRF 保護", csrf_protected, f"狀態碼: {response.status_code}")
            
        except Exception as e:
            self.log_test("安全措施", False, str(e))
    
    def run_all_tests(self):
        """執行所有測試"""
        print("🧪 開始全面系統測試...")
        print("=" * 50)
        
        # 執行所有測試
        self.test_user_authentication()
        self.test_url_patterns()
        self.test_page_accessibility()
        self.test_user_management_system()
        self.test_dj_management_system()
        self.test_database_integrity()
        self.test_template_rendering()
        self.test_security_measures()
        
        # 生成測試報告
        self.generate_report()
    
    def generate_report(self):
        """生成測試報告"""
        print("\n" + "=" * 50)
        print("📊 測試報告")
        print("=" * 50)
        
        total_tests = len(self.test_results)
        passed_tests = sum(1 for test in self.test_results if test['result'])
        failed_tests = total_tests - passed_tests
        success_rate = (passed_tests / total_tests * 100) if total_tests > 0 else 0
        
        print(f"總測試數: {total_tests}")
        print(f"通過測試: {passed_tests}")
        print(f"失敗測試: {failed_tests}")
        print(f"成功率: {success_rate:.1f}%")
        
        if self.bugs_found:
            print("\n🐛 發現的 Bug:")
            for i, bug in enumerate(self.bugs_found, 1):
                print(f"{i}. {bug}")
        else:
            print("\n🎉 沒有發現 Bug！")
        
        print("\n📝 詳細測試結果:")
        for test in self.test_results:
            status = "✅" if test['result'] else "❌"
            print(f"{status} {test['test']}")
            if test['details']:
                print(f"    {test['details']}")

if __name__ == "__main__":
    tester = SystemTester()
    tester.run_all_tests()
