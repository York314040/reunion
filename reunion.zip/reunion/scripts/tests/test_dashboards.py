#!/usr/bin/env python
"""
儀表板系統測試腳本
測試所有儀表板功能的安全性、性能和錯誤處理
"""
import os
import sys
import django

# Django 設置
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User
from django.core.exceptions import PermissionDenied
from dj_management.models import DJ
from suppliers.models import Supplier
from events.models import Event


def test_dashboard_security():
    """測試儀表板安全性"""
    print("🔒 測試儀表板安全性...")
    
    client = Client()
    
    # 測試未登入用戶訪問
    dashboard_urls = [
        '/dashboard/',
        '/dashboard/dj/',
        '/dashboard/supplier/',
        '/dashboard/client/',
        '/dashboard/admin/',
        '/dashboard/staff/',
    ]
    
    for url in dashboard_urls:
        response = client.get(url)
        if response.status_code != 302:  # 應該重定向到登入頁面
            print(f"❌ 安全性問題: {url} 允許未登入訪問")
        else:
            print(f"✅ {url} 正確拒絕未登入訪問")
    
    print("✅ 安全性測試完成")


def test_dashboard_performance():
    """測試儀表板性能"""
    print("⚡ 測試儀表板性能...")
    
    try:
        # 檢查是否有 N+1 查詢問題的提示
        from django.db import connection
        from django.test.utils import override_settings
        
        # 創建測試用戶
        user = User.objects.create_user(
            username='test_performance',
            password='testpass123',
            email='test@example.com'
        )
        
        client = Client()
        client.login(username='test_performance', password='testpass123')
        
        # 測試客戶儀表板
        with override_settings(DEBUG=True):
            connection.queries_log.clear()
            response = client.get('/dashboard/client/')
            query_count = len(connection.queries)
            
            if query_count > 20:
                print(f"⚠️  客戶儀表板查詢數量過多: {query_count} 次")
            else:
                print(f"✅ 客戶儀表板查詢優化良好: {query_count} 次")
        
        # 清理測試數據
        user.delete()
        
    except Exception as e:
        print(f"⚠️  性能測試時發生錯誤: {str(e)}")
    
    print("✅ 性能測試完成")


def test_error_handling():
    """測試錯誤處理"""
    print("🛡️  測試錯誤處理...")
    
    try:
        # 測試不存在的 DJ 用戶訪問 DJ 儀表板
        user = User.objects.create_user(
            username='test_error',
            password='testpass123',
            email='error@example.com'
        )
        
        client = Client()
        client.login(username='test_error', password='testpass123')
        
        response = client.get('/dashboard/dj/')
        if response.status_code == 302:  # 應該重定向
            print("✅ DJ 儀表板正確處理非 DJ 用戶訪問")
        else:
            print("❌ DJ 儀表板錯誤處理有問題")
        
        # 清理測試數據
        user.delete()
        
    except Exception as e:
        print(f"⚠️  錯誤處理測試時發生錯誤: {str(e)}")
    
    print("✅ 錯誤處理測試完成")


def test_template_rendering():
    """測試模板渲染"""
    print("🎨 測試模板渲染...")
    
    try:
        # 創建超級用戶測試管理員儀表板
        admin_user = User.objects.create_superuser(
            username='test_admin',
            password='testpass123',
            email='admin@example.com'
        )
        
        client = Client()
        client.login(username='test_admin', password='testpass123')
        
        response = client.get('/dashboard/admin/')
        if response.status_code == 200:
            print("✅ 管理員儀表板模板渲染成功")
            
            # 檢查關鍵元素
            content = response.content.decode()
            if '管理員控制台' in content:
                print("✅ 管理員儀表板標題正確")
            if 'fas fa-shield-alt' in content:
                print("✅ 管理員儀表板圖標正確")
                
        else:
            print(f"❌ 管理員儀表板渲染失敗: {response.status_code}")
        
        # 清理測試數據
        admin_user.delete()
        
    except Exception as e:
        print(f"⚠️  模板渲染測試時發生錯誤: {str(e)}")
    
    print("✅ 模板渲染測試完成")


def run_comprehensive_test():
    """運行全面測試"""
    print("🧪 開始儀表板系統全面測試")
    print("=" * 50)
    
    test_dashboard_security()
    print()
    
    test_dashboard_performance()
    print()
    
    test_error_handling()
    print()
    
    test_template_rendering()
    print()
    
    print("=" * 50)
    print("🎉 儀表板系統測試完成！")
    
    # 檢查系統狀態
    print("\n📊 系統狀態檢查:")
    print(f"總用戶數: {User.objects.count()}")
    print(f"DJ 數量: {DJ.objects.count()}")
    print(f"供應商數量: {Supplier.objects.count()}")
    print(f"活動數量: {Event.objects.count()}")


if __name__ == '__main__':
    run_comprehensive_test()
