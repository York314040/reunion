#!/usr/bin/env python
"""
直接測試刪除功能和頁面渲染
"""
import os
import sys
import django

# 設置 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.template.loader import render_to_string
from django.template import Context, Template

def test_direct_delete():
    """直接測試刪除功能"""
    
    print("=== 直接測試刪除功能 ===\n")
    
    # 1. 確保有測試用戶
    if not User.objects.filter(username='test_direct_delete').exists():
        test_user = User.objects.create_user(
            username='test_direct_delete',
            email='test_direct@example.com',
            password='testpass'
        )
        print(f"✅ 創建測試用戶: {test_user.username}")
    else:
        test_user = User.objects.get(username='test_direct_delete')
        print(f"✅ 使用現有測試用戶: {test_user.username}")
    
    # 2. 登入超級用戶並測試刪除
    client = Client()
    superuser = User.objects.filter(is_superuser=True).first()
    login_success = client.login(username=superuser.username, password='123456')
    
    if login_success:
        print("✅ 超級用戶登入成功")
        
        # 3. 直接測試刪除API
        delete_url = f'/manage/users/{test_user.id}/delete/'
        response = client.post(delete_url, 
            data={'csrfmiddlewaretoken': 'test'},
            HTTP_X_REQUESTED_WITH='XMLHttpRequest'
        )
        
        print(f"刪除請求 URL: {delete_url}")
        print(f"響應狀態: {response.status_code}")
        
        if response.status_code == 200:
            import json
            try:
                result = json.loads(response.content.decode())
                print(f"響應內容: {result}")
                
                if result.get('success'):
                    print("✅ 刪除成功！")
                else:
                    print(f"❌ 刪除失敗: {result.get('error', '未知錯誤')}")
            except json.JSONDecodeError:
                print(f"❌ 響應不是JSON: {response.content.decode()}")
        else:
            print(f"❌ 請求失敗，狀態碼: {response.status_code}")
            print(f"響應內容: {response.content.decode()[:500]}")
    else:
        print("❌ 登入失敗")

if __name__ == "__main__":
    test_direct_delete()
