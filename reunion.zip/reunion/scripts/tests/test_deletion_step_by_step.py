#!/usr/bin/env python
"""
逐步測試用戶刪除功能
"""
import os
import sys
import django
from django.conf import settings

# 設置 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
import json

def test_user_deletion():
    """測試用戶刪除功能"""
    
    print("=== 逐步測試用戶刪除功能 ===\n")
    
    # 1. 檢查超級用戶
    print("1. 檢查超級用戶...")
    superuser = User.objects.filter(is_superuser=True).first()
    if superuser:
        print(f"   ✅ 超級用戶: {superuser.username} (ID: {superuser.id})")
    else:
        print("   ❌ 未找到超級用戶")
        return
    
    # 2. 檢查要刪除的用戶
    print("\n2. 檢查要刪除的用戶...")
    regular_users = User.objects.filter(is_superuser=False, is_staff=False)
    print(f"   找到 {regular_users.count()} 個一般用戶:")
    for user in regular_users:
        print(f"   - {user.username} (ID: {user.id}, Email: {user.email})")
    
    if regular_users.count() == 0:
        print("   ⚠️ 沒有一般用戶可以刪除，創建測試用戶...")
        test_user = User.objects.create_user(
            username='test_deletion_user',
            email='deletion_test@example.com',
            password='testpass'
        )
        print(f"   ✅ 創建測試用戶: {test_user.username} (ID: {test_user.id})")
        target_user = test_user
    else:
        target_user = regular_users.first()
    
    # 3. 測試登入超級用戶
    print(f"\n3. 測試超級用戶登入...")
    client = Client()
    login_success = client.login(username=superuser.username, password='123456')
    if login_success:
        print("   ✅ 超級用戶登入成功")
    else:
        print("   ❌ 超級用戶登入失敗")
        return
    
    # 4. 測試訪問用戶管理頁面
    print(f"\n4. 測試用戶管理頁面訪問...")
    response = client.get('/manage/users/')
    if response.status_code == 200:
        print("   ✅ 用戶管理頁面訪問成功")
        if f'id="user-{target_user.id}"' in response.content.decode():
            print(f"   ✅ 頁面包含目標用戶 {target_user.username}")
        else:
            print(f"   ⚠️ 頁面未包含目標用戶 {target_user.username}")
    else:
        print(f"   ❌ 用戶管理頁面訪問失敗 (狀態碼: {response.status_code})")
        return
    
    # 5. 測試刪除用戶的 AJAX 請求
    print(f"\n5. 測試刪除用戶 AJAX 請求...")
    delete_url = f'/manage/users/{target_user.id}/delete/'
    
    # 先獲取CSRF token
    csrf_response = client.get('/manage/users/')
    csrf_token = None
    if 'csrfmiddlewaretoken' in csrf_response.content.decode():
        import re
        match = re.search(r'name="csrfmiddlewaretoken" value="([^"]*)"', csrf_response.content.decode())
        if match:
            csrf_token = match.group(1)
    
    # 設置 AJAX 標頭和 CSRF token
    headers = {
        'HTTP_X_REQUESTED_WITH': 'XMLHttpRequest',
        'HTTP_X_CSRFTOKEN': csrf_token or '',
    }
    
    data = {}
    if csrf_token:
        data['csrfmiddlewaretoken'] = csrf_token
    
    response = client.post(delete_url, data=data, **headers)
    
    print(f"   請求 URL: {delete_url}")
    print(f"   響應狀態碼: {response.status_code}")
    
    if response.status_code == 200:
        try:
            result = json.loads(response.content.decode())
            if result.get('success'):
                print("   ✅ 刪除請求成功")
                print(f"   訊息: {result.get('message', '無訊息')}")
                
                # 檢查用戶是否真的被刪除
                if not User.objects.filter(id=target_user.id).exists():
                    print("   ✅ 用戶已從數據庫中刪除")
                else:
                    print("   ⚠️ 用戶仍存在於數據庫中")
            else:
                print("   ❌ 刪除請求失敗")
                print(f"   錯誤: {result.get('error', '未知錯誤')}")
        except json.JSONDecodeError:
            print("   ❌ 響應不是有效的 JSON")
            print(f"   響應內容: {response.content.decode()[:200]}...")
    else:
        print(f"   ❌ 刪除請求失敗 (狀態碼: {response.status_code})")
    
    # 6. 檢查最終狀態
    print(f"\n6. 檢查最終用戶狀態...")
    remaining_users = User.objects.filter(is_superuser=False, is_staff=False)
    print(f"   剩餘一般用戶數量: {remaining_users.count()}")
    for user in remaining_users:
        print(f"   - {user.username} (ID: {user.id})")

if __name__ == "__main__":
    test_user_deletion()
