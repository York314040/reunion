#!/usr/bin/env python
"""
超級用戶全面系統測試腳本
執行全方位的系統檢測，找出問題並自動修復
"""

import os
import sys
import json
import time
from io import StringIO

# 設定 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')

import django
django.setup()

from django.conf import settings
from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
from django.core.management import call_command
from django.db import connection

from events.models import Event, EventType
from suppliers.models import Supplier, ServiceCategory
from messaging.models import Conversation, Message
from dj_management.models import DJ

class SuperUserSystemTest:
    """超級用戶系統測試類"""
    
    def __init__(self):
        self.client = Client()
        self.issues = []
        self.fixes_applied = []
        
    def print_header(self, title):
        """打印測試標題"""
        print(f"\n{'='*60}")
        print(f"🔥 {title}")
        print(f"{'='*60}")
    
    def print_status(self, message, status="INFO"):
        """打印狀態信息"""
        icons = {"INFO": "ℹ️", "SUCCESS": "✅", "ERROR": "❌", "WARNING": "⚠️", "FIX": "🔧"}
        print(f"{icons.get(status, 'ℹ️')} {message}")
    
    def test_database_integrity(self):
        """測試數據庫完整性"""
        self.print_header("數據庫完整性檢測")
        
        try:
            # 檢查數據庫連接
            with connection.cursor() as cursor:
                cursor.execute("SELECT 1")
                self.print_status("數據庫連接正常", "SUCCESS")
                
            # 檢查所有模型的完整性
            models_to_check = [User, Event, EventType, Supplier, ServiceCategory, 
                             Conversation, Message, DJ]
            
            for model in models_to_check:
                try:
                    count = model.objects.count()
                    self.print_status(f"{model.__name__}: {count} 筆記錄", "SUCCESS")
                except Exception as e:
                    self.print_status(f"{model.__name__}: 錯誤 - {str(e)}", "ERROR")
                    self.issues.append(f"模型 {model.__name__} 有問題: {str(e)}")
                    
        except Exception as e:
            self.print_status(f"數據庫檢測失敗: {str(e)}", "ERROR")
            self.issues.append(f"數據庫連接問題: {str(e)}")
    
    def test_admin_panel(self):
        """測試管理後台"""
        self.print_header("管理後台測試")
        
        try:
            # 創建或獲取超級用戶
            admin_user, created = User.objects.get_or_create(
                username='admin_test',
                defaults={
                    'email': 'admin@test.com',
                    'is_staff': True,
                    'is_superuser': True,
                    'first_name': 'Admin',
                }
            )
            if created:
                admin_user.set_password('admin123456')
                admin_user.save()
                self.print_status("創建測試超級用戶", "SUCCESS")
            
            # 登入管理後台
            login_success = self.client.login(username='admin_test', password='admin123456')
            if login_success:
                self.print_status("管理員登入成功", "SUCCESS")
            else:
                self.print_status("管理員登入失敗", "ERROR")
                self.issues.append("無法登入管理後台")
                return
                
            # 測試管理後台主要頁面
            admin_urls = [
                '/admin/',
                '/admin/auth/user/',
                '/admin/events/event/',
                '/admin/suppliers/supplier/',
                '/admin/messaging/conversation/',
                '/admin/dj_management/dj/',
            ]
            
            for url in admin_urls:
                try:
                    response = self.client.get(url)
                    if response.status_code == 200:
                        self.print_status(f"{url} 正常", "SUCCESS")
                    else:
                        self.print_status(f"{url} 狀態碼: {response.status_code}", "ERROR")
                        self.issues.append(f"管理頁面 {url} 無法訪問")
                except Exception as e:
                    self.print_status(f"{url} 錯誤: {str(e)}", "ERROR")
                    self.issues.append(f"管理頁面 {url} 錯誤: {str(e)}")
                    
        except Exception as e:
            self.print_status(f"管理後台測試失敗: {str(e)}", "ERROR")
            self.issues.append(f"管理後台問題: {str(e)}")
    
    def test_user_dashboards(self):
        """測試用戶儀表板"""
        self.print_header("用戶儀表板測試")
        
        try:
            # 測試不同角色的儀表板
            dashboard_urls = [
                '/dashboard/',
                '/dashboard/admin/',
                '/dashboard/staff/',
                '/dashboard/dj/',
                '/dashboard/supplier/',
                '/dashboard/client/',
            ]
            
            for url in dashboard_urls:
                try:
                    response = self.client.get(url)
                    # 應該重定向到登入頁面（未登入狀態）
                    if response.status_code in [302, 301]:
                        self.print_status(f"{url} 正確重定向（需要登入）", "SUCCESS")
                    elif response.status_code == 200:
                        self.print_status(f"{url} 可以訪問", "SUCCESS")
                    else:
                        self.print_status(f"{url} 狀態碼: {response.status_code}", "WARNING")
                except Exception as e:
                    self.print_status(f"{url} 錯誤: {str(e)}", "ERROR")
                    self.issues.append(f"儀表板 {url} 錯誤: {str(e)}")
                    
        except Exception as e:
            self.print_status(f"儀表板測試失敗: {str(e)}", "ERROR")
            self.issues.append(f"儀表板問題: {str(e)}")
    
    def test_static_files(self):
        """測試靜態文件"""
        self.print_header("靜態文件檢測")
        
        try:
            # 檢查靜態文件設置
            self.print_status(f"STATIC_URL: {settings.STATIC_URL}", "INFO")
            self.print_status(f"STATIC_ROOT: {getattr(settings, 'STATIC_ROOT', 'Not set')}", "INFO")
            
            # 測試靜態文件收集
            try:
                out = StringIO()
                call_command('collectstatic', '--noinput', stdout=out, verbosity=0)
                self.print_status("靜態文件收集成功", "SUCCESS")
            except Exception as e:
                self.print_status(f"靜態文件收集失敗: {str(e)}", "ERROR")
                self.issues.append(f"靜態文件問題: {str(e)}")
                
        except Exception as e:
            self.print_status(f"靜態文件檢測失敗: {str(e)}", "ERROR")
    
    def test_database_performance(self):
        """測試數據庫性能"""
        self.print_header("數據庫性能測試")
        
        try:
            from django.db import connection
            from django.test.utils import override_settings
            
            # 重置查詢計數器
            connection.queries_log.clear()
            
            # 執行一些常見查詢
            test_queries = [
                lambda: list(User.objects.all()[:10]),
                lambda: list(Event.objects.select_related('organizer', 'event_type')[:10]),
                lambda: list(Supplier.objects.prefetch_related('service_categories')[:10]),
            ]
            
            for i, query_func in enumerate(test_queries):
                start_time = time.time()
                result = query_func()
                end_time = time.time()
                query_time = (end_time - start_time) * 1000
                
                self.print_status(f"查詢 {i+1}: {query_time:.2f}ms", "SUCCESS" if query_time < 100 else "WARNING")
                
                if query_time > 500:
                    self.issues.append(f"查詢 {i+1} 性能過慢: {query_time:.2f}ms")
                    
        except Exception as e:
            self.print_status(f"性能測試失敗: {str(e)}", "ERROR")
    
    def test_security_settings(self):
        """測試安全設置"""
        self.print_header("安全設置檢測")
        
        security_checks = [
            ('DEBUG', False, getattr(settings, 'DEBUG', True)),
            ('SECRET_KEY', True, len(getattr(settings, 'SECRET_KEY', '')) > 20),
            ('ALLOWED_HOSTS', True, len(getattr(settings, 'ALLOWED_HOSTS', [])) > 0),
            ('CSRF_COOKIE_SECURE', True, getattr(settings, 'CSRF_COOKIE_SECURE', False)),
            ('SESSION_COOKIE_SECURE', True, getattr(settings, 'SESSION_COOKIE_SECURE', False)),
        ]
        
        for setting_name, should_be_true, actual_value in security_checks:
            if should_be_true == actual_value:
                self.print_status(f"{setting_name}: 正確設置", "SUCCESS")
            else:
                self.print_status(f"{setting_name}: 需要調整 (當前: {actual_value})", "WARNING")
                if setting_name in ['DEBUG'] and actual_value == True:
                    self.issues.append(f"生產環境不應該開啟 {setting_name}")
    
    def auto_fix_issues(self):
        """自動修復發現的問題"""
        self.print_header("自動修復問題")
        
        if not self.issues:
            self.print_status("未發現需要修復的問題", "SUCCESS")
            return
            
        self.print_status(f"發現 {len(self.issues)} 個問題，開始自動修復...", "INFO")
        
        for issue in self.issues:
            self.print_status(f"問題: {issue}", "WARNING")
            
            # 根據問題類型進行修復
            if "數據庫遷移" in issue:
                try:
                    call_command('migrate', verbosity=0)
                    self.print_status("執行數據庫遷移", "FIX")
                    self.fixes_applied.append("數據庫遷移")
                except Exception as e:
                    self.print_status(f"遷移失敗: {str(e)}", "ERROR")
                    
            elif "靜態文件" in issue:
                try:
                    call_command('collectstatic', '--noinput', verbosity=0)
                    self.print_status("重新收集靜態文件", "FIX")
                    self.fixes_applied.append("靜態文件收集")
                except Exception as e:
                    self.print_status(f"靜態文件收集失敗: {str(e)}", "ERROR")
    
    def generate_test_data(self):
        """生成測試數據"""
        self.print_header("生成測試數據")
        
        try:
            # 創建測試用戶
            test_users = [
                {'username': 'test_client', 'email': 'client@test.com', 'first_name': '測試客戶'},
                {'username': 'test_supplier', 'email': 'supplier@test.com', 'first_name': '測試供應商'},
                {'username': 'test_dj', 'email': 'dj@test.com', 'first_name': '測試DJ'},
            ]
            
            for user_data in test_users:
                user, created = User.objects.get_or_create(
                    username=user_data['username'],
                    defaults=user_data
                )
                if created:
                    user.set_password('test123456')
                    user.save()
                    self.print_status(f"創建測試用戶: {user_data['username']}", "SUCCESS")
            
            # 創建測試活動類型
            event_type, created = EventType.objects.get_or_create(
                name='婚禮',
                defaults={'description': '婚禮活動'}
            )
            if created:
                self.print_status("創建測試活動類型", "SUCCESS")
            
            # 創建測試服務類別
            service_cat, created = ServiceCategory.objects.get_or_create(
                name='DJ服務',
                defaults={'description': 'DJ音響服務'}
            )
            if created:
                self.print_status("創建測試服務類別", "SUCCESS")
                
        except Exception as e:
            self.print_status(f"測試數據生成失敗: {str(e)}", "ERROR")
    
    def run_comprehensive_test(self):
        """執行全面測試"""
        self.print_header("超級用戶全面系統測試開始")
        
        # 執行各項測試
        self.test_database_integrity()
        self.test_admin_panel()
        self.test_user_dashboards()
        self.test_static_files()
        self.test_database_performance()
        self.test_security_settings()
        self.generate_test_data()
        
        # 自動修復問題
        self.auto_fix_issues()
        
        # 生成測試報告
        self.generate_report()
    
    def generate_report(self):
        """生成測試報告"""
        self.print_header("測試報告")
        
        self.print_status(f"發現問題數量: {len(self.issues)}", "INFO")
        self.print_status(f"應用修復數量: {len(self.fixes_applied)}", "INFO")
        
        if self.issues:
            self.print_status("待解決問題:", "WARNING")
            for i, issue in enumerate(self.issues, 1):
                print(f"   {i}. {issue}")
        
        if self.fixes_applied:
            self.print_status("已應用修復:", "SUCCESS")
            for i, fix in enumerate(self.fixes_applied, 1):
                print(f"   {i}. {fix}")
        
        if not self.issues:
            self.print_status("🎉 系統測試完成，未發現重大問題！", "SUCCESS")
        else:
            self.print_status("⚠️ 系統測試完成，發現一些需要關注的問題", "WARNING")

if __name__ == "__main__":
    tester = SuperUserSystemTest()
    tester.run_comprehensive_test()
