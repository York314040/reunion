#!/usr/bin/env python
import os
import django

# 設置Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.contrib.auth.models import User

def create_test_users():
    """創建測試用戶供演示刪除功能"""
    test_users = [
        {
            'username': 'test_user1',
            'email': 'test1@example.com',
            'first_name': '測試',
            'last_name': '用戶1',
            'is_active': True,
        },
        {
            'username': 'test_user2',
            'email': 'test2@example.com',
            'first_name': '測試',
            'last_name': '用戶2',
            'is_active': True,
        },
        {
            'username': 'staff_user',
            'email': 'staff@example.com',
            'first_name': '管理員',
            'last_name': '測試',
            'is_staff': True,
            'is_active': True,
        },
        {
            'username': 'inactive_user',
            'email': 'inactive@example.com',
            'first_name': '停用',
            'last_name': '用戶',
            'is_active': False,
        }
    ]
    
    print("創建測試用戶...")
    for user_data in test_users:
        user, created = User.objects.get_or_create(
            username=user_data['username'],
            defaults=user_data
        )
        if created:
            user.set_password('testpass123')
            user.save()
            print(f"✓ 已創建測試用戶: {user.username}")
        else:
            print(f"- 用戶已存在: {user.username}")
    
    print(f"\n總用戶數: {User.objects.count()}")
    print(f"超級用戶: {User.objects.filter(is_superuser=True).count()}")
    print(f"管理員: {User.objects.filter(is_staff=True, is_superuser=False).count()}")
    print(f"一般用戶: {User.objects.filter(is_staff=False, is_superuser=False).count()}")
    print(f"啟用用戶: {User.objects.filter(is_active=True).count()}")
    print(f"停用用戶: {User.objects.filter(is_active=False).count()}")

if __name__ == '__main__':
    print("=== 創建測試用戶 ===\n")
    create_test_users()
    print("\n✅ 測試用戶創建完成！")
    print("\n您現在可以：")
    print("1. 登入管理員帳號 (admin/admin123)")
    print("2. 訪問用戶管理頁面: http://localhost:8000/admin/users/")
    print("3. 測試刪除功能 (可以刪除 test_user1, test_user2 等)")
    print("4. 測試權限管理功能")
    print("5. 測試啟用/停用功能")
