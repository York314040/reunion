#!/usr/bin/env python
import os
import sys
import django

# 設置 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.contrib.auth.models import User
from django.test import Client
from django.urls import reverse

def test_delete_user_functionality():
    """測試刪除用戶功能"""
    print("開始測試刪除用戶功能...")
    
    # 建立測試客戶端
    client = Client()
    
    # 建立超級用戶和一般用戶
    superuser = User.objects.get(username='admin')
    test_user = User.objects.get(username='test_user1')
    
    print(f"超級用戶: {superuser.username} (ID: {superuser.id})")
    print(f"測試用戶: {test_user.username} (ID: {test_user.id})")
    
    # 登入超級用戶
    login_success = client.login(username='admin', password='admin123')
    print(f"登入結果: {login_success}")
    
    if not login_success:
        print("無法登入，請檢查密碼")
        return
    
    # 測試用戶管理頁面
    response = client.get('/manage/users/')
    print(f"用戶管理頁面狀態碼: {response.status_code}")
    
    if response.status_code == 200:
        print("✅ 用戶管理頁面可正常訪問")
        # 檢查頁面是否包含測試用戶
        if 'test_user1' in response.content.decode():
            print("✅ 頁面包含測試用戶")
        else:
            print("❌ 頁面不包含測試用戶")
    else:
        print(f"❌ 用戶管理頁面無法訪問，狀態碼: {response.status_code}")
        return
    
    # 測試刪除用戶 API
    delete_url = f'/manage/users/{test_user.id}/delete/'
    print(f"嘗試刪除用戶，URL: {delete_url}")
    
    response = client.post(delete_url, {
        'csrfmiddlewaretoken': client.cookies['csrftoken'].value
    })
    
    print(f"刪除請求狀態碼: {response.status_code}")
    
    if response.status_code == 200:
        response_data = response.json()
        print(f"刪除回應: {response_data}")
        
        if response_data.get('success'):
            print("✅ 刪除成功")
            # 檢查用戶是否真的被刪除
            try:
                User.objects.get(id=test_user.id)
                print("❌ 用戶仍然存在於資料庫中")
            except User.DoesNotExist:
                print("✅ 用戶已從資料庫中刪除")
        else:
            print(f"❌ 刪除失敗: {response_data.get('message')}")
    else:
        print(f"❌ 刪除請求失敗，狀態碼: {response.status_code}")
        if hasattr(response, 'content'):
            print(f"錯誤內容: {response.content.decode()[:500]}")

if __name__ == "__main__":
    test_delete_user_functionality()
