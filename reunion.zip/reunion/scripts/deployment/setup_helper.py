"""
本地開發和 Heroku 部署的快速設置腳本
"""
import os
import subprocess
import sys

def run_command(command, description):
    """執行命令並顯示結果"""
    print(f"\n🔄 {description}")
    print(f"執行命令: {command}")
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True, encoding='utf-8')
        if result.returncode == 0:
            print(f"✅ 成功: {description}")
            if result.stdout.strip():
                print(f"輸出: {result.stdout.strip()}")
        else:
            print(f"❌ 失敗: {description}")
            print(f"錯誤: {result.stderr}")
            return False
    except Exception as e:
        print(f"❌ 執行錯誤: {e}")
        return False
    return True

def setup_local_development():
    """設置本地開發環境"""
    print("=== 設置本地開發環境 ===")
    
    # 應用數據庫遷移
    if not run_command("python manage.py makemigrations", "創建數據庫遷移文件"):
        return False
    
    if not run_command("python manage.py migrate", "應用數據庫遷移"):
        return False
    
    # 創建超級用戶（如果不存在）
    check_superuser = """
import os
import django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()
from django.contrib.auth.models import User
if not User.objects.filter(username='admin').exists():
    User.objects.create_superuser('admin', 'admin@example.com', 'admin123456')
    print('超級用戶已創建: admin / admin123456')
else:
    print('超級用戶已存在: admin')
"""
    
    with open('temp_create_superuser.py', 'w', encoding='utf-8') as f:
        f.write(check_superuser)
    
    run_command("python temp_create_superuser.py", "檢查/創建超級用戶")
    
    # 清理臨時文件
    if os.path.exists('temp_create_superuser.py'):
        os.remove('temp_create_superuser.py')
    
    # 初始化示例數據
    if os.path.exists('init_heroku_data.py'):
        run_command("python init_heroku_data.py", "初始化示例數據")
    
    # 收集靜態文件
    run_command("python manage.py collectstatic --noinput", "收集靜態文件")
    
    print("\n✅ 本地開發環境設置完成！")
    print("📍 現在可以運行: python manage.py runserver")
    print("🌐 然後訪問: http://127.0.0.1:8000")
    print("👤 管理員帳號: admin / admin123456")

def check_heroku_requirements():
    """檢查 Heroku 部署要求"""
    print("=== 檢查 Heroku 部署要求 ===")
    
    required_files = [
        'requirements.txt',
        'Procfile', 
        'runtime.txt',
        '.env',
        '.gitignore'
    ]
    
    missing_files = []
    for file in required_files:
        if os.path.exists(file):
            print(f"✅ {file} 存在")
        else:
            print(f"❌ {file} 缺少")
            missing_files.append(file)
    
    if missing_files:
        print(f"\n❌ 缺少必要文件: {', '.join(missing_files)}")
        print("請先運行部署設置腳本創建這些文件")
        return False
    
    # 檢查 Git 初始化
    if os.path.exists('.git'):
        print("✅ Git 倉庫已初始化")
    else:
        print("❌ Git 倉庫未初始化")
        print("請運行: git init")
        return False
    
    print("\n✅ Heroku 部署要求檢查完成！")
    return True

def deploy_to_heroku():
    """部署到 Heroku"""
    print("=== 部署到 Heroku ===")
    
    if not check_heroku_requirements():
        return False
    
    # Git 操作
    commands = [
        ("git add .", "添加所有文件到 Git"),
        ("git commit -m 'Prepare for Heroku deployment'", "提交更改"),
        ("heroku create your-app-name", "創建 Heroku 應用（需要替換 your-app-name）"),
        ("heroku addons:create heroku-postgresql:mini", "添加 PostgreSQL 數據庫"),
        ("git push heroku main", "推送到 Heroku"),
        ("heroku run python init_heroku_data.py", "初始化 Heroku 數據"),
        ("heroku open", "打開應用")
    ]
    
    print("將執行以下 Heroku 部署步驟：")
    for cmd, desc in commands:
        print(f"  {desc}: {cmd}")
    
    print("\n⚠️  注意事項：")
    print("1. 請確保已安裝 Heroku CLI")
    print("2. 請確保已登錄 Heroku: heroku login")  
    print("3. 請將 'your-app-name' 替換為您的應用名稱")
    print("4. 建議手動執行這些命令以確保每步成功")

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("用法:")
        print("  python setup_helper.py local    # 設置本地開發環境")
        print("  python setup_helper.py check    # 檢查 Heroku 部署要求")
        print("  python setup_helper.py heroku   # 顯示 Heroku 部署步驟")
        sys.exit(1)
    
    command = sys.argv[1].lower()
    
    if command == "local":
        setup_local_development()
    elif command == "check":
        check_heroku_requirements()
    elif command == "heroku":
        deploy_to_heroku()
    else:
        print(f"未知命令: {command}")
        print("可用命令: local, check, heroku")
