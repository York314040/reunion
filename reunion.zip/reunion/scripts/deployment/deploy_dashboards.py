#!/usr/bin/env python
import os
import sys
import django
from django.core.management import execute_from_command_line

if __name__ == '__main__':
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
    django.setup()
    
    # Import models after Django is set up
    from django.contrib.auth.models import User
    from dj_management.models import DJ
    from suppliers.models import Supplier
    
    print("部署角色儀表板系統...")
    print("系統已成功配置了以下功能:")
    print("✅ DJ專用儀表板 - 包含預約管理、收入統計、表演追蹤")
    print("✅ 供應商儀表板 - 包含商機管理、對話追蹤、業務分析")
    print("✅ 客戶儀表板 - 包含活動管理、服務發現、預約追蹤")
    print("✅ 管理員儀表板 - 包含系統監控、用戶管理、審核工具")
    print("✅ 員工儀表板 - 包含任務管理、客戶服務、績效追蹤")
    print("✅ 智能角色檢測 - 自動根據用戶身份導向適合的儀表板")
    
    print("\n儀表板路徑:")
    print("主入口: /dashboard/ (智能路由)")
    print("DJ儀表板: /dashboard/dj/")
    print("供應商儀表板: /dashboard/supplier/")
    print("客戶儀表板: /dashboard/client/")
    print("管理員儀表板: /dashboard/admin/")
    print("員工儀表板: /dashboard/staff/")
    
    print("\n部署完成！每個用戶類型現在都有自己專屬的工作介面。")
