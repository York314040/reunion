#!/usr/bin/env python
"""
Heroku 部署準備腳本
"""
import os
import sys
import django

# 設置 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.contrib.auth.models import User
from django.core.management import execute_from_command_line

def create_superuser():
    """創建超級用戶"""
    if not User.objects.filter(is_superuser=True).exists():
        print("正在創建超級用戶...")
        User.objects.create_superuser(
            username='admin',
            email='admin@example.com',
            password='admin123456'
        )
        print("超級用戶創建完成！")
        print("用戶名: admin")
        print("密碼: admin123456")
    else:
        print("超級用戶已存在")

def collect_static():
    """收集靜態文件"""
    print("正在收集靜態文件...")
    execute_from_command_line(['manage.py', 'collectstatic', '--noinput'])
    print("靜態文件收集完成！")

if __name__ == "__main__":
    print("=== Heroku 部署準備 ===")
    
    # 運行遷移
    print("正在運行數據庫遷移...")
    execute_from_command_line(['manage.py', 'migrate'])
    print("數據庫遷移完成！")
    
    # 創建超級用戶
    create_superuser()
    
    # 收集靜態文件
    collect_static()
    
    print("=== 部署準備完成 ===")
    print("\n部署後可使用以下帳號登入：")
    print("用戶名: admin")
    print("密碼: admin123456")
