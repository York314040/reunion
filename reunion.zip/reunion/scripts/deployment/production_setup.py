#!/usr/bin/env python
"""
生產環境安全配置建議和自動修復腳本
"""

import os
import sys
from pathlib import Path

def print_header(title):
    print(f"\n{'='*60}")
    print(f"🔒 {title}")
    print(f"{'='*60}")

def print_status(message, status="INFO"):
    icons = {"INFO": "ℹ️", "SUCCESS": "✅", "ERROR": "❌", "WARNING": "⚠️", "FIX": "🔧"}
    print(f"{icons.get(status, 'ℹ️')} {message}")

def check_production_settings():
    """檢查生產環境設置"""
    print_header("生產環境安全配置檢查")
    
    settings_file = Path("party_platform/settings.py")
    
    if not settings_file.exists():
        print_status("找不到 settings.py 文件", "ERROR")
        return
    
    with open(settings_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    issues = []
    recommendations = []
    
    # 檢查 DEBUG 設置
    if "DEBUG = True" in content:
        issues.append("DEBUG 設置為 True")
        recommendations.append("生產環境應設置 DEBUG = False")
    
    # 檢查 SECRET_KEY
    if "SECRET_KEY = " in content and len(content.split("SECRET_KEY = ")[1].split('\n')[0]) < 50:
        issues.append("SECRET_KEY 可能過短")
        recommendations.append("生產環境應使用更長的隨機密鑰")
    
    # 檢查 ALLOWED_HOSTS
    if "ALLOWED_HOSTS = []" in content:
        issues.append("ALLOWED_HOSTS 為空")
        recommendations.append("生產環境應設置正確的域名")
    
    # 檢查安全設置
    security_settings = [
        "CSRF_COOKIE_SECURE",
        "SESSION_COOKIE_SECURE", 
        "SECURE_SSL_REDIRECT",
        "SECURE_HSTS_SECONDS",
        "SECURE_CONTENT_TYPE_NOSNIFF",
        "SECURE_BROWSER_XSS_FILTER"
    ]
    
    missing_security = []
    for setting in security_settings:
        if setting not in content:
            missing_security.append(setting)
    
    if missing_security:
        issues.extend([f"缺少安全設置: {setting}" for setting in missing_security])
    
    return issues, recommendations

def create_production_settings():
    """創建生產環境配置文件"""
    print_header("創建生產環境配置")
    
    prod_settings = """# 生產環境設置
import os
from .settings import *

# 安全設置
DEBUG = False
ALLOWED_HOSTS = ['your-domain.com', 'www.your-domain.com']

# 密鑰（從環境變量讀取）
SECRET_KEY = os.environ.get('SECRET_KEY', 'your-production-secret-key-here')

# 數據庫設置（生產環境）
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': os.environ.get('DB_NAME', 'party_platform_prod'),
        'USER': os.environ.get('DB_USER', 'postgres'),
        'PASSWORD': os.environ.get('DB_PASSWORD', ''),
        'HOST': os.environ.get('DB_HOST', 'localhost'),
        'PORT': os.environ.get('DB_PORT', '5432'),
    }
}

# 靜態文件設置
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

# 安全設置
CSRF_COOKIE_SECURE = True
SESSION_COOKIE_SECURE = True
SECURE_SSL_REDIRECT = True
SECURE_HSTS_SECONDS = 31536000  # 1 年
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_BROWSER_XSS_FILTER = True
SECURE_REFERRER_POLICY = 'strict-origin-when-cross-origin'

# Cookie 設置
SESSION_COOKIE_HTTPONLY = True
CSRF_COOKIE_HTTPONLY = True
SESSION_COOKIE_AGE = 3600  # 1 小時

# 日誌設置
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '{levelname} {asctime} {module} {process:d} {thread:d} {message}',
            'style': '{',
        },
    },
    'handlers': {
        'file': {
            'level': 'INFO',
            'class': 'logging.FileHandler',
            'filename': 'logs/django.log',
            'formatter': 'verbose',
        },
        'error_file': {
            'level': 'ERROR',
            'class': 'logging.FileHandler',
            'filename': 'logs/django_errors.log',
            'formatter': 'verbose',
        },
    },
    'root': {
        'handlers': ['file'],
        'level': 'INFO',
    },
    'loggers': {
        'django': {
            'handlers': ['file', 'error_file'],
            'level': 'INFO',
            'propagate': True,
        },
    },
}

# 緩存設置
CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.redis.RedisCache',
        'LOCATION': 'redis://127.0.0.1:6379/1',
        'OPTIONS': {
            'CLIENT_CLASS': 'django_redis.client.DefaultClient',
        }
    }
}

# 電子郵件設置
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = os.environ.get('EMAIL_HOST', 'smtp.gmail.com')
EMAIL_PORT = int(os.environ.get('EMAIL_PORT', '587'))
EMAIL_USE_TLS = True
EMAIL_HOST_USER = os.environ.get('EMAIL_HOST_USER', '')
EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD', '')
DEFAULT_FROM_EMAIL = os.environ.get('DEFAULT_FROM_EMAIL', 'noreply@your-domain.com')
"""
    
    prod_file = Path("party_platform/settings_production.py")
    with open(prod_file, 'w', encoding='utf-8') as f:
        f.write(prod_settings)
    
    print_status("創建生產環境配置文件: settings_production.py", "SUCCESS")

def create_env_template():
    """創建環境變量模板"""
    print_header("創建環境變量模板")
    
    env_template = """# 環境變量配置文件 (.env)
# 複製此文件為 .env 並填入實際值

# Django 設置
SECRET_KEY=your-very-long-random-secret-key-here
DEBUG=False
ALLOWED_HOSTS=your-domain.com,www.your-domain.com

# 數據庫設置
DB_NAME=party_platform_prod
DB_USER=postgres
DB_PASSWORD=your-database-password
DB_HOST=localhost
DB_PORT=5432

# 電子郵件設置
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_HOST_USER=your-email@gmail.com
EMAIL_HOST_PASSWORD=your-email-password
DEFAULT_FROM_EMAIL=noreply@your-domain.com

# Redis 設置
REDIS_URL=redis://localhost:6379/1

# 其他設置
ADMIN_URL=your-secret-admin-path/
"""
    
    env_file = Path(".env.example")
    with open(env_file, 'w', encoding='utf-8') as f:
        f.write(env_template)
    
    print_status("創建環境變量模板: .env.example", "SUCCESS")

def create_deployment_checklist():
    """創建部署檢查清單"""
    print_header("生成部署檢查清單")
    
    checklist = """# 🚀 生產環境部署檢查清單

## 安全設置
- [ ] DEBUG = False
- [ ] 設置強壯的 SECRET_KEY
- [ ] 配置正確的 ALLOWED_HOSTS
- [ ] 啟用 HTTPS 相關設置
- [ ] 設置安全的 Cookie 配置

## 數據庫
- [ ] 配置生產數據庫（PostgreSQL 推薦）
- [ ] 執行數據遷移: `python manage.py migrate`
- [ ] 創建超級用戶: `python manage.py createsuperuser`
- [ ] 設置數據庫備份策略

## 靜態文件
- [ ] 執行: `python manage.py collectstatic`
- [ ] 配置 Web 服務器提供靜態文件
- [ ] 設置媒體文件存儲

## 日誌和監控
- [ ] 配置日誌記錄
- [ ] 設置錯誤監控（如 Sentry）
- [ ] 配置性能監控

## Web 服務器
- [ ] 配置 Nginx/Apache
- [ ] 設置 SSL 證書
- [ ] 配置防火牆
- [ ] 設置反向代理

## 環境變量
- [ ] 設置所有必要的環境變量
- [ ] 確保敏感信息不在代碼中
- [ ] 測試環境變量加載

## 測試
- [ ] 執行全面測試
- [ ] 測試所有功能
- [ ] 性能測試
- [ ] 安全測試

## 備份
- [ ] 設置代碼備份
- [ ] 設置數據庫備份
- [ ] 測試恢復流程

## 監控
- [ ] 設置系統監控
- [ ] 配置告警機制
- [ ] 監控資源使用
"""
    
    checklist_file = Path("DEPLOYMENT_CHECKLIST.md")
    with open(checklist_file, 'w', encoding='utf-8') as f:
        f.write(checklist)
    
    print_status("創建部署檢查清單: DEPLOYMENT_CHECKLIST.md", "SUCCESS")

def main():
    """主函數"""
    print_header("生產環境配置助手")
    
    # 檢查當前設置
    issues, recommendations = check_production_settings()
    
    if issues:
        print_status("發現以下問題:", "WARNING")
        for i, issue in enumerate(issues, 1):
            print(f"   {i}. {issue}")
        
        print_status("建議:", "INFO")
        for i, rec in enumerate(recommendations, 1):
            print(f"   {i}. {rec}")
    else:
        print_status("當前設置看起來不錯！", "SUCCESS")
    
    # 創建生產環境文件
    create_production_settings()
    create_env_template()
    create_deployment_checklist()
    
    print_header("完成")
    print_status("已創建以下文件:", "SUCCESS")
    print("   - party_platform/settings_production.py")
    print("   - .env.example") 
    print("   - DEPLOYMENT_CHECKLIST.md")
    
    print_status("下一步:", "INFO")
    print("   1. 複製 .env.example 為 .env 並填入實際值")
    print("   2. 在生產環境使用: DJANGO_SETTINGS_MODULE=party_platform.settings_production")
    print("   3. 按照 DEPLOYMENT_CHECKLIST.md 進行部署")

if __name__ == "__main__":
    main()
