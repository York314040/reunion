from django.contrib import admin
from .models import EventType, Event


@admin.register(EventType)
class EventTypeAdmin(admin.ModelAdmin):
    list_display = ['name', 'description']
    search_fields = ['name']


@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ['title', 'organizer', 'event_type', 'event_date', 'status', 'created_at']
    list_filter = ['status', 'event_type', 'created_at']
    search_fields = ['title', 'description', 'organizer__username']
    readonly_fields = ['created_at', 'updated_at']
    
    fieldsets = (
        ('基本資訊', {
            'fields': ('title', 'description', 'event_type', 'organizer', 'status')
        }),
        ('活動詳情', {
            'fields': ('event_date', 'location', 'expected_attendees', 'budget_min', 'budget_max')
        }),
        ('聯絡資訊', {
            'fields': ('contact_person', 'contact_phone', 'contact_email')
        }),
        ('時間戳記', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
