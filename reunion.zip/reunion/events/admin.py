from django.contrib import admin
from .models import EventType, Event


@admin.register(EventType)
class EventTypeAdmin(admin.ModelAdmin):
    list_display = ['name', 'description']
    search_fields = ['name']


@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ['title', 'organizer', 'event_type', 'event_date', 'status', 'is_featured', 'created_at']
    list_filter = ['status', 'event_type', 'is_featured', 'created_at']
    search_fields = ['title', 'description', 'organizer__username']
    readonly_fields = ['created_at', 'updated_at']
    list_editable = ['is_featured', 'status']
    
    fieldsets = (
        ('基本資訊', {
            'fields': ('title', 'description', 'event_type', 'organizer', 'status', 'is_featured')
        }),
        ('活動詳情', {
            'fields': ('event_date', 'location', 'expected_attendees', 'budget_min', 'budget_max', 'duration_hours', 'requirements')
        }),
        ('聯絡資訊', {
            'fields': ('contact_person', 'contact_phone', 'contact_email')
        }),
        ('時間戳記', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
