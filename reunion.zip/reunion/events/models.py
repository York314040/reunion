from django.db import models
from django.contrib.auth.models import User


class EventType(models.Model):
    """活動類型"""
    name = models.CharField(max_length=100, verbose_name="活動類型")
    description = models.TextField(blank=True, verbose_name="描述")
    
    class Meta:
        verbose_name = "活動類型"
        verbose_name_plural = "活動類型"
    
    def __str__(self):
        return self.name


class Event(models.Model):
    """活動需求"""
    STATUS_CHOICES = [
        ('pending', '待審核'),
        ('approved', '已通過'),
        ('rejected', '已拒絕'),
    ]
    
    title = models.CharField(max_length=200, verbose_name="活動標題")
    description = models.TextField(verbose_name="活動描述")
    event_type = models.ForeignKey(EventType, on_delete=models.CASCADE, verbose_name="活動類型")
    organizer = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="主辦方")
    
    # 活動詳情
    event_date = models.DateTimeField(verbose_name="活動日期")
    location = models.CharField(max_length=200, verbose_name="活動地點")
    expected_attendees = models.PositiveIntegerField(verbose_name="預計參與人數")
    budget_min = models.PositiveIntegerField(verbose_name="預算下限", help_text="新台幣")
    budget_max = models.PositiveIntegerField(verbose_name="預算上限", help_text="新台幣")
    requirements = models.TextField(blank=True, verbose_name="特殊需求")
    duration_hours = models.PositiveIntegerField(default=4, verbose_name="活動時長（小時）")
    
    # 聯絡資訊
    contact_person = models.CharField(max_length=100, verbose_name="聯絡人")
    contact_phone = models.CharField(max_length=20, verbose_name="聯絡電話")
    contact_email = models.EmailField(verbose_name="聯絡信箱")
    
    # 狀態管理
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending', verbose_name="狀態")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="建立時間")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="更新時間")
    
    class Meta:
        verbose_name = "活動需求"
        verbose_name_plural = "活動需求"
        ordering = ['-created_at']
    
    def __str__(self):
        return self.title
