from django import forms
from .models import Event, EventType

class EventForm(forms.ModelForm):
    class Meta:
        model = Event
        fields = [
            'title', 'description', 'event_type', 'budget_min', 'budget_max',
            'expected_attendees', 'event_date', 'location', 'contact_person',
            'contact_phone', 'contact_email'
        ]
        widgets = {
            'event_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'description': forms.Textarea(attrs={'rows': 4}),
            'budget_min': forms.NumberInput(attrs={'min': 1, 'max': 99999999}),
            'budget_max': forms.NumberInput(attrs={'min': 1, 'max': 99999999}),
            'expected_attendees': forms.NumberInput(attrs={'min': 1, 'max': 10000}),
        }
    
    def clean(self):
        cleaned_data = super().clean()
        budget_min = cleaned_data.get('budget_min')
        budget_max = cleaned_data.get('budget_max')
        
        if budget_min and budget_max:
            if budget_min > budget_max:
                raise forms.ValidationError('最小預算不能大於最大預算')
        
        title = cleaned_data.get('title')
        if title and len(title.strip()) == 0:
            raise forms.ValidationError('標題不能為空')
            
        expected_attendees = cleaned_data.get('expected_attendees')
        if expected_attendees and expected_attendees <= 0:
            raise forms.ValidationError('預期參與人數必須大於0')
        
        return cleaned_data
    
    def clean_contact_phone(self):
        phone = self.cleaned_data.get('contact_phone')
        if phone:
            # 簡單的電話號碼驗證
            import re
            if not re.match(r'^[0-9+\-\s()]{8,20}$', phone):
                raise forms.ValidationError('請輸入有效的電話號碼')
        return phone
    
    def clean_contact_email(self):
        email = self.cleaned_data.get('contact_email')
        if email:
            # 使用Django內建的郵箱驗證
            from django.core.validators import validate_email
            from django.core.exceptions import ValidationError
            try:
                validate_email(email)
            except ValidationError:
                raise forms.ValidationError('請輸入有效的郵箱地址')
        return email
