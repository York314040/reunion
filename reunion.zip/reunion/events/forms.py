from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Event


class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(required=True, label="電子信箱")
    first_name = forms.CharField(max_length=30, required=True, label="姓名")
    
    class Meta:
        model = User
        fields = ("username", "first_name", "email", "password1", "password2")
        labels = {
            'username': '使用者名稱',
        }
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data["email"]
        user.first_name = self.cleaned_data["first_name"]
        if commit:
            user.save()
        return user


class EventForm(forms.ModelForm):
    class Meta:
        model = Event
        fields = [
            'title', 'description', 'event_type', 'event_date', 'location',
            'expected_attendees', 'budget_min', 'budget_max',
            'contact_person', 'contact_phone', 'contact_email'
        ]
        labels = {
            'title': '活動標題',
            'description': '活動描述',
            'event_type': '活動類型',
            'event_date': '活動日期',
            'location': '活動地點',
            'expected_attendees': '預計參與人數',
            'budget_min': '預算下限 (新台幣)',
            'budget_max': '預算上限 (新台幣)',
            'contact_person': '聯絡人',
            'contact_phone': '聯絡電話',
            'contact_email': '聯絡信箱',
        }
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
            'event_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'budget_min': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '1',
                'max': '99999999',
                'step': '1',
                'placeholder': '預算下限 (新台幣)'
            }),
            'budget_max': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '1',
                'max': '99999999',
                'step': '1',
                'placeholder': '預算上限 (新台幣)'
            }),
        }

    def clean_budget_min(self):
        """驗證預算下限"""
        budget_min = self.cleaned_data.get('budget_min')
        if budget_min is not None:
            if budget_min < 1:
                raise forms.ValidationError('預算下限不能小於1元')
            if budget_min > 99999999:
                raise forms.ValidationError('預算下限不能超過99,999,999元')
        return budget_min

    def clean_budget_max(self):
        """驗證預算上限"""
        budget_max = self.cleaned_data.get('budget_max')
        if budget_max is not None:
            if budget_max < 1:
                raise forms.ValidationError('預算上限不能小於1元')
            if budget_max > 99999999:
                raise forms.ValidationError('預算上限不能超過99,999,999元')
        return budget_max

    def clean(self):
        """驗證預算邏輯"""
        cleaned_data = super().clean()
        budget_min = cleaned_data.get('budget_min')
        budget_max = cleaned_data.get('budget_max')
        
        if budget_min and budget_max:
            if budget_min >= budget_max:
                raise forms.ValidationError('預算上限必須大於預算下限')
        
        return cleaned_data
