from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User
from django.contrib import messages
from django.core.paginator import Paginator
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
import json


def is_superuser(user):
    """檢查用戶是否為超級用戶"""
    return user.is_superuser


@login_required
@user_passes_test(is_superuser)
def user_management(request):
    """用戶管理頁面"""
    # 獲取所有用戶
    users = User.objects.all().order_by('-date_joined')
    
    # 搜尋功能
    search_query = request.GET.get('search', '')
    if search_query:
        users = users.filter(
            username__icontains=search_query
        ) | users.filter(
            email__icontains=search_query
        ) | users.filter(
            first_name__icontains=search_query
        ) | users.filter(
            last_name__icontains=search_query
        )
    
    # 分頁
    paginator = Paginator(users, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'search_query': search_query,
        'total_users': User.objects.count(),
        'superuser_count': User.objects.filter(is_superuser=True).count(),
        'staff_count': User.objects.filter(is_staff=True).count(),
    }
    
    return render(request, 'events/user_management.html', context)


@login_required
@user_passes_test(is_superuser)
@require_POST
def toggle_superuser(request, user_id):
    """切換用戶的超級用戶狀態"""
    try:
        user = get_object_or_404(User, id=user_id)
        
        # 防止用戶移除自己的超級用戶權限
        if user.id == request.user.id and user.is_superuser:
            return JsonResponse({
                'success': False,
                'message': '您不能移除自己的超級用戶權限'
            })
        
        # 切換狀態
        user.is_superuser = not user.is_superuser
        user.is_staff = user.is_superuser  # 超級用戶通常也是staff
        user.save()
        
        action = "設為超級用戶" if user.is_superuser else "移除超級用戶權限"
        
        return JsonResponse({
            'success': True,
            'message': f'已{action}: {user.username}',
            'is_superuser': user.is_superuser
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'message': f'操作失敗: {str(e)}'
        })


@login_required
@user_passes_test(is_superuser)
@require_POST
def toggle_staff(request, user_id):
    """切換用戶的管理員狀態"""
    try:
        user = get_object_or_404(User, id=user_id)
        
        # 如果是超級用戶，不能移除staff狀態
        if user.is_superuser and user.is_staff:
            return JsonResponse({
                'success': False,
                'message': '超級用戶必須保持管理員狀態'
            })
        
        user.is_staff = not user.is_staff
        user.save()
        
        action = "設為管理員" if user.is_staff else "移除管理員權限"
        
        return JsonResponse({
            'success': True,
            'message': f'已{action}: {user.username}',
            'is_staff': user.is_staff
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'message': f'操作失敗: {str(e)}'
        })


@login_required
@user_passes_test(is_superuser)
@require_POST
def toggle_active(request, user_id):
    """切換用戶的啟用狀態"""
    try:
        user = get_object_or_404(User, id=user_id)
        
        # 防止用戶停用自己
        if user.id == request.user.id:
            return JsonResponse({
                'success': False,
                'message': '您不能停用自己的帳號'
            })
        
        user.is_active = not user.is_active
        user.save()
        
        action = "啟用" if user.is_active else "停用"
        
        return JsonResponse({
            'success': True,
            'message': f'已{action}用戶: {user.username}',
            'is_active': user.is_active
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'message': f'操作失敗: {str(e)}'
        })


@login_required
@user_passes_test(is_superuser)
def create_user(request):
    """創建新用戶"""
    if request.method == 'POST':
        try:
            username = request.POST.get('username')
            email = request.POST.get('email')
            password = request.POST.get('password')
            first_name = request.POST.get('first_name', '')
            last_name = request.POST.get('last_name', '')
            is_superuser = request.POST.get('is_superuser') == 'on'
            is_staff = request.POST.get('is_staff') == 'on'
            
            # 驗證必填欄位
            if not username or not password:
                messages.error(request, '用戶名和密碼為必填欄位')
                return redirect('events:user_management')
            
            # 檢查用戶名是否已存在
            if User.objects.filter(username=username).exists():
                messages.error(request, f'用戶名 "{username}" 已存在')
                return redirect('events:user_management')
            
            # 創建用戶
            user = User.objects.create_user(
                username=username,
                email=email,
                password=password,
                first_name=first_name,
                last_name=last_name
            )
            
            user.is_superuser = is_superuser
            user.is_staff = is_staff or is_superuser  # 超級用戶自動是staff
            user.save()
            
            messages.success(request, f'成功創建用戶: {username}')
            
        except Exception as e:
            messages.error(request, f'創建用戶失敗: {str(e)}')
    
    return redirect('events:user_management')


@login_required
@user_passes_test(is_superuser)
@login_required
@user_passes_test(is_superuser)
@require_POST
def delete_user(request, user_id):
    """刪除用戶"""
    try:
        user = get_object_or_404(User, id=user_id)
        
        # 防止用戶刪除自己
        if user.id == request.user.id:
            return JsonResponse({
                'success': False,
                'message': '您不能刪除自己的帳號'
            })
        
        # 防止刪除最後一個超級用戶
        if user.is_superuser:
            superuser_count = User.objects.filter(is_superuser=True).count()
            if superuser_count <= 1:
                return JsonResponse({
                    'success': False,
                    'message': '不能刪除最後一個超級用戶'
                })
        
        username = user.username
        user.delete()
        
        return JsonResponse({
            'success': True,
            'message': f'已刪除用戶: {username}'
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'message': f'刪除失敗: {str(e)}'
        })
