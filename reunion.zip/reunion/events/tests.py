from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
from django.utils import timezone
from datetime import datetime, timedelta
from .models import Event, EventType


class EventModelTest(TestCase):
    """活動模型測試"""
    
    def setUp(self):
        """測試前置設定"""
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )
        
        self.event_type = EventType.objects.create(
            name='會議',
            description='商務會議活動'
        )
        
        self.event = Event.objects.create(
            title='測試活動',
            description='這是一個測試活動',
            event_type=self.event_type,
            organizer=self.user,
            event_date=timezone.now() + timedelta(days=30),
            location='台北市信義區',
            expected_attendees=50,
            budget_min=10000,
            budget_max=50000,
            contact_person='張三',
            contact_phone='0912345678',
            contact_email='contact@example.com'
        )
    
    def test_event_creation(self):
        """測試活動創建"""
        self.assertEqual(self.event.title, '測試活動')
        self.assertEqual(self.event.organizer, self.user)
        self.assertEqual(self.event.status, 'pending')
        self.assertIsNotNone(self.event.created_at)
    
    def test_event_str_method(self):
        """測試活動字串表示"""
        # 檢查是否有定義 __str__ 方法
        event_str = str(self.event)
        self.assertIn('測試活動', event_str)
    
    def test_event_type_relationship(self):
        """測試活動類型關聯"""
        self.assertEqual(self.event.event_type.name, '會議')
    
    def test_budget_validation(self):
        """測試預算驗證"""
        self.assertLessEqual(self.event.budget_min, self.event.budget_max)
        self.assertGreater(self.event.budget_min, 0)
        self.assertGreater(self.event.budget_max, 0)


class EventTypeModelTest(TestCase):
    """活動類型模型測試"""
    
    def setUp(self):
        self.event_type = EventType.objects.create(
            name='研討會',
            description='學術研討會活動'
        )
    
    def test_event_type_creation(self):
        """測試活動類型創建"""
        self.assertEqual(self.event_type.name, '研討會')
        self.assertEqual(self.event_type.description, '學術研討會活動')
    
    def test_event_type_str_method(self):
        """測試活動類型字串表示"""
        self.assertEqual(str(self.event_type), '研討會')


class EventViewTest(TestCase):
    """活動視圖測試"""
    
    def setUp(self):
        """測試前置設定"""
        self.client = Client()
        
        # 創建測試用戶
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )
        
        # 創建超級用戶
        self.admin_user = User.objects.create_superuser(
            username='admin',
            email='admin@example.com',
            password='adminpass123'
        )
        
        self.event_type = EventType.objects.create(
            name='會議',
            description='商務會議'
        )
        
        self.event = Event.objects.create(
            title='測試活動',
            description='這是一個測試活動',
            event_type=self.event_type,
            organizer=self.user,
            event_date=timezone.now() + timedelta(days=30),
            location='台北市信義區',
            expected_attendees=50,
            budget_min=10000,
            budget_max=50000,
            contact_person='張三',
            contact_phone='0912345678',
            contact_email='contact@example.com'
        )
    
    def test_home_page_access(self):
        """測試首頁訪問"""
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
    
    def test_event_list_view(self):
        """測試活動列表頁面"""
        try:
            url = reverse('events:event_list')
            response = self.client.get(url)
            self.assertIn(response.status_code, [200, 302])  # 可能需要登入
        except:
            self.skipTest("事件列表URL不存在")
    
    def test_login_required_views(self):
        """測試需要登入的頁面"""
        protected_urls = [
            '/events/create/',
            '/events/user_management/',
        ]
        
        for url in protected_urls:
            response = self.client.get(url)
            # 應該重定向到登入頁面或返回403
            self.assertIn(response.status_code, [302, 403, 404])
    
    def test_user_authentication(self):
        """測試用戶認證"""
        # 測試登入
        login_successful = self.client.login(
            username='testuser',
            password='testpass123'
        )
        self.assertTrue(login_successful)
        
        # 測試登入後的頁面訪問
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
    
    def test_admin_access(self):
        """測試管理員權限"""
        # 登入管理員
        self.client.login(username='admin', password='adminpass123')
        
        # 測試管理員專用頁面
        admin_urls = [
            '/admin/',
        ]
        
        for url in admin_urls:
            response = self.client.get(url)
            self.assertIn(response.status_code, [200, 302])


class DatabaseIntegrityTest(TestCase):
    """資料庫完整性測試"""
    
    def setUp(self):
        self.user = User.objects.create_user(
            username='testuser',
            password='testpass123'
        )
        
        self.event_type = EventType.objects.create(
            name='測試類型'
        )
    
    def test_cascade_delete(self):
        """測試級聯刪除"""
        event = Event.objects.create(
            title='測試活動',
            description='測試描述',
            event_type=self.event_type,
            organizer=self.user,
            event_date=timezone.now() + timedelta(days=30),
            location='測試地點',
            expected_attendees=10,
            budget_min=1000,
            budget_max=5000,
            contact_person='測試人',
            contact_phone='0900000000',
            contact_email='test@test.com'
        )
        
        event_id = event.id
        
        # 刪除用戶，活動應該也被刪除
        self.user.delete()
        
        with self.assertRaises(Event.DoesNotExist):
            Event.objects.get(id=event_id)
    
    def test_required_fields(self):
        """測試必填欄位"""
        with self.assertRaises(Exception):
            Event.objects.create(
                # 缺少必填欄位
                title='',
                event_type=self.event_type,
                organizer=self.user
            )
