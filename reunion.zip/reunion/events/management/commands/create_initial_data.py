from django.core.management.base import BaseCommand
from events.models import EventType
from suppliers.models import ServiceCategory


class Command(BaseCommand):
    help = '建立初始數據'

    def handle(self, *args, **options):
        # 建立活動類型
        event_types = [
            {'name': '企業聚會', 'description': '公司聚餐、尾牙、春酒等企業活動'},
            {'name': '生日派對', 'description': '生日慶祝活動'},
            {'name': '婚禮', 'description': '婚禮相關活動'},
            {'name': '私人聚會', 'description': '朋友聚會、家庭聚會等'},
            {'name': '產品發表會', 'description': '新品發表、記者會等'},
        ]
        
        for event_type_data in event_types:
            event_type, created = EventType.objects.get_or_create(
                name=event_type_data['name'],
                defaults={'description': event_type_data['description']}
            )
            if created:
                self.stdout.write(f'建立活動類型: {event_type.name}')
        
        # 建立服務類別
        service_categories = [
            {'name': 'DJ', 'description': '音樂DJ服務'},
            {'name': '調酒師', 'description': '專業調酒服務'},
            {'name': '攝影師', 'description': '活動攝影服務'},
            {'name': '餐飲外燴', 'description': '餐飲外燴服務'},
            {'name': '場地佈置', 'description': '活動場地佈置'},
            {'name': '主持人', 'description': '活動主持服務'},
            {'name': '樂團表演', 'description': '現場音樂表演'},
            {'name': '魔術表演', 'description': '魔術娛樂表演'},
        ]
        
        for category_data in service_categories:
            category, created = ServiceCategory.objects.get_or_create(
                name=category_data['name'],
                defaults={'description': category_data['description']}
            )
            if created:
                self.stdout.write(f'建立服務類別: {category.name}')
        
        self.stdout.write(self.style.SUCCESS('初始數據建立完成！'))
