from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from events.models import Event, EventType
from datetime import datetime, timedelta
from django.utils import timezone

class Command(BaseCommand):
    help = '創建測試活動資料'

    def handle(self, *args, **options):
        # 確保有用戶
        if not User.objects.exists():
            user = User.objects.create_user(
                username='testuser',
                email='test@example.com',
                password='testpass123'
            )
            self.stdout.write('創建測試用戶: testuser')
        else:
            user = User.objects.first()

        # 清除現有活動
        Event.objects.all().delete()
        self.stdout.write('清除現有活動資料')

        # 獲取或創建EventType
        event_types = {}
        for type_name in ['企業聚會', '生日派對', '婚禮', '其他', '尾牙']:
            event_type, created = EventType.objects.get_or_create(name=type_name)
            event_types[type_name] = event_type
            if created:
                self.stdout.write(f'創建活動類型: {type_name}')

        # 創建測試活動
        events_data = [
            {
                'title': '台北海濱派對',
                'description': '需要場地、調酒師、音響場控',
                'location': '台北',
                'event_type': event_types['企業聚會'],
                'budget_min': 75000,
                'budget_max': 85000,
                'event_date': timezone.now() + timedelta(days=30),
                'expected_attendees': 50,
                'status': 'approved',
                'contact_person': '張先生',
                'contact_phone': '0912345678',
                'contact_email': 'zhang@example.com'
            },
            {
                'title': '成大耶誕舞會',
                'description': '需要場地、燈控、攝影',
                'location': '台南',
                'event_type': event_types['生日派對'],
                'budget_min': 45000,
                'budget_max': 55000,
                'event_date': timezone.now() + timedelta(days=25),
                'expected_attendees': 80,
                'status': 'approved',
                'contact_person': '李小姐',
                'contact_phone': '0923456789',
                'contact_email': 'lee@example.com'
            },
            {
                'title': '高雄頂樓夕陽派對',
                'description': '需要場地清潔、燈控、攝影',
                'location': '高雄',
                'event_type': event_types['其他'],
                'budget_min': 95000,
                'budget_max': 105000,
                'event_date': timezone.now() + timedelta(days=20),
                'expected_attendees': 60,
                'status': 'approved',
                'contact_person': '王先生',
                'contact_phone': '0934567890',
                'contact_email': 'wang@example.com'
            },
            {
                'title': '公司尾牙活動',
                'description': '需要場地、音響、主持人、餐飲',
                'location': '台北',
                'event_type': event_types['尾牙'],
                'budget_min': 115000,
                'budget_max': 125000,
                'event_date': timezone.now() + timedelta(days=15),
                'expected_attendees': 120,
                'status': 'approved',
                'contact_person': '陳小姐',
                'contact_phone': '0945678901',
                'contact_email': 'chen@example.com'
            }
        ]

        for event_data in events_data:
            event = Event.objects.create(
                organizer=user,
                **event_data
            )
            self.stdout.write(f'創建活動: {event.title}')

        self.stdout.write(
            self.style.SUCCESS(f'成功創建 {len(events_data)} 個測試活動')
        )
