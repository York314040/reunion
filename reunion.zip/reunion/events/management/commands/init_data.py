from django.core.management.base import BaseCommand
from events.models import EventType
from suppliers.models import ServiceCategory
from dj_management.models import DJCategory

class Command(BaseCommand):
    help = '初始化基本數據'

    def handle(self, *args, **options):
        # 創建活動類型
        event_types = [
            ('婚禮', '婚禮慶典活動'),
            ('生日派對', '生日慶祝活動'),
            ('企業聚會', '公司活動或會議'),
            ('私人聚會', '私人聚會活動'),
            ('音樂會', '音樂表演活動'),
        ]
        
        for name, desc in event_types:
            EventType.objects.get_or_create(
                name=name,
                defaults={'description': desc}
            )
        
        # 創建服務類別
        service_categories = [
            ('DJ', 'DJ音響服務'),
            ('攝影師', '專業攝影服務'),
            ('餐飲外燴', '餐飲外燴服務'),
            ('場地佈置', '活動場地佈置'),
            ('燈光音響', '燈光音響設備租賃'),
        ]
        
        for name, desc in service_categories:
            ServiceCategory.objects.get_or_create(
                name=name,
                defaults={'description': desc}
            )
        
        # 創建DJ類別
        dj_categories = [
            ('House', 'House電子音樂'),
            ('Hip-Hop', 'Hip-Hop嘻哈音樂'),
            ('流行音樂', '流行音樂DJ'),
            ('電子舞曲', '電子舞曲EDM'),
        ]
        
        for name, desc in dj_categories:
            DJCategory.objects.get_or_create(
                name=name,
                defaults={'description': desc}
            )
        
        self.stdout.write(
            self.style.SUCCESS('成功初始化基本數據')
        )
