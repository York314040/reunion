from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from django.contrib import messages
from django.core.paginator import Paginator
from django.http import HttpResponse, JsonResponse, Http404
from django.contrib.auth.models import User
from django.views.decorators.http import require_http_methods
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Q
import json
from .models import Event, EventType
from .forms import EventForm, CustomUserCreationForm


def home(request):
    """首頁"""
    recent_events = Event.objects.filter(status='approved')[:6]
    context = {
        'recent_events': recent_events,
    }
    return render(request, 'events/home.html', context)


def event_list(request):
    """活動列表"""
    events = Event.objects.filter(status='approved')
    
    # 分頁
    paginator = Paginator(events, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
    }
    return render(request, 'events/event_list.html', context)


def event_detail(request, pk):
    """活動詳情"""
    # 允許用戶查看自己創建的活動，即使還在審核中
    if request.user.is_authenticated:
        # 已登入用戶可以查看自己創建的活動或已通過的活動
        try:
            event = Event.objects.get(pk=pk)
            # 檢查是否有權限查看
            if event.status == 'approved' or event.organizer == request.user:
                pass  # 有權限查看
            else:
                # 無權限查看此活動
                raise Http404("您沒有權限查看此活動")
        except Event.DoesNotExist:
            raise Http404("活動不存在")
    else:
        # 未登入用戶只能查看已通過的活動
        event = get_object_or_404(Event, pk=pk, status='approved')
    
    context = {
        'event': event,
    }
    return render(request, 'events/event_detail.html', context)


@login_required
def create_event(request):
    """建立活動需求"""
    if request.method == 'POST':
        form = EventForm(request.POST)
        if form.is_valid():
            try:
                event = form.save(commit=False)
                event.organizer = request.user
                event.save()
                messages.success(request, '活動需求已提交，等待審核。')
                return redirect('events:event_detail', pk=event.pk)
            except Exception as e:
                # 記錄保存錯誤
                messages.error(request, f'保存活動時發生錯誤：{str(e)}')
                # 在開發環境下顯示詳細錯誤
                import logging
                logger = logging.getLogger(__name__)
                logger.error(f"Event save error: {e}", exc_info=True)
        else:
            # 表單驗證失敗時添加錯誤消息
            error_messages = []
            for field, errors in form.errors.items():
                for error in errors:
                    if field == '__all__':
                        error_messages.append(f"表單錯誤：{error}")
                    else:
                        field_name = form.fields[field].label or field
                        error_messages.append(f"{field_name}：{error}")
            
            if error_messages:
                for msg in error_messages:
                    messages.error(request, msg)
            else:
                messages.error(request, '表單提交失敗，請檢查所有必填欄位。')
    else:
        form = EventForm()
    
    context = {
        'form': form,
    }
    return render(request, 'events/create_event.html', context)


@login_required
def my_events(request):
    """我的活動"""
    events = Event.objects.filter(organizer=request.user)
    
    # 分頁
    paginator = Paginator(events, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
    }
    return render(request, 'events/my_events.html', context)


def register(request):
    """註冊"""
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, '註冊成功！')
            return redirect('events:home')
    else:
        form = CustomUserCreationForm()
    
    context = {
        'form': form,
    }
    return render(request, 'registration/register.html', context)


def test_view(request):
    """測試視圖"""
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>測試頁面</title>
        <style>
            body { font-family: Arial; margin: 40px; background: #f5f5f5; }
            .container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }
            h1 { color: #333; text-align: center; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🎉 PAPA COLLEGE - B2B聚會派對媒合平台</h1>
            <p>✅ Django 服務器正在運行</p>
            <p>✅ 視圖系統正常</p>
            <p>如果您能看到這個頁面，說明 Django 應用正常運行！</p>
            <a href="/">返回首頁</a> | <a href="/admin/">管理後台</a>
        </div>
    </body>
    </html>
    """
    return HttpResponse(html)


@staff_member_required
def user_management(request):
    """用戶管理頁面 - 僅超級用戶可訪問"""
    if not request.user.is_superuser:
        messages.error(request, '您沒有權限訪問此頁面')
        return redirect('events:home')
    
    # 獲取搜索參數
    search_query = request.GET.get('search', '')
    user_type = request.GET.get('type', 'all')
    
    # 基礎查詢
    users = User.objects.all()
    
    # 搜索過濾
    if search_query:
        users = users.filter(
            Q(username__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(first_name__icontains=search_query) |
            Q(last_name__icontains=search_query)
        )
    
    # 用戶類型過濾
    if user_type == 'superuser':
        users = users.filter(is_superuser=True)
    elif user_type == 'staff':
        users = users.filter(is_staff=True, is_superuser=False)
    elif user_type == 'regular':
        users = users.filter(is_staff=False, is_superuser=False)
    
    # 排序
    users = users.order_by('-date_joined')
    
    # 分頁
    paginator = Paginator(users, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    # 統計數據
    total_users = User.objects.count()
    superuser_count = User.objects.filter(is_superuser=True).count()
    staff_count = User.objects.filter(is_staff=True, is_superuser=False).count()
    regular_count = User.objects.filter(is_staff=False, is_superuser=False).count()
    
    context = {
        'page_obj': page_obj,
        'search_query': search_query,
        'user_type': user_type,
        'total_users': total_users,
        'superuser_count': superuser_count,
        'staff_count': staff_count,
        'regular_count': regular_count,
    }
    
    return render(request, 'events/user_management.html', context)


@staff_member_required
@require_http_methods(["POST"])
def delete_user(request, user_id):
    """刪除用戶 - 僅超級用戶可執行"""
    if not request.user.is_superuser:
        return JsonResponse({
            'success': False, 
            'message': '您沒有權限執行此操作'
        }, status=403)
    
    try:
        user_to_delete = get_object_or_404(User, pk=user_id)
        
        # 防止刪除自己
        if user_to_delete == request.user:
            return JsonResponse({
                'success': False,
                'message': '不能刪除自己的帳號'
            })
        
        # 防止刪除其他超級用戶（可選的安全措施）
        if user_to_delete.is_superuser:
            return JsonResponse({
                'success': False,
                'message': '不能刪除超級用戶帳號'
            })
        
        username = user_to_delete.username
        user_to_delete.delete()
        
        return JsonResponse({
            'success': True,
            'message': f'用戶 "{username}" 已成功刪除'
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'message': f'刪除失敗：{str(e)}'
        }, status=500)


@staff_member_required
@require_http_methods(["POST"])
def toggle_user_status(request, user_id):
    """切換用戶啟用/停用狀態"""
    if not request.user.is_superuser:
        return JsonResponse({
            'success': False, 
            'message': '您沒有權限執行此操作'
        }, status=403)
    
    try:
        user_to_toggle = get_object_or_404(User, pk=user_id)
        
        # 防止操作自己
        if user_to_toggle == request.user:
            return JsonResponse({
                'success': False,
                'message': '不能操作自己的帳號狀態'
            })
        
        # 防止操作其他超級用戶
        if user_to_toggle.is_superuser:
            return JsonResponse({
                'success': False,
                'message': '不能操作超級用戶的狀態'
            })
        
        user_to_toggle.is_active = not user_to_toggle.is_active
        user_to_toggle.save()
        
        status_text = "啟用" if user_to_toggle.is_active else "停用"
        
        return JsonResponse({
            'success': True,
            'message': f'用戶 "{user_to_toggle.username}" 已{status_text}',
            'is_active': user_to_toggle.is_active
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'message': f'操作失敗：{str(e)}'
        }, status=500)


@staff_member_required
@require_http_methods(["POST"])
def change_user_permissions(request, user_id):
    """修改用戶權限"""
    if not request.user.is_superuser:
        return JsonResponse({
            'success': False, 
            'message': '您沒有權限執行此操作'
        }, status=403)
    
    try:
        user_to_change = get_object_or_404(User, pk=user_id)
        
        # 防止操作自己
        if user_to_change == request.user:
            return JsonResponse({
                'success': False,
                'message': '不能修改自己的權限'
            })
        
        # 處理POST數據，可能是JSON或表單數據
        if request.content_type == 'application/json':
            data = json.loads(request.body)
            action = data.get('action')
        else:
            action = request.POST.get('action')
        
        if action == 'make_staff':
            user_to_change.is_staff = True
            user_to_change.save()
            message = f'用戶 "{user_to_change.username}" 已設為管理員'
            
        elif action == 'remove_staff':
            user_to_change.is_staff = False
            user_to_change.is_superuser = False  # 移除管理員權限時也移除超級用戶權限
            user_to_change.save()
            message = f'用戶 "{user_to_change.username}" 的管理員權限已移除'
            
        else:
            return JsonResponse({
                'success': False,
                'message': '無效的操作'
            })
        
        return JsonResponse({
            'success': True,
            'message': message,
            'is_staff': user_to_change.is_staff,
            'is_superuser': user_to_change.is_superuser
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'message': f'操作失敗：{str(e)}'
        }, status=500)


@staff_member_required
def user_detail(request, user_id):
    """用戶詳情頁面"""
    if not request.user.is_superuser:
        messages.error(request, '您沒有權限訪問此頁面')
        return redirect('events:home')
    
    user_detail_obj = get_object_or_404(User, pk=user_id)
    
    # 獲取用戶相關數據
    user_events = Event.objects.filter(organizer=user_detail_obj).order_by('-created_at')[:10]
    
    context = {
        'user_detail': user_detail_obj,
        'user_events': user_events,
    }
    
    return render(request, 'events/user_detail.html', context)


@staff_member_required
def user_management_test(request):
    """用戶管理測試頁面"""
    users = User.objects.all().order_by('-date_joined')
    context = {
        'users': users,
    }
    return render(request, 'events/user_management_test.html', context)

@staff_member_required
def js_diagnostic(request):
    """JavaScript診斷頁面"""
    return render(request, 'events/js_diagnostic.html')


@staff_member_required
def simple_delete_test(request):
    """簡單刪除測試頁面"""
    users = User.objects.all().order_by('-date_joined')
    context = {
        'users': users,
    }
    return render(request, 'events/simple_delete_test.html', context)
