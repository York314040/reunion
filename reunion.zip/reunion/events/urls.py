from django.urls import path
from django.contrib.auth import views as auth_views
from . import views
from . import admin_views

app_name = 'events'

urlpatterns = [
    path('', views.home, name='home'),
    path('events/', views.event_list, name='event_list'),
    path('events/<int:pk>/', views.event_detail, name='event_detail'),
    path('events/create/', views.create_event, name='create_event'),
    path('my-events/', views.my_events, name='my_events'),
    path('register/', views.register, name='register'),
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('test/', views.test_view, name='test'),

    # 用戶管理相關
    path('management/users/', admin_views.user_management, name='user_management'),
    path('management/users/create/', admin_views.create_user, name='create_user'),
    path('users/<int:user_id>/toggle-superuser/', admin_views.toggle_superuser, name='toggle_superuser'),
    path('users/<int:user_id>/toggle-staff/', admin_views.toggle_staff, name='toggle_staff'),
    path('users/<int:user_id>/toggle-active/', admin_views.toggle_active, name='toggle_active'),
    path('users/<int:user_id>/delete/', admin_views.delete_user, name='delete_user'),

    # 新的用戶管理功能
    path('manage/users/', views.user_management, name='user_management_new'),
    path('manage/users/<int:user_id>/delete/', views.delete_user, name='delete_user_new'),
    path('manage/users/<int:user_id>/toggle-status/', views.toggle_user_status, name='toggle_user_status'),
    path('manage/users/<int:user_id>/permissions/', views.change_user_permissions, name='change_user_permissions'),
    path('manage/users/<int:user_id>/', views.user_detail, name='user_detail_new'),

    # 用戶管理測試
    path('manage/users/test/', views.user_management_test, name='user_management_test'),
    path('simple-delete-test/', views.simple_delete_test, name='simple_delete_test'),
    path('js-diagnostic/', views.js_diagnostic, name='js_diagnostic'),
]
