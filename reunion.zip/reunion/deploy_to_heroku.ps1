# 聚會平台 Heroku 部署腳本 (PowerShell)
Write-Host "================================" -ForegroundColor Cyan
Write-Host "    聚會平台 Heroku 部署腳本" -ForegroundColor Cyan  
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""

# 檢查是否在正確的目錄
if (-not (Test-Path "manage.py")) {
    Write-Host "❌ 錯誤：請在項目根目錄運行此腳本" -ForegroundColor Red
    Read-Host "按任意鍵退出"
    exit 1
}

# 檢查 Heroku CLI
try {
    $herokuVersion = heroku --version 2>$null
    Write-Host "✅ Heroku CLI 已安裝: $herokuVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ 錯誤：未找到 Heroku CLI" -ForegroundColor Red
    Write-Host "請先安裝 Heroku CLI：https://devcenter.heroku.com/articles/heroku-cli" -ForegroundColor Yellow
    Write-Host "或查看 INSTALL_HEROKU.md 文件" -ForegroundColor Yellow
    Read-Host "按任意鍵退出"
    exit 1
}

# 檢查登錄狀態
try {
    $whoami = heroku auth:whoami 2>$null
    Write-Host "✅ 已登錄 Heroku: $whoami" -ForegroundColor Green
} catch {
    Write-Host "🔐 需要登錄 Heroku..." -ForegroundColor Yellow
    heroku login
    if ($LASTEXITCODE -ne 0) {
        Write-Host "❌ 登錄失敗" -ForegroundColor Red
        Read-Host "按任意鍵退出"
        exit 1
    }
}

# 提示用戶輸入應用名稱
Write-Host ""
Write-Host "請輸入您的 Heroku 應用名稱（例如：reunion-party-platform）" -ForegroundColor Yellow
Write-Host "注意：名稱必須是唯一的，只能包含小寫字母、數字和連字符" -ForegroundColor Yellow
$APP_NAME = Read-Host "應用名稱"

if ([string]::IsNullOrEmpty($APP_NAME)) {
    Write-Host "❌ 錯誤：應用名稱不能為空" -ForegroundColor Red
    Read-Host "按任意鍵退出"
    exit 1
}

Write-Host ""
Write-Host "🚀 開始部署到 Heroku..." -ForegroundColor Cyan
Write-Host "應用名稱：$APP_NAME" -ForegroundColor Cyan
Write-Host ""

# 創建 Heroku 應用
Write-Host "📱 創建 Heroku 應用..." -ForegroundColor Blue
heroku create $APP_NAME
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ 創建應用失敗，可能是名稱已被使用" -ForegroundColor Red
    Read-Host "按任意鍵退出"
    exit 1
}

Write-Host "✅ 應用創建成功" -ForegroundColor Green

# 添加 PostgreSQL
Write-Host "🗄️ 添加 PostgreSQL 數據庫..." -ForegroundColor Blue
heroku addons:create heroku-postgresql:mini --app $APP_NAME
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ 添加數據庫失敗" -ForegroundColor Red
    Read-Host "按任意鍵退出"
    exit 1
}

Write-Host "✅ 數據庫添加成功" -ForegroundColor Green

# 設置環境變量
Write-Host "⚙️ 設置環境變量..." -ForegroundColor Blue

# 生成隨機密鑰
$SECRET_KEY = "django-insecure-random-key-for-deployment-$(Get-Random)"

heroku config:set SECRET_KEY="$SECRET_KEY" --app $APP_NAME
heroku config:set DEBUG=False --app $APP_NAME
heroku config:set ALLOWED_HOSTS="$APP_NAME.herokuapp.com,localhost,127.0.0.1" --app $APP_NAME

Write-Host "✅ 環境變量設置完成" -ForegroundColor Green

# 部署代碼
Write-Host "📤 部署代碼到 Heroku..." -ForegroundColor Blue
git push heroku master
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ 部署失敗" -ForegroundColor Red
    Read-Host "按任意鍵退出"
    exit 1
}

Write-Host "✅ 代碼部署成功" -ForegroundColor Green

# 運行數據庫遷移
Write-Host "🗄️ 運行數據庫遷移..." -ForegroundColor Blue
heroku run python manage.py migrate --app $APP_NAME

# 初始化數據
Write-Host "📊 初始化示例數據..." -ForegroundColor Blue
heroku run python init_heroku_data.py --app $APP_NAME

Write-Host ""
Write-Host "🎉 部署完成！" -ForegroundColor Green
Write-Host ""
Write-Host "📱 應用信息：" -ForegroundColor Cyan
Write-Host "   網址：https://$APP_NAME.herokuapp.com" -ForegroundColor White
Write-Host "   管理後台：https://$APP_NAME.herokuapp.com/admin/" -ForegroundColor White
Write-Host ""
Write-Host "👤 演示帳號：" -ForegroundColor Cyan
Write-Host "   超級用戶：admin / admin123456" -ForegroundColor White
Write-Host "   管理員：manager / manager123456" -ForegroundColor White
Write-Host "   一般用戶：zhang_ming / demo123456" -ForegroundColor White
Write-Host ""

# 打開應用
Write-Host "🌐 正在打開應用..." -ForegroundColor Blue
heroku open --app $APP_NAME

Write-Host ""
Write-Host "📋 部署總結：" -ForegroundColor Cyan
Write-Host "   ✅ Heroku 應用已創建" -ForegroundColor Green
Write-Host "   ✅ PostgreSQL 數據庫已添加" -ForegroundColor Green
Write-Host "   ✅ 環境變量已設置" -ForegroundColor Green
Write-Host "   ✅ 代碼已部署" -ForegroundColor Green
Write-Host "   ✅ 數據庫已遷移" -ForegroundColor Green
Write-Host "   ✅ 示例數據已初始化" -ForegroundColor Green
Write-Host ""
Write-Host "現在您可以分享這個網址給朋友了！" -ForegroundColor Yellow
Write-Host ""
Read-Host "按任意鍵退出"
