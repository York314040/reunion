#!/usr/bin/env python
"""
詳細Bug檢測工具 - 針對不同角色用戶
"""

import os
import sys
import django
from datetime import datetime
from django.test import Client
from django.contrib.auth import get_user_model
from django.urls import reverse
from django.core.exceptions import ValidationError

# 設置Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from events.models import Event, EventType
try:
    from djs.models import DJ
except ImportError:
    DJ = None
try:
    from suppliers.models import Supplier
except ImportError:
    Supplier = None
try:
    from messaging.models import Quote, Message
except ImportError:
    Quote = Message = None
try:
    from users.models import Profile
except ImportError:
    Profile = None

User = get_user_model()

def test_user_roles():
    """測試不同角色用戶的功能"""
    print("🔍 開始角色功能測試...")
    client = Client()
    
    # 1. 測試一般用戶
    print("\n👤 測試一般用戶功能:")
    
    # 創建一般用戶
    try:
        normal_user = User.objects.create_user(
            username='test_normal_' + str(int(datetime.now().timestamp())),
            email='normal@test.com',
            password='testpass123'
        )
        print("✅ 一般用戶創建成功")
    except Exception as e:
        print(f"❌ 一般用戶創建失敗: {e}")
        return
    
    # 登入測試
    login_success = client.login(username=normal_user.username, password='testpass123')
    if login_success:
        print("✅ 一般用戶登入成功")
    else:
        print("❌ 一般用戶登入失敗")
    
    # 測試活動創建
    event_type = EventType.objects.first()
    if event_type:
        event_data = {
            'title': '測試活動_' + str(int(datetime.now().timestamp())),
            'description': '測試活動描述',
            'event_type': event_type.id,
            'budget_min': 10000,
            'budget_max': 50000,
            'expected_attendees': 100,
            'event_date': '2024-12-31T18:00',
            'location': '台北市',
            'contact_person': '測試聯絡人',
            'contact_phone': '0912345678',
            'contact_email': 'test@test.com'
        }
        
        response = client.post(reverse('events:create_event'), event_data)
        if response.status_code == 302:
            print("✅ 一般用戶可以創建活動")
        else:
            print(f"❌ 一般用戶創建活動失敗，狀態碼: {response.status_code}")
            if hasattr(response, 'context') and 'form' in response.context:
                print(f"表單錯誤: {response.context['form'].errors}")
    
    # 2. 測試DJ角色
    print("\n🎵 測試DJ用戶功能:")
    
    try:
        dj_user = User.objects.create_user(
            username='test_dj_' + str(int(datetime.now().timestamp())),
            email='dj@test.com',
            password='testpass123'
        )
        
        # 創建Profile
        profile, created = Profile.objects.get_or_create(user=dj_user)
        profile.user_type = 'dj'
        profile.save()
        
        print("✅ DJ用戶和Profile創建成功")
        
        # 創建DJ資料
        dj = DJ.objects.create(
            user=dj_user,
            stage_name='測試DJ',
            experience_years=5,
            music_style='Electronic',
            hourly_rate=3000,
            bio='測試DJ介紹'
        )
        print("✅ DJ資料創建成功")
        
    except Exception as e:
        print(f"❌ DJ用戶創建失敗: {e}")
    
    # 登入DJ
    client.login(username=dj_user.username, password='testpass123')
    
    # 測試DJ列表頁面
    try:
        response = client.get(reverse('djs:dj_list'))
        if response.status_code == 200:
            print("✅ DJ可以訪問DJ列表頁面")
        else:
            print(f"❌ DJ列表頁面錯誤，狀態碼: {response.status_code}")
    except Exception as e:
        print(f"❌ DJ列表頁面出錯: {e}")
    
    # 測試DJ詳情頁面
    try:
        response = client.get(reverse('djs:dj_detail', kwargs={'pk': dj.pk}))
        if response.status_code == 200:
            print("✅ DJ詳情頁面正常")
        else:
            print(f"❌ DJ詳情頁面錯誤，狀態碼: {response.status_code}")
    except Exception as e:
        print(f"❌ DJ詳情頁面出錯: {e}")
    
    # 3. 測試供應商角色
    print("\n🏢 測試供應商用戶功能:")
    
    try:
        supplier_user = User.objects.create_user(
            username='test_supplier_' + str(int(datetime.now().timestamp())),
            email='supplier@test.com',
            password='testpass123'
        )
        
        # 創建Profile
        profile, created = Profile.objects.get_or_create(user=supplier_user)
        profile.user_type = 'supplier'
        profile.save()
        
        print("✅ 供應商用戶和Profile創建成功")
        
        # 創建供應商資料
        supplier = Supplier.objects.create(
            user=supplier_user,
            company_name='測試供應商公司',
            service_type='catering',
            description='測試供應商描述',
            contact_phone='0987654321',
            address='台北市中正區'
        )
        print("✅ 供應商資料創建成功")
        
    except Exception as e:
        print(f"❌ 供應商用戶創建失敗: {e}")
    
    # 登入供應商
    client.login(username=supplier_user.username, password='testpass123')
    
    # 測試供應商列表頁面
    try:
        response = client.get(reverse('suppliers:supplier_list'))
        if response.status_code == 200:
            print("✅ 供應商可以訪問供應商列表頁面")
        else:
            print(f"❌ 供應商列表頁面錯誤，狀態碼: {response.status_code}")
    except Exception as e:
        print(f"❌ 供應商列表頁面出錯: {e}")

def test_messaging_system():
    """測試訊息系統"""
    print("\n💬 測試訊息系統...")
    
    client = Client()
    
    # 獲取測試用戶
    try:
        normal_user = User.objects.filter(username__startswith='test_normal_').first()
        supplier_user = User.objects.filter(username__startswith='test_supplier_').first()
        
        if not normal_user or not supplier_user:
            print("❌ 缺少測試用戶，請先運行角色測試")
            return
        
        # 創建測試活動
        event_type = EventType.objects.first()
        event = Event.objects.create(
            organizer=normal_user,
            title='訊息測試活動',
            description='測試描述',
            event_type=event_type,
            budget_min=10000,
            budget_max=50000,
            expected_attendees=100,
            event_date='2024-12-31 18:00:00',
            location='台北市',
            contact_person='測試',
            contact_phone='0912345678',
            contact_email='test@test.com'
        )
        
        # 供應商登入並創建報價
        client.login(username=supplier_user.username, password='testpass123')
        
        quote_data = {
            'event': event.id,
            'price': 25000,
            'description': '測試報價描述',
            'valid_until': '2024-12-30'
        }
        
        response = client.post(reverse('messaging:create_quote'), quote_data)
        if response.status_code in [200, 302]:
            print("✅ 供應商可以創建報價")
        else:
            print(f"❌ 報價創建失敗，狀態碼: {response.status_code}")
            
        # 測試訊息列表
        response = client.get(reverse('messaging:message_list'))
        if response.status_code == 200:
            print("✅ 訊息列表頁面正常")
        else:
            print(f"❌ 訊息列表頁面錯誤，狀態碼: {response.status_code}")
            
    except Exception as e:
        print(f"❌ 訊息系統測試出錯: {e}")

def test_permissions():
    """測試權限控制"""
    print("\n🔒 測試權限控制...")
    
    client = Client()
    
    # 測試未登入用戶
    protected_urls = [
        'events:create_event',
        'messaging:create_quote',
        'messaging:message_list'
    ]
    
    for url_name in protected_urls:
        try:
            response = client.get(reverse(url_name))
            if response.status_code == 302:  # 重定向到登入頁面
                print(f"✅ {url_name} 正確保護，未登入用戶被重定向")
            else:
                print(f"❌ {url_name} 權限漏洞，未登入用戶可以訪問")
        except Exception as e:
            print(f"⚠️ {url_name} 測試出錯: {e}")

def test_form_validation():
    """測試表單驗證"""
    print("\n📝 測試表單驗證...")
    
    client = Client()
    
    # 創建測試用戶並登入
    try:
        user = User.objects.filter(username__startswith='test_normal_').first()
        if not user:
            user = User.objects.create_user(
                username='test_validation_user',
                email='validation@test.com',
                password='testpass123'
            )
        
        client.login(username=user.username, password='testpass123')
        
        # 測試無效的活動數據
        invalid_data = {
            'title': '',  # 空標題
            'description': 'a' * 2000,  # 過長描述
            'event_type': 999,  # 不存在的類型
            'budget_min': -1000,  # 負數
            'budget_max': 500,  # 最大值小於最小值
            'expected_attendees': 0,  # 零人數
            'event_date': 'invalid-date',  # 無效日期
            'location': '',  # 空地點
            'contact_person': '',
            'contact_phone': '123',  # 無效電話
            'contact_email': 'invalid-email'  # 無效郵箱
        }
        
        response = client.post(reverse('events:create_event'), invalid_data)
        if response.status_code == 200:  # 返回表單頁面，說明驗證生效
            if hasattr(response, 'context') and 'form' in response.context:
                form_errors = response.context['form'].errors
                if form_errors:
                    print("✅ 表單驗證正常工作，發現錯誤:")
                    for field, errors in form_errors.items():
                        print(f"  - {field}: {errors}")
                else:
                    print("❌ 表單驗證失效，無效數據被接受")
            else:
                print("❌ 無法檢查表單錯誤")
        else:
            print(f"❌ 表單驗證異常，狀態碼: {response.status_code}")
            
    except Exception as e:
        print(f"❌ 表單驗證測試出錯: {e}")

def main():
    """主測試函數"""
    print("🚀 開始全面Bug檢測...")
    print("=" * 60)
    
    # 導入datetime
    from datetime import datetime
    
    try:
        test_user_roles()
        test_messaging_system()
        test_permissions()
        test_form_validation()
        
        print("\n" + "=" * 60)
        print("🏁 Bug檢測完成")
        print("=" * 60)
        
    except Exception as e:
        print(f"❌ 測試過程中發生嚴重錯誤: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    main()
