#!/usr/bin/env python
"""
診斷供應商檔案 Not Found 問題
"""

import os
import sys

# 設定 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')

import django
django.setup()

from suppliers.models import Supplier

def main():
    print("🔍 供應商檔案 Not Found 診斷")
    print("="*50)
    
    # 查看所有供應商
    suppliers = Supplier.objects.all()
    print(f"📊 總共有 {suppliers.count()} 個供應商檔案")
    
    if suppliers.exists():
        print("\n📋 供應商列表:")
        for supplier in suppliers:
            print(f"  ID: {supplier.pk}")
            print(f"  公司名稱: {supplier.company_name}")
            print(f"  狀態: {supplier.status}")
            print(f"  用戶: {supplier.user.username if supplier.user else '無'}")
            print(f"  創建時間: {supplier.created_at}")
            print("-" * 30)
    
    # 檢查狀態為 'approved' 的供應商
    approved_suppliers = Supplier.objects.filter(status='approved')
    print(f"\n✅ 已審核通過的供應商: {approved_suppliers.count()} 個")
    
    # 檢查狀態為 'pending' 的供應商
    pending_suppliers = Supplier.objects.filter(status='pending')
    print(f"⏳ 等待審核的供應商: {pending_suppliers.count()} 個")
    
    # 檢查狀態為 'rejected' 的供應商
    rejected_suppliers = Supplier.objects.filter(status='rejected')
    print(f"❌ 被拒絕的供應商: {rejected_suppliers.count()} 個")
    
    # 修復建議
    if pending_suppliers.exists():
        print(f"\n🔧 修復建議:")
        print(f"檢測到 {pending_suppliers.count()} 個等待審核的供應商")
        print("這是導致 Not Found 錯誤的原因，因為詳情頁面只顯示已審核通過的供應商")
        
        # 詢問是否要修改狀態
        latest_supplier = pending_suppliers.order_by('-created_at').first()
        if latest_supplier:
            print(f"\n最新的供應商檔案:")
            print(f"  ID: {latest_supplier.pk}")
            print(f"  公司名稱: {latest_supplier.company_name}")
            print(f"  狀態: {latest_supplier.status}")
            
            # 自動修改為審核通過狀態
            print(f"\n🛠️ 正在修改供應商 ID {latest_supplier.pk} 的狀態為 'approved'...")
            latest_supplier.status = 'approved'
            latest_supplier.save()
            print("✅ 狀態修改成功！")
            
            # 驗證修改
            updated_supplier = Supplier.objects.get(pk=latest_supplier.pk)
            print(f"✓ 驗證: 供應商 {updated_supplier.pk} 狀態現在是 '{updated_supplier.status}'")

if __name__ == "__main__":
    main()
