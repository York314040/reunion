from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Supplier


class SupplierRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True, label="電子信箱")
    first_name = forms.CharField(max_length=30, required=True, label="姓名")
    
    class Meta:
        model = User
        fields = ("username", "first_name", "email", "password1", "password2")
        labels = {
            'username': '使用者名稱',
        }
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data["email"]
        user.first_name = self.cleaned_data["first_name"]
        if commit:
            user.save()
        return user


class SupplierForm(forms.ModelForm):
    class Meta:
        model = Supplier
        fields = [
            'company_name', 'service_categories', 'description', 'experience_years',
            'service_area', 'contact_person', 'contact_phone', 'contact_email',
            'website', 'price_range_min', 'price_range_max', 'logo', 'portfolio_images'
        ]
        labels = {
            'company_name': '公司名稱',
            'service_categories': '服務類別',
            'description': '服務描述',
            'experience_years': '經驗年數',
            'service_area': '服務區域',
            'contact_person': '聯絡人',
            'contact_phone': '聯絡電話',
            'contact_email': '聯絡信箱',
            'website': '官方網站',
            'price_range_min': '價格範圍下限 (新台幣)',
            'price_range_max': '價格範圍上限 (新台幣)',
            'logo': '公司標誌',
            'portfolio_images': '作品集圖片URL',
        }
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
            'portfolio_images': forms.Textarea(attrs={'rows': 2, 'placeholder': '多個URL用逗號分隔'}),
            'service_categories': forms.CheckboxSelectMultiple(),
            'price_range_min': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '1',
                'max': '99999999',
                'step': '1',
                'placeholder': '最低價格 (新台幣)'
            }),
            'price_range_max': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '1',
                'max': '99999999',
                'step': '1',
                'placeholder': '最高價格 (新台幣)'
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 確保價格字段的HTML屬性正確設置
        self.fields['price_range_min'].widget.attrs.update({
            'min': '1',
            'max': '99999999',
            'step': '1'
        })
        self.fields['price_range_max'].widget.attrs.update({
            'min': '1',
            'max': '99999999',
            'step': '1'
        })

    def clean_price_range_min(self):
        """驗證價格範圍下限"""
        price_min = self.cleaned_data.get('price_range_min')
        if price_min is not None:
            if price_min < 1:
                raise forms.ValidationError('價格下限不能小於1元')
            if price_min > 99999999:
                raise forms.ValidationError('價格下限不能超過99,999,999元')
        return price_min

    def clean_price_range_max(self):
        """驗證價格範圍上限"""
        price_max = self.cleaned_data.get('price_range_max')
        if price_max is not None:
            if price_max < 1:
                raise forms.ValidationError('價格上限不能小於1元')
            if price_max > 99999999:
                raise forms.ValidationError('價格上限不能超過99,999,999元')
        return price_max

    def clean(self):
        """驗證價格範圍邏輯"""
        cleaned_data = super().clean()
        price_min = cleaned_data.get('price_range_min')
        price_max = cleaned_data.get('price_range_max')
        
        if price_min and price_max:
            if price_min >= price_max:
                raise forms.ValidationError('價格上限必須大於價格下限')
        
        return cleaned_data


class SupplierSearchForm(forms.Form):
    query = forms.CharField(
        max_length=200,
        required=False,
        label="搜尋關鍵字",
        widget=forms.TextInput(attrs={'placeholder': '輸入公司名稱、服務內容等關鍵字'})
    )
    service_category = forms.ModelChoiceField(
        queryset=None,
        required=False,
        label="服務類別",
        empty_label="所有類別"
    )
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from .models import ServiceCategory
        self.fields['service_category'].queryset = ServiceCategory.objects.all()
