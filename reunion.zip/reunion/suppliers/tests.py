from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
from .models import Supplier, ServiceCategory


class ServiceCategoryModelTest(TestCase):
    """服務類別模型測試"""
    
    def setUp(self):
        self.category = ServiceCategory.objects.create(
            name='餐飲服務',
            description='提供各種餐飲相關服務'
        )
    
    def test_category_creation(self):
        """測試服務類別創建"""
        self.assertEqual(self.category.name, '餐飲服務')
        self.assertEqual(str(self.category), '餐飲服務')
    
    def test_category_description_optional(self):
        """測試描述欄位為可選"""
        category = ServiceCategory.objects.create(name='測試類別')
        self.assertEqual(category.description, '')


class SupplierModelTest(TestCase):
    """供應商模型測試"""
    
    def setUp(self):
        self.user = User.objects.create_user(
            username='supplier_user',
            email='supplier@example.com',
            password='supplierpass123'
        )
        
        self.category = ServiceCategory.objects.create(
            name='活動策劃',
            description='活動策劃服務'
        )
        
        self.supplier = Supplier.objects.create(
            user=self.user,
            company_name='測試活動公司',
            description='專業的活動策劃公司',
            experience_years=5,
            service_area='台北市',
            contact_person='張三',
            contact_phone='02-12345678',
            contact_email='info@testcompany.com',
            website='https://www.testcompany.com',
            price_range_min=10000,
            price_range_max=50000
        )
        
        self.supplier.service_categories.add(self.category)
    
    def test_supplier_creation(self):
        """測試供應商創建"""
        self.assertEqual(self.supplier.company_name, '測試活動公司')
        self.assertEqual(self.supplier.user, self.user)
        self.assertEqual(self.supplier.status, 'pending')
    
    def test_supplier_service_categories(self):
        """測試供應商服務類別關聯"""
        self.assertIn(self.category, self.supplier.service_categories.all())
    
    def test_supplier_str_method(self):
        """測試供應商字串表示"""
        supplier_str = str(self.supplier)
        self.assertIn('測試活動公司', supplier_str)
    
    def test_one_to_one_relationship(self):
        """測試一對一關聯"""
        # 同一個用戶不能創建多個供應商資料
        with self.assertRaises(Exception):
            Supplier.objects.create(
                user=self.user,  # 重複使用同一個用戶
                company_name='另一家公司'
            )


class SupplierViewTest(TestCase):
    """供應商視圖測試"""
    
    def setUp(self):
        self.client = Client()
        
        # 創建一般用戶
        self.user = User.objects.create_user(
            username='testuser',
            password='testpass123'
        )
        
        # 創建供應商用戶
        self.supplier_user = User.objects.create_user(
            username='supplier',
            password='supplierpass123'
        )
        
        self.category = ServiceCategory.objects.create(
            name='餐飲服務'
        )
        
        self.supplier = Supplier.objects.create(
            user=self.supplier_user,
            company_name='測試餐飲公司',
            description='專業餐飲服務',
            experience_years=3,
            service_area='台北市',
            contact_person='李四',
            contact_phone='02-87654321',
            contact_email='catering@example.com',
            price_range_min=5000,
            price_range_max=20000
        )
        self.supplier.service_categories.add(self.category)
    
    def test_supplier_list_access(self):
        """測試供應商列表訪問"""
        try:
            url = reverse('suppliers:supplier_list')
            response = self.client.get(url)
            self.assertIn(response.status_code, [200, 302])
        except:
            self.skipTest("供應商列表URL不存在")
    
    def test_supplier_registration_access(self):
        """測試供應商註冊頁面"""
        self.client.login(username='testuser', password='testpass123')
        
        try:
            url = reverse('suppliers:register')
            response = self.client.get(url)
            self.assertIn(response.status_code, [200, 302])
        except:
            self.skipTest("供應商註冊URL不存在")


class SupplierBusinessLogicTest(TestCase):
    """供應商業務邏輯測試"""
    
    def setUp(self):
        self.user = User.objects.create_user(
            username='business_user',
            password='businesspass123'
        )
        
        self.categories = [
            ServiceCategory.objects.create(name='餐飲'),
            ServiceCategory.objects.create(name='場地'),
            ServiceCategory.objects.create(name='攝影')
        ]
    
    def test_supplier_status_workflow(self):
        """測試供應商狀態流程"""
        supplier = Supplier.objects.create(
            user=self.user,
            company_name='測試公司',
            description='測試供應商',
            experience_years=2,
            service_area='台北市',
            contact_person='測試人',
            contact_phone='0900000000',
            contact_email='test@example.com',
            price_range_min=1000,
            price_range_max=5000,
            status='pending'
        )
        
        # 初始狀態為待審核
        self.assertEqual(supplier.status, 'pending')
        
        # 審核通過
        supplier.status = 'approved'
        supplier.save()
        self.assertEqual(supplier.status, 'approved')
        
        # 審核拒絕
        supplier.status = 'rejected'
        supplier.save()
        self.assertEqual(supplier.status, 'rejected')
    
    def test_multiple_service_categories(self):
        """測試多重服務類別"""
        supplier = Supplier.objects.create(
            user=self.user,
            company_name='綜合服務公司',
            description='提供多項服務',
            experience_years=5,
            service_area='全台灣',
            contact_person='服務人員',
            contact_phone='0900000000',
            contact_email='service@example.com',
            price_range_min=5000,
            price_range_max=30000
        )
        
        # 添加多個服務類別
        for category in self.categories:
            supplier.service_categories.add(category)
        
        self.assertEqual(supplier.service_categories.count(), 3)
        
        # 移除一個服務類別
        supplier.service_categories.remove(self.categories[0])
        self.assertEqual(supplier.service_categories.count(), 2)


class SupplierDataValidationTest(TestCase):
    """供應商資料驗證測試"""
    
    def setUp(self):
        self.user = User.objects.create_user(
            username='validation_user',
            password='validationpass123'
        )
    
    def test_required_fields(self):
        """測試必填欄位"""
        # 缺少公司名稱應該失敗
        with self.assertRaises(Exception):
            Supplier.objects.create(
                user=self.user,
                company_name=''  # 空的公司名稱
            )
    
    def test_email_validation(self):
        """測試電子郵件格式驗證"""
        supplier = Supplier.objects.create(
            user=self.user,
            company_name='測試公司',
            description='測試供應商',
            experience_years=1,
            service_area='台北市',
            contact_person='測試人',
            contact_phone='0900000000',
            contact_email='valid@email.com',
            price_range_min=1000,
            price_range_max=5000
        )
        
        self.assertEqual(supplier.contact_email, 'valid@email.com')
    
    def test_phone_field(self):
        """測試電話欄位"""
        supplier = Supplier.objects.create(
            user=self.user,
            company_name='測試公司',
            description='測試供應商',
            experience_years=1,
            service_area='台北市',
            contact_person='測試人',
            contact_phone='02-12345678',
            contact_email='test@example.com',
            price_range_min=1000,
            price_range_max=5000
        )
        
        self.assertEqual(supplier.contact_phone, '02-12345678')
