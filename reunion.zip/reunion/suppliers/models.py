from django.db import models
from django.contrib.auth.models import User


class ServiceCategory(models.Model):
    """服務類別"""
    name = models.CharField(max_length=100, verbose_name="服務類別")
    description = models.TextField(blank=True, verbose_name="描述")
    
    class Meta:
        verbose_name = "服務類別"
        verbose_name_plural = "服務類別"
    
    def __str__(self):
        return self.name


class Supplier(models.Model):
    """供應商"""
    STATUS_CHOICES = [
        ('pending', '待審核'),
        ('approved', '已通過'),
        ('rejected', '已拒絕'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name="使用者")
    company_name = models.CharField(max_length=200, verbose_name="公司名稱")
    service_categories = models.ManyToManyField(ServiceCategory, verbose_name="服務類別")
    
    # 基本資訊
    description = models.TextField(verbose_name="服務描述")
    experience_years = models.PositiveIntegerField(verbose_name="經驗年數")
    service_area = models.CharField(max_length=200, verbose_name="服務區域")
    
    # 聯絡資訊
    contact_person = models.CharField(max_length=100, verbose_name="聯絡人")
    contact_phone = models.CharField(max_length=20, verbose_name="聯絡電話")
    contact_email = models.EmailField(verbose_name="聯絡信箱")
    website = models.URLField(blank=True, verbose_name="官方網站")
    
    # 價格資訊
    price_range_min = models.PositiveIntegerField(verbose_name="價格範圍下限", help_text="新台幣")
    price_range_max = models.PositiveIntegerField(verbose_name="價格範圍上限", help_text="新台幣")
    
    # 其他資訊
    logo = models.ImageField(upload_to='supplier_logos/', blank=True, verbose_name="公司標誌")
    portfolio_images = models.TextField(blank=True, verbose_name="作品集圖片URL", help_text="多個URL用逗號分隔")
    
    # 狀態管理
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending', verbose_name="狀態")
    featured = models.BooleanField(default=False, verbose_name="推薦供應商")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="建立時間")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="更新時間")
    
    class Meta:
        verbose_name = "供應商"
        verbose_name_plural = "供應商"
        ordering = ['-featured', '-created_at']
    
    def __str__(self):
        return self.company_name
    
    def get_portfolio_images_list(self):
        """取得作品集圖片列表"""
        if self.portfolio_images:
            return [url.strip() for url in self.portfolio_images.split(',')]
        return []
