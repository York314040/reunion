from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Q
from .models import Supplier, ServiceCategory
from .forms import SupplierForm, SupplierRegistrationForm, SupplierSearchForm


def supplier_list(request):
    """供應商列表"""
    suppliers = Supplier.objects.filter(status='approved')
    
    # 搜尋功能
    form = SupplierSearchForm(request.GET)
    if form.is_valid():
        query = form.cleaned_data.get('query')
        service_category = form.cleaned_data.get('service_category')
        
        if query:
            suppliers = suppliers.filter(
                Q(company_name__icontains=query) |
                Q(description__icontains=query) |
                Q(service_area__icontains=query)
            )
        
        if service_category:
            suppliers = suppliers.filter(service_categories=service_category)
    
    # 分頁
    paginator = Paginator(suppliers, 12)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'search_form': form,
    }
    return render(request, 'suppliers/supplier_list.html', context)


def supplier_detail(request, pk):
    """供應商詳情"""
    supplier = get_object_or_404(Supplier, pk=pk, status='approved')
    context = {
        'supplier': supplier,
    }
    return render(request, 'suppliers/supplier_detail.html', context)


@login_required
def create_supplier_profile(request):
    """建立供應商檔案"""
    # 檢查是否已經有供應商檔案
    try:
        supplier = request.user.supplier
        return redirect('suppliers:edit_supplier_profile')
    except Supplier.DoesNotExist:
        pass
    
    if request.method == 'POST':
        form = SupplierForm(request.POST, request.FILES)
        if form.is_valid():
            supplier = form.save(commit=False)
            supplier.user = request.user
            supplier.save()
            form.save_m2m()  # 保存多對多關係
            messages.success(request, '供應商檔案已提交，等待審核。')
            return redirect('suppliers:my_supplier_profile')
    else:
        form = SupplierForm()
    
    context = {
        'form': form,
    }
    return render(request, 'suppliers/create_supplier_profile.html', context)


@login_required
def edit_supplier_profile(request):
    """編輯供應商檔案"""
    try:
        supplier = request.user.supplier
    except Supplier.DoesNotExist:
        return redirect('suppliers:create_supplier_profile')
    
    if request.method == 'POST':
        form = SupplierForm(request.POST, request.FILES, instance=supplier)
        if form.is_valid():
            form.save()
            messages.success(request, '供應商檔案已更新。')
            return redirect('suppliers:my_supplier_profile')
    else:
        form = SupplierForm(instance=supplier)
    
    context = {
        'form': form,
        'supplier': supplier,
    }
    return render(request, 'suppliers/edit_supplier_profile.html', context)


def supplier_register(request):
    """供應商註冊"""
    if request.method == 'POST':
        form = SupplierRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, '註冊成功！請完善您的供應商檔案。')
            return redirect('suppliers:create_supplier_profile')
    else:
        form = SupplierRegistrationForm()
    
    context = {
        'form': form,
    }
    return render(request, 'suppliers/supplier_register.html', context)


@login_required
def my_supplier_profile(request):
    """我的供應商檔案 - 顯示供應商檔案狀態和詳情"""
    try:
        supplier = request.user.supplier
    except Supplier.DoesNotExist:
        messages.info(request, '您尚未建立供應商檔案。')
        return redirect('suppliers:create_supplier_profile')
    
    context = {
        'supplier': supplier,
        'can_edit': True,  # 用戶總是可以編輯自己的檔案
    }
    return render(request, 'suppliers/my_supplier_profile.html', context)
