from django.contrib import admin
from .models import ServiceCategory, Supplier


@admin.register(ServiceCategory)
class ServiceCategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'description']
    search_fields = ['name']


@admin.register(Supplier)
class SupplierAdmin(admin.ModelAdmin):
    list_display = ['company_name', 'user', 'status', 'featured', 'created_at']
    list_filter = ['status', 'featured', 'service_categories', 'created_at']
    search_fields = ['company_name', 'description', 'user__username']
    readonly_fields = ['created_at', 'updated_at']
    filter_horizontal = ['service_categories']
    
    fieldsets = (
        ('基本資訊', {
            'fields': ('user', 'company_name', 'service_categories', 'status', 'featured')
        }),
        ('服務資訊', {
            'fields': ('description', 'experience_years', 'service_area')
        }),
        ('聯絡資訊', {
            'fields': ('contact_person', 'contact_phone', 'contact_email', 'website')
        }),
        ('價格資訊', {
            'fields': ('price_range_min', 'price_range_max')
        }),
        ('媒體資訊', {
            'fields': ('logo', 'portfolio_images')
        }),
        ('時間戳記', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
