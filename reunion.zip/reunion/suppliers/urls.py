from django.urls import path
from . import views

app_name = 'suppliers'

urlpatterns = [
    path('', views.supplier_list, name='supplier_list'),
    path('<int:pk>/', views.supplier_detail, name='supplier_detail'),
    path('create/', views.create_supplier_profile, name='create_supplier_profile'),
    path('edit/', views.edit_supplier_profile, name='edit_supplier_profile'),
    path('my-profile/', views.my_supplier_profile, name='my_supplier_profile'),
    path('register/', views.supplier_register, name='supplier_register'),
]
