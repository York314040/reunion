#!/usr/bin/env python
"""
詳細說明 Django 用戶權限系統
"""

import os
import sys
import django

# 設置Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission

User = get_user_model()

def explain_user_permissions():
    """詳細說明用戶權限系統"""
    
    print("🔍 Django 用戶權限系統說明")
    print("=" * 80)
    
    print("\n📋 用戶類型及權限:")
    print("-" * 50)
    
    print("\n1️⃣ 普通用戶 (Regular User)")
    print("   - is_superuser: False")
    print("   - is_staff: False")
    print("   - is_active: True")
    print("   ✅ 可以做的事:")
    print("     • 登入前台系統")
    print("     • 瀏覽供應商、DJ、活動")
    print("     • 發送訊息")
    print("     • 創建活動需求")
    print("     • 管理自己的個人資料")
    print("   ❌ 不能做的事:")
    print("     • 訪問 Django Admin 管理後台")
    print("     • 管理其他用戶")
    print("     • 修改系統設定")
    
    print("\n2️⃣ 管理員 (Staff)")
    print("   - is_superuser: False")
    print("   - is_staff: True")
    print("   - is_active: True")
    print("   ✅ 可以做的事:")
    print("     • 普通用戶的所有功能")
    print("     • 訪問 Django Admin 管理後台")
    print("     • 根據分配的權限管理特定模型")
    print("     • 查看和編輯被授權的數據")
    print("   ❌ 不能做的事:")
    print("     • 管理其他用戶的權限")
    print("     • 訪問沒有權限的模型")
    print("     • 執行超級用戶專屬功能")
    
    print("\n3️⃣ 超級用戶 (Superuser)")
    print("   - is_superuser: True")
    print("   - is_staff: True (自動設為 True)")
    print("   - is_active: True")
    print("   ✅ 可以做的事:")
    print("     • 普通用戶和管理員的所有功能")
    print("     • 完全訪問 Django Admin 管理後台")
    print("     • 管理所有用戶和權限")
    print("     • 訪問所有模型和數據")
    print("     • 執行系統級操作")
    print("     • 創建和刪除其他超級用戶")
    print("     • 修改系統設定")
    print("     • 執行數據庫操作")
    
    print("\n🔐 權限檢查機制:")
    print("-" * 50)
    print("在 Django 中，權限檢查的優先級:")
    print("1. 如果 is_superuser=True → 自動擁有所有權限")
    print("2. 如果 is_staff=True → 可以登入 admin，但需要具體權限")
    print("3. 如果 is_active=False → 無法登入任何系統")
    
    print("\n💡 實際範例:")
    print("-" * 50)
    
    # 檢查現有用戶
    users = User.objects.all()
    print(f"\n📊 系統中共有 {users.count()} 個用戶:")
    
    for user in users:
        print(f"\n👤 用戶: {user.username}")
        print(f"   📧 Email: {user.email}")
        print(f"   🏆 超級用戶: {'是' if user.is_superuser else '否'}")
        print(f"   🛡️ 管理員: {'是' if user.is_staff else '否'}")
        print(f"   ✅ 啟用: {'是' if user.is_active else '否'}")
        print(f"   📅 加入日期: {user.date_joined.strftime('%Y-%m-%d')}")
        
        # 權限分析
        if user.is_superuser:
            print("   🔥 權限級別: 超級用戶 - 擁有完全控制權")
        elif user.is_staff:
            print("   ⚡ 權限級別: 管理員 - 可訪問後台但受限")
        else:
            print("   👥 權限級別: 普通用戶 - 僅前台功能")
    
    print("\n🎯 在我們的 B2B 派對平台中:")
    print("-" * 50)
    print("• 超級用戶: 平台擁有者/技術管理員")
    print("  - 可以管理所有供應商、DJ、用戶")
    print("  - 可以調整其他用戶的權限")
    print("  - 可以訪問所有數據和設定")
    print("  - 可以執行系統維護操作")
    print("\n• 管理員: 平台營運人員")
    print("  - 可以審核供應商申請")
    print("  - 可以管理活動和內容")
    print("  - 可以處理用戶問題")
    print("  - 但不能修改用戶權限")
    print("\n• 普通用戶: 客戶和供應商")
    print("  - 客戶: 尋找供應商、創建活動需求")
    print("  - 供應商: 管理服務、回應需求")
    print("  - DJ: 管理音樂服務、展示作品")

def check_permission_code():
    """檢查權限相關的代碼實現"""
    print("\n\n🔧 權限檢查代碼範例:")
    print("-" * 50)
    
    print("""
# 在 Django 視圖中檢查權限:

# 1. 檢查是否為超級用戶
if request.user.is_superuser:
    # 可以做任何事情
    pass

# 2. 檢查是否為管理員
if request.user.is_staff:
    # 可以訪問 admin
    pass

# 3. 檢查是否啟用
if request.user.is_active:
    # 可以正常使用系統
    pass

# 4. 組合檢查
if request.user.is_authenticated and request.user.is_active:
    if request.user.is_superuser:
        # 超級用戶邏輯
        pass
    elif request.user.is_staff:
        # 管理員邏輯
        pass
    else:
        # 普通用戶邏輯
        pass
""")

def main():
    """主函數"""
    explain_user_permissions()
    check_permission_code()

if __name__ == '__main__':
    main()
