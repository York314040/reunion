#!/usr/bin/env python
import os
import django

# 設置Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from dj_management.models import DJCategory, DJ
from django.contrib.auth.models import User

def create_dj_categories():
    """創建DJ分類"""
    categories = [
        {'name': 'House', 'description': '深受歡迎的電子舞曲風格'},
        {'name': 'Techno', 'description': '具有強烈節拍的電子音樂'},
        {'name': 'Hip-Hop', 'description': '說唱和嘻哈音樂'},
        {'name': 'Rock', 'description': '搖滾音樂風格'},
        {'name': 'Pop', 'description': '流行音樂'},
        {'name': 'Jazz', 'description': '爵士樂風格'},
        {'name': 'Wedding', 'description': '婚禮音樂專門'},
        {'name': 'Party', 'description': '派對音樂'},
    ]

    print("創建DJ分類...")
    for cat_data in categories:
        category, created = DJCategory.objects.get_or_create(
            name=cat_data['name'],
            defaults={'description': cat_data['description']}
        )
        if created:
            print(f"✓ 已創建分類: {category.name}")
        else:
            print(f"- 分類已存在: {category.name}")

def create_sample_djs():
    """創建示例DJ"""
    print("\n創建示例DJ...")
    
    # 獲取分類
    house_category = DJCategory.objects.get(name='House')
    techno_category = DJCategory.objects.get(name='Techno')
    wedding_category = DJCategory.objects.get(name='Wedding')
    
    sample_djs = [
        {
            'username': 'dj_neon',
            'email': 'dj.neon@email.com',
            'stage_name': 'DJ NEON',
            'category': house_category,
            'description': '擁有10年以上經驗的專業House DJ，擅長營造熱情洋溢的派對氛圍。曾在台北各大知名夜店演出，深受年輕族群喜愛。專精於Deep House、Tech House等風格，能夠完美掌控現場氣氛，讓每位客人都能沉醉在音樂的魅力中。',
            'experience_level': 'professional',
            'price_per_hour': 3500,
            'minimum_hours': 3,
            'specialties': 'Deep House, Tech House, Progressive House',
            'service_areas': '台北市, 新北市, 桃園市',
            'is_available': True,
            'is_featured': True,
            'contact_email': 'dj.neon@email.com',
            'contact_phone': '0912-345-678',
        },
        {
            'username': 'dj_pulse',
            'email': 'dj.pulse@email.com',
            'stage_name': 'DJ PULSE',
            'category': techno_category,
            'description': '新生代Techno DJ，以獨特的混音技巧和選曲品味聞名。擅長融合傳統Techno與現代電子元素，創造出令人震撼的聽覺體驗。經常在地下音樂場所演出，擁有忠實的粉絲群體。',
            'experience_level': 'advanced',
            'price_per_hour': 2800,
            'minimum_hours': 2,
            'specialties': 'Techno, Minimal Techno, Industrial',
            'service_areas': '台北市, 新北市',
            'is_available': True,
            'is_featured': False,
            'contact_email': 'dj.pulse@email.com',
            'contact_phone': '0923-456-789',
        },
        {
            'username': 'dj_harmony',
            'email': 'dj.harmony@email.com',
            'stage_name': 'DJ HARMONY',
            'category': wedding_category,
            'description': '專業婚禮DJ，擁有豐富的婚宴主持經驗。深諳各種場合的音樂搭配，能夠完美配合婚禮流程，營造溫馨浪漫的氛圍。服務過上百場婚禮，深受新人好評。',
            'experience_level': 'professional',
            'price_per_hour': 4200,
            'minimum_hours': 4,
            'specialties': '婚禮音樂, 流行歌曲, 經典老歌',
            'service_areas': '台北市, 新北市, 桃園市, 新竹市',
            'is_available': True,
            'is_featured': True,
            'contact_email': 'dj.harmony@email.com',
            'contact_phone': '0934-567-890',
        }
    ]

    for dj_data in sample_djs:
        # 為每個DJ創建獨立的用戶
        user, user_created = User.objects.get_or_create(
            username=dj_data['username'],
            defaults={
                'email': dj_data['email'],
                'first_name': dj_data['stage_name'],
            }
        )
        if user_created:
            user.set_password('password123')
            user.save()
            print(f"✓ 已創建用戶: {user.username}")
        
        # 創建DJ個人檔案
        dj_profile_data = {k: v for k, v in dj_data.items() 
                          if k not in ['username', 'email']}
        dj_profile_data['user'] = user
        
        dj, created = DJ.objects.get_or_create(
            stage_name=dj_data['stage_name'],
            defaults=dj_profile_data
        )
        if created:
            print(f"✓ 已創建DJ: {dj.stage_name}")
        else:
            print(f"- DJ已存在: {dj.stage_name}")
    
    # 確保管理員用戶存在
    admin_user, created = User.objects.get_or_create(
        username='admin',
        defaults={
            'email': 'admin@reunion.com',
            'is_staff': True,
            'is_superuser': True
        }
    )
    if created:
        admin_user.set_password('admin123')
        admin_user.save()
        print("✓ 已創建管理員用戶")

if __name__ == '__main__':
    print("=== DJ管理系統初始化 ===\n")
    
    try:
        create_dj_categories()
        create_sample_djs()
        print(f"\n✅ 初始化完成！")
        print(f"- DJ分類: {DJCategory.objects.count()} 個")
        print(f"- 示例DJ: {DJ.objects.count()} 位")
        print("\n您現在可以訪問以下頁面：")
        print("- 熱門DJ: http://localhost:8000/dj/popular/")
        print("- DJ列表: http://localhost:8000/dj/")
        print("- DJ註冊: http://localhost:8000/dj/register/")
        
    except Exception as e:
        print(f"❌ 初始化失敗: {e}")
        import traceback
        traceback.print_exc()
