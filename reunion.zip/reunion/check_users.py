#!/usr/bin/env python
"""
檢查Heroku上的用戶資訊
"""
import os
import sys
import django

# 設置 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.contrib.auth.models import User

def check_users():
    """檢查所有用戶"""
    print("=== 所有用戶資訊 ===")
    users = User.objects.all()
    
    for user in users:
        print(f"用戶名: {user.username}")
        print(f"信箱: {user.email}")
        print(f"超級用戶: {user.is_superuser}")
        print(f"管理員: {user.is_staff}")
        print(f"啟用: {user.is_active}")
        print("-" * 30)
    
    print(f"總共 {users.count()} 個用戶")

if __name__ == "__main__":
    check_users()
