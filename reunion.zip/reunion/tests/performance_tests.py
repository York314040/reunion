"""
效能測試 (Performance Tests)
測試系統在不同負載下的表現
"""

import time
from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.test.utils import override_settings
from django.db import transaction
from django.utils import timezone
from datetime import timedelta

from events.models import Event, EventType
from suppliers.models import Supplier, ServiceCategory


class DatabasePerformanceTest(TestCase):
    """資料庫效能測試"""
    
    def setUp(self):
        self.client = Client()
        
        # 創建測試資料
        self.users = []
        self.event_types = []
        self.events = []
        
        # 批量創建用戶
        for i in range(100):
            user = User.objects.create_user(
                username=f'user_{i}',
                email=f'user_{i}@example.com',
                password='pass123'
            )
            self.users.append(user)
        
        # 創建活動類型
        for i in range(10):
            event_type = EventType.objects.create(
                name=f'活動類型_{i}',
                description=f'活動類型描述_{i}'
            )
            self.event_types.append(event_type)
    
    def test_bulk_event_creation_performance(self):
        """測試批量創建活動的效能"""
        start_time = time.time()
        
        # 批量創建活動
        events_to_create = []
        for i in range(200):
            event = Event(
                title=f'測試活動_{i}',
                description=f'活動描述_{i}',
                event_type=self.event_types[i % len(self.event_types)],
                organizer=self.users[i % len(self.users)],
                event_date=timezone.now() + timedelta(days=i % 365),
                location=f'地點_{i}',
                expected_attendees=50 + (i % 100),
                budget_min=5000 + (i % 10) * 1000,
                budget_max=10000 + (i % 20) * 1000,
                contact_person=f'聯絡人_{i}',
                contact_phone=f'09{i:08d}',
                contact_email=f'contact_{i}@example.com'
            )
            events_to_create.append(event)
        
        # 使用bulk_create提高效能
        Event.objects.bulk_create(events_to_create)
        
        end_time = time.time()
        creation_time = end_time - start_time
        
        # 確認創建成功
        self.assertEqual(Event.objects.count(), 200)
        
        # 效能檢查：應在5秒內完成
        self.assertLess(creation_time, 5.0, f"批量創建耗時過長: {creation_time:.2f}秒")
    
    def test_database_query_performance(self):
        """測試資料庫查詢效能"""
        # 先創建測試資料
        self.test_bulk_event_creation_performance()
        
        start_time = time.time()
        
        # 執行複雜查詢
        events = Event.objects.select_related('event_type', 'organizer').filter(
            event_date__gte=timezone.now(),
            status='pending'
        )[:50]
        
        # 強制執行查詢
        list(events)
        
        end_time = time.time()
        query_time = end_time - start_time
        
        # 查詢應在1秒內完成
        self.assertLess(query_time, 1.0, f"查詢耗時過長: {query_time:.2f}秒")
    
    def test_pagination_performance(self):
        """測試分頁效能"""
        # 創建大量測試資料
        self.test_bulk_event_creation_performance()
        
        start_time = time.time()
        
        # 測試分頁查詢
        page_size = 20
        for page in range(5):  # 測試前5頁
            offset = page * page_size
            events = Event.objects.all()[offset:offset + page_size]
            list(events)  # 強制執行查詢
        
        end_time = time.time()
        pagination_time = end_time - start_time
        
        # 分頁查詢應在2秒內完成
        self.assertLess(pagination_time, 2.0, f"分頁查詢耗時過長: {pagination_time:.2f}秒")


class ViewPerformanceTest(TestCase):
    """視圖效能測試"""
    
    def setUp(self):
        self.client = Client()
        
        # 創建測試用戶
        self.user = User.objects.create_user(
            username='testuser',
            password='pass123'
        )
        
        # 創建測試資料
        self.event_type = EventType.objects.create(name='測試類型')
        
        # 創建多個活動
        for i in range(50):
            Event.objects.create(
                title=f'活動_{i}',
                description=f'描述_{i}',
                event_type=self.event_type,
                organizer=self.user,
                event_date=timezone.now() + timedelta(days=i),
                location=f'地點_{i}',
                expected_attendees=50,
                budget_min=10000,
                budget_max=20000,
                contact_person='測試',
                contact_phone='0900000000',
                contact_email='test@test.com'
            )
    
    def test_homepage_load_time(self):
        """測試首頁載入時間"""
        start_time = time.time()
        
        response = self.client.get('/')
        
        end_time = time.time()
        load_time = end_time - start_time
        
        # 首頁應在1秒內載入
        self.assertEqual(response.status_code, 200)
        self.assertLess(load_time, 1.0, f"首頁載入耗時過長: {load_time:.2f}秒")
    
    def test_event_list_performance(self):
        """測試活動列表頁面效能"""
        try:
            from django.urls import reverse
            url = reverse('events:event_list')
            
            start_time = time.time()
            response = self.client.get(url)
            end_time = time.time()
            
            load_time = end_time - start_time
            
            # 活動列表應在2秒內載入
            if response.status_code == 200:
                self.assertLess(load_time, 2.0, f"活動列表載入耗時過長: {load_time:.2f}秒")
            
        except Exception as e:
            self.skipTest(f"活動列表效能測試失敗: {str(e)}")
    
    def test_search_performance(self):
        """測試搜尋功能效能"""
        try:
            from django.urls import reverse
            url = reverse('events:event_list')
            
            start_time = time.time()
            
            # 執行搜尋
            response = self.client.get(url, {'search': '活動'})
            
            end_time = time.time()
            search_time = end_time - start_time
            
            # 搜尋應在1.5秒內完成
            if response.status_code == 200:
                self.assertLess(search_time, 1.5, f"搜尋耗時過長: {search_time:.2f}秒")
            
        except Exception as e:
            self.skipTest(f"搜尋效能測試失敗: {str(e)}")


class ConcurrencyTest(TestCase):
    """並發測試"""
    
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(
            username='concurrent_user',
            password='pass123'
        )
        self.event_type = EventType.objects.create(name='並發測試類型')
    
    def test_concurrent_event_creation(self):
        """測試並發創建活動"""
        import threading
        import queue
        
        results = queue.Queue()
        
        def create_event(thread_id):
            """線程函數：創建活動"""
            try:
                with transaction.atomic():
                    event = Event.objects.create(
                        title=f'並發活動_{thread_id}',
                        description=f'並發測試活動_{thread_id}',
                        event_type=self.event_type,
                        organizer=self.user,
                        event_date=timezone.now() + timedelta(days=thread_id),
                        location=f'地點_{thread_id}',
                        expected_attendees=50,
                        budget_min=10000,
                        budget_max=20000,
                        contact_person=f'聯絡人_{thread_id}',
                        contact_phone=f'09{thread_id:08d}',
                        contact_email=f'test_{thread_id}@example.com'
                    )
                    results.put(('success', event.id))
            except Exception as e:
                results.put(('error', str(e)))
        
        # 創建多個線程同時創建活動
        threads = []
        num_threads = 10
        
        for i in range(num_threads):
            thread = threading.Thread(target=create_event, args=(i,))
            threads.append(thread)
        
        # 啟動所有線程
        start_time = time.time()
        for thread in threads:
            thread.start()
        
        # 等待所有線程完成
        for thread in threads:
            thread.join()
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        # 收集結果
        success_count = 0
        error_count = 0
        
        while not results.empty():
            result_type, result_data = results.get()
            if result_type == 'success':
                success_count += 1
            else:
                error_count += 1
        
        # 檢查結果
        self.assertGreater(success_count, 0, "應該有成功創建的活動")
        self.assertLess(execution_time, 5.0, f"並發執行耗時過長: {execution_time:.2f}秒")
        
        # 驗證資料庫中的活動數量
        created_events = Event.objects.filter(title__startswith='並發活動_')
        self.assertEqual(created_events.count(), success_count)


class MemoryUsageTest(TestCase):
    """記憶體使用測試"""
    
    def setUp(self):
        self.client = Client()
    
    def test_memory_usage_with_large_dataset(self):
        """測試大資料集的記憶體使用"""
        import psutil
        import os
        
        # 獲取當前進程
        process = psutil.Process(os.getpid())
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB
        
        # 創建大量測試資料
        users = []
        for i in range(500):
            user = User.objects.create_user(
                username=f'memory_user_{i}',
                password='pass123'
            )
            users.append(user)
        
        event_type = EventType.objects.create(name='記憶體測試')
        
        events = []
        for i in range(1000):
            event = Event.objects.create(
                title=f'記憶體測試活動_{i}',
                description=f'測試記憶體使用的活動_{i}',
                event_type=event_type,
                organizer=users[i % len(users)],
                event_date=timezone.now() + timedelta(days=i % 365),
                location=f'地點_{i}',
                expected_attendees=50,
                budget_min=10000,
                budget_max=20000,
                contact_person='測試',
                contact_phone='0900000000',
                contact_email='test@test.com'
            )
            events.append(event)
        
        # 執行查詢操作
        all_events = list(Event.objects.select_related('event_type', 'organizer').all())
        
        final_memory = process.memory_info().rss / 1024 / 1024  # MB
        memory_increase = final_memory - initial_memory
        
        # 記憶體增長不應超過100MB
        self.assertLess(memory_increase, 100, 
                       f"記憶體使用增長過多: {memory_increase:.2f}MB")
        
        # 清理
        del all_events
        del events
        del users


@override_settings(DEBUG=False)
class ProductionModeTest(TestCase):
    """生產環境模式測試"""
    
    def setUp(self):
        self.client = Client()
    
    def test_debug_mode_disabled(self):
        """測試生產環境下Debug模式已關閉"""
        from django.conf import settings
        self.assertFalse(settings.DEBUG, "生產環境應關閉DEBUG模式")
    
    def test_static_files_handling(self):
        """測試靜態文件處理"""
        # 測試CSS文件
        response = self.client.get('/static/css/style.css')
        # 在測試環境中可能返回404，這是正常的
        self.assertIn(response.status_code, [200, 404])
    
    def test_error_pages(self):
        """測試錯誤頁面"""
        # 測試404頁面
        response = self.client.get('/nonexistent-page/')
        self.assertEqual(response.status_code, 404)
        
        # 在生產環境中，應該有自定義404頁面而不顯示技術細節
        if hasattr(response, 'content'):
            content = response.content.decode('utf-8')
            self.assertNotIn('Traceback', content)
