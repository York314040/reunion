#!/usr/bin/env python
"""
測試金額字段輸入限制修復
"""

import os
import sys

# 設定 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')

import django
django.setup()

from messaging.forms import QuoteForm
from suppliers.forms import SupplierForm
from events.forms import EventForm
from datetime import datetime, timedelta

def test_quote_form():
    """測試報價表單金額限制"""
    print("🧪 測試報價表單金額限制")
    print("-" * 40)
    
    # 測試大金額
    test_cases = [
        {'price': 999, 'expected': True, 'desc': '3位數'},
        {'price': 9999, 'expected': True, 'desc': '4位數'},
        {'price': 99999, 'expected': True, 'desc': '5位數'},
        {'price': 999999, 'expected': True, 'desc': '6位數'},
        {'price': 9999999, 'expected': True, 'desc': '7位數'},
        {'price': 99999999, 'expected': True, 'desc': '8位數 (最大值)'},
        {'price': 100000000, 'expected': False, 'desc': '9位數 (超出範圍)'},
        {'price': 0, 'expected': False, 'desc': '零值'},
        {'price': -1, 'expected': False, 'desc': '負值'},
    ]
    
    from datetime import datetime, timedelta
    valid_until = datetime.now() + timedelta(days=7)
    
    for case in test_cases:
        form_data = {
            'price': case['price'],
            'description': '測試報價說明',
            'valid_until': valid_until.strftime('%Y-%m-%dT%H:%M')
        }
        
        form = QuoteForm(data=form_data)
        is_valid = form.is_valid()
        
        status = "✅ PASS" if is_valid == case['expected'] else "❌ FAIL"
        print(f"{status} {case['desc']}: {case['price']:,} 元 - 預期: {case['expected']}, 實際: {is_valid}")
        
        if not is_valid and case['expected']:
            print(f"     錯誤: {form.errors}")
        elif is_valid and not case['expected']:
            print(f"     警告: 應該要驗證失敗但通過了")

def test_supplier_form():
    """測試供應商表單價格限制"""
    print("\n🧪 測試供應商表單價格限制")
    print("-" * 40)
    
    test_cases = [
        {'min': 1000, 'max': 5000, 'expected': True, 'desc': '正常範圍'},
        {'min': 50000, 'max': 100000, 'expected': True, 'desc': '中等範圍'},
        {'min': 1000000, 'max': 5000000, 'expected': True, 'desc': '大金額範圍'},
        {'min': 10000000, 'max': 50000000, 'expected': True, 'desc': '超大金額範圍'},
        {'min': 50000000, 'max': 99999999, 'expected': True, 'desc': '最大範圍'},
        {'min': 5000, 'max': 1000, 'expected': False, 'desc': '下限大於上限'},
        {'min': 0, 'max': 5000, 'expected': False, 'desc': '下限為零'},
        {'min': 1000, 'max': 100000000, 'expected': False, 'desc': '上限超出範圍'},
    ]
    
    for case in test_cases:
        form_data = {
            'company_name': '測試公司',
            'description': '測試描述',
            'contact_person': '測試聯絡人',
            'phone': '0912345678',
            'email': 'test@test.com',
            'service_area': '台北市',
            'price_range_min': case['min'],
            'price_range_max': case['max'],
        }
        
        form = SupplierForm(data=form_data)
        is_valid = form.is_valid()
        
        status = "✅ PASS" if is_valid == case['expected'] else "❌ FAIL"
        print(f"{status} {case['desc']}: {case['min']:,} - {case['max']:,} 元 - 預期: {case['expected']}, 實際: {is_valid}")
        
        if not is_valid and case['expected']:
            print(f"     錯誤: {form.errors}")

def test_event_form():
    """測試活動表單預算限制"""
    print("\n🧪 測試活動表單預算限制")
    print("-" * 40)
    
    test_cases = [
        {'min': 10000, 'max': 50000, 'expected': True, 'desc': '正常預算'},
        {'min': 100000, 'max': 500000, 'expected': True, 'desc': '中等預算'},
        {'min': 1000000, 'max': 5000000, 'expected': True, 'desc': '大預算'},
        {'min': 10000000, 'max': 50000000, 'expected': True, 'desc': '超大預算'},
        {'min': 50000000, 'max': 99999999, 'expected': True, 'desc': '最大預算'},
        {'min': 50000, 'max': 10000, 'expected': False, 'desc': '下限大於上限'},
        {'min': 0, 'max': 50000, 'expected': False, 'desc': '下限為零'},
        {'min': 10000, 'max': 100000000, 'expected': False, 'desc': '上限超出範圍'},
    ]
    
    from datetime import datetime
    
    for case in test_cases:
        form_data = {
            'title': '測試活動',
            'description': '測試活動描述',
            'event_type': 'birthday',
            'event_date': (datetime.now() + timedelta(days=30)).strftime('%Y-%m-%dT%H:%M'),
            'location': '台北市',
            'expected_attendees': 50,
            'budget_min': case['min'],
            'budget_max': case['max'],
            'contact_person': '測試聯絡人',
            'contact_phone': '0912345678',
            'contact_email': 'test@test.com',
        }
        
        form = EventForm(data=form_data)
        is_valid = form.is_valid()
        
        status = "✅ PASS" if is_valid == case['expected'] else "❌ FAIL"
        print(f"{status} {case['desc']}: {case['min']:,} - {case['max']:,} 元 - 預期: {case['expected']}, 實際: {is_valid}")
        
        if not is_valid and case['expected']:
            print(f"     錯誤: {form.errors}")

def main():
    print("🔧 金額字段輸入限制修復測試")
    print("=" * 50)
    
    test_quote_form()
    test_supplier_form()
    test_event_form()
    
    print("\n" + "=" * 50)
    print("✅ 測試完成！")
    print("\n💡 修復摘要:")
    print("1. 報價金額: 支援 1 到 99,999,999 元")
    print("2. 供應商價格範圍: 支援 1 到 99,999,999 元")
    print("3. 活動預算: 支援 1 到 99,999,999 元")
    print("4. 添加了完整的表單驗證")
    print("5. 改善了用戶體驗和錯誤提示")

if __name__ == "__main__":
    main()
