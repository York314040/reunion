# 簡單 Heroku 更新部署腳本
Write-Host "🚀 開始 Heroku 更新部署..." -ForegroundColor Cyan

# 檢查是否在正確目錄
if (-not (Test-Path "manage.py")) {
    Write-Host "❌ 請在項目根目錄運行此腳本" -ForegroundColor Red
    exit 1
}

# 收集靜態文件
Write-Host "📦 收集靜態文件..." -ForegroundColor Yellow
python manage.py collectstatic --noinput

# 提交更改
Write-Host "📝 提交更改..." -ForegroundColor Yellow
git add .
git commit -m "Update: $(Get-Date -Format 'yyyy-MM-dd HH:mm') - 後端修復完成版本"

# 推送到 Heroku
Write-Host "🚀 推送到 Heroku..." -ForegroundColor Blue
git push heroku main

Write-Host "✅ 部署完成！" -ForegroundColor Green
Read-Host "按任意鍵退出"
