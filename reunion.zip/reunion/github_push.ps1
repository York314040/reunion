#!/usr/bin/env powershell
# GitHub推送腳本 - 處理認證問題

param(
    [string]$Token = ""
)

Write-Host "🚀 GitHub推送工具" -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor Cyan

# 檢查是否在正確目錄
if (-not (Test-Path "manage.py")) {
    Write-Host "❌ 錯誤: 請在Django專案根目錄執行此腳本" -ForegroundColor Red
    Read-Host "按Enter鍵退出"
    exit 1
}

# 如果沒有提供Token，詢問用戶
if ([string]::IsNullOrEmpty($Token)) {
    Write-Host ""
    Write-Host "🔑 需要Personal Access Token來推送到GitHub" -ForegroundColor Yellow
    Write-Host "取得Token的步驟：" -ForegroundColor White
    Write-Host "1. 前往 https://github.com/settings/tokens" -ForegroundColor Gray
    Write-Host "2. 點擊 'Generate new token (classic)'" -ForegroundColor Gray
    Write-Host "3. 選擇 'repo' 權限範圍" -ForegroundColor Gray
    Write-Host "4. 複製生成的token" -ForegroundColor Gray
    Write-Host ""
    
    $Token = Read-Host "請輸入您的Personal Access Token (或按Enter跳過)"
}

# 確保Git配置正確
Write-Host "🔧 配置Git設定..." -ForegroundColor Yellow
git config user.name "York314040"
git config user.email "nm6101103@gs.ncku.edu.tw"

# 配置遠程倉庫
Write-Host "🔗 配置遠程倉庫..." -ForegroundColor Yellow
git remote remove origin 2>$null
git remote add origin https://github.com/York314040/reunion.git

# 確保在main分支
Write-Host "📂 確保在main分支..." -ForegroundColor Yellow
git checkout main 2>$null
if ($LASTEXITCODE -ne 0) {
    git checkout -b main
}

# 添加所有文件
Write-Host "📦 添加所有文件..." -ForegroundColor Yellow
git add .

# 檢查是否有變更需要提交
$gitStatus = git status --porcelain
if ($gitStatus) {
    Write-Host "💾 提交變更..." -ForegroundColor Yellow
    git commit -m "完整B2B聚會派對媒合平台 - 準備推送到GitHub

- Django 4.2.23 Web應用程式
- 已修復價格驗證問題
- 已修復活動表單提交問題  
- 完整的使用者認證系統
- 響應式前端設計
- 詳細的專案文檔"
} else {
    Write-Host "✅ 沒有新的變更需要提交" -ForegroundColor Green
}

# 推送到GitHub
Write-Host "📤 推送到GitHub..." -ForegroundColor Yellow

if (-not [string]::IsNullOrEmpty($Token)) {
    # 使用Token推送
    $tokenUrl = "https://${Token}@github.com/York314040/reunion.git"
    git push $tokenUrl main
    $pushResult = $LASTEXITCODE
} else {
    # 嘗試正常推送（可能會提示輸入憑證）
    git push -u origin main
    $pushResult = $LASTEXITCODE
}

if ($pushResult -eq 0) {
    Write-Host ""
    Write-Host "🎉 成功推送到GitHub!" -ForegroundColor Green
    Write-Host "🌐 倉庫連結: https://github.com/York314040/reunion" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "✨ 您的B2B聚會派對媒合平台已成功上傳！" -ForegroundColor Green
} else {
    Write-Host ""
    Write-Host "❌ 推送失敗！" -ForegroundColor Red
    Write-Host ""
    Write-Host "💡 建議的解決方案：" -ForegroundColor Yellow
    Write-Host "1. 使用Personal Access Token (重新執行此腳本並提供Token)" -ForegroundColor White
    Write-Host "2. 使用GitHub Desktop應用程式" -ForegroundColor White
    Write-Host "3. 使用ZIP檔案上傳 (參考 UPLOAD_INSTRUCTIONS.md)" -ForegroundColor White
}

Write-Host ""
Read-Host "按Enter鍵退出"
