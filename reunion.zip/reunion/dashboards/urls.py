from django.urls import path
from . import views

app_name = 'dashboards'

urlpatterns = [
    # 儀表板路由器
    path('', views.dashboard_router, name='dashboard_router'),
    
    # 各角色專用儀表板
    path('dj/', views.dj_dashboard, name='dj_dashboard'),
    path('supplier/', views.supplier_dashboard, name='supplier_dashboard'),
    path('client/', views.client_dashboard, name='client_dashboard'),
    path('admin/', views.admin_dashboard, name='admin_dashboard'),
    path('staff/', views.staff_dashboard, name='staff_dashboard'),
]
