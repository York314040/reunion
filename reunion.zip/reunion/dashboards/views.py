from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.core.paginator import Paginator
from django.db.models import Q, Count, Avg, Sum, Prefetch
from django.utils import timezone
from django.core.exceptions import PermissionDenied
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_protect
from datetime import datetime, timedelta
import logging

from django.contrib.auth.models import User
from events.models import Event, EventType
from suppliers.models import Supplier
from dj_management.models import DJ, DJBooking, DJRating
from messaging.models import Conversation, Message

logger = logging.getLogger(__name__)


@login_required
def dashboard_router(request):
    """儀表板路由器 - 根據用戶角色導向不同儀表板"""
    user = request.user
    
    # 檢查用戶是否為DJ
    try:
        dj = DJ.objects.get(user=user)
        return redirect('dashboards:dj_dashboard')
    except DJ.DoesNotExist:
        pass
    
    # 檢查用戶是否為供應商
    try:
        supplier = Supplier.objects.get(user=user)
        return redirect('dashboards:supplier_dashboard')
    except Supplier.DoesNotExist:
        pass
    
    # 檢查是否為超級用戶/管理員
    if user.is_superuser:
        return redirect('dashboards:admin_dashboard')
    elif user.is_staff:
        return redirect('dashboards:staff_dashboard')
    
    # 一般客戶用戶
    return redirect('dashboards:client_dashboard')


@login_required
@csrf_protect
def dj_dashboard(request):
    """DJ專用儀表板"""
    try:
        dj = DJ.objects.select_related('user', 'category').get(user=request.user)
    except DJ.DoesNotExist:
        messages.info(request, '請先註冊成為DJ')
        return redirect('dj_management:dj_register')
    
    try:
        # 統計數據
        today = timezone.now().date()
        this_month = today.replace(day=1)
        
        # 預約統計 - 優化查詢
        pending_bookings = DJBooking.objects.filter(dj=dj, status='pending').select_related('supplier')
        confirmed_bookings = DJBooking.objects.filter(dj=dj, status='confirmed').select_related('supplier')
        completed_bookings = DJBooking.objects.filter(dj=dj, status='completed').select_related('supplier')
        total_bookings = DJBooking.objects.filter(dj=dj).select_related('supplier')
        
        # 本月收入
        month_earnings = completed_bookings.filter(
            event_date__gte=this_month
        ).aggregate(total=Sum('total_price'))['total'] or 0
        
        # 總收入
        total_earnings = completed_bookings.aggregate(
            total=Sum('total_price'))['total'] or 0
        
        # 評分統計 - 優化查詢
        ratings = DJRating.objects.filter(dj=dj).select_related('supplier')
        avg_rating = ratings.aggregate(avg=Avg('rating'))['avg'] or 0
        total_ratings = ratings.count()
        
        # 最近預約 - 限制查詢數量
        recent_bookings = DJBooking.objects.filter(dj=dj).select_related('supplier').order_by('-created_at')[:5]
        
        # 最近評價
        recent_ratings = ratings.order_by('-created_at')[:5]
        
        # 即將到來的演出
        upcoming_gigs = confirmed_bookings.filter(
            event_date__gte=today
        ).order_by('event_date')[:5]
        
        context = {
            'dj': dj,
            'pending_count': pending_bookings.count(),
            'confirmed_count': confirmed_bookings.count(),
            'completed_count': completed_bookings.count(),
            'total_bookings_count': total_bookings.count(),
            'month_earnings': month_earnings,
            'total_earnings': total_earnings,
            'avg_rating': round(avg_rating, 1) if avg_rating else 0,
            'total_ratings': total_ratings,
            'recent_bookings': recent_bookings,
            'recent_ratings': recent_ratings,
            'upcoming_gigs': upcoming_gigs,
        }
        
        return render(request, 'dashboards/dj_dashboard.html', context)
        
    except Exception as e:
        logger.error(f"DJ dashboard error for user {request.user.id}: {str(e)}")
        messages.error(request, '載入儀表板時發生錯誤，請稍後再試')
        return redirect('events:home')
    
    return render(request, 'dashboards/dj_dashboard.html', context)


@login_required
@csrf_protect
def supplier_dashboard(request):
    """供應商專用儀表板"""
    try:
        supplier = Supplier.objects.select_related('user').prefetch_related('service_categories').get(user=request.user)
    except Supplier.DoesNotExist:
        messages.info(request, '請先註冊成為供應商')
        return redirect('suppliers:create_supplier_profile')
    
    try:
        # 統計數據
        today = timezone.now().date()
        this_month = today.replace(day=1)
        
        # 訊息統計 - 優化查詢
        conversations = Conversation.objects.filter(
            supplier=supplier
        ).select_related('supplier').prefetch_related('participants')
        
        unread_messages = Message.objects.filter(
            conversation__supplier=supplier,
            is_read=False
        ).exclude(sender=request.user).select_related('sender', 'conversation')
        
        # 檔案瀏覽統計（這裡可以添加瀏覽次數追蹤）
        profile_views = 0  # 需要實現瀏覽次數追蹤
        
        # 服務類別 - 使用 prefetch_related 避免 N+1
        service_categories = supplier.service_categories.all()
        
        # 最近對話 - 限制查詢數量
        recent_conversations = conversations.order_by('-updated_at')[:5]
        
        # 相關活動（可能感興趣的活動）- 優化查詢
        if service_categories.exists():
            # 獲取所有活動，不依賴名稱匹配
            related_events = Event.objects.select_related('organizer', 'event_type').order_by('-created_at')[:5]
        else:
            related_events = Event.objects.none()
        
        context = {
            'supplier': supplier,
            'total_conversations': conversations.count(),
            'unread_messages_count': unread_messages.count(),
            'profile_views': profile_views,
            'service_categories': service_categories,
            'recent_conversations': recent_conversations,
            'related_events': related_events,
            'is_approved': supplier.status == 'approved',
        }
        
        return render(request, 'dashboards/supplier_dashboard.html', context)
        
    except Exception as e:
        logger.error(f"Supplier dashboard error for user {request.user.id}: {str(e)}")
        messages.error(request, '載入儀表板時發生錯誤，請稍後再試')
        return redirect('events:home')


@login_required
def client_dashboard(request):
    """客戶專用儀表板"""
    user = request.user
    
    # 統計數據
    my_events = Event.objects.filter(organizer=user)
    active_events = my_events.filter(status='published')
    completed_events = my_events.filter(status='completed')
    
    # DJ預約
    my_dj_bookings = DJBooking.objects.filter(client=user)
    pending_dj_bookings = my_dj_bookings.filter(status='pending')
    confirmed_dj_bookings = my_dj_bookings.filter(status='confirmed')
    
    # 對話
    my_conversations = Conversation.objects.filter(
        participants=user
    ).select_related('event', 'supplier').prefetch_related('participants')
    
    unread_messages = Message.objects.filter(
        conversation__participants=user,
        is_read=False
    ).exclude(sender=user).select_related('sender', 'conversation')
    
    # 最近活動
    recent_events = my_events.order_by('-created_at')[:5]
    
    # 最近預約
    recent_bookings = my_dj_bookings.order_by('-created_at')[:5]
    
    # 推薦DJ和供應商
    recommended_djs = DJ.objects.filter(
        status='approved',
        is_featured=True
    )[:4]
    
    recommended_suppliers = Supplier.objects.filter(
        status='approved',
        featured=True
    )[:4]
    
    context = {
        'total_events': my_events.count(),
        'active_events_count': active_events.count(),
        'completed_events_count': completed_events.count(),
        'pending_bookings_count': pending_dj_bookings.count(),
        'confirmed_bookings_count': confirmed_dj_bookings.count(),
        'total_conversations': my_conversations.count(),
        'unread_messages_count': unread_messages.count(),
        'recent_events': recent_events,
        'recent_bookings': recent_bookings,
        'recommended_djs': recommended_djs,
        'recommended_suppliers': recommended_suppliers,
    }
    
    return render(request, 'dashboards/client_dashboard.html', context)


@login_required
@csrf_protect
def admin_dashboard(request):
    """管理員專用儀表板"""
    if not request.user.is_superuser:
        logger.warning(f"Unauthorized admin dashboard access attempt by user {request.user.id}")
        raise PermissionDenied('您沒有權限訪問此頁面')
    
    try:
        # 統計數據
        today = timezone.now().date()
        this_month = today.replace(day=1)
        
        # 用戶統計
        total_users = User.objects.count()
        new_users_month = User.objects.filter(
            date_joined__gte=this_month
        ).count()
        
        # DJ統計 - 優化查詢
        total_djs = DJ.objects.count()
        pending_djs = DJ.objects.filter(status='pending').count()
        approved_djs = DJ.objects.filter(status='approved').count()
        
        # 供應商統計
        total_suppliers = Supplier.objects.count()
        pending_suppliers = Supplier.objects.filter(status='pending').count()
        approved_suppliers = Supplier.objects.filter(status='approved').count()
        
        # 活動統計
        total_events = Event.objects.count()
        active_events = Event.objects.filter(status='published').count()
        
        # 預約統計
        total_bookings = DJBooking.objects.count()
        pending_bookings = DJBooking.objects.filter(status='pending').count()
        
        # 最近註冊的用戶 - 限制敏感資訊
        recent_users = User.objects.only('id', 'username', 'date_joined', 'is_active').order_by('-date_joined')[:5]
        
        # 待審核項目 - 限制查詢數量
        pending_dj_list = DJ.objects.filter(status='pending').select_related('user')[:5]
        pending_supplier_list = Supplier.objects.filter(status='pending').select_related('user')[:5]
        
        context = {
            'total_users': total_users,
            'new_users_this_month': new_users_month,  # 修正變數名稱
            'total_djs': total_djs,
            'pending_dj_approvals': pending_djs,  # 修正變數名稱
            'approved_djs': approved_djs,
            'total_suppliers': total_suppliers,
            'pending_supplier_approvals': pending_suppliers,  # 修正變數名稱
            'approved_suppliers': approved_suppliers,
            'total_events': total_events,
            'active_events': active_events,
            'total_bookings': total_bookings,
            'pending_bookings': pending_bookings,
            'recent_users': recent_users,
            'pending_dj_list': pending_dj_list,
            'pending_supplier_list': pending_supplier_list,
        }
        
        return render(request, 'dashboards/admin_dashboard.html', context)
        
    except Exception as e:
        logger.error(f"Admin dashboard error for user {request.user.id}: {str(e)}")
        messages.error(request, '載入管理員儀表板時發生錯誤，請稍後再試')
        return redirect('events:home')
    
    return render(request, 'dashboards/admin_dashboard.html', context)


@login_required
def staff_dashboard(request):
    """一般管理員儀表板"""
    if not request.user.is_staff:
        messages.error(request, '您沒有權限訪問此頁面')
        return redirect('events:home')
    
    # 基礎統計（較少權限）
    total_events = Event.objects.count()
    active_events = Event.objects.filter(status='published').count()
    total_bookings = DJBooking.objects.count()
    
    # 最近活動
    recent_events = Event.objects.order_by('-created_at')[:10]
    
    context = {
        'total_events': total_events,
        'active_events': active_events,
        'total_bookings': total_bookings,
        'recent_events': recent_events,
    }
    
    return render(request, 'dashboards/staff_dashboard.html', context)
