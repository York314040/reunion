# PAPA COLLEGE B2B 聚會派對媒合平台

🎉 一個專為B2B聚會和派對活動設計的媒合平台

## 📋 功能特色

### 🎯 核心功能
- **供應商管理** - 完整的供應商註冊和管理系統
- **活動發布** - 多種類型的派對活動創建和管理
- **DJ 管理** - DJ 檔案管理和排名系統
- **用戶系統** - 用戶註冊、登入和個人資料管理
- **響應式設計** - 支援桌面和行動裝置

### 🎪 活動類型
- 生日派對
- 公司聚會
- 婚禮派對
- 畢業派對
- 節慶派對
- 主題派對
- 商務酒會
- 音樂派對
- 戶外派對
- 歡送派對

## 🚀 技術架構

### 後端技術
- **Django 4.2.23** - Python Web 框架
- **PostgreSQL** - 資料庫系統
- **Gunicorn** - WSGI HTTP 伺服器
- **WhiteNoise** - 靜態文件服務

### 前端技術
- **Bootstrap 4** - CSS 框架
- **Django Templates** - 模板系統
- **Crispy Forms** - 表單美化

### 部署平台
- **Heroku** - 雲端部署平台
- **GitHub** - 原始碼管理

## 🌐 線上版本

- **網站**: https://papa-college-b2b-ee7db6fb42bd.herokuapp.com/
- **管理後台**: https://papa-college-b2b-ee7db6fb42bd.herokuapp.com/admin/

## 🛠️ 本地開發

### 環境需求
- Python 3.9+
- Django 4.2+
- PostgreSQL (生產環境)
- SQLite (開發環境)

### 安裝步驟

1. **克隆專案**
```bash
git clone https://github.com/York314040/reunion.git
cd reunion
```

2. **創建虛擬環境**
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# 或
venv\Scripts\activate  # Windows
```

3. **安裝依賴**
```bash
pip install -r requirements.txt
```

4. **設置環境變數**
創建 `.env` 文件：
```
SECRET_KEY=your-secret-key
DEBUG=True
ALLOWED_HOSTS=localhost,127.0.0.1
```

5. **執行遷移**
```bash
python manage.py migrate
```

6. **創建超級用戶**
```bash
python manage.py createsuperuser
```

7. **啟動開發伺服器**
```bash
python manage.py runserver
```

## 📦 部署到 Heroku

使用自動化部署腳本：
```bash
python heroku_auto_deploy.py
```

或手動部署：
```bash
# 1. 創建 Heroku 應用
heroku create your-app-name

# 2. 設置環境變數
heroku config:set SECRET_KEY="your-secret-key"
heroku config:set DEBUG=False
heroku config:set ALLOWED_HOSTS="your-app.herokuapp.com"

# 3. 部署
git push heroku main

# 4. 執行遷移
heroku run python manage.py migrate

# 5. 創建超級用戶
heroku run python manage.py createsuperuser
```

## 📁 專案結構

```
reunion/
├── party_platform/          # Django 主要設定
├── events/                  # 活動管理應用
├── suppliers/               # 供應商管理應用
├── dj_management/           # DJ 管理應用
├── users/                   # 用戶管理應用
├── messaging/               # 訊息系統應用
├── static/                  # 靜態文件
├── templates/               # 模板文件
├── requirements.txt         # Python 依賴
├── Procfile                # Heroku 部署設定
├── runtime.txt             # Python 版本設定
└── manage.py               # Django 管理腳本
```

## 🔧 管理命令

### 本地開發
```bash
# 啟動開發伺服器
python manage.py runserver

# 創建新的遷移
python manage.py makemigrations

# 執行遷移
python manage.py migrate

# 收集靜態文件
python manage.py collectstatic

# 創建超級用戶
python manage.py createsuperuser
```

### Heroku 部署
```bash
# 查看應用狀態
heroku ps --app your-app-name

# 查看日誌
heroku logs --tail --app your-app-name

# 重啟應用
heroku restart --app your-app-name

# 執行 Django 命令
heroku run python manage.py <command> --app your-app-name
```

## 🤝 貢獻

歡迎提交 Issue 和 Pull Request 來改善專案！

## 📄 授權

本專案採用 MIT 授權條款。

## 👨‍💻 開發者

- **York** - 主要開發者
- **Email**: wssd314040@gmail.com

## 🙏 致謝

感謝所有為這個專案貢獻的開發者和使用者！

---

⭐ 如果這個專案對您有幫助，請給我們一個 Star！
