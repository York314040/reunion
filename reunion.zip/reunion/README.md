# 🎉 B2B聚會派對媒合平台

一個基於Django開發的B2B聚會派對媒合平台，連接活動主辦方、供應商和DJ，提供完整的活動策劃解決方案。

## 📋 功能特色

### 🎯 核心功能
- **活動需求發布** - 客戶可以發布詳細的活動需求
- **供應商管理** - 供應商註冊和服務展示
- **DJ管理系統** - DJ個人檔案和作品展示
- **報價系統** - 智能報價和比較功能
- **訊息交流** - 即時訊息溝通平台
- **儀表板分析** - 數據分析和業務洞察

### 💰 價格管理
- 支援1-99,999,999新台幣的價格範圍
- 智能價格驗證和格式化
- 預算範圍設定和比較

### 🔐 用戶權限
- 多角色用戶系統（客戶、供應商、DJ、管理員）
- 權限分級管理
- 活動狀態管理（待審核、已通過、已拒絕）

## 🛠 技術架構

### 後端技術
- **Django 4.2.23** - Web框架
- **Python 3.9+** - 程式語言
- **SQLite** - 資料庫（開發環境）
- **PostgreSQL** - 資料庫（生產環境）

### 前端技術
- **Bootstrap 4.6** - UI框架
- **HTML5/CSS3** - 標準網頁技術
- **JavaScript** - 互動功能
- **Font Awesome** - 圖示庫

### 部署平台
- **Heroku** - 雲端部署平台
- **WhiteNoise** - 靜態文件服務
- **Gunicorn** - WSGI伺服器

## 🚀 快速開始

### 環境要求
- Python 3.9+
- Django 4.2+
- 現代網頁瀏覽器

### 安裝步驟

1. **克隆專案**
```bash
git clone https://github.com/您的用戶名/reunion-party-platform.git
cd reunion-party-platform
```

2. **創建虛擬環境**
```bash
python -m venv venv
# Windows
venv\Scripts\activate
# macOS/Linux
source venv/bin/activate
```

3. **安裝依賴**
```bash
pip install -r requirements.txt
```

4. **資料庫設置**
```bash
python manage.py migrate
python manage.py createsuperuser
```

5. **啟動開發服務器**
```bash
python manage.py runserver
```

6. **訪問應用**
打開瀏覽器前往 `http://localhost:8000`

## 📁 專案結構

```
reunion-party-platform/
├── events/                 # 活動管理應用
├── suppliers/              # 供應商管理應用
├── dj_management/          # DJ管理應用
├── messaging/              # 訊息系統應用
├── dashboards/             # 儀表板應用
├── templates/              # HTML模板
├── static/                 # 靜態文件
├── party_platform/         # 主要設定
├── manage.py              # Django管理腳本
├── requirements.txt       # Python依賴
└── README.md             # 專案說明
```

## 🎨 主要頁面

- **首頁** - 平台介紹和功能展示
- **活動發布** - 客戶發布活動需求
- **供應商列表** - 瀏覽供應商服務
- **DJ展示** - DJ個人檔案和作品
- **訊息中心** - 用戶間溝通平台
- **管理後台** - 系統管理介面

## 🔧 最近更新

### v1.2.0 (2025-07-15)
- ✅ 修復表單價格欄位限制問題
- ✅ 增強QuoteForm價格驗證，支援1-99,999,999範圍
- ✅ 修正活動詳情頁面權限問題
- ✅ 改進表單錯誤處理和用戶體驗
- ✅ 解決活動表單提交後Not Found錯誤

### v1.1.0
- 🎯 完善供應商和DJ管理系統
- 💬 增加訊息交流功能
- 📊 添加數據分析儀表板
- 🔐 完善用戶權限管理

### v1.0.0
- 🎉 初始版本發布
- 基礎活動媒合功能
- 用戶註冊和登入系統
- 基本的活動發布功能

## 🤝 貢獻指南

歡迎提交Issue和Pull Request來改進專案！

### 開發流程
1. Fork 專案
2. 創建功能分支 (`git checkout -b feature/新功能`)
3. 提交修改 (`git commit -am '添加新功能'`)
4. 推送分支 (`git push origin feature/新功能`)
5. 創建Pull Request

## 📝 授權

本專案採用 MIT 授權條款 - 詳見 [LICENSE](LICENSE) 文件

## 📞 聯絡資訊

- **開發者**: 朱佑修
- **Email**: nm6101103@ncku.edu.tw
- **專案連結**: [GitHub Repository](https://github.com/您的用戶名/reunion-party-platform)

## 🙏 致謝

感謝所有貢獻者和支持這個專案的人！

---

<div align="center">
<strong>🎪 讓每一場聚會都成為難忘的回憶 🎪</strong>
</div>
