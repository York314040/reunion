#!/usr/bin/env python
"""
Heroku部署自動化工具
一鍵部署Django應用到Heroku
"""

import os
import sys
import subprocess
import json
from datetime import datetime
from typing import Dict, Any, List


class HerokuDeploymentManager:
    """Heroku部署管理器"""
    
    def __init__(self):
        self.app_name = "django-party-platform"  # 可以修改為您想要的app名稱
        self.current_dir = os.getcwd()
        self.deployment_log = []
    
    def check_heroku_cli(self) -> bool:
        """檢查Heroku CLI是否安裝"""
        try:
            result = subprocess.run(['heroku', '--version'], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                print(f"✅ Heroku CLI已安裝: {result.stdout.strip()}")
                return True
            else:
                print("❌ Heroku CLI未正確安裝")
                return False
        except FileNotFoundError:
            print("❌ 未找到Heroku CLI，請先安裝")
            return False
    
    def check_git_repo(self) -> bool:
        """檢查Git倉庫狀態"""
        try:
            # 檢查是否是Git倉庫
            result = subprocess.run(['git', 'status'], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                print("✅ Git倉庫狀態正常")
                return True
            else:
                print("❌ 不是有效的Git倉庫")
                return False
        except FileNotFoundError:
            print("❌ 未找到Git，請先安裝Git")
            return False
    
    def initialize_git_if_needed(self) -> bool:
        """如果需要，初始化Git倉庫"""
        if not os.path.exists('.git'):
            print("🔧 初始化Git倉庫...")
            try:
                subprocess.run(['git', 'init'], check=True)
                subprocess.run(['git', 'add', '.'], check=True)
                subprocess.run(['git', 'commit', '-m', 'Initial commit'], check=True)
                print("✅ Git倉庫初始化完成")
                return True
            except subprocess.CalledProcessError as e:
                print(f"❌ Git初始化失敗: {e}")
                return False
        return True
    
    def create_heroku_files(self) -> Dict[str, Any]:
        """創建Heroku所需的配置文件"""
        files_created = []
        
        # 1. 創建Procfile
        procfile_content = """web: gunicorn party_platform.wsgi --log-file -
release: python manage.py migrate"""
        
        with open('Procfile', 'w') as f:
            f.write(procfile_content)
        files_created.append('Procfile')
        
        # 2. 創建runtime.txt
        runtime_content = "python-3.9.21"
        
        with open('runtime.txt', 'w') as f:
            f.write(runtime_content)
        files_created.append('runtime.txt')
        
        # 3. 更新requirements.txt為生產環境
        production_requirements = """Django==4.2.23
django-bootstrap4==25.1
Pillow==10.4.0
python-dotenv==1.0.0
whitenoise==6.9.0
gunicorn==23.0.0
psycopg2-binary==2.9.10
dj-database-url==2.1.0
python-decouple==3.8"""
        
        with open('requirements.txt', 'w') as f:
            f.write(production_requirements)
        files_created.append('requirements.txt (updated)')
        
        # 4. 創建.env.example
        env_example = """# Heroku環境變量範例
SECRET_KEY=your-secret-key-here
DEBUG=False
ALLOWED_HOSTS=your-app-name.herokuapp.com
DATABASE_URL=postgres://...
"""
        
        with open('.env.example', 'w') as f:
            f.write(env_example)
        files_created.append('.env.example')
        
        return {
            'success': True,
            'files_created': files_created,
            'message': f'成功創建 {len(files_created)} 個Heroku配置文件'
        }
    
    def update_settings_for_heroku(self) -> bool:
        """更新Django設置以支持Heroku"""
        settings_file = 'party_platform/settings.py'
        
        if not os.path.exists(settings_file):
            print(f"❌ 找不到設置文件: {settings_file}")
            return False
        
        # 讀取現有設置
        with open(settings_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 檢查是否已經配置了Heroku設置
        if 'import dj_database_url' in content:
            print("✅ Django設置已配置Heroku支持")
            return True
        
        # 添加Heroku配置
        heroku_config = """
# Heroku配置
import dj_database_url
from decouple import config

# 生產環境配置
if not DEBUG:
    # 靜態文件設置
    STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')
    STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'
    
    # 數據庫配置
    DATABASES['default'] = dj_database_url.parse(
        config('DATABASE_URL', default='sqlite:///db.sqlite3')
    )
    
    # 安全設置
    SECURE_SSL_REDIRECT = True
    SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
    SECURE_HSTS_SECONDS = 31536000
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD = True
    
    # 會話安全
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True

# 中介軟體添加WhiteNoise
if 'whitenoise.middleware.WhiteNoiseMiddleware' not in MIDDLEWARE:
    MIDDLEWARE.insert(1, 'whitenoise.middleware.WhiteNoiseMiddleware')
"""
        
        # 將配置添加到文件末尾
        updated_content = content + heroku_config
        
        with open(settings_file, 'w', encoding='utf-8') as f:
            f.write(updated_content)
        
        print("✅ Django設置已更新支持Heroku")
        return True
    
    def heroku_login_check(self) -> bool:
        """檢查Heroku登入狀態"""
        try:
            result = subprocess.run(['heroku', 'auth:whoami'], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                user = result.stdout.strip()
                print(f"✅ 已登入Heroku: {user}")
                return True
            else:
                print("❌ 未登入Heroku")
                return False
        except Exception as e:
            print(f"❌ 檢查Heroku登入狀態失敗: {e}")
            return False
    
    def create_heroku_app(self) -> bool:
        """創建Heroku應用"""
        try:
            # 檢查應用是否已存在
            result = subprocess.run(['heroku', 'apps:info', self.app_name], 
                                  capture_output=True, text=True)
            
            if result.returncode == 0:
                print(f"✅ Heroku應用 '{self.app_name}' 已存在")
                return True
            
            # 創建新應用
            print(f"🔧 創建Heroku應用: {self.app_name}")
            result = subprocess.run(['heroku', 'create', self.app_name], 
                                  capture_output=True, text=True)
            
            if result.returncode == 0:
                print(f"✅ 成功創建Heroku應用: {self.app_name}")
                app_url = f"https://{self.app_name}.herokuapp.com"
                print(f"🌐 應用URL: {app_url}")
                return True
            else:
                # 如果名稱已被使用，嘗試添加隨機後綴
                import random
                suffix = str(random.randint(1000, 9999))
                new_app_name = f"{self.app_name}-{suffix}"
                
                result = subprocess.run(['heroku', 'create', new_app_name], 
                                      capture_output=True, text=True)
                
                if result.returncode == 0:
                    self.app_name = new_app_name
                    print(f"✅ 成功創建Heroku應用: {self.app_name}")
                    app_url = f"https://{self.app_name}.herokuapp.com"
                    print(f"🌐 應用URL: {app_url}")
                    return True
                else:
                    print(f"❌ 創建Heroku應用失敗: {result.stderr}")
                    return False
                    
        except Exception as e:
            print(f"❌ 創建Heroku應用時出錯: {e}")
            return False
    
    def set_heroku_config_vars(self) -> bool:
        """設置Heroku環境變量"""
        try:
            # 生成安全的SECRET_KEY
            import secrets
            secret_key = secrets.token_urlsafe(50)
            
            config_vars = {
                'SECRET_KEY': secret_key,
                'DEBUG': 'False',
                'ALLOWED_HOSTS': f'{self.app_name}.herokuapp.com,localhost,127.0.0.1',
                'DJANGO_SETTINGS_MODULE': 'party_platform.settings'
            }
            
            print("🔧 設置Heroku環境變量...")
            
            for key, value in config_vars.items():
                cmd = ['heroku', 'config:set', f'{key}={value}', '--app', self.app_name]
                result = subprocess.run(cmd, capture_output=True, text=True)
                
                if result.returncode == 0:
                    print(f"✅ 設置 {key}")
                else:
                    print(f"❌ 設置 {key} 失敗: {result.stderr}")
                    return False
            
            return True
            
        except Exception as e:
            print(f"❌ 設置環境變量時出錯: {e}")
            return False
    
    def deploy_to_heroku(self) -> bool:
        """部署到Heroku"""
        try:
            print("🚀 開始部署到Heroku...")
            
            # 添加所有文件到Git
            subprocess.run(['git', 'add', '.'], check=True)
            
            # 提交更改
            commit_msg = f"Deploy to Heroku - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            subprocess.run(['git', 'commit', '-m', commit_msg], check=True)
            
            # 推送到Heroku
            result = subprocess.run(['git', 'push', 'heroku', 'main'], 
                                  capture_output=True, text=True)
            
            if result.returncode == 0:
                print("✅ 成功部署到Heroku!")
                print(f"🌐 您的應用現在可以在以下地址訪問:")
                print(f"   https://{self.app_name}.herokuapp.com")
                return True
            else:
                # 嘗試使用master分支
                result = subprocess.run(['git', 'push', 'heroku', 'master'], 
                                      capture_output=True, text=True)
                if result.returncode == 0:
                    print("✅ 成功部署到Heroku!")
                    print(f"🌐 您的應用現在可以在以下地址訪問:")
                    print(f"   https://{self.app_name}.herokuapp.com")
                    return True
                else:
                    print(f"❌ 部署失敗: {result.stderr}")
                    return False
                    
        except Exception as e:
            print(f"❌ 部署過程中出錯: {e}")
            return False
    
    def run_heroku_migrations(self) -> bool:
        """在Heroku上運行數據庫遷移"""
        try:
            print("🔄 在Heroku上運行數據庫遷移...")
            
            result = subprocess.run(['heroku', 'run', 'python', 'manage.py', 'migrate', '--app', self.app_name], 
                                  capture_output=True, text=True)
            
            if result.returncode == 0:
                print("✅ 數據庫遷移完成")
                return True
            else:
                print(f"❌ 數據庫遷移失敗: {result.stderr}")
                return False
                
        except Exception as e:
            print(f"❌ 運行遷移時出錯: {e}")
            return False
    
    def create_superuser_instructions(self) -> str:
        """創建超級用戶的說明"""
        instructions = f"""
📋 創建Heroku超級用戶:

1. 在終端中運行以下命令:
   heroku run python manage.py createsuperuser --app {self.app_name}

2. 按照提示輸入用戶名、郵箱和密碼

3. 創建完成後，您可以訪問管理後台:
   https://{self.app_name}.herokuapp.com/admin/

4. 使用剛創建的超級用戶登入管理系統
"""
        return instructions
    
    def full_deployment_process(self) -> Dict[str, Any]:
        """完整的Heroku部署流程"""
        print("🚀 開始Heroku完整部署流程")
        print("="*60)
        
        deployment_steps = [
            ("檢查Heroku CLI", self.check_heroku_cli),
            ("檢查Git倉庫", self.check_git_repo),
            ("初始化Git (如需要)", self.initialize_git_if_needed),
            ("創建Heroku配置文件", lambda: self.create_heroku_files()['success']),
            ("更新Django設置", self.update_settings_for_heroku),
            ("檢查Heroku登入", self.heroku_login_check),
            ("創建Heroku應用", self.create_heroku_app),
            ("設置環境變量", self.set_heroku_config_vars),
            ("部署到Heroku", self.deploy_to_heroku),
            ("運行數據庫遷移", self.run_heroku_migrations)
        ]
        
        results = {}
        success_count = 0
        
        for step_name, step_function in deployment_steps:
            print(f"\n🔄 {step_name}...")
            try:
                if step_function():
                    results[step_name] = "✅ 成功"
                    success_count += 1
                else:
                    results[step_name] = "❌ 失敗"
                    if step_name in ["檢查Heroku CLI", "檢查Heroku登入"]:
                        print(f"\n⚠️ {step_name}失敗，請先完成以下步驟:")
                        if step_name == "檢查Heroku CLI":
                            print("1. 前往 https://devcenter.heroku.com/articles/heroku-cli 下載並安裝Heroku CLI")
                            print("2. 安裝完成後重新運行此腳本")
                        elif step_name == "檢查Heroku登入":
                            print("1. 運行命令: heroku login")
                            print("2. 按照提示完成登入")
                            print("3. 登入完成後重新運行此腳本")
                        break
            except Exception as e:
                results[step_name] = f"❌ 錯誤: {str(e)}"
        
        # 總結
        total_steps = len(deployment_steps)
        success_rate = (success_count / total_steps) * 100
        
        print(f"\n" + "="*60)
        print(f"📊 部署總結")
        print(f"="*60)
        print(f"✅ 成功步驟: {success_count}/{total_steps}")
        print(f"📈 成功率: {success_rate:.1f}%")
        
        if success_count == total_steps:
            print(f"\n🎉 恭喜！您的Django應用已成功部署到Heroku!")
            print(f"🌐 應用地址: https://{self.app_name}.herokuapp.com")
            print(f"🔧 管理後台: https://{self.app_name}.herokuapp.com/admin/")
            
            # 顯示創建超級用戶的說明
            print(self.create_superuser_instructions())
            
            # 保存部署信息
            deployment_info = {
                'app_name': self.app_name,
                'app_url': f"https://{self.app_name}.herokuapp.com",
                'admin_url': f"https://{self.app_name}.herokuapp.com/admin/",
                'deployment_date': datetime.now().isoformat(),
                'status': 'success'
            }
            
            with open('heroku_deployment_info.json', 'w') as f:
                json.dump(deployment_info, f, indent=2)
            
            print(f"\n📄 部署信息已保存到: heroku_deployment_info.json")
        
        return {
            'success': success_count == total_steps,
            'app_name': self.app_name,
            'app_url': f"https://{self.app_name}.herokuapp.com" if success_count == total_steps else None,
            'steps_completed': success_count,
            'total_steps': total_steps,
            'success_rate': success_rate,
            'results': results
        }


def main():
    """主函數"""
    print("🚀 Django到Heroku自動部署工具")
    print("="*50)
    
    deployer = HerokuDeploymentManager()
    result = deployer.full_deployment_process()
    
    return result


if __name__ == "__main__":
    main()
