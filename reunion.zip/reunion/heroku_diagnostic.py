#!/usr/bin/env python
"""
Heroku 錯誤診斷腳本
"""
import os
import sys
import django

# 設置 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

def diagnose_dj_popular_view():
    """診斷 DJ popular 視圖問題"""
    print("=== DJ Popular 視圖診斷 ===")
    
    try:
        from dj_management.models import DJ, DJRating, DJBooking
        from django.db.models import Avg, Count
        
        # 檢查 DJ 模型
        dj_count = DJ.objects.count()
        approved_dj_count = DJ.objects.filter(status='approved').count()
        print(f"總 DJ 數量: {dj_count}")
        print(f"已審核 DJ 數量: {approved_dj_count}")
        
        # 檢查評分模型
        rating_count = DJRating.objects.count()
        print(f"評分總數: {rating_count}")
        
        # 檢查預約模型
        booking_count = DJBooking.objects.count()
        completed_booking_count = DJBooking.objects.filter(status='completed').count()
        print(f"預約總數: {booking_count}")
        print(f"完成預約數: {completed_booking_count}")
        
        # 測試查詢
        try:
            top_rated_djs = DJ.objects.filter(status='approved').annotate(
                avg_rating=Avg('djrating__rating'),
                rating_count=Count('djrating')
            ).filter(rating_count__gte=3).order_by('-avg_rating')[:10]
            print(f"評分最高 DJ 查詢成功，數量: {len(top_rated_djs)}")
        except Exception as e:
            print(f"評分最高 DJ 查詢失敗: {e}")
        
        # 測試精選 DJ 查詢
        try:
            featured_djs = DJ.objects.filter(status='approved', is_featured=True).order_by('-created_at')[:8]
            print(f"精選 DJ 查詢成功，數量: {len(featured_djs)}")
        except Exception as e:
            print(f"精選 DJ 查詢失敗: {e}")
            
        print("DJ Popular 視圖診斷完成")
        
    except Exception as e:
        print(f"診斷過程中出現錯誤: {e}")
        import traceback
        traceback.print_exc()

def diagnose_favicon():
    """診斷 favicon 問題"""
    print("\n=== Favicon 診斷 ===")
    
    import os
    from django.conf import settings
    
    # 檢查靜態文件設置
    print(f"STATIC_URL: {settings.STATIC_URL}")
    print(f"STATIC_ROOT: {getattr(settings, 'STATIC_ROOT', 'Not set')}")
    print(f"STATICFILES_DIRS: {getattr(settings, 'STATICFILES_DIRS', 'Not set')}")
    
    # 檢查 favicon 文件
    possible_paths = [
        os.path.join(settings.BASE_DIR, 'static', 'favicon.ico'),
        os.path.join(settings.BASE_DIR, 'staticfiles', 'favicon.ico'),
        os.path.join(settings.BASE_DIR, 'templates', 'favicon.ico'),
    ]
    
    for path in possible_paths:
        if os.path.exists(path):
            print(f"✅ 找到 favicon: {path}")
        else:
            print(f"❌ 未找到 favicon: {path}")

def diagnose_users():
    """診斷用戶問題"""
    print("\n=== 用戶診斷 ===")
    
    from django.contrib.auth.models import User
    
    total_users = User.objects.count()
    active_users = User.objects.filter(is_active=True).count()
    superusers = User.objects.filter(is_superuser=True).count()
    staff_users = User.objects.filter(is_staff=True).count()
    
    print(f"總用戶數: {total_users}")
    print(f"活躍用戶數: {active_users}")
    print(f"超級用戶數: {superusers}")
    print(f"管理員用戶數: {staff_users}")
    
    # 檢查演示用戶
    demo_users = ['admin', 'manager', 'zhang_ming', 'li_hua', 'wang_mei']
    for username in demo_users:
        try:
            user = User.objects.get(username=username)
            print(f"✅ {username}: 存在 (is_active={user.is_active}, is_superuser={user.is_superuser})")
        except User.DoesNotExist:
            print(f"❌ {username}: 不存在")

if __name__ == "__main__":
    print("=== Heroku 應用診斷 ===")
    
    # 運行所有診斷
    diagnose_dj_popular_view()
    diagnose_favicon()
    diagnose_users()
    
    print("\n=== 診斷完成 ===")
