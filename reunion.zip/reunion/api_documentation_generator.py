#!/usr/bin/env python
"""
API 自動化文檔生成器
自動分析 Django 項目並生成完整的 API 文檔
"""

import os
import sys
import json
import inspect
from typing import Dict, Any, List
from datetime import datetime

# 設定 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')

import django
django.setup()

from django.apps import apps
from django.urls import get_resolver
from django.contrib.auth.models import User


class APIDocumentationGenerator:
    """API 文檔生成器"""
    
    def __init__(self):
        self.documentation = {
            'project_name': 'PAPA COLLEGE B2B聚會派對媒合平台',
            'version': '1.0.0',
            'generated_at': datetime.now().isoformat(),
            'base_url': 'http://localhost:8000',
            'models': {},
            'views': {},
            'urls': {},
            'api_endpoints': {}
        }
    
    def analyze_models(self) -> Dict[str, Any]:
        """分析 Django 模型"""
        print("📊 分析 Django 模型...")
        
        models_info = {}
        
        # 獲取所有已安裝的應用
        for app_config in apps.get_app_configs():
            if app_config.name in ['events', 'suppliers', 'dj_management', 'messaging', 'dashboards']:
                app_models = {}
                
                for model in app_config.get_models():
                    model_name = model.__name__
                    
                    # 獲取模型字段
                    fields = {}
                    for field in model._meta.fields:
                        fields[field.name] = {
                            'type': field.__class__.__name__,
                            'null': field.null,
                            'blank': field.blank,
                            'help_text': field.help_text,
                            'max_length': getattr(field, 'max_length', None)
                        }
                    
                    # 獲取關係字段
                    relations = {}
                    for field in model._meta.many_to_many:
                        relations[field.name] = {
                            'type': 'ManyToMany',
                            'related_model': field.related_model.__name__
                        }
                    
                    for field in model._meta.get_fields():
                        if hasattr(field, 'related_model') and field.related_model:
                            if field.name not in fields:  # 避免重複
                                relations[field.name] = {
                                    'type': field.__class__.__name__,
                                    'related_model': field.related_model.__name__
                                }
                    
                    app_models[model_name] = {
                        'fields': fields,
                        'relations': relations,
                        'verbose_name': model._meta.verbose_name,
                        'verbose_name_plural': model._meta.verbose_name_plural,
                        'ordering': list(model._meta.ordering) if model._meta.ordering else [],
                        'table_name': model._meta.db_table
                    }
                
                if app_models:
                    models_info[app_config.name] = app_models
        
        return models_info
    
    def analyze_views(self) -> Dict[str, Any]:
        """分析 Django 視圖"""
        print("👁️ 分析 Django 視圖...")
        
        views_info = {}
        
        # 獲取各應用的視圖
        apps_to_analyze = ['events', 'suppliers', 'dj_management', 'messaging', 'dashboards']
        
        for app_name in apps_to_analyze:
            try:
                # 動態導入視圖模組
                views_module = __import__(f'{app_name}.views', fromlist=[''])
                
                app_views = {}
                
                # 獲取模組中的所有函數和類
                for name, obj in inspect.getmembers(views_module):
                    if inspect.isfunction(obj) or inspect.isclass(obj):
                        if not name.startswith('_'):  # 跳過私有成員
                            
                            view_info = {
                                'type': 'function' if inspect.isfunction(obj) else 'class',
                                'docstring': inspect.getdoc(obj),
                                'source_file': inspect.getfile(obj) if hasattr(obj, '__file__') else None
                            }
                            
                            # 如果是函數，獲取參數
                            if inspect.isfunction(obj):
                                sig = inspect.signature(obj)
                                view_info['parameters'] = []
                                for param_name, param in sig.parameters.items():
                                    view_info['parameters'].append({
                                        'name': param_name,
                                        'default': str(param.default) if param.default != param.empty else None,
                                        'annotation': str(param.annotation) if param.annotation != param.empty else None
                                    })
                            
                            # 如果是類，獲取方法
                            if inspect.isclass(obj):
                                methods = []
                                for method_name, method in inspect.getmembers(obj, predicate=inspect.ismethod):
                                    if not method_name.startswith('_'):
                                        methods.append({
                                            'name': method_name,
                                            'docstring': inspect.getdoc(method)
                                        })
                                view_info['methods'] = methods
                            
                            app_views[name] = view_info
                
                if app_views:
                    views_info[app_name] = app_views
                    
            except ImportError as e:
                print(f"無法導入 {app_name}.views: {str(e)}")
        
        return views_info
    
    def analyze_urls(self) -> Dict[str, Any]:
        """分析 URL 模式"""
        print("🔗 分析 URL 模式...")
        
        urls_info = {}
        
        try:
            # 獲取主 URL 配置
            resolver = get_resolver()
            
            def extract_url_patterns(url_patterns, prefix=''):
                patterns = []
                
                for pattern in url_patterns:
                    pattern_info = {
                        'pattern': str(pattern.pattern),
                        'name': getattr(pattern, 'name', None),
                        'full_path': prefix + str(pattern.pattern)
                    }
                    
                    # 如果是 URLResolver（包含子模式）
                    if hasattr(pattern, 'url_patterns'):
                        pattern_info['type'] = 'include'
                        pattern_info['namespace'] = getattr(pattern, 'namespace', None)
                        # 遞歸獲取子模式
                        pattern_info['sub_patterns'] = extract_url_patterns(
                            pattern.url_patterns, 
                            prefix + str(pattern.pattern)
                        )
                    else:
                        pattern_info['type'] = 'view'
                        # 獲取視圖信息
                        if hasattr(pattern, 'callback'):
                            callback = pattern.callback
                            pattern_info['view_name'] = getattr(callback, '__name__', str(callback))
                            pattern_info['view_module'] = getattr(callback, '__module__', None)
                    
                    patterns.append(pattern_info)
                
                return patterns
            
            urls_info = extract_url_patterns(resolver.url_patterns)
            
        except Exception as e:
            print(f"分析 URL 失敗: {str(e)}")
            urls_info = {'error': str(e)}
        
        return urls_info
    
    def generate_api_endpoints(self) -> Dict[str, Any]:
        """生成 API 端點文檔"""
        print("🚀 生成 API 端點文檔...")
        
        api_endpoints = {
            'authentication': {
                'login': {
                    'url': '/accounts/login/',
                    'method': 'POST',
                    'description': '用戶登入',
                    'parameters': {
                        'username': '用戶名',
                        'password': '密碼'
                    },
                    'response': '登入成功返回用戶信息'
                },
                'logout': {
                    'url': '/accounts/logout/',
                    'method': 'POST',
                    'description': '用戶登出',
                    'parameters': {},
                    'response': '登出成功'
                },
                'register': {
                    'url': '/register/',
                    'method': 'POST',
                    'description': '用戶註冊',
                    'parameters': {
                        'username': '用戶名',
                        'email': '電子郵件',
                        'password': '密碼',
                        'user_type': '用戶類型 (client/supplier/dj)'
                    },
                    'response': '註冊成功返回用戶信息'
                }
            },
            'events': {
                'list_events': {
                    'url': '/events/',
                    'method': 'GET',
                    'description': '獲取活動列表',
                    'parameters': {
                        'page': '頁碼 (可選)',
                        'search': '搜索關鍵字 (可選)'
                    },
                    'response': '活動列表和分頁信息'
                },
                'create_event': {
                    'url': '/events/create/',
                    'method': 'POST',
                    'description': '創建新活動',
                    'parameters': {
                        'title': '活動標題',
                        'description': '活動描述',
                        'event_date': '活動日期',
                        'location': '活動地點',
                        'budget': '預算'
                    },
                    'response': '創建的活動信息'
                },
                'event_detail': {
                    'url': '/events/<id>/',
                    'method': 'GET',
                    'description': '獲取活動詳情',
                    'parameters': {
                        'id': '活動ID'
                    },
                    'response': '活動詳細信息'
                }
            },
            'suppliers': {
                'list_suppliers': {
                    'url': '/suppliers/',
                    'method': 'GET',
                    'description': '獲取供應商列表',
                    'parameters': {
                        'page': '頁碼 (可選)',
                        'category': '分類 (可選)'
                    },
                    'response': '供應商列表和分頁信息'
                },
                'supplier_detail': {
                    'url': '/suppliers/<id>/',
                    'method': 'GET',
                    'description': '獲取供應商詳情',
                    'parameters': {
                        'id': '供應商ID'
                    },
                    'response': '供應商詳細信息'
                }
            },
            'dj_management': {
                'list_djs': {
                    'url': '/dj/',
                    'method': 'GET',
                    'description': '獲取DJ列表',
                    'parameters': {
                        'page': '頁碼 (可選)',
                        'genre': '音樂類型 (可選)'
                    },
                    'response': 'DJ列表和分頁信息'
                },
                'dj_detail': {
                    'url': '/dj/<id>/',
                    'method': 'GET',
                    'description': '獲取DJ詳情',
                    'parameters': {
                        'id': 'DJ ID'
                    },
                    'response': 'DJ詳細信息'
                }
            },
            'messaging': {
                'conversations': {
                    'url': '/messaging/',
                    'method': 'GET',
                    'description': '獲取對話列表',
                    'parameters': {},
                    'response': '用戶的對話列表'
                },
                'send_message': {
                    'url': '/messaging/send/',
                    'method': 'POST',
                    'description': '發送訊息',
                    'parameters': {
                        'recipient_id': '收件人ID',
                        'message': '訊息內容'
                    },
                    'response': '發送成功確認'
                }
            }
        }
        
        return api_endpoints
    
    def generate_markdown_documentation(self) -> str:
        """生成 Markdown 格式的文檔"""
        print("📝 生成 Markdown 文檔...")
        
        # 分析各組件
        self.documentation['models'] = self.analyze_models()
        self.documentation['views'] = self.analyze_views()
        self.documentation['urls'] = self.analyze_urls()
        self.documentation['api_endpoints'] = self.generate_api_endpoints()
        
        # 生成 Markdown 內容
        md_content = f"""# {self.documentation['project_name']} API 文檔

**版本**: {self.documentation['version']}  
**生成時間**: {self.documentation['generated_at']}  
**基礎URL**: {self.documentation['base_url']}

---

## 📋 目錄

1. [項目概覽](#項目概覽)
2. [認證系統](#認證系統)
3. [API 端點](#api-端點)
4. [數據模型](#數據模型)
5. [視圖分析](#視圖分析)
6. [URL 路由](#url-路由)

---

## 📖 項目概覽

PAPA COLLEGE 是一個 B2B 聚會派對媒合平台，連接活動主辦方、供應商和DJ，提供完整的活動策劃解決方案。

### 主要功能
- 👥 多角色用戶系統 (客戶、供應商、DJ、管理員)
- 🎉 活動需求發布和管理
- 🏪 供應商服務展示
- 🎵 DJ 檔案管理
- 💬 即時訊息系統
- 📊 數據分析和報告

---

## 🔐 認證系統

### 用戶類型
- **客戶 (Client)**: 發布活動需求，尋找供應商和DJ
- **供應商 (Supplier)**: 提供活動相關服務和產品
- **DJ**: 提供音樂表演服務
- **管理員 (Admin)**: 系統管理和監控

### 認證流程
1. 用戶註冊並選擇角色
2. 系統驗證用戶信息
3. 完善個人或企業檔案
4. 開始使用平台功能

---

## 🚀 API 端點

"""

        # 添加 API 端點文檔
        for category, endpoints in self.documentation['api_endpoints'].items():
            md_content += f"### {category.upper()}\n\n"
            
            for endpoint_name, endpoint_info in endpoints.items():
                md_content += f"#### {endpoint_info['description']}\n\n"
                md_content += f"**URL**: `{endpoint_info['url']}`  \n"
                md_content += f"**方法**: `{endpoint_info['method']}`  \n\n"
                
                if endpoint_info['parameters']:
                    md_content += "**參數**:\n"
                    for param, desc in endpoint_info['parameters'].items():
                        md_content += f"- `{param}`: {desc}\n"
                    md_content += "\n"
                
                md_content += f"**響應**: {endpoint_info['response']}\n\n"
                md_content += "---\n\n"

        # 添加數據模型文檔
        md_content += "## 📊 數據模型\n\n"
        
        for app_name, models in self.documentation['models'].items():
            md_content += f"### {app_name.upper()} 應用\n\n"
            
            for model_name, model_info in models.items():
                md_content += f"#### {model_name}\n\n"
                md_content += f"**說明**: {model_info['verbose_name']}\n\n"
                
                if model_info['fields']:
                    md_content += "**字段**:\n"
                    for field_name, field_info in model_info['fields'].items():
                        md_content += f"- `{field_name}` ({field_info['type']})"
                        if field_info['help_text']:
                            md_content += f": {field_info['help_text']}"
                        md_content += "\n"
                    md_content += "\n"
                
                if model_info['relations']:
                    md_content += "**關聯**:\n"
                    for rel_name, rel_info in model_info['relations'].items():
                        md_content += f"- `{rel_name}` ({rel_info['type']}) → {rel_info['related_model']}\n"
                    md_content += "\n"
                
                md_content += "---\n\n"

        # 添加使用示例
        md_content += """## 💡 使用示例

### 創建活動需求

```bash
curl -X POST http://localhost:8000/events/create/ \\
  -H "Content-Type: application/json" \\
  -d '{
    "title": "公司年會",
    "description": "需要場地、餐飲和音響設備",
    "event_date": "2025-12-31",
    "location": "台北市信義區",
    "budget": 100000
  }'
```

### 搜索供應商

```bash
curl "http://localhost:8000/suppliers/?category=餐飲&page=1"
```

### 發送訊息

```bash
curl -X POST http://localhost:8000/messaging/send/ \\
  -H "Content-Type: application/json" \\
  -d '{
    "recipient_id": 123,
    "message": "您好，我想詢問關於音響設備租賃的問題。"
  }'
```

---

## 📞 技術支援

如有任何問題或建議，請聯繫開發團隊。

**文檔更新時間**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""

        return md_content
    
    def save_documentation(self) -> Dict[str, Any]:
        """保存文檔"""
        print("💾 保存文檔...")
        
        try:
            # 生成 Markdown 文檔
            markdown_content = self.generate_markdown_documentation()
            
            # 保存 Markdown 文件
            with open('API_DOCUMENTATION.md', 'w', encoding='utf-8') as f:
                f.write(markdown_content)
            
            # 保存 JSON 格式的結構化數據
            with open('api_documentation.json', 'w', encoding='utf-8') as f:
                json.dump(self.documentation, f, ensure_ascii=False, indent=2)
            
            return {
                'success': True,
                'markdown_file': 'API_DOCUMENTATION.md',
                'json_file': 'api_documentation.json',
                'models_count': sum(len(models) for models in self.documentation['models'].values()),
                'endpoints_count': sum(len(endpoints) for endpoints in self.documentation['api_endpoints'].values()),
                'file_size_md': os.path.getsize('API_DOCUMENTATION.md'),
                'file_size_json': os.path.getsize('api_documentation.json')
            }
            
        except Exception as e:
            return {'success': False, 'error': str(e)}


def main():
    """主函數"""
    generator = APIDocumentationGenerator()
    
    print("📚 開始生成 API 文檔...")
    print("="*50)
    
    result = generator.save_documentation()
    
    if result['success']:
        print("✅ API 文檔生成成功!")
        print(f"📄 Markdown 文檔: {result['markdown_file']} ({result['file_size_md']} bytes)")
        print(f"📊 JSON 數據: {result['json_file']} ({result['file_size_json']} bytes)")
        print(f"📊 統計:")
        print(f"  • 數據模型: {result['models_count']} 個")
        print(f"  • API 端點: {result['endpoints_count']} 個")
    else:
        print(f"❌ 文檔生成失敗: {result['error']}")


if __name__ == "__main__":
    main()
