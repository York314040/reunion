#!/usr/bin/env python3
"""
PAPA COLLEGE - 用戶功能測試腳本
模擬真實用戶操作，測試所有功能是否正常
"""

import requests
import time
import json
import re
from datetime import datetime
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup

class UserFunctionalTest:
    def __init__(self, base_url="http://127.0.0.1:8080"):
        self.base_url = base_url
        self.session = requests.Session()
        self.test_results = []
        self.csrf_token = None
        self.test_user_data = {
            'username': 'testuser_' + str(int(time.time())),
            'email': f'test{int(time.time())}@example.com',
            'password': 'testpass123',
            'first_name': '測試',
            'last_name': '用戶'
        }
        
    def log_test(self, test_name, status, message="", details=""):
        """記錄測試結果"""
        result = {
            'test_name': test_name,
            'status': status,
            'message': message,
            'details': details,
            'timestamp': datetime.now().strftime('%H:%M:%S')
        }
        self.test_results.append(result)
        
        # 即時輸出
        icon = "✅" if status == "PASS" else "❌" if status == "FAIL" else "⚠️"
        print(f"{icon} {test_name}: {message}")
        if details:
            print(f"   詳細: {details}")
            
    def get_csrf_token(self, html_content):
        """從頁面中提取 CSRF token"""
        soup = BeautifulSoup(html_content, 'html.parser')
        csrf_input = soup.find('input', {'name': 'csrfmiddlewaretoken'})
        if csrf_input:
            return csrf_input.get('value')
        
        # 從 meta 標籤中尋找
        csrf_meta = soup.find('meta', {'name': 'csrf-token'})
        if csrf_meta:
            return csrf_meta.get('content')
        return None
    
    def test_homepage_access(self):
        """測試首頁訪問"""
        try:
            response = self.session.get(self.base_url)
            if response.status_code == 200:
                if "PAPA COLLEGE" in response.text:
                    self.log_test("首頁訪問", "PASS", f"成功載入首頁 ({response.status_code})")
                    return True
                else:
                    self.log_test("首頁訪問", "FAIL", "頁面內容不正確")
            else:
                self.log_test("首頁訪問", "FAIL", f"HTTP錯誤: {response.status_code}")
        except Exception as e:
            self.log_test("首頁訪問", "FAIL", f"連接失敗: {str(e)}")
        return False
    
    def test_navigation_links(self):
        """測試導航連結"""
        navigation_tests = [
            ('/', '首頁'),
            ('/suppliers/', '供應商列表'),
            ('/dj/', 'DJ列表'),
            ('/dj/popular/', '熱門DJ'),
            ('/login/', '登入頁面'),
            ('/users/register/', '註冊頁面'),
        ]
        
        for url_path, page_name in navigation_tests:
            try:
                url = urljoin(self.base_url, url_path)
                response = self.session.get(url)
                if response.status_code == 200:
                    self.log_test(f"導航-{page_name}", "PASS", f"頁面正常載入")
                else:
                    self.log_test(f"導航-{page_name}", "FAIL", f"HTTP錯誤: {response.status_code}")
            except Exception as e:
                self.log_test(f"導航-{page_name}", "FAIL", f"連接失敗: {str(e)}")
    
    def test_user_registration(self):
        """測試用戶註冊功能"""
        try:
            # 先獲取註冊頁面
            register_url = urljoin(self.base_url, '/users/register/')
            response = self.session.get(register_url)
            
            if response.status_code != 200:
                self.log_test("用戶註冊", "FAIL", f"無法訪問註冊頁面: {response.status_code}")
                return False
            
            # 提取 CSRF token
            self.csrf_token = self.get_csrf_token(response.text)
            if not self.csrf_token:
                self.log_test("用戶註冊", "FAIL", "無法獲取 CSRF token")
                return False
            
            # 提交註冊表單
            register_data = {
                'csrfmiddlewaretoken': self.csrf_token,
                'username': self.test_user_data['username'],
                'email': self.test_user_data['email'],
                'first_name': self.test_user_data['first_name'],
                'last_name': self.test_user_data['last_name'],
                'password1': self.test_user_data['password'],
                'password2': self.test_user_data['password'],
            }
            
            response = self.session.post(register_url, data=register_data)
            
            # 檢查註冊是否成功（可能重定向到首頁或顯示成功訊息）
            if response.status_code in [200, 302]:
                if response.status_code == 302 or "成功" in response.text or "歡迎" in response.text:
                    self.log_test("用戶註冊", "PASS", f"註冊成功 (用戶: {self.test_user_data['username']})")
                    return True
                else:
                    self.log_test("用戶註冊", "WARN", "註冊請求已提交，但無法確認成功")
            else:
                self.log_test("用戶註冊", "FAIL", f"註冊失敗: {response.status_code}")
                
        except Exception as e:
            self.log_test("用戶註冊", "FAIL", f"註冊過程出錯: {str(e)}")
        return False
    
    def test_user_login(self):
        """測試用戶登入功能"""
        try:
            # 獲取登入頁面
            login_url = urljoin(self.base_url, '/login/')
            response = self.session.get(login_url)
            
            if response.status_code != 200:
                self.log_test("用戶登入", "FAIL", f"無法訪問登入頁面: {response.status_code}")
                return False
            
            # 提取 CSRF token
            self.csrf_token = self.get_csrf_token(response.text)
            if not self.csrf_token:
                self.log_test("用戶登入", "FAIL", "無法獲取 CSRF token")
                return False
            
            # 提交登入表單
            login_data = {
                'csrfmiddlewaretoken': self.csrf_token,
                'username': self.test_user_data['username'],
                'password': self.test_user_data['password'],
            }
            
            response = self.session.post(login_url, data=login_data)
            
            # 檢查登入是否成功
            if response.status_code in [200, 302]:
                # 檢查是否重定向到首頁或包含用戶名
                if (response.status_code == 302 or 
                    self.test_user_data['username'] in response.text or
                    "登出" in response.text):
                    self.log_test("用戶登入", "PASS", "登入成功")
                    return True
                else:
                    self.log_test("用戶登入", "WARN", "登入請求已提交，但無法確認成功")
            else:
                self.log_test("用戶登入", "FAIL", f"登入失敗: {response.status_code}")
                
        except Exception as e:
            self.log_test("用戶登入", "FAIL", f"登入過程出錯: {str(e)}")
        return False
    
    def test_event_creation(self):
        """測試活動創建功能"""
        try:
            # 獲取創建活動頁面
            create_url = urljoin(self.base_url, '/events/create/')
            response = self.session.get(create_url)
            
            if response.status_code != 200:
                self.log_test("活動創建", "FAIL", f"無法訪問創建頁面: {response.status_code}")
                return False
            
            # 提取 CSRF token
            self.csrf_token = self.get_csrf_token(response.text)
            if not self.csrf_token:
                self.log_test("活動創建", "FAIL", "無法獲取 CSRF token")
                return False
            
            # 準備活動資料
            event_data = {
                'csrfmiddlewaretoken': self.csrf_token,
                'title': f'測試活動 - {int(time.time())}',
                'description': '這是一個測試活動的描述',
                'event_date': '2025-08-01',
                'event_time': '18:00',
                'location': '台北市信義區',
                'estimated_attendees': '50',
                'budget_min': '10000',
                'budget_max': '50000',
            }
            
            response = self.session.post(create_url, data=event_data)
            
            if response.status_code in [200, 302]:
                self.log_test("活動創建", "PASS", "活動創建請求已提交")
                return True
            else:
                self.log_test("活動創建", "FAIL", f"創建失敗: {response.status_code}")
                
        except Exception as e:
            self.log_test("活動創建", "FAIL", f"活動創建出錯: {str(e)}")
        return False
    
    def test_search_functionality(self):
        """測試搜尋功能"""
        try:
            # 測試供應商搜尋
            search_url = urljoin(self.base_url, '/suppliers/')
            params = {'search': '音響'}
            response = self.session.get(search_url, params=params)
            
            if response.status_code == 200:
                self.log_test("搜尋功能", "PASS", "供應商搜尋功能正常")
            else:
                self.log_test("搜尋功能", "FAIL", f"搜尋失敗: {response.status_code}")
                
        except Exception as e:
            self.log_test("搜尋功能", "FAIL", f"搜尋出錯: {str(e)}")
    
    def test_responsive_design(self):
        """測試響應式設計"""
        try:
            # 模擬不同設備的 User-Agent
            mobile_headers = {
                'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15'
            }
            
            response = self.session.get(self.base_url, headers=mobile_headers)
            if response.status_code == 200:
                # 檢查是否包含響應式設計的關鍵字
                if 'viewport' in response.text and 'bootstrap' in response.text.lower():
                    self.log_test("響應式設計", "PASS", "包含響應式設計元素")
                else:
                    self.log_test("響應式設計", "WARN", "可能缺少響應式設計元素")
            else:
                self.log_test("響應式設計", "FAIL", f"無法測試: {response.status_code}")
                
        except Exception as e:
            self.log_test("響應式設計", "FAIL", f"測試出錯: {str(e)}")
    
    def test_performance(self):
        """測試頁面性能"""
        pages_to_test = [
            ('/', '首頁'),
            ('/suppliers/', '供應商列表'),
            ('/dj/', 'DJ列表'),
        ]
        
        for url_path, page_name in pages_to_test:
            try:
                start_time = time.time()
                response = self.session.get(urljoin(self.base_url, url_path))
                end_time = time.time()
                
                load_time = (end_time - start_time) * 1000
                
                if response.status_code == 200:
                    if load_time < 1000:  # 1秒內
                        self.log_test(f"性能-{page_name}", "PASS", f"載入時間: {load_time:.0f}ms")
                    else:
                        self.log_test(f"性能-{page_name}", "WARN", f"載入較慢: {load_time:.0f}ms")
                else:
                    self.log_test(f"性能-{page_name}", "FAIL", f"頁面錯誤: {response.status_code}")
                    
            except Exception as e:
                self.log_test(f"性能-{page_name}", "FAIL", f"測試出錯: {str(e)}")
    
    def test_security_features(self):
        """測試安全性功能"""
        try:
            # 測試 CSRF 保護
            create_url = urljoin(self.base_url, '/events/create/')
            response = self.session.get(create_url)
            
            if 'csrfmiddlewaretoken' in response.text:
                self.log_test("安全性-CSRF", "PASS", "CSRF 保護已啟用")
            else:
                self.log_test("安全性-CSRF", "WARN", "可能缺少 CSRF 保護")
                
            # 測試 SQL 注入防護（基本測試）
            search_url = urljoin(self.base_url, '/suppliers/')
            malicious_params = {'search': "'; DROP TABLE users; --"}
            response = self.session.get(search_url, params=malicious_params)
            
            if response.status_code == 200:
                self.log_test("安全性-SQL注入", "PASS", "系統能處理惡意輸入")
            else:
                self.log_test("安全性-SQL注入", "WARN", "需要進一步檢查安全性")
                
        except Exception as e:
            self.log_test("安全性測試", "FAIL", f"安全性測試出錯: {str(e)}")
    
    def run_all_tests(self):
        """執行所有測試"""
        print("🎯 PAPA COLLEGE - 用戶功能測試開始")
        print("模擬真實用戶操作，測試所有功能")
        print("=" * 60)
        
        # 基本功能測試
        print("\n📋 基本功能測試:")
        if not self.test_homepage_access():
            print("❌ 首頁無法訪問，停止後續測試")
            return
            
        self.test_navigation_links()
        
        # 用戶功能測試
        print("\n👤 用戶功能測試:")
        if self.test_user_registration():
            time.sleep(1)  # 等待註冊完成
            self.test_user_login()
            time.sleep(1)  # 等待登入完成
            self.test_event_creation()
        
        # 其他功能測試
        print("\n🔍 其他功能測試:")
        self.test_search_functionality()
        
        # 性能和安全性測試
        print("\n⚡ 性能和安全性測試:")
        self.test_responsive_design()
        self.test_performance()
        self.test_security_features()
    
    def generate_report(self):
        """生成測試報告"""
        print("\n" + "=" * 60)
        print("📊 測試報告總結")
        print("=" * 60)
        
        passed = len([r for r in self.test_results if r['status'] == 'PASS'])
        failed = len([r for r in self.test_results if r['status'] == 'FAIL'])
        warnings = len([r for r in self.test_results if r['status'] == 'WARN'])
        total = len(self.test_results)
        
        print(f"✅ 通過測試: {passed} 個")
        print(f"❌ 失敗測試: {failed} 個")
        print(f"⚠️  警告項目: {warnings} 個")
        print(f"📈 總測試數: {total} 個")
        
        if failed == 0:
            if warnings == 0:
                print(f"🌟 系統狀態: 優秀 - 所有功能運作正常")
            else:
                print(f"👍 系統狀態: 良好 - 主要功能正常，有 {warnings} 個需要關注的項目")
        else:
            print(f"🚫 系統狀態: 需要修復 - 發現 {failed} 個嚴重問題")
        
        # 顯示失敗的測試
        if failed > 0:
            print(f"\n❌ 需要修復的問題:")
            for result in self.test_results:
                if result['status'] == 'FAIL':
                    print(f"   • {result['test_name']}: {result['message']}")
        
        # 顯示警告項目
        if warnings > 0:
            print(f"\n⚠️  需要關注的項目:")
            for result in self.test_results:
                if result['status'] == 'WARN':
                    print(f"   • {result['test_name']}: {result['message']}")

def main():
    print("🧪 PAPA COLLEGE - 全面功能測試工具")
    print("時間:", datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    
    tester = UserFunctionalTest()
    tester.run_all_tests()
    tester.generate_report()
    
    print(f"\n💡 測試建議:")
    print(f"   1. 定期執行此測試確保功能正常")
    print(f"   2. 在部署前務必執行完整測試")
    print(f"   3. 根據警告項目進行系統優化")
    print(f"   4. 監控用戶回饋以發現潛在問題")

if __name__ == "__main__":
    main()
