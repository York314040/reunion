#!/usr/bin/env python
"""
系統Bug修復工具 - 後端工程師視角
"""

import os
import sys
import django

# 設置Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.contrib.auth.models import User
from django.core.management import execute_from_command_line
from django.db import transaction

def create_users_app():
    """創建users應用"""
    print("🔧 創建users應用...")
    
    try:
        # 檢查users app是否存在
        if not os.path.exists('users'):
            os.system('python manage.py startapp users')
            print("✅ users應用創建成功")
        else:
            print("✅ users應用已存在")
    except Exception as e:
        print(f"❌ 創建users應用失敗: {e}")

def fix_user_profile_model():
    """修復用戶Profile模型"""
    print("🔧 修復用戶Profile模型...")
    
    profile_model = '''from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

class Profile(models.Model):
    USER_TYPE_CHOICES = [
        ('normal', '一般用戶'),
        ('dj', 'DJ'),
        ('supplier', '供應商'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    user_type = models.CharField(max_length=20, choices=USER_TYPE_CHOICES, default='normal')
    phone = models.CharField(max_length=20, blank=True)
    bio = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.user.username} - {self.get_user_type_display()}"

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    if hasattr(instance, 'profile'):
        instance.profile.save()
'''
    
    try:
        os.makedirs('users', exist_ok=True)
        with open('users/models.py', 'w', encoding='utf-8') as f:
            f.write(profile_model)
        print("✅ Profile模型創建成功")
    except Exception as e:
        print(f"❌ Profile模型創建失敗: {e}")

def fix_users_views():
    """修復users視圖"""
    print("🔧 修復users視圖...")
    
    views_content = '''from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import Profile
from .forms import ProfileForm

class CustomUserCreationForm(UserCreationForm):
    user_type = forms.ChoiceField(choices=Profile.USER_TYPE_CHOICES)
    
    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2', 'user_type')
    
    def save(self, commit=True):
        user = super().save(commit=commit)
        if commit:
            profile = Profile.objects.get(user=user)
            profile.user_type = self.cleaned_data['user_type']
            profile.save()
        return user

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, '註冊成功！')
            return redirect('events:home')
    else:
        form = CustomUserCreationForm()
    return render(request, 'registration/register.html', {'form': form})

@login_required
def profile(request):
    profile_obj, created = Profile.objects.get_or_create(user=request.user)
    return render(request, 'users/profile.html', {'profile': profile_obj})
'''
    
    try:
        with open('users/views.py', 'w', encoding='utf-8') as f:
            f.write(views_content)
        print("✅ users視圖創建成功")
    except Exception as e:
        print(f"❌ users視圖創建失敗: {e}")

def fix_users_urls():
    """修復users URL配置"""
    print("🔧 修復users URL配置...")
    
    urls_content = '''from django.urls import path
from . import views

app_name = 'users'

urlpatterns = [
    path('register/', views.register, name='register'),
    path('profile/', views.profile, name='profile'),
]
'''
    
    try:
        with open('users/urls.py', 'w', encoding='utf-8') as f:
            f.write(urls_content)
        print("✅ users URL配置創建成功")
    except Exception as e:
        print(f"❌ users URL配置創建失敗: {e}")

def fix_messaging_views():
    """修復messaging視圖中的bug"""
    print("🔧 修復messaging視圖...")
    
    # 讀取現有的messaging views
    try:
        with open('messaging/views.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 檢查是否需要修復日期時間問題
        if 'timezone' not in content:
            # 添加timezone import
            if 'from django.utils import timezone' not in content:
                content = content.replace(
                    'from django.shortcuts import render',
                    'from django.shortcuts import render\nfrom django.utils import timezone'
                )
        
        # 修復event_date的時區問題
        content = content.replace(
            "event_date='2024-12-31 18:00:00'",
            "event_date=timezone.make_aware(datetime(2024, 12, 31, 18, 0))"
        )
        
        with open('messaging/views.py', 'w', encoding='utf-8') as f:
            f.write(content)
        print("✅ messaging視圖修復成功")
        
    except Exception as e:
        print(f"❌ messaging視圖修復失敗: {e}")

def fix_form_validation():
    """修復表單驗證"""
    print("🔧 修復表單驗證...")
    
    # 修復events/forms.py
    try:
        events_form_content = '''from django import forms
from .models import Event, EventType

class EventForm(forms.ModelForm):
    class Meta:
        model = Event
        fields = [
            'title', 'description', 'event_type', 'budget_min', 'budget_max',
            'expected_attendees', 'event_date', 'location', 'contact_person',
            'contact_phone', 'contact_email'
        ]
        widgets = {
            'event_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'description': forms.Textarea(attrs={'rows': 4}),
            'budget_min': forms.NumberInput(attrs={'min': 1, 'max': 99999999}),
            'budget_max': forms.NumberInput(attrs={'min': 1, 'max': 99999999}),
            'expected_attendees': forms.NumberInput(attrs={'min': 1, 'max': 10000}),
        }
    
    def clean(self):
        cleaned_data = super().clean()
        budget_min = cleaned_data.get('budget_min')
        budget_max = cleaned_data.get('budget_max')
        
        if budget_min and budget_max:
            if budget_min > budget_max:
                raise forms.ValidationError('最小預算不能大於最大預算')
        
        title = cleaned_data.get('title')
        if title and len(title.strip()) == 0:
            raise forms.ValidationError('標題不能為空')
            
        expected_attendees = cleaned_data.get('expected_attendees')
        if expected_attendees and expected_attendees <= 0:
            raise forms.ValidationError('預期參與人數必須大於0')
        
        return cleaned_data
    
    def clean_contact_phone(self):
        phone = self.cleaned_data.get('contact_phone')
        if phone:
            # 簡單的電話號碼驗證
            import re
            if not re.match(r'^[0-9+\-\s()]{8,20}$', phone):
                raise forms.ValidationError('請輸入有效的電話號碼')
        return phone
    
    def clean_contact_email(self):
        email = self.cleaned_data.get('contact_email')
        if email:
            # 使用Django內建的郵箱驗證
            from django.core.validators import validate_email
            from django.core.exceptions import ValidationError
            try:
                validate_email(email)
            except ValidationError:
                raise forms.ValidationError('請輸入有效的郵箱地址')
        return email
'''
        
        with open('events/forms.py', 'w', encoding='utf-8') as f:
            f.write(events_form_content)
        print("✅ events表單驗證修復成功")
        
    except Exception as e:
        print(f"❌ 表單驗證修復失敗: {e}")

def update_settings():
    """更新settings.py添加users app"""
    print("🔧 更新settings.py...")
    
    try:
        with open('party_platform/settings.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        if "'users'," not in content:
            # 添加users app到INSTALLED_APPS
            content = content.replace(
                "'django.contrib.staticfiles',",
                "'django.contrib.staticfiles',\n    'users',"
            )
            
            with open('party_platform/settings.py', 'w', encoding='utf-8') as f:
                f.write(content)
            print("✅ settings.py更新成功")
        else:
            print("✅ users app已在settings.py中")
            
    except Exception as e:
        print(f"❌ settings.py更新失敗: {e}")

def update_main_urls():
    """更新主URL配置"""
    print("🔧 更新主URL配置...")
    
    try:
        with open('party_platform/urls.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        if "path('users/', include('users.urls'))," not in content:
            # 添加users URLs
            content = content.replace(
                "path('dashboards/', include('dashboards.urls')),",
                "path('dashboards/', include('dashboards.urls')),\n    path('users/', include('users.urls')),"
            )
            
            with open('party_platform/urls.py', 'w', encoding='utf-8') as f:
                f.write(content)
            print("✅ 主URL配置更新成功")
        else:
            print("✅ users URLs已配置")
            
    except Exception as e:
        print(f"❌ 主URL配置更新失敗: {e}")

def create_admin_py():
    """創建users admin配置"""
    print("🔧 創建users admin配置...")
    
    admin_content = '''from django.contrib import admin
from .models import Profile

@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'user_type', 'created_at']
    list_filter = ['user_type', 'created_at']
    search_fields = ['user__username', 'user__email']
'''
    
    try:
        with open('users/admin.py', 'w', encoding='utf-8') as f:
            f.write(admin_content)
        print("✅ users admin配置創建成功")
    except Exception as e:
        print(f"❌ users admin配置創建失敗: {e}")

def create_init_files():
    """創建必要的__init__.py文件"""
    print("🔧 創建__init__.py文件...")
    
    try:
        with open('users/__init__.py', 'w') as f:
            f.write('')
        with open('users/apps.py', 'w', encoding='utf-8') as f:
            f.write('''from django.apps import AppConfig

class UsersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'users'
''')
        print("✅ __init__.py和apps.py創建成功")
    except Exception as e:
        print(f"❌ 文件創建失敗: {e}")

def main():
    """主修復函數"""
    print("🚀 開始系統Bug修復...")
    print("=" * 60)
    
    # 1. 創建users應用和相關文件
    create_users_app()
    create_init_files()
    fix_user_profile_model()
    fix_users_views()
    fix_users_urls()
    create_admin_py()
    
    # 2. 更新配置
    update_settings()
    update_main_urls()
    
    # 3. 修復其他問題
    fix_messaging_views()
    fix_form_validation()
    
    print("\n" + "=" * 60)
    print("🏁 Bug修復完成")
    print("=" * 60)
    
    print("\n📋 接下來需要執行的命令:")
    print("1. python manage.py makemigrations users")
    print("2. python manage.py migrate")
    print("3. 重新啟動開發服務器")

if __name__ == '__main__':
    main()
