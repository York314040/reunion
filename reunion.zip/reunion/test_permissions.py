#!/usr/bin/env python
"""
測試權限管理功能
"""

import os
import sys
import django

# 設置Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.test import Client
from django.contrib.auth.models import User

def test_permission_management():
    """測試權限管理功能"""
    print("🔧 測試權限管理功能...")
    
    # 創建測試客戶端
    client = Client()
    
    # 使用York（超級用戶）登入
    login_success = client.login(username='York', password='york0314')
    if not login_success:
        print("❌ 超級用戶登入失敗")
        return
    print("✅ 超級用戶登入成功")
    
    # 獲取一個一般用戶進行測試
    test_user = User.objects.filter(is_superuser=False, username='ABCD').first()
    if not test_user:
        print("❌ 找不到測試用戶")
        return
    
    print(f"📝 測試用戶: {test_user.username}")
    print(f"   初始狀態: superuser={test_user.is_superuser}, staff={test_user.is_staff}, active={test_user.is_active}")
    
    # 測試切換超級用戶權限
    print("\n🔄 測試切換超級用戶權限...")
    
    # 先獲取 CSRF token
    csrf_response = client.get('/events/manage/users/')
    csrf_token = csrf_response.context['csrf_token'] if csrf_response.context else None
    
    response = client.post(f'/events/users/{test_user.id}/toggle-superuser/', {
        'csrfmiddlewaretoken': csrf_token
    })
    
    print(f"響應狀態碼: {response.status_code}")
    if response.status_code == 200:
        data = response.json()
        print(f"響應內容: {data}")
    else:
        print(f"響應內容: {response.content.decode()[:200]}")
    
    # 重新獲取用戶狀態
    test_user.refresh_from_db()
    print(f"   更新後狀態: superuser={test_user.is_superuser}, staff={test_user.is_staff}, active={test_user.is_active}")

def test_user_management_page():
    """測試用戶管理頁面訪問"""
    print("\n📄 測試用戶管理頁面訪問...")
    
    client = Client()
    
    # 使用York（超級用戶）登入
    login_success = client.login(username='York', password='york0314')
    if not login_success:
        print("❌ 超級用戶登入失敗")
        return
    
    # 訪問新的用戶管理頁面
    response = client.get('/events/manage/users/')
    print(f"新用戶管理頁面狀態碼: {response.status_code}")
    
    # 訪問舊的用戶管理頁面
    response = client.get('/events/management/users/')
    print(f"舊用戶管理頁面狀態碼: {response.status_code}")

def main():
    """主函數"""
    print("🚀 開始測試權限管理功能...")
    print("=" * 60)
    
    test_user_management_page()
    test_permission_management()
    
    print("\n" + "=" * 60)
    print("🏁 測試完成")

if __name__ == '__main__':
    main()
