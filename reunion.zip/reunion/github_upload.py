#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GitHub 自動上傳腳本 - PAPA COLLEGE B2B聚會派對媒合平台
"""

import subprocess
import sys
import os
import time
from datetime import datetime

def run_command(command, description, check_output=False, ignore_errors=False):
    """執行命令並處理結果"""
    print(f"\n🔧 {description}")
    print(f"📝 執行命令: {command}")
    
    try:
        if check_output:
            result = subprocess.run(command, shell=True, capture_output=True, text=True, cwd=os.getcwd())
            if result.returncode == 0:
                print(f"✅ 成功: {description}")
                return result.stdout.strip()
            else:
                if ignore_errors:
                    print(f"⚠️ 警告: {description} - {result.stderr}")
                    return result.stdout.strip() if result.stdout else ""
                else:
                    print(f"❌ 失敗: {description}")
                    print(f"錯誤信息: {result.stderr}")
                    return None
        else:
            result = subprocess.run(command, shell=True, cwd=os.getcwd())
            if result.returncode == 0:
                print(f"✅ 成功: {description}")
                return True
            else:
                if ignore_errors:
                    print(f"⚠️ 警告: {description}")
                    return True
                else:
                    print(f"❌ 失敗: {description}")
                    return False
    except Exception as e:
        print(f"❌ 執行錯誤: {str(e)}")
        return False if not ignore_errors else True

def check_git_status():
    """檢查 Git 狀態"""
    print("\n📊 檢查 Git 狀態...")
    
    # 檢查是否為 Git 倉庫
    if not os.path.exists('.git'):
        print("❌ 這不是一個 Git 倉庫")
        return False
    
    # 檢查分支
    branch = run_command("git branch --show-current", "檢查當前分支", check_output=True)
    if branch:
        print(f"📍 當前分支: {branch}")
    
    # 檢查狀態
    status = run_command("git status --porcelain", "檢查 Git 狀態", check_output=True)
    if status:
        print("📋 有未提交的變更:")
        print(status)
        return False
    else:
        print("✅ 工作目錄乾淨")
        return True

def setup_github_remote(repo_name, username):
    """設置 GitHub remote"""
    print(f"\n🔗 設置 GitHub remote...")
    
    # 檢查是否已有 origin remote
    remotes = run_command("git remote -v", "檢查現有 remote", check_output=True)
    if remotes:
        print("📋 現有 remote:")
        print(remotes)
        
        if "origin" in remotes:
            # 更新 origin
            github_url = f"https://github.com/{username}/{repo_name}.git"
            success = run_command(f"git remote set-url origin {github_url}", f"更新 origin 為 GitHub")
        else:
            # 添加 origin
            github_url = f"https://github.com/{username}/{repo_name}.git"
            success = run_command(f"git remote add origin {github_url}", f"添加 GitHub origin")
    else:
        # 添加 origin
        github_url = f"https://github.com/{username}/{repo_name}.git"
        success = run_command(f"git remote add origin {github_url}", f"添加 GitHub origin")
    
    return success

def create_gitignore():
    """創建 .gitignore 文件"""
    print("\n📝 創建/更新 .gitignore 文件...")
    
    gitignore_content = """# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
env/
venv/
ENV/
env.bak/
venv.bak/

# Django
*.log
local_settings.py
db.sqlite3
db.sqlite3-journal
media/
staticfiles/

# Environment variables
.env
.env.local
.env.production

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Heroku
.heroku/

# Node modules (if any)
node_modules/

# Build files
build/
dist/

# Logs
*.log
logs/

# Coverage reports
htmlcov/
.coverage
.coverage.*
coverage.xml

# pytest
.pytest_cache/

# mypy
.mypy_cache/
.dmypy.json
dmypy.json
"""
    
    try:
        with open('.gitignore', 'w', encoding='utf-8') as f:
            f.write(gitignore_content.strip())
        print("✅ .gitignore 文件已創建/更新")
        return True
    except Exception as e:
        print(f"❌ 創建 .gitignore 失敗: {str(e)}")
        return False

def create_readme():
    """創建 README.md 文件"""
    print("\n📄 創建/更新 README.md 文件...")
    
    readme_content = """# PAPA COLLEGE B2B 聚會派對媒合平台

🎉 一個專為B2B聚會和派對活動設計的媒合平台

## 📋 功能特色

### 🎯 核心功能
- **供應商管理** - 完整的供應商註冊和管理系統
- **活動發布** - 多種類型的派對活動創建和管理
- **DJ 管理** - DJ 檔案管理和排名系統
- **用戶系統** - 用戶註冊、登入和個人資料管理
- **響應式設計** - 支援桌面和行動裝置

### 🎪 活動類型
- 生日派對
- 公司聚會
- 婚禮派對
- 畢業派對
- 節慶派對
- 主題派對
- 商務酒會
- 音樂派對
- 戶外派對
- 歡送派對

## 🚀 技術架構

### 後端技術
- **Django 4.2.23** - Python Web 框架
- **PostgreSQL** - 資料庫系統
- **Gunicorn** - WSGI HTTP 伺服器
- **WhiteNoise** - 靜態文件服務

### 前端技術
- **Bootstrap 4** - CSS 框架
- **Django Templates** - 模板系統
- **Crispy Forms** - 表單美化

### 部署平台
- **Heroku** - 雲端部署平台
- **GitHub** - 原始碼管理

## 🌐 線上版本

- **網站**: https://papa-college-b2b-ee7db6fb42bd.herokuapp.com/
- **管理後台**: https://papa-college-b2b-ee7db6fb42bd.herokuapp.com/admin/

## 🛠️ 本地開發

### 環境需求
- Python 3.9+
- Django 4.2+
- PostgreSQL (生產環境)
- SQLite (開發環境)

### 安裝步驟

1. **克隆專案**
```bash
git clone https://github.com/York314040/reunion.git
cd reunion
```

2. **創建虛擬環境**
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# 或
venv\\Scripts\\activate  # Windows
```

3. **安裝依賴**
```bash
pip install -r requirements.txt
```

4. **設置環境變數**
創建 `.env` 文件：
```
SECRET_KEY=your-secret-key
DEBUG=True
ALLOWED_HOSTS=localhost,127.0.0.1
```

5. **執行遷移**
```bash
python manage.py migrate
```

6. **創建超級用戶**
```bash
python manage.py createsuperuser
```

7. **啟動開發伺服器**
```bash
python manage.py runserver
```

## 📦 部署到 Heroku

使用自動化部署腳本：
```bash
python heroku_auto_deploy.py
```

或手動部署：
```bash
# 1. 創建 Heroku 應用
heroku create your-app-name

# 2. 設置環境變數
heroku config:set SECRET_KEY="your-secret-key"
heroku config:set DEBUG=False
heroku config:set ALLOWED_HOSTS="your-app.herokuapp.com"

# 3. 部署
git push heroku main

# 4. 執行遷移
heroku run python manage.py migrate

# 5. 創建超級用戶
heroku run python manage.py createsuperuser
```

## 📁 專案結構

```
reunion/
├── party_platform/          # Django 主要設定
├── events/                  # 活動管理應用
├── suppliers/               # 供應商管理應用
├── dj_management/           # DJ 管理應用
├── users/                   # 用戶管理應用
├── messaging/               # 訊息系統應用
├── static/                  # 靜態文件
├── templates/               # 模板文件
├── requirements.txt         # Python 依賴
├── Procfile                # Heroku 部署設定
├── runtime.txt             # Python 版本設定
└── manage.py               # Django 管理腳本
```

## 🔧 管理命令

### 本地開發
```bash
# 啟動開發伺服器
python manage.py runserver

# 創建新的遷移
python manage.py makemigrations

# 執行遷移
python manage.py migrate

# 收集靜態文件
python manage.py collectstatic

# 創建超級用戶
python manage.py createsuperuser
```

### Heroku 部署
```bash
# 查看應用狀態
heroku ps --app your-app-name

# 查看日誌
heroku logs --tail --app your-app-name

# 重啟應用
heroku restart --app your-app-name

# 執行 Django 命令
heroku run python manage.py <command> --app your-app-name
```

## 🤝 貢獻

歡迎提交 Issue 和 Pull Request 來改善專案！

## 📄 授權

本專案採用 MIT 授權條款。

## 👨‍💻 開發者

- **York** - 主要開發者
- **Email**: wssd314040@gmail.com

## 🙏 致謝

感謝所有為這個專案貢獻的開發者和使用者！

---

⭐ 如果這個專案對您有幫助，請給我們一個 Star！
"""
    
    try:
        with open('README.md', 'w', encoding='utf-8') as f:
            f.write(readme_content)
        print("✅ README.md 文件已創建/更新")
        return True
    except Exception as e:
        print(f"❌ 創建 README.md 失敗: {str(e)}")
        return False

def commit_and_push():
    """提交並推送到 GitHub"""
    print("\n📤 準備提交並推送到 GitHub...")
    
    # 添加所有文件
    if not run_command("git add .", "添加所有文件"):
        return False
    
    # 提交變更
    commit_message = f"Upload to GitHub - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    if not run_command(f'git commit -m "{commit_message}"', "提交變更", ignore_errors=True):
        print("⚠️ 可能沒有新的變更需要提交")
    
    # 推送到 GitHub
    success = run_command("git push -u origin main", "推送到 GitHub main 分支")
    if not success:
        # 嘗試推送到 master 分支
        print("⚠️ 推送到 main 分支失敗，嘗試推送到 master 分支...")
        success = run_command("git push -u origin master", "推送到 GitHub master 分支")
    
    return success

def main():
    """主函數"""
    print("="*70)
    print("🐙 PAPA COLLEGE - GitHub 自動上傳工具")
    print("="*70)
    print(f"⏰ 開始時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    try:
        # 1. 檢查 Git 狀態
        print("\n📋 檢查專案狀態...")
        
        # 2. 創建必要文件
        create_gitignore()
        create_readme()
        
        # 3. 設置 GitHub 信息
        print("\n🔗 設置 GitHub 資訊...")
        repo_name = "reunion"  # 使用現有的倉庫名稱
        username = "York314040"  # 使用現有的用戶名
        
        print(f"📍 GitHub 用戶名: {username}")
        print(f"📁 倉庫名稱: {repo_name}")
        print(f"🌐 GitHub 網址: https://github.com/{username}/{repo_name}")
        
        # 4. 設置 remote
        if not setup_github_remote(repo_name, username):
            print("❌ 設置 GitHub remote 失敗")
            return
        
        # 5. 提交並推送
        if not commit_and_push():
            print("❌ 推送到 GitHub 失敗")
            return
        
        # 6. 完成
        print("\n" + "="*70)
        print("🎊 GitHub 上傳完成！")
        print("="*70)
        print(f"🌐 GitHub 倉庫: https://github.com/{username}/{repo_name}")
        print(f"📁 主分支: https://github.com/{username}/{repo_name}/tree/main")
        print(f"📄 README: https://github.com/{username}/{repo_name}#readme")
        
        print("\n🔗 快速連結:")
        print(f"   📋 查看代碼: https://github.com/{username}/{repo_name}")
        print(f"   📥 克隆倉庫: git clone https://github.com/{username}/{repo_name}.git")
        print(f"   🌐 線上版本: https://papa-college-b2b-ee7db6fb42bd.herokuapp.com/")
        
        print("\n📊 專案統計:")
        file_count = run_command("find . -name '*.py' | wc -l", "統計 Python 文件數量", check_output=True, ignore_errors=True)
        if file_count:
            print(f"   🐍 Python 文件: {file_count} 個")
        
        print(f"\n⏰ 完成時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("🎉 您的 PAPA COLLEGE 平台已成功上傳到 GitHub！")
        
    except KeyboardInterrupt:
        print("\n⏹️ 用戶中斷上傳")
    except Exception as e:
        print(f"\n❌ 上傳過程中發生錯誤: {str(e)}")

if __name__ == "__main__":
    main()
