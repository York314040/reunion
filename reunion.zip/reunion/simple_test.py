#!/usr/bin/env python
"""
簡單測試權限管理功能
"""

import os
import sys
import django

# 設置Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.test import Client
from django.contrib.auth.models import User

def test_simple():
    """簡單測試"""
    print("🔧 簡單測試權限管理功能...")
    
    # 創建測試客戶端
    client = Client()
    
    # 使用York（超級用戶）登入
    login_success = client.login(username='York', password='york0314')
    if not login_success:
        print("❌ 超級用戶登入失敗")
        return
    print("✅ 超級用戶登入成功")
    
    # 訪問用戶管理頁面
    response = client.get('/manage/users/')
    print(f"用戶管理頁面狀態碼: {response.status_code}")
    
    if response.status_code == 200:
        print("✅ 用戶管理頁面可以正常訪問")
    else:
        print(f"❌ 用戶管理頁面訪問失敗: {response.status_code}")
        print(f"響應內容: {response.content.decode()[:200]}")
    
    # 獲取一個一般用戶進行測試
    test_user = User.objects.filter(is_superuser=False, username='ABCD').first()
    if not test_user:
        print("❌ 找不到測試用戶")
        return
    
    print(f"📝 測試用戶: {test_user.username}")
    print(f"   初始狀態: superuser={test_user.is_superuser}, staff={test_user.is_staff}")
    
    # 測試切換超級用戶權限
    print("\n🔄 測試切換超級用戶權限...")
    
    response = client.post(f'/users/{test_user.id}/toggle-superuser/')
    print(f"切換超級用戶響應狀態碼: {response.status_code}")
    
    if response.status_code == 200:
        data = response.json()
        print(f"響應內容: {data}")
        if data.get('success'):
            print("✅ 超級用戶權限切換成功")
        else:
            print(f"❌ 超級用戶權限切換失敗: {data.get('message')}")
    else:
        print(f"❌ 請求失敗，狀態碼: {response.status_code}")
        print(f"響應內容: {response.content.decode()[:200]}")
    
    # 重新獲取用戶狀態
    test_user.refresh_from_db()
    print(f"   更新後狀態: superuser={test_user.is_superuser}, staff={test_user.is_staff}")

if __name__ == '__main__':
    test_simple()
