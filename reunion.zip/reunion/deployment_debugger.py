#!/usr/bin/env python
"""
部署錯誤調試器 - 詳細診斷部署問題
"""

import os
import sys
import traceback
from pathlib import Path

# 設定 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')

import django
django.setup()

from deployment_automation import DeploymentAutomation


def debug_deployment_check():
    """詳細調試部署檢查"""
    print("🔍 詳細部署錯誤調試")
    print("="*60)
    
    automation = DeploymentAutomation()
    
    try:
        print("1. 開始執行部署檢查...")
        result = automation.pre_deployment_checks()
        
        print(f"\n📊 檢查結果概覽:")
        print(f"總體狀態: {'✅ 通過' if result['all_passed'] else '❌ 失敗'}")
        print(f"檢查時間: {result['timestamp']}")
        
        print(f"\n📋 詳細檢查項目:")
        for check_name, check_result in result['checks'].items():
            status = "✅" if check_result['passed'] else "❌"
            print(f"  {status} {check_name}: {check_result['message']}")
            
            # 如果有詳細信息，顯示出來
            if 'details' in check_result:
                print(f"     詳細: {check_result['details']}")
                
            # 如果檢查失敗，顯示錯誤原因
            if not check_result['passed']:
                print(f"     ⚠️ 失敗原因: {check_result.get('error', '未知錯誤')}")
                
    except Exception as e:
        print(f"❌ 部署檢查執行失敗:")
        print(f"錯誤類型: {type(e).__name__}")
        print(f"錯誤信息: {str(e)}")
        print(f"\n📜 詳細錯誤堆疊:")
        traceback.print_exc()
        
        # 嘗試分析可能的原因
        print(f"\n💡 可能的解決方案:")
        
        if "WindowsPath" in str(e):
            print("- JSON序列化錯誤: 需要將Path對象轉換為字符串")
            
        if "No module named" in str(e):
            print("- 模組導入錯誤: 檢查依賴是否正確安裝")
            
        if "does not exist" in str(e):
            print("- 文件/目錄不存在: 檢查路徑是否正確")
            
        if "Permission denied" in str(e):
            print("- 權限錯誤: 檢查文件/目錄權限")


def test_individual_checks():
    """單獨測試每個檢查項目"""
    print("\n🔬 單獨測試各個檢查項目")
    print("="*60)
    
    automation = DeploymentAutomation()
    
    # 測試各個檢查項目
    check_methods = [
        ('數據庫遷移', automation._check_migrations),
        ('依賴檢查', automation._check_dependencies),
        ('設定檢查', automation._check_settings),
        ('靜態文件', automation._check_static_files),
        ('數據庫連接', automation._check_database_connection),
        ('關鍵測試', automation._run_critical_tests)
    ]
    
    for check_name, check_method in check_methods:
        print(f"\n🧪 測試: {check_name}")
        try:
            result = check_method()
            status = "✅ 通過" if result['passed'] else "❌ 失敗"
            print(f"結果: {status}")
            print(f"訊息: {result['message']}")
            
            if 'details' in result:
                print(f"詳細: {result['details']}")
                
        except Exception as e:
            print(f"❌ 執行失敗: {str(e)}")
            print(f"錯誤類型: {type(e).__name__}")


def check_environment():
    """檢查環境配置"""
    print("\n🌍 環境配置檢查")
    print("="*60)
    
    # 檢查Python版本
    print(f"Python版本: {sys.version}")
    
    # 檢查Django版本
    try:
        import django
        print(f"Django版本: {django.get_version()}")
    except:
        print("❌ Django未正確安裝")
    
    # 檢查工作目錄
    print(f"工作目錄: {os.getcwd()}")
    
    # 檢查關鍵文件是否存在
    critical_files = [
        'manage.py',
        'party_platform/settings.py',
        'deployment_automation.py',
        'requirements.txt'
    ]
    
    print(f"\n📁 關鍵文件檢查:")
    for file_path in critical_files:
        exists = os.path.exists(file_path)
        status = "✅" if exists else "❌"
        print(f"  {status} {file_path}")
    
    # 檢查環境變量
    print(f"\n🔧 環境變量:")
    django_settings = os.environ.get('DJANGO_SETTINGS_MODULE', '未設定')
    print(f"  DJANGO_SETTINGS_MODULE: {django_settings}")


def main():
    """主函數"""
    print("🚨 部署系統詳細錯誤診斷工具")
    print("="*70)
    
    # 環境檢查
    check_environment()
    
    # 單獨測試各個檢查項目
    test_individual_checks()
    
    # 詳細調試部署檢查
    debug_deployment_check()
    
    print("\n" + "="*70)
    print("📊 診斷完成！請查看上述詳細輸出以找出問題所在。")


if __name__ == "__main__":
    main()
