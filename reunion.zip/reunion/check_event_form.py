#!/usr/bin/env python
"""
檢查EventType數據並創建測試數據
"""

import os
import sys
import django
from django.test import Client
from django.contrib.auth import get_user_model

# 設置Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from events.models import Event, EventType

User = get_user_model()

def check_event_types():
    """檢查EventType數據"""
    print("🔍 檢查EventType數據...")
    
    event_types = EventType.objects.all()
    print(f"✅ 現有EventType數量: {event_types.count()}")
    
    for et in event_types:
        print(f"  - {et.name} (ID: {et.id})")
    
    if event_types.count() == 0:
        print("⚠️ 沒有EventType數據，創建測試數據...")
        
        # 創建基本的活動類型
        types_to_create = [
            {'name': 'corporate', 'description': '企業活動'},
            {'name': 'wedding', 'description': '婚禮'},
            {'name': 'birthday', 'description': '生日派對'},
            {'name': 'conference', 'description': '會議'},
            {'name': 'other', 'description': '其他'},
        ]
        
        for type_data in types_to_create:
            et, created = EventType.objects.get_or_create(
                name=type_data['name'],
                defaults={'description': type_data['description']}
            )
            if created:
                print(f"✅ 創建EventType: {et.name}")
            else:
                print(f"⚠️ EventType已存在: {et.name}")
    
    return EventType.objects.first()

def test_event_form_with_valid_data():
    """使用有效數據測試活動表單"""
    print("\n🔍 使用有效數據測試活動表單...")
    
    # 確保有EventType
    event_type = check_event_types()
    if not event_type:
        print("❌ 無法獲取EventType，停止測試")
        return
    
    # 創建測試客戶端
    client = Client()
    
    # 獲取或創建測試用戶
    try:
        user = User.objects.get(username='testuser_debug')
        print(f"✅ 使用現有測試用戶: {user.username}")
    except User.DoesNotExist:
        user = User.objects.create_user(
            username='testuser_debug',
            email='test@example.com',
            password='testpass123'
        )
        print(f"✅ 創建測試用戶: {user.username}")
    
    # 登入
    login_success = client.login(username='testuser_debug', password='testpass123')
    if not login_success:
        print("❌ 用戶登入失敗")
        return
    print("✅ 用戶登入成功")
    
    # 正確的表單數據
    event_data = {
        'title': '測試活動需求',
        'description': '這是一個測試活動需求的詳細描述',
        'event_type': event_type.id,  # 使用EventType的ID
        'budget_min': 10000,
        'budget_max': 50000,
        'expected_attendees': 100,
        'event_date': '2024-12-31T18:00',  # datetime-local格式
        'location': '台北市信義區',
        'contact_person': '測試聯絡人',
        'contact_phone': '0912345678',
        'contact_email': 'test@example.com'
    }
    
    print(f"📝 表單數據: {event_data}")
    
    # 測試POST請求
    from django.urls import reverse
    create_url = reverse('events:create_event')
    
    try:
        response = client.post(create_url, event_data)
        print(f"✅ POST請求完成: 狀態碼 {response.status_code}")
        
        if response.status_code == 302:
            print(f"✅ 表單提交成功，重定向到: {response.url}")
            
            # 檢查是否創建了Event
            events = Event.objects.filter(title='測試活動需求')
            if events.exists():
                event = events.first()
                print(f"✅ Event創建成功: {event.title} (ID: {event.id})")
            else:
                print("❌ Event未創建")
                
        elif response.status_code == 200:
            print("⚠️ 表單有驗證錯誤，檢查表單內容...")
            
            # 檢查是否有form錯誤
            if hasattr(response, 'context') and 'form' in response.context:
                form = response.context['form']
                if form.errors:
                    print(f"❌ 表單錯誤: {form.errors}")
                if form.non_field_errors():
                    print(f"❌ 非字段錯誤: {form.non_field_errors()}")
            
            # 檢查響應內容中的錯誤信息
            content = response.content.decode()
            if 'invalid' in content.lower() or 'error' in content.lower():
                print("❌ 響應中發現錯誤信息")
                # 找到錯誤信息部分
                lines = content.split('\n')
                for i, line in enumerate(lines):
                    if 'error' in line.lower() or 'invalid' in line.lower():
                        print(f"錯誤行 {i}: {line.strip()}")
                        
        else:
            print(f"❌ 意外的狀態碼: {response.status_code}")
            print(f"響應內容: {response.content.decode()[:500]}")
            
    except Exception as e:
        print(f"❌ 請求失敗: {e}")
        import traceback
        traceback.print_exc()

def main():
    """主函數"""
    print("🚀 檢查活動表單提交問題...")
    print("=" * 60)
    
    test_event_form_with_valid_data()
    
    print("\n" + "=" * 60)
    print("🏁 檢查完成")

if __name__ == '__main__':
    main()
