#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
完整 Heroku 重新部署腳本 - PAPA COLLEGE B2B聚會派對媒合平台
"""

import subprocess
import sys
import os
import time
from datetime import datetime
import json

def run_command(command, description, check_output=False, ignore_errors=False):
    """執行命令並處理結果"""
    print(f"\n🔧 {description}")
    print(f"📝 執行命令: {command}")
    
    try:
        if check_output:
            result = subprocess.run(command, shell=True, capture_output=True, text=True, cwd=os.getcwd())
            if result.returncode == 0:
                print(f"✅ 成功: {description}")
                return result.stdout.strip()
            else:
                if ignore_errors:
                    print(f"⚠️ 警告: {description} (忽略錯誤)")
                    return result.stdout.strip() if result.stdout else None
                else:
                    print(f"❌ 失敗: {description}")
                    print(f"錯誤信息: {result.stderr}")
                    return None
        else:
            result = subprocess.run(command, shell=True, cwd=os.getcwd())
            if result.returncode == 0:
                print(f"✅ 成功: {description}")
                return True
            else:
                if ignore_errors:
                    print(f"⚠️ 警告: {description} (忽略錯誤)")
                    return True
                else:
                    print(f"❌ 失敗: {description}")
                    return False
    except Exception as e:
        print(f"❌ 執行錯誤: {str(e)}")
        return False

def fix_settings_for_heroku():
    """修復 Django 設定以適配 Heroku"""
    print("\n🔧 修復 Django 設定...")
    
    settings_path = 'party_platform/settings.py'
    
    # 讀取現有設定
    with open(settings_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 確保正確的 ALLOWED_HOSTS 設定
    if "papa-college-b2b-ee7db6fb42bd.herokuapp.com" not in content:
        content = content.replace(
            "ALLOWED_HOSTS = config('ALLOWED_HOSTS', default='localhost,127.0.0.1,testserver,*.herokuapp.com').split(',')",
            "ALLOWED_HOSTS = config('ALLOWED_HOSTS', default='localhost,127.0.0.1,testserver,*.herokuapp.com,papa-college-b2b-ee7db6fb42bd.herokuapp.com').split(',')"
        )
    
    # 確保有正確的靜態文件設定
    if "STATICFILES_STORAGE" not in content:
        content += "\n# Static files storage for Heroku\nSTATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'\n"
    
    # 寫回文件
    with open(settings_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print("✅ Django 設定已更新")

def setup_heroku_config(app_name):
    """設置 Heroku 配置變數"""
    print(f"\n⚙️ 設置 Heroku 環境變數...")
    
    # 生成更安全的 SECRET_KEY
    import secrets
    import string
    secret_key = ''.join(secrets.choice(string.ascii_letters + string.digits + '!@#$%^&*') for _ in range(50))
    
    env_vars = {
        'SECRET_KEY': secret_key,
        'DEBUG': 'False',
        'ALLOWED_HOSTS': f'papa-college-b2b-ee7db6fb42bd.herokuapp.com,*.herokuapp.com,localhost,127.0.0.1',
        'DJANGO_SETTINGS_MODULE': 'party_platform.settings'
    }
    
    for key, value in env_vars.items():
        success = run_command(f'heroku config:set {key}="{value}" --app {app_name}', f"設置 {key}")
        if not success:
            print(f"⚠️ 設置 {key} 失敗，但繼續進行...")
    
    return True

def ensure_database(app_name):
    """確保資料庫存在並正常工作"""
    print(f"\n🗄️ 確保資料庫配置...")
    
    # 檢查是否已有資料庫
    addons_result = run_command(f"heroku addons --app {app_name}", "檢查現有附加組件", check_output=True)
    
    if addons_result and "heroku-postgresql" in addons_result:
        print("✅ PostgreSQL 資料庫已存在")
    else:
        print("🔧 添加 PostgreSQL 資料庫...")
        success = run_command(f"heroku addons:create heroku-postgresql:essential-0 --app {app_name}", "添加 PostgreSQL", ignore_errors=True)
        if not success:
            print("嘗試添加免費版本...")
            run_command(f"heroku addons:create heroku-postgresql:mini --app {app_name}", "添加免費 PostgreSQL", ignore_errors=True)
    
    return True

def collect_static_files():
    """收集靜態文件"""
    print(f"\n📁 收集靜態文件...")
    
    # 確保 staticfiles 目錄存在
    os.makedirs('staticfiles', exist_ok=True)
    
    return True

def deploy_complete_app(app_name):
    """完整部署應用"""
    print(f"\n🚀 開始完整部署...")
    
    # 1. 確保 Git 倉庫狀態
    print("📋 準備 Git 倉庫...")
    
    # 檢查是否有未提交的更改
    status_result = run_command("git status --porcelain", "檢查 Git 狀態", check_output=True)
    
    if status_result:
        print("📝 發現未提交的更改，正在提交...")
        run_command("git add .", "添加所有文件", ignore_errors=True)
        commit_msg = f"Complete redeploy - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        run_command(f'git commit -m "{commit_msg}"', "提交更改", ignore_errors=True)
    
    # 2. 確保 Heroku remote 存在
    run_command(f"heroku git:remote --app {app_name}", "設置 Heroku remote", ignore_errors=True)
    
    # 3. 強制推送到 Heroku
    print("\n🔄 推送到 Heroku...")
    success = run_command("git push heroku main --force", "強制推送到 Heroku")
    
    return success

def run_heroku_migrations(app_name):
    """在 Heroku 上執行遷移"""
    print(f"\n📊 執行資料庫遷移...")
    
    # 先重置遷移
    run_command(f"heroku run python manage.py migrate --app {app_name}", "執行遷移", ignore_errors=True)
    
    # 創建測試數據
    run_command(f"heroku run python manage.py shell -c \"from django.contrib.auth.models import User; User.objects.filter(username='admin').exists() or User.objects.create_superuser('admin', 'admin@example.com', 'admin123')\" --app {app_name}", "創建預設管理員", ignore_errors=True)
    
    return True

def setup_sample_data(app_name):
    """設置範例數據"""
    print(f"\n📋 設置範例數據...")
    
    # 創建一個臨時腳本來設置數據
    setup_script = '''
from django.contrib.auth.models import User
from events.models import Event
from suppliers.models import Supplier
from users.models import UserProfile
import datetime

# 創建管理員用戶（如果不存在）
if not User.objects.filter(username="admin").exists():
    admin_user = User.objects.create_superuser("admin", "admin@papacollege.com", "admin123")
    print("Admin user created")

# 創建一些範例事件
if Event.objects.count() == 0:
    for i in range(3):
        Event.objects.create(
            title=f"範例活動 {i+1}",
            description=f"這是第 {i+1} 個範例活動",
            budget_min=100000,
            budget_max=500000,
            event_date=datetime.date.today() + datetime.timedelta(days=30+i*10),
            location=f"台北市範例地點 {i+1}",
            expected_guests=50 + i*20
        )
    print("Sample events created")

print("Sample data setup completed")
'''
    
    # 將腳本寫入臨時文件
    with open('temp_setup.py', 'w', encoding='utf-8') as f:
        f.write(setup_script)
    
    # 上傳並執行腳本
    run_command("git add temp_setup.py", "添加設置腳本", ignore_errors=True)
    run_command('git commit -m "Add sample data setup script"', "提交設置腳本", ignore_errors=True)
    run_command("git push heroku main", "推送設置腳本", ignore_errors=True)
    run_command(f"heroku run python temp_setup.py --app {app_name}", "執行數據設置", ignore_errors=True)
    
    # 清理臨時文件
    if os.path.exists('temp_setup.py'):
        os.remove('temp_setup.py')
    
    return True

def test_deployment(app_name):
    """測試部署是否成功"""
    print(f"\n🧪 測試部署...")
    
    # 測試應用是否響應
    app_url = f"https://papa-college-b2b-ee7db6fb42bd.herokuapp.com"
    
    try:
        import requests
        response = requests.get(app_url, timeout=30)
        if response.status_code == 200:
            print("✅ 應用正常響應")
            return True
        else:
            print(f"⚠️ 應用響應狀態碼: {response.status_code}")
            return False
    except ImportError:
        print("⚠️ 無法導入 requests，跳過 HTTP 測試")
        return True
    except Exception as e:
        print(f"⚠️ 測試時發生錯誤: {str(e)}")
        return False

def main():
    """主要部署流程"""
    app_name = "papa-college-b2b"
    
    print("="*70)
    print("🎉 PAPA COLLEGE - 完整 Heroku 重新部署工具")
    print("="*70)
    print(f"⏰ 開始時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"🎯 目標應用: {app_name}")
    print(f"🌐 應用網址: https://papa-college-b2b-ee7db6fb42bd.herokuapp.com")
    
    try:
        # 步驟 1: 修復設定
        fix_settings_for_heroku()
        
        # 步驟 2: 設置 Heroku 配置
        setup_heroku_config(app_name)
        
        # 步驟 3: 確保資料庫
        ensure_database(app_name)
        
        # 步驟 4: 收集靜態文件
        collect_static_files()
        
        # 步驟 5: 完整部署
        if not deploy_complete_app(app_name):
            print("❌ 部署失敗")
            return False
        
        # 步驟 6: 執行遷移
        run_heroku_migrations(app_name)
        
        # 步驟 7: 設置範例數據
        setup_sample_data(app_name)
        
        # 步驟 8: 測試部署
        test_deployment(app_name)
        
        # 完成
        print("\n" + "="*70)
        print("🎊 完整重新部署完成！")
        print("="*70)
        print(f"🌐 應用網址: https://papa-college-b2b-ee7db6fb42bd.herokuapp.com")
        print(f"⚙️ 管理後台: https://papa-college-b2b-ee7db6fb42bd.herokuapp.com/admin")
        print("👤 預設管理員: admin / admin123")
        print("\n📋 常用命令:")
        print(f"   查看日誌: heroku logs --tail --app {app_name}")
        print(f"   重啟應用: heroku restart --app {app_name}")
        print(f"   執行命令: heroku run python manage.py <command> --app {app_name}")
        
        # 詢問是否打開應用
        print(f"\n🎉 部署成功！是否要打開應用？(y/N): ", end="")
        open_app = input().lower().strip()
        if open_app == 'y':
            run_command(f"heroku open --app {app_name}", "打開應用")
        
        print(f"\n⏰ 完成時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("🎊 恭喜！PAPA COLLEGE 平台已成功重新部署到 Heroku！")
        
        return True
        
    except KeyboardInterrupt:
        print("\n⏹️ 用戶中斷部署")
        return False
    except Exception as e:
        print(f"\n❌ 部署過程中發生錯誤: {str(e)}")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
