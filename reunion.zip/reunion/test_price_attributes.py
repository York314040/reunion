#!/usr/bin/env python
"""
測試價格字段HTML屬性
"""

import os
import sys

# 設定 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')

import django
django.setup()

from messaging.forms import QuoteForm
from suppliers.forms import SupplierForm
from events.forms import EventForm

def test_price_field_attributes():
    """測試價格字段的HTML屬性"""
    print("🔧 測試價格字段HTML屬性")
    print("=" * 50)
    
    # 測試報價表單
    print("\n📋 報價表單 (QuoteForm)")
    quote_form = QuoteForm()
    price_widget = quote_form.fields['price'].widget
    print(f"Widget類型: {type(price_widget).__name__}")
    print(f"HTML屬性: {price_widget.attrs}")
    
    # 測試供應商表單
    print("\n🏢 供應商表單 (SupplierForm)")
    supplier_form = SupplierForm()
    
    price_min_widget = supplier_form.fields['price_range_min'].widget
    print(f"價格下限 Widget: {type(price_min_widget).__name__}")
    print(f"價格下限屬性: {price_min_widget.attrs}")
    
    price_max_widget = supplier_form.fields['price_range_max'].widget
    print(f"價格上限 Widget: {type(price_max_widget).__name__}")
    print(f"價格上限屬性: {price_max_widget.attrs}")
    
    # 測試活動表單
    print("\n🎉 活動表單 (EventForm)")
    event_form = EventForm()
    
    budget_min_widget = event_form.fields['budget_min'].widget
    print(f"預算下限 Widget: {type(budget_min_widget).__name__}")
    print(f"預算下限屬性: {budget_min_widget.attrs}")
    
    budget_max_widget = event_form.fields['budget_max'].widget
    print(f"預算上限 Widget: {type(budget_max_widget).__name__}")
    print(f"預算上限屬性: {budget_max_widget.attrs}")

def test_simple_price_validation():
    """簡單測試價格驗證"""
    print("\n🧪 簡單價格驗證測試")
    print("-" * 40)
    
    # 只測試價格字段
    from datetime import datetime, timedelta
    
    # 測試報價表單的價格字段
    valid_until = datetime.now() + timedelta(days=7)
    
    test_prices = [999, 9999, 99999, 999999, 9999999, 99999999]
    
    for price in test_prices:
        form_data = {
            'price': price,
            'description': '測試',
            'valid_until': valid_until.strftime('%Y-%m-%dT%H:%M')
        }
        
        form = QuoteForm(data=form_data)
        if form.is_valid():
            print(f"✅ {price:,} 元 - 驗證通過")
        else:
            print(f"❌ {price:,} 元 - 驗證失敗: {form.errors.get('price', 'Unknown error')}")

def main():
    test_price_field_attributes()
    test_simple_price_validation()
    
    print("\n" + "=" * 50)
    print("✅ 價格字段修復完成！")
    print("\n💡 修復內容:")
    print("1. ✅ 設定 max='99999999' (支援8位數)")
    print("2. ✅ 設定 min='1' (最小值1元)")
    print("3. ✅ 設定 step='1' (整數步進)")
    print("4. ✅ 添加表單驗證邏輯")
    print("5. ✅ 改善錯誤提示訊息")

if __name__ == "__main__":
    main()
