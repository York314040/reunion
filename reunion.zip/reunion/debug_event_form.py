#!/usr/bin/env python
"""
調試活動表單提交問題
"""

import os
import sys
import django
from django.test import Client
from django.contrib.auth import get_user_model
from django.urls import reverse, NoReverseMatch

# 設置Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

User = get_user_model()

def test_event_form():
    """測試活動表單提交"""
    print("🔍 測試活動表單提交...")
    
    # 1. 測試URL解析
    try:
        create_url = reverse('events:create_event')
        print(f"✅ URL解析成功: {create_url}")
    except NoReverseMatch as e:
        print(f"❌ URL解析失敗: {e}")
        return
    
    # 2. 創建測試客戶端
    client = Client()
    
    # 3. 創建測試用戶
    try:
        user = User.objects.create_user(
            username='testuser_debug',
            email='test@example.com',
            password='testpass123'
        )
        print(f"✅ 測試用戶創建成功: {user.username}")
    except Exception as e:
        # 用戶可能已存在，嘗試獲取
        try:
            user = User.objects.get(username='testuser_debug')
            print(f"✅ 使用現有測試用戶: {user.username}")
        except User.DoesNotExist:
            print(f"❌ 用戶創建失敗: {e}")
            return
    
    # 4. 登入用戶
    login_success = client.login(username='testuser_debug', password='testpass123')
    if login_success:
        print("✅ 用戶登入成功")
    else:
        print("❌ 用戶登入失敗")
        return
    
    # 5. 測試GET請求
    try:
        response = client.get(create_url)
        print(f"✅ GET請求成功: 狀態碼 {response.status_code}")
        if response.status_code != 200:
            print(f"❌ GET請求異常: {response.status_code}")
            print(f"響應內容: {response.content.decode()[:500]}")
    except Exception as e:
        print(f"❌ GET請求失敗: {e}")
        return
    
    # 6. 測試POST請求
    event_data = {
        'title': '測試活動需求',
        'description': '這是一個測試活動需求',
        'event_type': 'corporate',
        'budget_min': 10000,
        'budget_max': 50000,
        'expected_attendees': 100,
        'event_date': '2024-12-31',
        'location': '台北市',
        'contact_phone': '0912345678',
        'contact_email': 'test@example.com'
    }
    
    try:
        response = client.post(create_url, event_data)
        print(f"✅ POST請求完成: 狀態碼 {response.status_code}")
        
        if response.status_code == 302:
            print(f"✅ 重定向成功: {response.url}")
        elif response.status_code == 200:
            print("⚠️ 表單可能有驗證錯誤")
            # 檢查響應中是否有錯誤信息
            content = response.content.decode()
            if 'error' in content.lower() or 'invalid' in content.lower():
                print("❌ 發現表單錯誤")
                print(content[:1000])
            else:
                print("✅ 表單顯示正常")
        else:
            print(f"❌ POST請求異常: {response.status_code}")
            print(f"響應內容: {response.content.decode()[:500]}")
            
    except Exception as e:
        print(f"❌ POST請求失敗: {e}")
        import traceback
        traceback.print_exc()

def check_url_patterns():
    """檢查URL模式"""
    print("\n🔍 檢查URL模式...")
    
    from django.urls import get_resolver
    from django.conf import settings
    
    try:
        resolver = get_resolver(settings.ROOT_URLCONF)
        print(f"✅ 根URL配置: {settings.ROOT_URLCONF}")
        
        # 檢查events命名空間
        for pattern in resolver.url_patterns:
            if hasattr(pattern, 'namespace') and pattern.namespace == 'events':
                print(f"✅ 找到events命名空間")
                # 檢查create_event模式
                for sub_pattern in pattern.url_patterns:
                    if hasattr(sub_pattern, 'name') and sub_pattern.name == 'create_event':
                        print(f"✅ 找到create_event URL模式: {sub_pattern.pattern}")
                        return True
        
        print("❌ 未找到events:create_event URL模式")
        return False
        
    except Exception as e:
        print(f"❌ URL模式檢查失敗: {e}")
        return False

def main():
    """主函數"""
    print("🚀 開始調試活動表單提交問題...")
    print("=" * 60)
    
    # 檢查URL模式
    url_ok = check_url_patterns()
    
    if url_ok:
        # 測試表單提交
        test_event_form()
    
    print("\n" + "=" * 60)
    print("🏁 調試完成")

if __name__ == '__main__':
    main()
