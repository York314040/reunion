#!/usr/bin/env python
"""
活動表單提交問題診斷指南
"""

import os
import sys
import django

# 設置Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.contrib.auth import get_user_model
from events.models import EventType

User = get_user_model()

def print_header(title):
    """打印標題"""
    print("\n" + "="*60)
    print(f"🔍 {title}")
    print("="*60)

def check_prerequisites():
    """檢查先決條件"""
    print_header("檢查系統先決條件")
    
    issues = []
    
    # 1. 檢查EventType數據
    event_types = EventType.objects.all()
    print(f"✅ EventType數量: {event_types.count()}")
    
    if event_types.count() == 0:
        issues.append("❌ 沒有EventType數據")
        print("   解決方案: 需要在管理後台創建活動類型")
    else:
        print("   可用的活動類型:")
        for et in event_types:
            print(f"     - {et.name} (ID: {et.id})")
    
    # 2. 檢查用戶數量
    user_count = User.objects.count()
    print(f"✅ 系統用戶數量: {user_count}")
    
    if user_count == 0:
        issues.append("❌ 沒有用戶數據")
        print("   解決方案: 需要註冊用戶帳號")
    
    return issues

def print_troubleshooting_guide():
    """打印問題排查指南"""
    print_header("活動表單提交問題排查指南")
    
    print("🚨 常見問題及解決方案:")
    print()
    
    print("1️⃣ **Not Found 錯誤**")
    print("   原因: 用戶未登入")
    print("   解決方案:")
    print("   - 確保已登入用戶帳號")
    print("   - 檢查瀏覽器是否啟用cookies")
    print("   - 清除瀏覽器快取")
    print()
    
    print("2️⃣ **表單提交無反應**")
    print("   原因: JavaScript錯誤或CSRF問題")
    print("   解決方案:")
    print("   - 按F12打開開發者工具檢查錯誤")
    print("   - 重新載入頁面再提交")
    print("   - 確保瀏覽器支援JavaScript")
    print()
    
    print("3️⃣ **表單驗證失敗**")
    print("   原因: 必填欄位未填寫或格式錯誤")
    print("   解決方案:")
    print("   - 檢查所有必填欄位是否已填寫")
    print("   - 確認日期格式正確")
    print("   - 確認預算範圍合理")
    print("   - 確認聯絡資訊格式正確")
    print()
    
    print("4️⃣ **頁面載入失敗**")
    print("   原因: 服務器問題或URL錯誤")
    print("   解決方案:")
    print("   - 檢查網路連線")
    print("   - 確認服務器是否運行")
    print("   - 檢查URL是否正確")
    print()

def print_form_requirements():
    """打印表單要求"""
    print_header("活動表單填寫要求")
    
    print("📝 **必填欄位:**")
    print("   ✅ 活動標題 - 簡潔明確的標題")
    print("   ✅ 活動描述 - 詳細的活動說明")
    print("   ✅ 活動類型 - 從下拉選單選擇")
    print("   ✅ 活動日期 - 格式: YYYY-MM-DD HH:MM")
    print("   ✅ 活動地點 - 具體地址或區域")
    print("   ✅ 預計參與人數 - 正整數")
    print("   ✅ 預算範圍 - 下限和上限（新台幣）")
    print("   ✅ 聯絡人姓名")
    print("   ✅ 聯絡電話 - 有效的電話號碼")
    print("   ✅ 聯絡信箱 - 有效的電子郵件地址")
    print()
    
    print("💰 **預算範圍建議:**")
    print("   - 小型聚會 (10-30人): 5,000 - 20,000")
    print("   - 中型活動 (30-100人): 20,000 - 100,000")
    print("   - 大型活動 (100+人): 100,000+")
    print()
    
    print("📅 **日期格式範例:**")
    print("   - 正確: 2024-12-31 18:00")
    print("   - 錯誤: 31/12/2024, 2024年12月31日")
    print()

def create_test_user_guide():
    """創建測試用戶指南"""
    print_header("測試用戶創建指南")
    
    print("🧪 **創建測試用戶:**")
    print("1. 打開瀏覽器，前往註冊頁面")
    print("2. 填寫以下測試資訊:")
    print("   - 使用者名稱: testuser")
    print("   - 姓名: 測試用戶")
    print("   - 電子信箱: test@example.com")
    print("   - 密碼: testpass123")
    print("3. 點擊註冊按鈕")
    print("4. 登入後即可使用表單")
    print()
    
    print("🔑 **快速登入測試:")
    try:
        user = User.objects.get(username='testuser_debug')
        print(f"   ✅ 測試用戶已存在: {user.username}")
        print("   - 使用者名稱: testuser_debug")
        print("   - 密碼: testpass123")
    except User.DoesNotExist:
        print("   ❌ 測試用戶不存在")
        print("   - 請按照上述步驟創建用戶")

def main():
    """主函數"""
    print("🚀 活動表單提交問題診斷工具")
    
    # 檢查先決條件
    issues = check_prerequisites()
    
    # 打印排查指南
    print_troubleshooting_guide()
    
    # 打印表單要求
    print_form_requirements()
    
    # 測試用戶指南
    create_test_user_guide()
    
    print_header("總結")
    
    if issues:
        print("⚠️ **發現的問題:**")
        for issue in issues:
            print(f"   {issue}")
        print()
    
    print("📞 **需要幫助？**")
    print("   如果問題仍然存在，請提供以下資訊:")
    print("   1. 錯誤訊息的完整內容")
    print("   2. 瀏覽器類型和版本")
    print("   3. 填寫的表單內容")
    print("   4. 是否已登入用戶帳號")
    
    print("\n🎯 **快速解決方案:**")
    print("   1. 確保已登入 → 前往 /accounts/login/ 登入")
    print("   2. 清除瀏覽器快取")
    print("   3. 重新載入表單頁面")
    print("   4. 仔細填寫所有必填欄位")
    print("   5. 檢查網路連線")

if __name__ == '__main__':
    main()
