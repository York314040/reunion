#!/usr/bin/env python
"""
診斷熱門DJ頁面500錯誤的腳本
"""
import os
import django
import sys
import traceback

# 設置Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.db.models import Avg, Count
from dj_management.models import DJ, DJRating, DJBooking

def debug_popular_djs_view():
    """調試熱門DJ視圖"""
    print("🔍 開始診斷熱門DJ頁面...")
    
    try:
        # 測試基本DJ查詢
        print("\n1. 測試基本DJ查詢...")
        total_djs = DJ.objects.count()
        approved_djs = DJ.objects.filter(status='approved').count()
        print(f"   總DJ數量: {total_djs}")
        print(f"   已審核DJ數量: {approved_djs}")
        
        # 測試評分聚合查詢
        print("\n2. 測試評分聚合查詢...")
        try:
            top_rated_djs = DJ.objects.filter(status='approved').annotate(
                avg_rating=Avg('djrating__rating'),
                rating_count=Count('djrating')
            ).filter(rating_count__gte=3).order_by('-avg_rating')[:10]
            
            print(f"   高評分DJ查詢成功，找到 {top_rated_djs.count()} 個DJ")
            for dj in top_rated_djs:
                print(f"   - {dj.name}: 平均評分 {dj.avg_rating}, 評分數 {dj.rating_count}")
                
        except Exception as e:
            print(f"   ❌ 評分聚合查詢失敗: {e}")
            traceback.print_exc()
        
        # 測試精選DJ查詢
        print("\n3. 測試精選DJ查詢...")
        try:
            featured_djs = DJ.objects.filter(status='approved', is_featured=True).order_by('-created_at')[:8]
            print(f"   精選DJ查詢成功，找到 {featured_djs.count()} 個DJ")
        except Exception as e:
            print(f"   ❌ 精選DJ查詢失敗: {e}")
            traceback.print_exc()
        
        # 測試最新DJ查詢
        print("\n4. 測試最新DJ查詢...")
        try:
            newest_djs = DJ.objects.filter(status='approved').order_by('-created_at')[:6]
            print(f"   最新DJ查詢成功，找到 {newest_djs.count()} 個DJ")
        except Exception as e:
            print(f"   ❌ 最新DJ查詢失敗: {e}")
            traceback.print_exc()
        
        # 測試統計查詢
        print("\n5. 測試統計查詢...")
        try:
            total_bookings = DJBooking.objects.filter(status='completed').count()
            total_ratings = DJRating.objects.count()
            print(f"   完成預訂數: {total_bookings}")
            print(f"   總評分數: {total_ratings}")
        except Exception as e:
            print(f"   ❌ 統計查詢失敗: {e}")
            traceback.print_exc()
        
        # 測試模板渲染所需的完整上下文
        print("\n6. 測試完整上下文...")
        try:
            context = {
                'top_rated_djs': DJ.objects.filter(status='approved').annotate(
                    avg_rating=Avg('djrating__rating'),
                    rating_count=Count('djrating')
                ).filter(rating_count__gte=3).order_by('-avg_rating')[:10],
                'featured_djs': DJ.objects.filter(status='approved', is_featured=True).order_by('-created_at')[:8],
                'newest_djs': DJ.objects.filter(status='approved').order_by('-created_at')[:6],
                'total_djs': DJ.objects.filter(status='approved').count(),
                'total_bookings': DJBooking.objects.filter(status='completed').count(),
                'total_ratings': DJRating.objects.count(),
            }
            print("   ✅ 完整上下文創建成功")
            
            # 檢查查詢集是否可以迭代
            for dj in context['top_rated_djs']:
                pass
            for dj in context['featured_djs']:
                pass
            for dj in context['newest_djs']:
                pass
            print("   ✅ 所有查詢集都可以正常迭代")
            
        except Exception as e:
            print(f"   ❌ 完整上下文測試失敗: {e}")
            traceback.print_exc()
        
        print("\n✅ 診斷完成")
        
    except Exception as e:
        print(f"❌ 診斷過程中發生錯誤: {e}")
        traceback.print_exc()

if __name__ == '__main__':
    debug_popular_djs_view()
