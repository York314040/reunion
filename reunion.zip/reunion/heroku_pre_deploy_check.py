#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Heroku 部署前檢查腳本
"""

import os
import sys
from pathlib import Path

def check_file_exists(filepath, description):
    """檢查文件是否存在"""
    if os.path.exists(filepath):
        print(f"✅ {description}: {filepath}")
        return True
    else:
        print(f"❌ {description}缺失: {filepath}")
        return False

def check_requirements():
    """檢查 requirements.txt"""
    if not check_file_exists('requirements.txt', 'requirements.txt'):
        return False
    
    with open('requirements.txt', 'r') as f:
        content = f.read()
        required_packages = ['Django', 'gunicorn', 'whitenoise', 'dj-database-url', 'psycopg2-binary']
        
        for package in required_packages:
            if package in content:
                print(f"  ✅ {package} 已包含")
            else:
                print(f"  ❌ {package} 缺失")
                return False
    return True

def check_procfile():
    """檢查 Procfile"""
    if not check_file_exists('Procfile', 'Procfile'):
        return False
    
    with open('Procfile', 'r') as f:
        content = f.read()
        if 'web: gunicorn' in content:
            print("  ✅ Procfile 配置正確")
            return True
        else:
            print("  ❌ Procfile 配置錯誤")
            return False

def check_settings():
    """檢查 Django settings"""
    settings_path = 'party_platform/settings.py'
    if not check_file_exists(settings_path, 'Django settings'):
        return False
    
    with open(settings_path, 'r', encoding='utf-8') as f:
        content = f.read()
        
        checks = [
            ('ALLOWED_HOSTS', '*.herokuapp.com'),
            ('WhiteNoiseMiddleware', 'whitenoise.middleware.WhiteNoiseMiddleware'),
            ('STATIC_ROOT', 'STATIC_ROOT'),
            ('dj_database_url', 'dj_database_url'),
        ]
        
        all_good = True
        for check_name, check_content in checks:
            if check_content in content:
                print(f"  ✅ {check_name} 配置正確")
            else:
                print(f"  ❌ {check_name} 配置缺失")
                all_good = False
        
        return all_good

def check_git():
    """檢查 Git 狀態"""
    if os.path.exists('.git'):
        print("✅ Git 倉庫已初始化")
        return True
    else:
        print("⚠️ Git 倉庫未初始化，部署時會自動初始化")
        return True

def main():
    """主檢查函數"""
    print("🔍 Heroku 部署前檢查")
    print("=" * 40)
    
    checks = [
        ("requirements.txt", check_requirements),
        ("Procfile", check_procfile),
        ("Django Settings", check_settings),
        ("Git Repository", check_git),
    ]
    
    all_passed = True
    
    for check_name, check_func in checks:
        print(f"\n📋 檢查 {check_name}:")
        if not check_func():
            all_passed = False
    
    print("\n" + "=" * 40)
    
    if all_passed:
        print("🎉 所有檢查通過！可以開始部署")
        return True
    else:
        print("❌ 部分檢查失敗，請修復後再部署")
        return False

if __name__ == "__main__":
    if main():
        sys.exit(0)
    else:
        sys.exit(1)
