#!/usr/bin/env python
"""
Heroku 初始化數據腳本
為新部署的應用創建基本數據
"""
import os
import sys
import django

# 設置 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.contrib.auth.models import User
from events.models import Event, EventType
from suppliers.models import Supplier, ServiceCategory
from dj_management.models import DJ, DJCategory

def create_sample_data():
    """創建示例數據"""
    print("正在創建示例數據...")
    
    # 創建活動類型
    event_types = [
        ('birthday', '生日派對'),
        ('wedding', '婚禮'),
        ('corporate', '企業活動'),
        ('conference', '會議'),
        ('party', '聚會'),
    ]
    
    for type_code, type_name in event_types:
        EventType.objects.get_or_create(
            name=type_name,
            defaults={'description': f'{type_name}相關活動'}
        )
    
    # 創建服務類型
    service_types = [
        ('catering', '餐飲服務'),
        ('decoration', '裝飾佈置'),
        ('photography', '攝影服務'),
        ('music', '音響音樂'),
        ('venue', '場地租借'),
    ]
    
    for type_code, type_name in service_types:
        ServiceCategory.objects.get_or_create(
            name=type_name,
            defaults={'description': f'{type_name}相關服務'}
        )
    
    # 創建 DJ 音樂類型
    dj_genres = [
        'Electronic',
        'Hip Hop',
        'Rock',
        'Pop',
        'Jazz',
        'Classical',
        'R&B',
        'Country',
        'Reggae',
        'Latin'
    ]
    
    for genre_name in dj_genres:
        DJCategory.objects.get_or_create(name=genre_name)
    
    print("示例數據創建完成！")

def create_demo_users():
    """創建演示用戶"""
    print("正在創建演示用戶...")
    
    # 創建一般用戶
    demo_users = [
        ('張小明', 'zhang_ming', 'zhang@example.com'),
        ('李小華', 'li_hua', 'li@example.com'),
        ('王小美', 'wang_mei', 'wang@example.com'),
    ]
    
    for name, username, email in demo_users:
        if not User.objects.filter(username=username).exists():
            user = User.objects.create_user(
                username=username,
                email=email,
                password='demo123456',
                first_name=name.split('小')[0],
                last_name='小' + name.split('小')[1] if '小' in name else name[1:]
            )
            print(f"創建演示用戶: {username}")
    
    # 創建管理員用戶
    if not User.objects.filter(username='manager').exists():
        manager = User.objects.create_user(
            username='manager',
            email='manager@example.com',
            password='manager123456',
            is_staff=True,
            first_name='管理',
            last_name='員'
        )
        print("創建管理員用戶: manager")
    
    print("演示用戶創建完成！")
    print("\n可用的演示帳號：")
    print("1. 超級用戶 - admin / admin123456")
    print("2. 管理員 - manager / manager123456") 
    print("3. 一般用戶 - zhang_ming / demo123456")
    print("4. 一般用戶 - li_hua / demo123456")
    print("5. 一般用戶 - wang_mei / demo123456")

if __name__ == "__main__":
    print("=== Heroku 初始化數據 ===")
    
    # 創建示例數據
    create_sample_data()
    
    # 創建演示用戶
    create_demo_users()
    
    print("=== 初始化完成 ===")
