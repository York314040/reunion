#!/usr/bin/env python
"""
用戶管理功能診斷腳本
檢查刪除功能是否正常工作
"""
import os
import sys
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.contrib.auth.models import User
from django.test import Client
from django.urls import reverse

def diagnose_user_management():
    """診斷用戶管理功能"""
    print("🔍 用戶管理功能診斷")
    print("=" * 50)
    
    # 檢查用戶狀態
    users = User.objects.all()
    print(f"📊 當前用戶總數: {users.count()}")
    
    superusers = users.filter(is_superuser=True)
    regular_users = users.filter(is_superuser=False)
    
    print(f"👑 超級用戶數: {superusers.count()}")
    for user in superusers:
        print(f"   - {user.username} (ID: {user.id})")
    
    print(f"👤 一般用戶數: {regular_users.count()}")
    for user in regular_users:
        print(f"   - {user.username} (ID: {user.id})")
    
    # 測試用戶管理頁面
    print("\n🌐 測試用戶管理頁面訪問...")
    client = Client()
    
    # 登入超級用戶
    york_user = User.objects.get(username='York')
    login_success = client.login(username='York', password='123456')
    
    if login_success:
        print("✅ 超級用戶登入成功")
        
        # 測試用戶管理頁面
        try:
            response = client.get('/manage/users/')
            print(f"✅ 用戶管理頁面訪問成功 (狀態碼: {response.status_code})")
            
            # 檢查頁面內容
            content = response.content.decode('utf-8')
            if 'demo_user_1' in content:
                print("✅ 頁面包含測試用戶")
            else:
                print("❌ 頁面不包含測試用戶")
            
            if 'delete-user' in content:
                print("✅ 頁面包含刪除按鈕")
            else:
                print("❌ 頁面缺少刪除按鈕")
                
        except Exception as e:
            print(f"❌ 用戶管理頁面訪問失敗: {e}")
        
        # 測試刪除功能 API
        print("\n🗑️ 測試刪除功能...")
        test_user = User.objects.filter(username='demo_user_1').first()
        
        if test_user:
            delete_url = f'/manage/users/{test_user.id}/delete/'
            print(f"🎯 測試刪除 URL: {delete_url}")
            
            # 獲取 CSRF token
            csrf_response = client.get('/manage/users/')
            csrf_token = csrf_response.context.get('csrf_token', 'test') if csrf_response.context else 'test'
            
            # 執行刪除請求
            delete_response = client.post(delete_url, {
                'csrfmiddlewaretoken': csrf_token
            })
            
            print(f"📡 刪除請求狀態碼: {delete_response.status_code}")
            
            if delete_response.status_code == 200:
                try:
                    response_data = delete_response.json()
                    print(f"📋 刪除回應: {response_data}")
                    
                    if response_data.get('success'):
                        print("✅ 刪除功能正常工作")
                        
                        # 檢查用戶是否真的被刪除
                        user_still_exists = User.objects.filter(id=test_user.id).exists()
                        if not user_still_exists:
                            print("✅ 用戶已從資料庫刪除")
                        else:
                            print("❌ 用戶仍存在於資料庫中")
                    else:
                        print(f"❌ 刪除失敗: {response_data.get('message')}")
                        
                except Exception as e:
                    print(f"❌ 解析刪除回應失敗: {e}")
                    print(f"原始回應: {delete_response.content.decode('utf-8')[:200]}")
            else:
                print(f"❌ 刪除請求失敗，狀態碼: {delete_response.status_code}")
                
    else:
        print("❌ 超級用戶登入失敗")
    
    # 檢查 JavaScript 和模板
    print("\n📄 檢查模板文件...")
    template_path = "templates/events/user_management_new.html"
    if os.path.exists(template_path):
        with open(template_path, 'r', encoding='utf-8') as f:
            template_content = f.read()
            
        if 'delete-user' in template_content:
            print("✅ 模板包含刪除按鈕 class")
        else:
            print("❌ 模板缺少刪除按鈕 class")
            
        if 'confirmDeleteBtn' in template_content:
            print("✅ 模板包含刪除確認按鈕")
        else:
            print("❌ 模板缺少刪除確認按鈕")
            
        if 'ajax' in template_content.lower():
            print("✅ 模板包含 AJAX 功能")
        else:
            print("❌ 模板缺少 AJAX 功能")
    else:
        print("❌ 找不到用戶管理模板文件")
    
    # 最終報告
    print("\n" + "=" * 50)
    final_users = User.objects.all()
    print(f"📊 診斷完成，當前用戶總數: {final_users.count()}")
    
    print("\n💡 解決建議:")
    print("1. 確保以超級用戶 York 身份登入")
    print("2. 訪問: http://localhost:8000/manage/users/")
    print("3. 查找紅色垃圾桶圖示按鈕")
    print("4. 點擊後應該出現確認對話框")
    print("5. 確認刪除即可")

if __name__ == "__main__":
    diagnose_user_management()
