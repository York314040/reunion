#!/usr/bin/env python
import os
import sys
import django

# 設置 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.contrib.auth.models import User
from django.urls import reverse
from django.conf import settings

def debug_user_management():
    """調試用戶管理功能"""
    print("=== 用戶管理功能調試 ===")
    
    # 檢查用戶
    print("\n1. 檢查用戶:")
    users = User.objects.all()
    for user in users:
        print(f"   ID: {user.id}, 用戶名: {user.username}, 超級用戶: {user.is_superuser}")
    
    # 檢查 URL 路由
    print("\n2. 檢查 URL 路由:")
    try:
        user_mgmt_url = reverse('events:user_management_new')
        print(f"   用戶管理 URL: {user_mgmt_url}")
    except Exception as e:
        print(f"   ❌ 無法解析用戶管理 URL: {e}")
    
    try:
        delete_url = reverse('events:delete_user_new', kwargs={'user_id': 9})
        print(f"   刪除用戶 URL: {delete_url}")
    except Exception as e:
        print(f"   ❌ 無法解析刪除用戶 URL: {e}")
    
    # 檢查模板是否存在
    print("\n3. 檢查模板:")
    import os
    template_path = os.path.join(settings.BASE_DIR, 'templates', 'events', 'user_management_new.html')
    if os.path.exists(template_path):
        print(f"   ✅ 模板存在: {template_path}")
        # 檢查模板大小
        size = os.path.getsize(template_path)
        print(f"   模板大小: {size} bytes")
    else:
        print(f"   ❌ 模板不存在: {template_path}")
    
    # 檢查視圖函數
    print("\n4. 檢查視圖函數:")
    try:
        from events.views import user_management, delete_user
        print("   ✅ 視圖函數已導入")
        print(f"   user_management: {user_management}")
        print(f"   delete_user: {delete_user}")
    except ImportError as e:
        print(f"   ❌ 無法導入視圖函數: {e}")
    
    print("\n=== 調試完成 ===")

if __name__ == "__main__":
    debug_user_management()
