#!/usr/bin/env python
"""
全端工程師視角 - 全面系統測試
測試前端、後端、API、數據庫、安全等各個層面
"""

import os
import sys
import time
import requests
import json
from datetime import datetime
from typing import Dict, Any, List

# 設定 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')

import django
django.setup()

from django.test import Client, TestCase
from django.contrib.auth.models import User
from django.urls import reverse
from django.core.management import call_command
from django.db import connection
from events.models import Event
from suppliers.models import Supplier
from dj_management.models import DJ


class FullStackTester:
    """全端測試器"""
    
    def __init__(self):
        self.client = Client()
        self.test_results = {
            'timestamp': datetime.now().isoformat(),
            'frontend': {},
            'backend': {},
            'api': {},
            'database': {},
            'security': {},
            'performance': {},
            'mobile': {},
            'overall': {}
        }
        self.base_url = 'http://localhost:8000'
        
    def test_frontend_functionality(self) -> Dict[str, Any]:
        """測試前端功能"""
        print("🎨 測試前端功能...")
        
        frontend_tests = {}
        
        # 1. 頁面可訪問性測試
        pages_to_test = [
            ('/', '首頁'),
            ('/events/', '活動列表'),
            ('/suppliers/', '供應商列表'),
            ('/dj/', 'DJ列表'),
            ('/accounts/login/', '登入頁面'),
            ('/register/', '註冊頁面'),
            ('/admin/', '管理後台')
        ]
        
        page_tests = {}
        for url, name in pages_to_test:
            try:
                response = self.client.get(url)
                page_tests[name] = {
                    'status_code': response.status_code,
                    'accessible': response.status_code in [200, 302, 401],
                    'has_content': len(response.content) > 0,
                    'content_type': response.get('Content-Type', ''),
                    'response_time': 0  # 簡化處理
                }
                
                # 檢查HTML結構
                if response.status_code == 200:
                    content = response.content.decode('utf-8', errors='ignore')
                    page_tests[name]['has_doctype'] = '<!DOCTYPE html>' in content
                    page_tests[name]['has_viewport'] = 'viewport' in content
                    page_tests[name]['has_bootstrap'] = 'bootstrap' in content.lower()
                    page_tests[name]['has_jquery'] = 'jquery' in content.lower()
                    page_tests[name]['has_navigation'] = 'nav' in content.lower()
                    
            except Exception as e:
                page_tests[name] = {
                    'error': str(e),
                    'accessible': False
                }
        
        frontend_tests['page_accessibility'] = page_tests
        
        # 2. 靜態文件測試
        static_tests = {}
        static_files = [
            '/static/css/bootstrap.min.css',
            '/static/js/bootstrap.min.js',
            '/static/css/custom.css'
        ]
        
        for static_file in static_files:
            try:
                response = self.client.get(static_file)
                static_tests[static_file] = {
                    'status_code': response.status_code,
                    'accessible': response.status_code == 200,
                    'size': len(response.content)
                }
            except Exception as e:
                static_tests[static_file] = {
                    'error': str(e),
                    'accessible': False
                }
        
        frontend_tests['static_files'] = static_tests
        
        # 3. 表單測試
        form_tests = {}
        
        # 登入表單測試
        try:
            login_response = self.client.get('/accounts/login/')
            if login_response.status_code == 200:
                content = login_response.content.decode('utf-8', errors='ignore')
                form_tests['login_form'] = {
                    'has_csrf': 'csrfmiddlewaretoken' in content,
                    'has_username_field': 'username' in content,
                    'has_password_field': 'password' in content,
                    'has_submit_button': 'submit' in content.lower()
                }
        except Exception as e:
            form_tests['login_form'] = {'error': str(e)}
        
        # 註冊表單測試
        try:
            register_response = self.client.get('/register/')
            if register_response.status_code == 200:
                content = register_response.content.decode('utf-8', errors='ignore')
                form_tests['register_form'] = {
                    'has_csrf': 'csrfmiddlewaretoken' in content,
                    'has_username_field': 'username' in content,
                    'has_email_field': 'email' in content,
                    'has_password_field': 'password' in content
                }
        except Exception as e:
            form_tests['register_form'] = {'error': str(e)}
        
        frontend_tests['forms'] = form_tests
        
        return frontend_tests
    
    def test_backend_functionality(self) -> Dict[str, Any]:
        """測試後端功能"""
        print("⚙️ 測試後端功能...")
        
        backend_tests = {}
        
        # 1. 數據庫連接測試
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT 1")
                result = cursor.fetchone()
            
            backend_tests['database_connection'] = {
                'connected': result[0] == 1,
                'engine': connection.settings_dict['ENGINE']
            }
        except Exception as e:
            backend_tests['database_connection'] = {
                'connected': False,
                'error': str(e)
            }
        
        # 2. 模型完整性測試
        model_tests = {}
        
        # 測試用戶模型
        try:
            user_count = User.objects.count()
            model_tests['User'] = {
                'count': user_count,
                'can_create': True,
                'can_query': True
            }
        except Exception as e:
            model_tests['User'] = {'error': str(e)}
        
        # 測試事件模型
        try:
            event_count = Event.objects.count()
            model_tests['Event'] = {
                'count': event_count,
                'can_create': True,
                'can_query': True
            }
        except Exception as e:
            model_tests['Event'] = {'error': str(e)}
        
        backend_tests['models'] = model_tests
        
        # 3. 中介軟體測試
        middleware_tests = {
            'csrf_middleware': True,  # Django 默認啟用
            'session_middleware': True,  # Django 默認啟用
            'auth_middleware': True,  # Django 默認啟用
        }
        
        backend_tests['middleware'] = middleware_tests
        
        return backend_tests
    
    def test_api_endpoints(self) -> Dict[str, Any]:
        """測試API端點"""
        print("🚀 測試API端點...")
        
        api_tests = {}
        
        # 1. 基本GET請求測試
        get_endpoints = [
            ('/', 'home'),
            ('/events/', 'events_list'),
            ('/suppliers/', 'suppliers_list'),
            ('/dj/', 'dj_list')
        ]
        
        get_tests = {}
        for url, name in get_endpoints:
            try:
                response = self.client.get(url)
                get_tests[name] = {
                    'status_code': response.status_code,
                    'success': response.status_code in [200, 302],
                    'content_length': len(response.content),
                    'headers': dict(response.items())
                }
            except Exception as e:
                get_tests[name] = {'error': str(e)}
        
        api_tests['get_endpoints'] = get_tests
        
        # 2. POST請求測試
        post_tests = {}
        
        # 測試用戶註冊
        try:
            register_data = {
                'username': f'test_user_{int(time.time())}',
                'email': f'test_{int(time.time())}@example.com',
                'password1': 'testpass123',
                'password2': 'testpass123',
                'user_type': 'client'
            }
            
            response = self.client.post('/register/', register_data)
            post_tests['user_registration'] = {
                'status_code': response.status_code,
                'success': response.status_code in [200, 302],
                'redirect': response.status_code == 302
            }
        except Exception as e:
            post_tests['user_registration'] = {'error': str(e)}
        
        api_tests['post_endpoints'] = post_tests
        
        return api_tests
    
    def test_database_integrity(self) -> Dict[str, Any]:
        """測試數據庫完整性"""
        print("🗄️ 測試數據庫完整性...")
        
        db_tests = {}
        
        # 1. 表結構測試
        try:
            tables = connection.introspection.table_names()
            db_tests['table_count'] = len(tables)
            db_tests['has_user_table'] = 'auth_user' in tables
            db_tests['has_event_table'] = any('event' in table for table in tables)
            db_tests['has_supplier_table'] = any('supplier' in table for table in tables)
        except Exception as e:
            db_tests['table_structure'] = {'error': str(e)}
        
        # 2. 索引和約束測試
        try:
            with connection.cursor() as cursor:
                # 檢查是否有外鍵約束
                cursor.execute("""
                    SELECT COUNT(*) 
                    FROM information_schema.table_constraints 
                    WHERE constraint_type = 'FOREIGN KEY'
                """)
                fk_count = cursor.fetchone()[0] if cursor.fetchone() else 0
                db_tests['foreign_keys'] = fk_count
        except Exception as e:
            db_tests['constraints'] = {'error': str(e)}
        
        # 3. 數據一致性測試
        try:
            # 檢查孤立記錄
            orphan_tests = {}
            
            # 檢查沒有對應用戶的profile
            supplier_count = Supplier.objects.count()
            orphan_tests['supplier_profiles'] = supplier_count
            
            dj_count = DJ.objects.count()
            orphan_tests['dj_profiles'] = dj_count
            
            db_tests['data_consistency'] = orphan_tests
        except Exception as e:
            db_tests['data_consistency'] = {'error': str(e)}
        
        return db_tests
    
    def test_security_features(self) -> Dict[str, Any]:
        """測試安全功能"""
        print("🔒 測試安全功能...")
        
        security_tests = {}
        
        # 1. CSRF 保護測試
        try:
            response = self.client.get('/accounts/login/')
            csrf_tests = {
                'csrf_token_present': 'csrfmiddlewaretoken' in response.content.decode(),
                'csrf_header_present': 'X-CSRFToken' in str(response.content)
            }
            security_tests['csrf_protection'] = csrf_tests
        except Exception as e:
            security_tests['csrf_protection'] = {'error': str(e)}
        
        # 2. 認證保護測試
        auth_tests = {}
        
        # 測試未認證用戶訪問受保護頁面
        protected_urls = [
            '/dashboards/',
            '/events/create/',
            '/messaging/'
        ]
        
        for url in protected_urls:
            try:
                response = self.client.get(url)
                auth_tests[url] = {
                    'redirects_to_login': response.status_code == 302,
                    'status_code': response.status_code
                }
            except Exception as e:
                auth_tests[url] = {'error': str(e)}
        
        security_tests['authentication'] = auth_tests
        
        # 3. SQL注入防護測試
        sql_injection_tests = {}
        
        # 測試基本SQL注入攻擊
        malicious_inputs = [
            "'; DROP TABLE auth_user; --",
            "' OR '1'='1",
            "<script>alert('xss')</script>"
        ]
        
        for payload in malicious_inputs:
            try:
                response = self.client.get(f'/events/?search={payload}')
                sql_injection_tests[payload[:20]] = {
                    'status_code': response.status_code,
                    'safe': response.status_code in [200, 400, 404]
                }
            except Exception as e:
                sql_injection_tests[payload[:20]] = {'error': str(e)}
        
        security_tests['sql_injection'] = sql_injection_tests
        
        return security_tests
    
    def test_performance(self) -> Dict[str, Any]:
        """測試性能"""
        print("⚡ 測試性能...")
        
        performance_tests = {}
        
        # 1. 頁面載入時間測試
        urls_to_test = [
            '/',
            '/events/',
            '/suppliers/',
            '/dj/'
        ]
        
        load_times = {}
        for url in urls_to_test:
            times = []
            for i in range(3):  # 測試3次取平均
                try:
                    start_time = time.time()
                    response = self.client.get(url)
                    end_time = time.time()
                    
                    if response.status_code == 200:
                        times.append(end_time - start_time)
                except Exception:
                    pass
            
            if times:
                load_times[url] = {
                    'average_time': sum(times) / len(times),
                    'min_time': min(times),
                    'max_time': max(times),
                    'acceptable': sum(times) / len(times) < 2.0  # 2秒以內
                }
        
        performance_tests['load_times'] = load_times
        
        # 2. 數據庫查詢性能
        try:
            from django.db import reset_queries
            from django import db
            
            reset_queries()
            
            # 執行一個典型的頁面請求
            response = self.client.get('/events/')
            
            query_count = len(db.connection.queries)
            performance_tests['database_queries'] = {
                'query_count': query_count,
                'acceptable': query_count < 50  # 少於50個查詢
            }
        except Exception as e:
            performance_tests['database_queries'] = {'error': str(e)}
        
        return performance_tests
    
    def test_mobile_responsiveness(self) -> Dict[str, Any]:
        """測試移動端響應性"""
        print("📱 測試移動端響應性...")
        
        mobile_tests = {}
        
        # 模擬移動設備請求
        mobile_user_agent = 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X) AppleWebKit/605.1.15'
        
        urls_to_test = ['/', '/events/', '/suppliers/', '/dj/']
        
        for url in urls_to_test:
            try:
                response = self.client.get(url, HTTP_USER_AGENT=mobile_user_agent)
                
                if response.status_code == 200:
                    content = response.content.decode('utf-8', errors='ignore')
                    
                    mobile_tests[url] = {
                        'has_viewport_meta': 'viewport' in content,
                        'has_responsive_classes': 'col-' in content,
                        'has_bootstrap': 'bootstrap' in content.lower(),
                        'content_length': len(content)
                    }
                else:
                    mobile_tests[url] = {'status_code': response.status_code}
                    
            except Exception as e:
                mobile_tests[url] = {'error': str(e)}
        
        return mobile_tests
    
    def run_comprehensive_test(self) -> Dict[str, Any]:
        """運行全面測試"""
        print("🔍 開始全面系統測試...")
        print("="*60)
        
        # 執行各項測試
        self.test_results['frontend'] = self.test_frontend_functionality()
        self.test_results['backend'] = self.test_backend_functionality()
        self.test_results['api'] = self.test_api_endpoints()
        self.test_results['database'] = self.test_database_integrity()
        self.test_results['security'] = self.test_security_features()
        self.test_results['performance'] = self.test_performance()
        self.test_results['mobile'] = self.test_mobile_responsiveness()
        
        # 計算整體評分
        self.calculate_overall_score()
        
        return self.test_results
    
    def calculate_overall_score(self):
        """計算整體評分"""
        scores = {}
        
        # 前端評分
        frontend = self.test_results['frontend']
        if 'page_accessibility' in frontend:
            accessible_pages = sum(1 for page in frontend['page_accessibility'].values() 
                                 if page.get('accessible', False))
            total_pages = len(frontend['page_accessibility'])
            scores['frontend'] = (accessible_pages / total_pages * 100) if total_pages > 0 else 0
        
        # 後端評分
        backend = self.test_results['backend']
        backend_score = 0
        if backend.get('database_connection', {}).get('connected'):
            backend_score += 50
        if 'models' in backend:
            working_models = sum(1 for model in backend['models'].values() 
                               if 'error' not in model)
            backend_score += (working_models / len(backend['models']) * 50) if backend['models'] else 0
        scores['backend'] = backend_score
        
        # API評分
        api = self.test_results['api']
        if 'get_endpoints' in api:
            working_endpoints = sum(1 for endpoint in api['get_endpoints'].values() 
                                  if endpoint.get('success', False))
            total_endpoints = len(api['get_endpoints'])
            scores['api'] = (working_endpoints / total_endpoints * 100) if total_endpoints > 0 else 0
        
        # 安全評分
        security = self.test_results['security']
        security_score = 100  # 基礎分數
        if not security.get('csrf_protection', {}).get('csrf_token_present'):
            security_score -= 30
        scores['security'] = max(0, security_score)
        
        # 性能評分
        performance = self.test_results['performance']
        perf_score = 100
        if 'load_times' in performance:
            slow_pages = sum(1 for page in performance['load_times'].values() 
                           if not page.get('acceptable', True))
            if slow_pages > 0:
                perf_score -= (slow_pages * 20)
        scores['performance'] = max(0, perf_score)
        
        # 整體評分
        overall_score = sum(scores.values()) / len(scores) if scores else 0
        
        self.test_results['overall'] = {
            'category_scores': scores,
            'overall_score': overall_score,
            'grade': self.get_grade(overall_score),
            'status': 'excellent' if overall_score >= 90 else 'good' if overall_score >= 80 else 'needs_improvement'
        }
    
    def get_grade(self, score: float) -> str:
        """根據分數獲取等級"""
        if score >= 95:
            return 'A+'
        elif score >= 90:
            return 'A'
        elif score >= 85:
            return 'B+'
        elif score >= 80:
            return 'B'
        elif score >= 75:
            return 'C+'
        elif score >= 70:
            return 'C'
        else:
            return 'D'
    
    def generate_report(self) -> str:
        """生成測試報告"""
        report = f"""
# 🔍 全端工程師測試報告

**測試時間**: {self.test_results['timestamp']}
**整體評分**: {self.test_results['overall']['overall_score']:.1f}/100 ({self.test_results['overall']['grade']})
**系統狀態**: {self.test_results['overall']['status'].upper()}

---

## 📊 各項目評分

"""
        
        for category, score in self.test_results['overall']['category_scores'].items():
            status = "✅" if score >= 80 else "⚠️" if score >= 60 else "❌"
            report += f"- **{category.upper()}**: {score:.1f}/100 {status}\n"
        
        report += "\n---\n\n## 🔍 詳細測試結果\n\n"
        
        # 前端測試結果
        if 'frontend' in self.test_results:
            report += "### 🎨 前端測試\n\n"
            frontend = self.test_results['frontend']
            
            if 'page_accessibility' in frontend:
                report += "**頁面可訪問性**:\n"
                for page, result in frontend['page_accessibility'].items():
                    status = "✅" if result.get('accessible') else "❌"
                    report += f"- {page}: {status} (狀態碼: {result.get('status_code', 'N/A')})\n"
                report += "\n"
        
        # 發現的問題
        report += "## ⚠️ 發現的問題\n\n"
        
        issues = []
        
        # 檢查各種問題
        for category, results in self.test_results.items():
            if category in ['timestamp', 'overall']:
                continue
                
            if isinstance(results, dict):
                for key, value in results.items():
                    if isinstance(value, dict):
                        if 'error' in value:
                            issues.append(f"**{category.upper()}**: {key} - {value['error']}")
                        elif not value.get('success', True) and not value.get('accessible', True):
                            issues.append(f"**{category.upper()}**: {key} - 功能異常")
        
        if issues:
            for issue in issues[:10]:  # 限制顯示前10個問題
                report += f"- {issue}\n"
        else:
            report += "🎉 未發現重大問題！\n"
        
        report += "\n---\n\n"
        report += "## 💡 建議改進\n\n"
        
        # 根據評分提供建議
        overall_score = self.test_results['overall']['overall_score']
        
        if overall_score < 80:
            report += "- 建議檢查並修復上述發現的問題\n"
            report += "- 加強錯誤處理和異常捕獲\n"
            report += "- 優化頁面載入速度\n"
        
        if self.test_results['overall']['category_scores'].get('security', 100) < 90:
            report += "- 加強安全防護措施\n"
            report += "- 確保所有表單都有CSRF保護\n"
        
        if self.test_results['overall']['category_scores'].get('performance', 100) < 85:
            report += "- 優化數據庫查詢性能\n"
            report += "- 考慮使用緩存機制\n"
            report += "- 壓縮靜態文件\n"
        
        return report
    
    def save_report(self):
        """保存測試報告"""
        # 保存JSON格式的詳細結果
        with open('fullstack_test_results.json', 'w', encoding='utf-8') as f:
            json.dump(self.test_results, f, ensure_ascii=False, indent=2)
        
        # 保存Markdown格式的報告
        report = self.generate_report()
        with open('FULLSTACK_TEST_REPORT.md', 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"\n📄 測試報告已保存:")
        print(f"- 詳細結果: fullstack_test_results.json")
        print(f"- 測試報告: FULLSTACK_TEST_REPORT.md")


def main():
    """主函數"""
    tester = FullStackTester()
    
    print("🚀 開始全端工程師視角測試")
    print("="*60)
    
    # 運行全面測試
    results = tester.run_comprehensive_test()
    
    # 顯示測試摘要
    print("\n" + "="*60)
    print("📊 測試完成！")
    print("="*60)
    
    overall = results['overall']
    print(f"🎯 整體評分: {overall['overall_score']:.1f}/100 ({overall['grade']})")
    print(f"📈 系統狀態: {overall['status'].upper()}")
    
    print(f"\n📋 各項評分:")
    for category, score in overall['category_scores'].items():
        status = "✅" if score >= 80 else "⚠️" if score >= 60 else "❌"
        print(f"  • {category.upper()}: {score:.1f}/100 {status}")
    
    # 保存報告
    tester.save_report()
    
    return results


if __name__ == "__main__":
    main()
