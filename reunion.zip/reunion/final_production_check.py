#!/usr/bin/env python
"""
最終生產就緒檢查 - 完整驗證
確保系統100%可以上線
"""

import os
import sys
from pathlib import Path

# 設定 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')

import django
django.setup()

from django.test import Client
from django.contrib.auth.models import User
from django.urls import reverse
from django.core.management import call_command
from django.conf import settings
from events.models import Event, EventType
from suppliers.models import Supplier, ServiceCategory
from dj_management.models import DJ, DJCategory

class FinalProductionValidator:
    """最終生產環境驗證器"""
    
    def __init__(self):
        self.client = Client()
        self.issues = []
        self.successes = []
        
    def print_status(self, message, status="INFO"):
        icons = {"INFO": "ℹ️", "SUCCESS": "✅", "ERROR": "❌", "WARNING": "⚠️"}
        print(f"{icons.get(status, 'ℹ️')} {message}")
        
        if status == "SUCCESS":
            self.successes.append(message)
        elif status == "ERROR":
            self.issues.append(message)
    
    def check_database_integrity(self):
        """檢查數據庫完整性"""
        print("\n🔍 檢查數據庫完整性")
        
        try:
            # 檢查基本數據是否存在
            event_types = EventType.objects.count()
            service_categories = ServiceCategory.objects.count()
            dj_categories = DJCategory.objects.count()
            
            if event_types >= 3:
                self.print_status(f"活動類型: {event_types} 個", "SUCCESS")
            else:
                self.print_status("活動類型數量不足", "ERROR")
            
            if service_categories >= 3:
                self.print_status(f"服務類別: {service_categories} 個", "SUCCESS")
            else:
                self.print_status("服務類別數量不足", "ERROR")
            
            if dj_categories >= 3:
                self.print_status(f"DJ類別: {dj_categories} 個", "SUCCESS")
            else:
                self.print_status("DJ類別數量不足", "ERROR")
                
        except Exception as e:
            self.print_status(f"數據庫檢查失敗: {str(e)}", "ERROR")
    
    def check_critical_urls(self):
        """檢查關鍵URL路由"""
        print("\n🔍 檢查關鍵URL路由")
        
        critical_urls = [
            '/',  # 首頁
            '/events/',  # 活動頁面
            '/suppliers/',  # 供應商頁面
            '/dj/',  # DJ頁面
            '/messaging/',  # 訊息頁面（剛修復的）
            '/admin/',  # 管理頁面
        ]
        
        for url in critical_urls:
            try:
                response = self.client.get(url)
                if response.status_code == 200:
                    self.print_status(f"{url} - 正常訪問", "SUCCESS")
                elif response.status_code == 302:
                    self.print_status(f"{url} - 重定向（需要登錄）", "SUCCESS")
                else:
                    self.print_status(f"{url} - 狀態碼 {response.status_code}", "ERROR")
            except Exception as e:
                self.print_status(f"{url} - 錯誤: {str(e)}", "ERROR")
    
    def check_templates_existence(self):
        """檢查模板文件存在性"""
        print("\n🔍 檢查模板文件存在性")
        
        template_dirs = [
            'templates/dashboards/',
            'templates/events/',
            'templates/suppliers/',
            'templates/dj_management/',
            'templates/messaging/',
        ]
        
        required_templates = [
            'templates/base.html',
            'templates/dashboards/admin_dashboard.html',
            'templates/dashboards/client_dashboard.html',
            'templates/dashboards/supplier_dashboard.html',
            'templates/messaging/my_quotes.html',  # 剛創建的
        ]
        
        # 檢查模板目錄
        for template_dir in template_dirs:
            dir_path = Path(template_dir)
            if dir_path.exists():
                files_count = len(list(dir_path.glob('*.html')))
                self.print_status(f"{template_dir} - {files_count} 個模板文件", "SUCCESS")
            else:
                self.print_status(f"{template_dir} - 目錄不存在", "ERROR")
        
        # 檢查關鍵模板
        for template in required_templates:
            if Path(template).exists():
                self.print_status(f"{template} - 存在", "SUCCESS")
            else:
                self.print_status(f"{template} - 不存在", "ERROR")
    
    def check_static_files(self):
        """檢查靜態文件"""
        print("\n🔍 檢查靜態文件")
        
        static_dirs = [
            'static/css/',
            'static/js/',
            'static/images/',
        ]
        
        for static_dir in static_dirs:
            dir_path = Path(static_dir)
            if dir_path.exists():
                files_count = len(list(dir_path.rglob('*')))
                self.print_status(f"{static_dir} - {files_count} 個文件", "SUCCESS")
            else:
                self.print_status(f"{static_dir} - 目錄不存在", "WARNING")
    
    def check_user_authentication(self):
        """檢查用戶認證系統"""
        print("\n🔍 檢查用戶認證系統")
        
        try:
            # 檢查是否有超級用戶
            superusers = User.objects.filter(is_superuser=True).count()
            if superusers > 0:
                self.print_status(f"超級用戶: {superusers} 個", "SUCCESS")
            else:
                self.print_status("沒有超級用戶", "ERROR")
            
            # 檢查總用戶數
            total_users = User.objects.count()
            self.print_status(f"總用戶數: {total_users}", "SUCCESS")
            
        except Exception as e:
            self.print_status(f"用戶檢查失敗: {str(e)}", "ERROR")
    
    def check_forms_validation(self):
        """檢查表單驗證"""
        print("\n🔍 檢查表單驗證")
        
        try:
            # 檢查服務類別是否存在（供應商註冊需要）
            if ServiceCategory.objects.exists():
                self.print_status("服務類別存在，供應商註冊表單可用", "SUCCESS")
            else:
                self.print_status("缺少服務類別，供應商註冊會失敗", "ERROR")
            
            # 檢查活動類型
            if EventType.objects.exists():
                self.print_status("活動類型存在，活動創建表單可用", "SUCCESS")
            else:
                self.print_status("缺少活動類型，活動創建會失敗", "ERROR")
                
        except Exception as e:
            self.print_status(f"表單驗證檢查失敗: {str(e)}", "ERROR")
    
    def check_security_settings(self):
        """檢查安全設置"""
        print("\n🔍 檢查安全設置")
        
        # 檢查CSRF設置
        if 'django.middleware.csrf.CsrfViewMiddleware' in settings.MIDDLEWARE:
            self.print_status("CSRF保護已啟用", "SUCCESS")
        else:
            self.print_status("CSRF保護未啟用", "ERROR")
        
        # 檢查認證設置
        if 'django.contrib.auth.middleware.AuthenticationMiddleware' in settings.MIDDLEWARE:
            self.print_status("認證中間件已啟用", "SUCCESS")
        else:
            self.print_status("認證中間件未啟用", "ERROR")
        
        # 檢查密鑰設置
        if hasattr(settings, 'SECRET_KEY') and len(settings.SECRET_KEY) > 20:
            self.print_status("SECRET_KEY設置正確", "SUCCESS")
        else:
            self.print_status("SECRET_KEY設置有問題", "ERROR")
    
    def test_core_functionality(self):
        """測試核心功能"""
        print("\n🔍 測試核心功能")
        
        try:
            # 創建測試用戶
            test_user = User.objects.create_user(
                username='final_test_user',
                email='test@test.com',
                password='testpass123'
            )
            
            # 登錄測試
            login_success = self.client.login(username='final_test_user', password='testpass123')
            if login_success:
                self.print_status("用戶登錄功能正常", "SUCCESS")
            else:
                self.print_status("用戶登錄功能異常", "ERROR")
            
            # 測試dashboard訪問
            response = self.client.get('/dashboards/')
            if response.status_code in [200, 302]:
                self.print_status("Dashboard訪問正常", "SUCCESS")
            else:
                self.print_status("Dashboard訪問異常", "ERROR")
            
            # 清理測試用戶
            test_user.delete()
            
        except Exception as e:
            self.print_status(f"功能測試失敗: {str(e)}", "ERROR")
    
    def check_production_readiness(self):
        """檢查生產就緒狀態"""
        print("\n🔍 檢查生產就緒狀態")
        
        # 檢查是否有生產環境設置
        prod_settings_path = Path("party_platform/settings_production.py")
        if prod_settings_path.exists():
            self.print_status("生產環境設置文件存在", "SUCCESS")
        else:
            self.print_status("缺少生產環境設置文件", "WARNING")
        
        # 檢查管理命令
        mgmt_commands_dir = Path("events/management/commands")
        if mgmt_commands_dir.exists():
            commands = list(mgmt_commands_dir.glob('*.py'))
            self.print_status(f"管理命令: {len(commands)} 個", "SUCCESS")
        else:
            self.print_status("缺少管理命令", "WARNING")
    
    def run_final_validation(self):
        """執行最終驗證"""
        print("🚀 開始最終生產就緒驗證")
        print("=" * 60)
        
        # 執行所有檢查
        self.check_database_integrity()
        self.check_critical_urls()
        self.check_templates_existence()
        self.check_static_files()
        self.check_user_authentication()
        self.check_forms_validation()
        self.check_security_settings()
        self.test_core_functionality()
        self.check_production_readiness()
        
        # 總結報告
        print("\n" + "=" * 60)
        print("📊 最終驗證報告")
        print("=" * 60)
        
        print(f"✅ 成功檢查項目: {len(self.successes)}")
        for success in self.successes:
            print(f"   ✓ {success}")
        
        if self.issues:
            print(f"\n❌ 發現問題: {len(self.issues)}")
            for issue in self.issues:
                print(f"   ✗ {issue}")
        else:
            print("\n🎉 沒有發現任何問題！")
        
        # 最終結果
        print("\n" + "=" * 60)
        if len(self.issues) == 0:
            print("🎉 ✅ 系統完全準備就緒，可以安全上線！")
            print("🚀 您的朋友們可以開始使用這個平台了！")
        elif len(self.issues) <= 2:
            print("⚠️  系統基本就緒，有少量非關鍵問題")
            print("🚀 可以上線，建議後續修復小問題")
        else:
            print("❌ 系統還有一些問題需要修復")
            print("🔧 建議先修復這些問題再上線")

if __name__ == "__main__":
    validator = FinalProductionValidator()
    validator.run_final_validation()
