#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Heroku 自動部署腳本 - PAPA COLLEGE B2B聚會派對媒合平台
"""

import subprocess
import sys
import os
import time
from datetime import datetime
import json

def run_command(command, description, check_output=False):
    """執行命令並處理結果"""
    print(f"\n🔧 {description}")
    print(f"📝 執行命令: {command}")
    
    try:
        if check_output:
            result = subprocess.run(command, shell=True, capture_output=True, text=True, cwd=os.getcwd())
            if result.returncode == 0:
                print(f"✅ 成功: {description}")
                return result.stdout.strip()
            else:
                print(f"❌ 失敗: {description}")
                print(f"錯誤信息: {result.stderr}")
                return None
        else:
            result = subprocess.run(command, shell=True, cwd=os.getcwd())
            if result.returncode == 0:
                print(f"✅ 成功: {description}")
                return True
            else:
                print(f"❌ 失敗: {description}")
                return False
    except Exception as e:
        print(f"❌ 執行錯誤: {str(e)}")
        return False

def check_heroku_app_exists(app_name):
    """檢查 Heroku 應用是否存在"""
    result = run_command(f"heroku apps:info {app_name}", f"檢查應用 {app_name} 是否存在", check_output=True)
    return result is not None

def create_heroku_app(app_name):
    """創建 Heroku 應用"""
    print(f"\n🚀 創建 Heroku 應用: {app_name}")
    
    # 檢查應用是否已存在
    if check_heroku_app_exists(app_name):
        print(f"✅ 應用 {app_name} 已存在，跳過創建步驟")
        return True
    
    # 創建新應用
    result = run_command(f"heroku create {app_name}", f"創建應用 {app_name}")
    if result:
        print(f"🎉 Heroku 應用 {app_name} 創建成功！")
        return True
    else:
        print(f"❌ 創建應用失敗，嘗試創建隨機名稱的應用...")
        return run_command("heroku create", "創建隨機名稱應用")

def setup_environment_variables(app_name):
    """設置環境變數"""
    print(f"\n⚙️ 設置 Heroku 環境變數...")
    
    env_vars = {
        'SECRET_KEY': 'django-insecure-production-key-change-this-in-production-12345',
        'DEBUG': 'False',
        'ALLOWED_HOSTS': f'{app_name}.herokuapp.com,*.herokuapp.com',
        'DJANGO_SETTINGS_MODULE': 'party_platform.settings'
    }
    
    for key, value in env_vars.items():
        success = run_command(f'heroku config:set {key}="{value}" --app {app_name}', f"設置 {key}")
        if not success:
            print(f"⚠️ 設置 {key} 失敗，但繼續進行...")
    
    return True

def setup_database(app_name):
    """設置 PostgreSQL 資料庫"""
    print(f"\n🗄️ 設置 PostgreSQL 資料庫...")
    
    # 添加 PostgreSQL 附加組件
    success = run_command(f"heroku addons:create heroku-postgresql:essential-0 --app {app_name}", "添加 PostgreSQL 資料庫")
    if not success:
        print("⚠️ 無法添加付費資料庫，嘗試免費版本...")
        success = run_command(f"heroku addons:create heroku-postgresql:mini --app {app_name}", "添加免費 PostgreSQL 資料庫")
    
    return success

def deploy_to_heroku(app_name):
    """部署到 Heroku"""
    print(f"\n🚀 開始部署到 Heroku...")
    
    # 1. 初始化 Git（如果需要）
    if not os.path.exists('.git'):
        run_command("git init", "初始化 Git 倉庫")
        run_command("git branch -M main", "設置主分支為 main")
    
    # 2. 添加 Heroku remote
    run_command(f"heroku git:remote --app {app_name}", f"添加 Heroku remote")
    
    # 3. 添加所有文件
    run_command("git add .", "添加所有文件到 Git")
    
    # 4. 提交變更
    commit_message = f"Deploy to Heroku - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    run_command(f'git commit -m "{commit_message}"', "提交變更")
    
    # 5. 推送到 Heroku
    print("\n🔄 推送到 Heroku (這可能需要幾分鐘)...")
    success = run_command("git push heroku main", "推送到 Heroku")
    
    if success:
        print("✅ 代碼推送成功！")
        return True
    else:
        print("❌ 代碼推送失敗")
        return False

def run_migrations(app_name):
    """執行資料庫遷移"""
    print(f"\n📊 執行資料庫遷移...")
    success = run_command(f"heroku run python manage.py migrate --app {app_name}", "執行資料庫遷移")
    return success

def create_superuser(app_name):
    """創建超級用戶"""
    print(f"\n👤 創建管理員帳戶...")
    print("請按照提示輸入管理員資訊：")
    
    # 使用互動式命令創建超級用戶
    success = run_command(f"heroku run python manage.py createsuperuser --app {app_name}", "創建超級用戶")
    return success

def open_app(app_name):
    """打開應用"""
    print(f"\n🌐 打開應用...")
    run_command(f"heroku open --app {app_name}", "打開應用")

def main():
    """主函數"""
    print("="*60)
    print("🎉 PAPA COLLEGE - Heroku 自動部署工具")
    print("="*60)
    print(f"⏰ 開始時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # 設置應用名稱
    app_name = "papa-college-b2b"
    
    try:
        # 1. 創建 Heroku 應用
        if not create_heroku_app(app_name):
            print("❌ 創建應用失敗，終止部署")
            return
        
        # 2. 設置環境變數
        setup_environment_variables(app_name)
        
        # 3. 設置資料庫
        print("\n🤔 是否要設置 PostgreSQL 資料庫？")
        print("注意：免費版本有限制，可以稍後手動添加")
        setup_db = input("輸入 y 設置資料庫，或按 Enter 跳過: ").lower()
        
        if setup_db == 'y':
            setup_database(app_name)
        
        # 4. 部署應用
        if not deploy_to_heroku(app_name):
            print("❌ 部署失敗，請檢查錯誤信息")
            return
        
        # 5. 執行遷移
        if not run_migrations(app_name):
            print("⚠️ 資料庫遷移失敗，可能需要手動執行")
        
        # 6. 創建超級用戶
        print("\n🤔 是否要創建管理員帳戶？")
        create_admin = input("輸入 y 創建管理員，或按 Enter 跳過: ").lower()
        
        if create_admin == 'y':
            create_superuser(app_name)
        
        # 7. 完成部署
        print("\n" + "="*60)
        print("🎊 部署完成！")
        print("="*60)
        print(f"🌐 應用網址: https://{app_name}.herokuapp.com")
        print(f"⚙️ 管理後台: https://{app_name}.herokuapp.com/admin")
        print("📋 常用命令:")
        print(f"   查看日誌: heroku logs --tail --app {app_name}")
        print(f"   執行命令: heroku run python manage.py <command> --app {app_name}")
        print(f"   重啟應用: heroku restart --app {app_name}")
        
        # 8. 詢問是否打開應用
        open_browser = input("\n是否要在瀏覽器中打開應用？(y/N): ").lower()
        if open_browser == 'y':
            open_app(app_name)
        
        print(f"\n⏰ 完成時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("🎉 恭喜！您的 PAPA COLLEGE 平台已成功部署到 Heroku！")
        
    except KeyboardInterrupt:
        print("\n⏹️ 用戶中斷部署")
    except Exception as e:
        print(f"\n❌ 部署過程中發生錯誤: {str(e)}")

if __name__ == "__main__":
    main()
