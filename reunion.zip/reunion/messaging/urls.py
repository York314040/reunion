from django.urls import path
from . import views

app_name = 'messaging'

urlpatterns = [
    # 訊息系統主頁
    path('', views.conversations_list, name='messaging_home'),
    
    # 對話相關
    path('conversations/', views.conversations_list, name='conversations_list'),
    path('conversations/<int:pk>/', views.conversation_detail, name='conversation_detail'),
    path('start-conversation/', views.start_conversation, name='start_conversation'),
    path('start-conversation/event/<int:event_id>/', views.start_conversation, name='start_conversation_event'),
    path('start-conversation/supplier/<int:supplier_id>/', views.start_conversation, name='start_conversation_supplier'),
    
    # 報價相關
    path('quotes/', views.my_quotes, name='my_quotes'),
    path('quotes/<int:pk>/', views.quote_detail, name='quote_detail'),
    path('quotes/create/<int:event_id>/', views.create_quote, name='create_quote'),
    
    # 通知相關
    path('notifications/', views.notifications_list, name='notifications_list'),
    path('notifications/mark-read/', views.mark_notification_read, name='mark_notification_read'),
    path('notifications/mark-all-read/', views.mark_all_notifications_read, name='mark_all_notifications_read'),
    path('notifications/delete/', views.delete_notification, name='delete_notification'),
    path('notifications/clear-read/', views.clear_read_notifications, name='clear_read_notifications'),
    
    # AJAX 端點
    path('api/send-message/', views.send_message_ajax, name='send_message_ajax'),
    path('api/conversations/<int:pk>/messages/', views.get_conversation_messages, name='get_conversation_messages'),
]
