from django.contrib import admin
from .models import Conversation, Message, Quote, Notification


@admin.register(Conversation)
class ConversationAdmin(admin.ModelAdmin):
    list_display = ['__str__', 'event', 'supplier', 'created_at', 'updated_at']
    list_filter = ['created_at', 'updated_at']
    filter_horizontal = ['participants']
    readonly_fields = ['created_at', 'updated_at']


@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ['sender', 'conversation', 'content_preview', 'is_read', 'created_at']
    list_filter = ['is_read', 'created_at']
    search_fields = ['content', 'sender__username']
    readonly_fields = ['created_at']
    
    def content_preview(self, obj):
        return obj.content[:50] + "..." if len(obj.content) > 50 else obj.content
    content_preview.short_description = "內容預覽"


@admin.register(Quote)
class QuoteAdmin(admin.ModelAdmin):
    list_display = ['supplier', 'event', 'price_formatted', 'status', 'valid_until', 'created_at']
    list_filter = ['status', 'created_at', 'valid_until']
    search_fields = ['supplier__company_name', 'event__title']
    readonly_fields = ['created_at', 'updated_at']
    
    def price_formatted(self, obj):
        return f"NT${obj.price:,}"
    price_formatted.short_description = "報價金額"


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ['recipient', 'title', 'notification_type', 'is_read', 'created_at']
    list_filter = ['notification_type', 'is_read', 'created_at']
    search_fields = ['title', 'message', 'recipient__username']
    readonly_fields = ['created_at']
