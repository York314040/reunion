# Messaging app for party platform
