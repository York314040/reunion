from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.views.decorators.http import require_http_methods
import json

from .models import Conversation, Message, Quote, Notification
from .forms import MessageForm, QuoteForm
from events.models import Event
from suppliers.models import Supplier


@login_required
def conversations_list(request):
    """對話列表"""
    conversations = Conversation.objects.filter(participants=request.user).order_by('-updated_at')
    
    # 分頁
    paginator = Paginator(conversations, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
    }
    return render(request, 'messaging/conversation_list.html', context)


@login_required
def conversation_detail(request, pk):
    """對話詳情"""
    conversation = get_object_or_404(Conversation, pk=pk, participants=request.user)
    
    # 處理發送訊息
    if request.method == 'POST':
        form = MessageForm(request.POST)
        if form.is_valid():
            message = form.save(commit=False)
            message.conversation = conversation
            message.sender = request.user
            message.save()
            
            # 更新對話時間
            conversation.save()  # 這會觸發 updated_at 更新
            
            # 發送通知給其他參與者
            for participant in conversation.participants.exclude(pk=request.user.pk):
                Notification.objects.create(
                    recipient=participant,
                    notification_type='message',
                    title=f'來自 {request.user.first_name or request.user.username} 的新訊息',
                    message=message.content[:100],
                    related_url=f'/messaging/conversations/{conversation.pk}/'
                )
            
            messages.success(request, '訊息已發送')
            return redirect('messaging:conversation_detail', pk=conversation.pk)
    else:
        form = MessageForm()
    
    # 獲取訊息
    messages_list = conversation.messages.all()
    
    context = {
        'conversation': conversation,
        'messages': messages_list,
        'form': form,
    }
    return render(request, 'messaging/conversation_detail.html', context)


@login_required
def start_conversation(request, event_id=None, supplier_id=None):
    """開始對話"""
    if event_id:
        event = get_object_or_404(Event, pk=event_id)
        # 確保這是供應商要聯繫活動主辦方
        if not hasattr(request.user, 'supplier'):
            messages.error(request, '只有供應商可以聯繫活動主辦方')
            return redirect('events:event_detail', pk=event_id)
        
        # 檢查是否已存在對話
        conversation = Conversation.objects.filter(
            participants=request.user,
            event=event
        ).filter(participants=event.organizer).first()
        
        if not conversation:
            conversation = Conversation.objects.create(event=event, supplier=request.user.supplier)
            conversation.participants.add(request.user, event.organizer)
        
        return redirect('messaging:conversation_detail', pk=conversation.pk)
    
    elif supplier_id:
        supplier = get_object_or_404(Supplier, pk=supplier_id)
        # 檢查是否已存在對話
        conversation = Conversation.objects.filter(
            participants=request.user,
            supplier=supplier
        ).filter(participants=supplier.user).first()
        
        if not conversation:
            conversation = Conversation.objects.create(supplier=supplier)
            conversation.participants.add(request.user, supplier.user)
        
        return redirect('messaging:conversation_detail', pk=conversation.pk)
    
    messages.error(request, '無效的對話參數')
    return redirect('events:home')


@login_required
def create_quote(request, event_id):
    """建立報價"""
    event = get_object_or_404(Event, pk=event_id)
    
    # 確保這是供應商
    if not hasattr(request.user, 'supplier'):
        messages.error(request, '只有供應商可以提供報價')
        return redirect('events:event_detail', pk=event_id)
    
    supplier = request.user.supplier
    
    # 檢查是否已經報價過
    existing_quote = Quote.objects.filter(event=event, supplier=supplier).first()
    if existing_quote:
        messages.warning(request, '您已經對此活動提供過報價')
        return redirect('messaging:quote_detail', pk=existing_quote.pk)
    
    if request.method == 'POST':
        form = QuoteForm(request.POST)
        if form.is_valid():
            quote = form.save(commit=False)
            quote.event = event
            quote.supplier = supplier
            quote.save()
            
            # 發送通知給活動主辦方
            Notification.objects.create(
                recipient=event.organizer,
                notification_type='quote',
                title=f'來自 {supplier.company_name} 的新報價',
                message=f'您的活動「{event.title}」收到了新報價：NT${quote.price:,}',
                related_url=f'/messaging/quotes/{quote.pk}/'
            )
            
            messages.success(request, '報價已提交')
            return redirect('messaging:quote_detail', pk=quote.pk)
    else:
        form = QuoteForm()
    
    context = {
        'form': form,
        'event': event,
    }
    return render(request, 'messaging/create_quote.html', context)


@login_required
def quote_detail(request, pk):
    """報價詳情"""
    quote = get_object_or_404(Quote, pk=pk)
    
    # 確保用戶有權限查看
    if request.user not in [quote.event.organizer, quote.supplier.user]:
        messages.error(request, '您沒有權限查看此報價')
        return redirect('events:home')
    
    # 處理報價回應
    if request.method == 'POST' and request.user == quote.event.organizer:
        action = request.POST.get('action')
        if action == 'accept':
            quote.status = 'accepted'
            quote.save()
            
            # 發送通知給供應商
            Notification.objects.create(
                recipient=quote.supplier.user,
                notification_type='quote',
                title='報價被接受',
                message=f'您對活動「{quote.event.title}」的報價已被接受',
                related_url=f'/messaging/quotes/{quote.pk}/'
            )
            
            messages.success(request, '報價已接受')
        elif action == 'reject':
            quote.status = 'rejected'
            quote.save()
            
            # 發送通知給供應商
            Notification.objects.create(
                recipient=quote.supplier.user,
                notification_type='quote',
                title='報價被拒絕',
                message=f'您對活動「{quote.event.title}」的報價已被拒絕',
                related_url=f'/messaging/quotes/{quote.pk}/'
            )
            
            messages.info(request, '報價已拒絕')
    
    context = {
        'quote': quote,
    }
    return render(request, 'messaging/quote_detail.html', context)


@login_required
def notifications_list(request):
    """通知列表"""
    notifications = Notification.objects.filter(recipient=request.user).order_by('-created_at')
    unread_count = notifications.filter(is_read=False).count()
    
    # 分頁
    paginator = Paginator(notifications, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'notifications': page_obj,
        'unread_count': unread_count,
        'is_paginated': page_obj.has_other_pages(),
        'page_obj': page_obj,
    }
    return render(request, 'messaging/notifications.html', context)


@login_required
def my_quotes(request):
    """我的報價"""
    if hasattr(request.user, 'supplier'):
        # 供應商查看自己的報價
        quotes = Quote.objects.filter(supplier=request.user.supplier)
    else:
        # 主辦方查看收到的報價
        quotes = Quote.objects.filter(event__organizer=request.user)
    
    # 分頁
    paginator = Paginator(quotes, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'is_supplier': hasattr(request.user, 'supplier'),
    }
    return render(request, 'messaging/my_quotes.html', context)


# AJAX 視圖
@login_required
@require_http_methods(["POST"])
def mark_notification_read(request):
    """標記通知為已讀"""
    try:
        data = json.loads(request.body)
        notification_id = data.get('notification_id')
        
        notification = get_object_or_404(Notification, 
                                       id=notification_id, 
                                       recipient=request.user)
        notification.is_read = True
        notification.save()
        
        return JsonResponse({'success': True})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_http_methods(["POST"])
def mark_all_notifications_read(request):
    """標記所有通知為已讀"""
    try:
        Notification.objects.filter(recipient=request.user, is_read=False).update(is_read=True)
        return JsonResponse({'success': True})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_http_methods(["POST"])
def delete_notification(request):
    """刪除通知"""
    try:
        data = json.loads(request.body)
        notification_id = data.get('notification_id')
        
        notification = get_object_or_404(Notification, 
                                       id=notification_id, 
                                       recipient=request.user)
        notification.delete()
        
        return JsonResponse({'success': True})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_http_methods(["POST"])
def clear_read_notifications(request):
    """清除已讀通知"""
    try:
        Notification.objects.filter(recipient=request.user, is_read=True).delete()
        return JsonResponse({'success': True})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_http_methods(["POST"])
def send_message_ajax(request):
    """AJAX發送訊息"""
    try:
        data = json.loads(request.body)
        conversation_id = data.get('conversation_id')
        content = data.get('content')
        
        conversation = get_object_or_404(Conversation, 
                                       id=conversation_id, 
                                       participants=request.user)
        
        message = Message.objects.create(
            conversation=conversation,
            sender=request.user,
            content=content
        )
        
        # 更新對話時間
        conversation.save()
        
        # 發送通知給其他參與者
        for participant in conversation.participants.exclude(pk=request.user.pk):
            Notification.objects.create(
                recipient=participant,
                notification_type='message',
                title=f'來自 {request.user.first_name or request.user.username} 的新訊息',
                message=content[:100],
                related_url=f'/messaging/conversations/{conversation.pk}/'
            )
        
        return JsonResponse({
            'success': True,
            'message': {
                'id': message.id,
                'content': message.content,
                'sender': message.sender.username,
                'created_at': message.created_at.strftime('%Y-%m-%d %H:%M'),
            }
        })
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
def get_conversation_messages(request, pk):
    """獲取對話訊息（AJAX）"""
    conversation = get_object_or_404(Conversation, pk=pk, participants=request.user)
    messages_list = conversation.messages.all()
    
    messages_data = []
    for message in messages_list:
        messages_data.append({
            'id': message.id,
            'content': message.content,
            'sender': message.sender.username,
            'sender_id': message.sender.id,
            'created_at': message.created_at.strftime('%Y-%m-%d %H:%M'),
            'is_mine': message.sender == request.user,
        })
    
    return JsonResponse({
        'success': True,
        'messages': messages_data
    })
