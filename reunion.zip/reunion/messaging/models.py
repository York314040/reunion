from django.db import models
from django.contrib.auth.models import User
from events.models import Event
from suppliers.models import Supplier


class Conversation(models.Model):
    """對話"""
    participants = models.ManyToManyField(User, verbose_name="參與者")
    event = models.ForeignKey(Event, on_delete=models.CASCADE, null=True, blank=True, verbose_name="相關活動")
    supplier = models.ForeignKey(Supplier, on_delete=models.CASCADE, null=True, blank=True, verbose_name="相關供應商")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="建立時間")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="更新時間")
    
    class Meta:
        verbose_name = "對話"
        verbose_name_plural = "對話"
        ordering = ['-updated_at']
    
    def __str__(self):
        participants_str = ", ".join([user.first_name or user.username for user in self.participants.all()])
        return f"對話: {participants_str}"
    
    @property
    def last_message(self):
        return self.messages.first()


class Message(models.Model):
    """訊息"""
    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name='messages', verbose_name="對話")
    sender = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="發送者")
    content = models.TextField(verbose_name="訊息內容")
    is_read = models.BooleanField(default=False, verbose_name="已讀")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="發送時間")
    
    class Meta:
        verbose_name = "訊息"
        verbose_name_plural = "訊息"
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.sender.first_name or self.sender.username}: {self.content[:50]}"


class Quote(models.Model):
    """報價"""
    STATUS_CHOICES = [
        ('pending', '待回覆'),
        ('accepted', '已接受'),
        ('rejected', '已拒絕'),
        ('expired', '已過期'),
    ]
    
    event = models.ForeignKey(Event, on_delete=models.CASCADE, verbose_name="活動需求")
    supplier = models.ForeignKey(Supplier, on_delete=models.CASCADE, verbose_name="供應商")
    price = models.PositiveIntegerField(verbose_name="報價金額")
    description = models.TextField(verbose_name="報價說明")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending', verbose_name="狀態")
    valid_until = models.DateTimeField(verbose_name="有效期限")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="建立時間")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="更新時間")
    
    class Meta:
        verbose_name = "報價"
        verbose_name_plural = "報價"
        ordering = ['-created_at']
        unique_together = ['event', 'supplier']  # 每個供應商對同一活動只能報價一次
    
    def __str__(self):
        return f"{self.supplier.company_name} → {self.event.title}: NT${self.price:,}"


class Notification(models.Model):
    """通知"""
    TYPE_CHOICES = [
        ('message', '新訊息'),
        ('quote', '新報價'),
        ('quote_accepted', '報價被接受'),
        ('quote_rejected', '報價被拒絕'),
        ('event_inquiry', '活動詢問'),
    ]
    
    recipient = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="接收者")
    notification_type = models.CharField(max_length=20, choices=TYPE_CHOICES, verbose_name="通知類型")
    title = models.CharField(max_length=200, verbose_name="標題")
    message = models.TextField(verbose_name="內容")
    is_read = models.BooleanField(default=False, verbose_name="已讀")
    related_url = models.URLField(blank=True, verbose_name="相關連結")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="建立時間")
    
    class Meta:
        verbose_name = "通知"
        verbose_name_plural = "通知"
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.recipient.first_name or self.recipient.username}: {self.title}"
