from django import forms
from .models import Message, Quote


class MessageForm(forms.ModelForm):
    """訊息表單"""
    class Meta:
        model = Message
        fields = ['content']
        widgets = {
            'content': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': '輸入訊息...'
            })
        }


class QuoteForm(forms.ModelForm):
    """報價表單"""
    class Meta:
        model = Quote
        fields = ['price', 'description', 'valid_until']
        widgets = {
            'price': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': '請輸入報價金額 (新台幣)',
                'min': '1',
                'max': '99999999',
                'step': '1'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 4,
                'placeholder': '請詳細說明您的服務內容、價格構成等...'
            }),
            'valid_until': forms.DateTimeInput(attrs={
                'class': 'form-control',
                'type': 'datetime-local'
            })
        }
        labels = {
            'price': '報價金額 (NT$)',
            'description': '服務說明',
            'valid_until': '報價有效期限'
        }
        help_texts = {
            'price': '請輸入1到99,999,999之間的整數金額',
            'description': '詳細說明服務內容、包含項目、價格構成等',
            'valid_until': '建議設定為7-30天內的有效期限'
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 確保price字段的HTML屬性正確設置
        self.fields['price'].widget.attrs.update({
            'min': '1',
            'max': '99999999',
            'step': '1'
        })

    def clean_price(self):
        """驗證報價金額"""
        price = self.cleaned_data.get('price')
        if price is not None:
            if price < 1:
                raise forms.ValidationError('報價金額不能小於1元')
            if price > 99999999:
                raise forms.ValidationError('報價金額不能超過99,999,999元')
        return price

    def clean_valid_until(self):
        """驗證有效期限"""
        from django.utils import timezone
        from datetime import timedelta
        
        valid_until = self.cleaned_data.get('valid_until')
        if valid_until:
            now = timezone.now()
            if valid_until <= now:
                raise forms.ValidationError('有效期限必須是未來的時間')
            if valid_until > now + timedelta(days=365):
                raise forms.ValidationError('有效期限不能超過一年')
        return valid_until
