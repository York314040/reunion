#!/usr/bin/env python
"""
依賴優化器 - 解決Python包依賴衝突
"""

import subprocess
import sys
import pkg_resources
from typing import List, Dict, Any


class DependencyOptimizer:
    """依賴優化器"""
    
    def __init__(self):
        self.conflicts = []
        self.resolved = []
        
    def check_dependencies(self) -> Dict[str, Any]:
        """檢查依賴衝突"""
        print("🔍 檢查依賴衝突...")
        
        try:
            # 使用pip check檢查依賴
            result = subprocess.run([sys.executable, '-m', 'pip', 'check'], 
                                  capture_output=True, text=True)
            
            if result.returncode == 0:
                return {
                    'success': True,
                    'message': '所有依賴正常',
                    'conflicts': []
                }
            else:
                conflicts = result.stdout.strip().split('\n') if result.stdout else []
                self.conflicts = [c for c in conflicts if c.strip()]
                
                return {
                    'success': False,
                    'message': f'發現 {len(self.conflicts)} 個依賴衝突',
                    'conflicts': self.conflicts
                }
                
        except Exception as e:
            return {
                'success': False,
                'message': f'依賴檢查失敗: {str(e)}',
                'conflicts': []
            }
    
    def get_installed_packages(self) -> Dict[str, str]:
        """獲取已安裝的包列表"""
        installed = {}
        
        try:
            result = subprocess.run([sys.executable, '-m', 'pip', 'list'], 
                                  capture_output=True, text=True)
            
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')[2:]  # 跳過標題行
                for line in lines:
                    if line.strip():
                        parts = line.split()
                        if len(parts) >= 2:
                            installed[parts[0]] = parts[1]
        except:
            pass
            
        return installed
    
    def resolve_conflicts(self) -> Dict[str, Any]:
        """解決依賴衝突"""
        print("🔧 解決依賴衝突...")
        
        if not self.conflicts:
            return {'success': True, 'message': '無需解決衝突'}
        
        # 分析衝突並提取需要升級的包
        packages_to_upgrade = set()
        
        for conflict in self.conflicts:
            if 'has requirement' in conflict:
                # 解析衝突信息
                parts = conflict.split(' has requirement ')
                if len(parts) == 2:
                    package_part = parts[1].split(',')[0]  # 取第一個要求
                    if '>=' in package_part:
                        package_name = package_part.split('>=')[0].strip()
                        packages_to_upgrade.add(package_name)
                    elif '>' in package_part:
                        package_name = package_part.split('>')[0].strip()
                        packages_to_upgrade.add(package_name)
        
        if not packages_to_upgrade:
            return {'success': False, 'message': '無法自動解析衝突'}
        
        print(f"🎯 需要升級的包: {', '.join(packages_to_upgrade)}")
        
        # 嘗試升級包
        success_count = 0
        errors = []
        
        for package in packages_to_upgrade:
            try:
                print(f"  📦 升級 {package}...")
                result = subprocess.run([
                    sys.executable, '-m', 'pip', 'install', '--upgrade', package
                ], capture_output=True, text=True)
                
                if result.returncode == 0:
                    success_count += 1
                    self.resolved.append(package)
                    print(f"    ✅ {package} 升級成功")
                else:
                    errors.append(f"{package}: {result.stderr}")
                    print(f"    ❌ {package} 升級失敗")
                    
            except Exception as e:
                errors.append(f"{package}: {str(e)}")
                print(f"    ❌ {package} 升級出錯: {str(e)}")
        
        return {
            'success': success_count > 0,
            'message': f'成功升級 {success_count}/{len(packages_to_upgrade)} 個包',
            'resolved': self.resolved,
            'errors': errors
        }
    
    def create_clean_requirements(self) -> Dict[str, Any]:
        """創建清理後的requirements.txt"""
        print("📝 生成優化後的requirements.txt...")
        
        try:
            installed = self.get_installed_packages()
            
            # 核心Django相關包
            core_packages = [
                'Django', 'django-bootstrap4', 'Pillow', 'python-dotenv',
                'whitenoise', 'gunicorn', 'psycopg2-binary'
            ]
            
            # 生成requirements內容
            requirements_content = "# Django核心依賴\n"
            
            for package in core_packages:
                if package in installed:
                    requirements_content += f"{package}=={installed[package]}\n"
                elif package.lower() in installed:
                    requirements_content += f"{package.lower()}=={installed[package.lower()]}\n"
            
            # 添加其他重要包（如果存在）
            requirements_content += "\n# 其他重要依賴\n"
            other_packages = ['requests', 'httpx', 'certifi', 'beautifulsoup4']
            
            for package in other_packages:
                if package in installed:
                    requirements_content += f"{package}=={installed[package]}\n"
            
            # 保存文件
            with open('requirements_optimized.txt', 'w') as f:
                f.write(requirements_content)
            
            return {
                'success': True,
                'message': '已生成優化的requirements_optimized.txt',
                'package_count': len(requirements_content.split('\n')) - 3  # 減去註釋行
            }
            
        except Exception as e:
            return {
                'success': False,
                'message': f'生成requirements失敗: {str(e)}'
            }
    
    def run_optimization(self) -> Dict[str, Any]:
        """運行完整優化流程"""
        print("🚀 啟動依賴優化流程")
        print("="*50)
        
        results = {}
        
        # 1. 檢查當前依賴狀態
        results['check'] = self.check_dependencies()
        print(f"依賴檢查: {results['check']['message']}")
        
        if results['check']['conflicts']:
            print(f"發現衝突:")
            for conflict in results['check']['conflicts'][:5]:  # 顯示前5個
                print(f"  • {conflict}")
            
            # 2. 解決衝突
            results['resolve'] = self.resolve_conflicts()
            print(f"衝突解決: {results['resolve']['message']}")
            
            # 3. 重新檢查
            results['recheck'] = self.check_dependencies()
            print(f"重新檢查: {results['recheck']['message']}")
        
        # 4. 生成優化的requirements
        results['requirements'] = self.create_clean_requirements()
        print(f"Requirements: {results['requirements']['message']}")
        
        return results


def main():
    """主函數"""
    optimizer = DependencyOptimizer()
    
    print("🔧 Python依賴優化工具")
    print("="*60)
    
    # 顯示當前Python環境信息
    print(f"Python版本: {sys.version}")
    print(f"pip版本: ", end="")
    
    try:
        pip_result = subprocess.run([sys.executable, '-m', 'pip', '--version'], 
                                  capture_output=True, text=True)
        print(pip_result.stdout.strip())
    except:
        print("未知")
    
    print("="*60)
    
    # 運行優化
    results = optimizer.run_optimization()
    
    print("\n" + "="*60)
    print("📊 優化完成摘要")
    print("="*60)
    
    if 'check' in results:
        status = "✅" if results['check']['success'] else "❌"
        print(f"{status} 初始檢查: {results['check']['message']}")
    
    if 'resolve' in results:
        status = "✅" if results['resolve']['success'] else "❌"
        print(f"{status} 衝突解決: {results['resolve']['message']}")
        if results['resolve']['resolved']:
            print(f"  已解決: {', '.join(results['resolve']['resolved'])}")
    
    if 'recheck' in results:
        status = "✅" if results['recheck']['success'] else "❌"
        print(f"{status} 最終檢查: {results['recheck']['message']}")
    
    if 'requirements' in results:
        status = "✅" if results['requirements']['success'] else "❌"
        print(f"{status} Requirements: {results['requirements']['message']}")
    
    print("\n💡 建議:")
    print("- 使用 requirements_optimized.txt 作為乾淨的依賴列表")
    print("- 定期運行此工具檢查依賴健康狀態")
    print("- 在生產環境部署前務必解決所有依賴衝突")


if __name__ == "__main__":
    main()
