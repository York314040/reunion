#!/usr/bin/env python
"""
修復模型字段並重新測試
"""

import os
import sys
import django

# 設置Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.test import Client
from django.contrib.auth.models import User
from django.urls import reverse
from datetime import datetime
from events.models import Event, EventType
from dj_management.models import DJ, DJCategory
from suppliers.models import Supplier, ServiceCategory
from users.models import Profile

def test_with_correct_fields():
    """使用正確的字段測試模型"""
    print("🔧 使用正確字段測試模型...")
    print("=" * 60)
    
    client = Client()
    
    # 1. 測試DJ功能（使用正確字段）
    print("\n🎵 測試DJ功能:")
    try:
        dj_user = User.objects.create_user(
            username=f'test_dj_{int(datetime.now().timestamp())}',
            email='dj@test.com',
            password='testpass123'
        )
        
        # 設置用戶類型為DJ
        profile = Profile.objects.get(user=dj_user)
        profile.user_type = 'dj'
        profile.save()
        
        # 確保有DJ類別
        dj_category, created = DJCategory.objects.get_or_create(
            name='電子音樂',
            defaults={'description': '專業電子音樂DJ'}
        )
        
        # 使用正確的字段創建DJ資料
        dj = DJ.objects.create(
            user=dj_user,
            stage_name='測試DJ',
            real_name='測試DJ真名',
            category=dj_category,
            description='專業DJ介紹',
            experience_level='intermediate',
            specialties='Electronic, Pop, House',
            contact_phone='0912345678',
            contact_email='dj@test.com'
        )
        print(f"✅ DJ資料創建成功: {dj.stage_name}")
        
        # 測試DJ頁面訪問
        client.login(username=dj_user.username, password='testpass123')
        response = client.get('/dj/')
        print(f"✅ DJ頁面訪問成功，狀態碼: {response.status_code}")
        
    except Exception as e:
        print(f"❌ DJ功能測試失敗: {e}")
        import traceback
        traceback.print_exc()
    
    # 2. 測試供應商功能（使用正確字段）
    print("\n🏢 測試供應商功能:")
    try:
        supplier_user = User.objects.create_user(
            username=f'test_supplier_{int(datetime.now().timestamp())}',
            email='supplier@test.com',
            password='testpass123'
        )
        
        # 設置用戶類型為供應商
        profile = Profile.objects.get(user=supplier_user)
        profile.user_type = 'supplier'
        profile.save()
        
        # 確保有服務類別
        service_category, created = ServiceCategory.objects.get_or_create(
            name='餐飲服務',
            defaults={'description': '專業餐飲服務'}
        )
        
        # 使用正確的字段創建供應商資料
        supplier = Supplier.objects.create(
            user=supplier_user,
            company_name='測試供應商公司',
            description='專業餐飲服務公司',
            contact_phone='0987654321',
            contact_email='supplier@test.com',
            business_license='12345678',
            status='approved'
        )
        
        # 添加服務類別
        supplier.service_categories.add(service_category)
        
        print(f"✅ 供應商資料創建成功: {supplier.company_name}")
        
        # 測試供應商頁面訪問
        client.login(username=supplier_user.username, password='testpass123')
        response = client.get('/suppliers/')
        print(f"✅ 供應商頁面訪問成功，狀態碼: {response.status_code}")
        
    except Exception as e:
        print(f"❌ 供應商功能測試失敗: {e}")
        import traceback
        traceback.print_exc()
    
    # 3. 測試完整的工作流程
    print("\n🔄 測試完整工作流程:")
    try:
        # 創建一般用戶
        normal_user = User.objects.create_user(
            username=f'normal_user_{int(datetime.now().timestamp())}',
            email='normal@test.com',
            password='testpass123'
        )
        
        # 一般用戶登入並創建活動
        client.login(username=normal_user.username, password='testpass123')
        
        event_type = EventType.objects.first()
        event_data = {
            'title': '完整測試活動',
            'description': '測試完整工作流程的活動',
            'event_type': event_type.id,
            'budget_min': 15000,
            'budget_max': 30000,
            'expected_attendees': 80,
            'event_date': '2024-12-31T19:00',
            'location': '台北市大安區',
            'contact_person': '活動聯絡人',
            'contact_phone': '0911222333',
            'contact_email': 'event@test.com'
        }
        
        response = client.post(reverse('events:create_event'), event_data)
        if response.status_code == 302:
            print("✅ 一般用戶成功創建活動")
            
            # 獲取創建的活動
            event = Event.objects.filter(title='完整測試活動').first()
            if event:
                print(f"✅ 活動ID: {event.id}, 狀態: {event.status}")
                
                # 供應商登入並查看活動
                client.login(username=supplier_user.username, password='testpass123')
                
                # 供應商可以查看活動列表
                response = client.get(reverse('events:event_list'))
                print(f"✅ 供應商可以查看活動列表，狀態碼: {response.status_code}")
                
                # 供應商可以查看具體活動
                response = client.get(reverse('events:event_detail', kwargs={'pk': event.id}))
                print(f"✅ 供應商可以查看活動詳情，狀態碼: {response.status_code}")
        else:
            print(f"❌ 活動創建失敗，狀態碼: {response.status_code}")
            
    except Exception as e:
        print(f"❌ 完整工作流程測試失敗: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n" + "=" * 60)
    print("🎉 修復測試完成！")
    print("=" * 60)

if __name__ == '__main__':
    test_with_correct_fields()
