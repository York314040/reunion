#!/usr/bin/env python
"""
檢查用戶管理頁面的HTML內容
"""
import os
import sys
import django

# 設置 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.test import TestCase, Client
from django.contrib.auth.models import User
import re

def check_page_content():
    """檢查用戶管理頁面內容"""
    
    print("=== 檢查用戶管理頁面內容 ===\n")
    
    # 1. 登入超級用戶
    client = Client()
    superuser = User.objects.filter(is_superuser=True).first()
    login_success = client.login(username=superuser.username, password='123456')
    
    if not login_success:
        print("❌ 登入失敗")
        return
    
    print("✅ 登入成功")
    
    # 2. 獲取用戶管理頁面
    response = client.get('/manage/users/')
    html_content = response.content.decode()
    
    print(f"✅ 頁面狀態碼: {response.status_code}")
    print(f"✅ 頁面長度: {len(html_content)} 字符")
    
    # 3. 檢查一般用戶
    regular_users = User.objects.filter(is_superuser=False, is_staff=False)
    print(f"✅ 找到 {regular_users.count()} 個一般用戶")
    
    for user in regular_users:
        print(f"\n=== 檢查用戶: {user.username} (ID: {user.id}) ===")
        
        # 檢查用戶是否在表格中
        user_row_pattern = f'<tr[^>]*>.*?{user.username}.*?</tr>'
        user_match = re.search(user_row_pattern, html_content, re.DOTALL)
        
        if user_match:
            print("✅ 用戶在表格中")
            user_row = user_match.group(0)
            
            # 檢查刪除按鈕
            delete_btn_pattern = f'delete-user.*?data-user-id="{user.id}"'
            if re.search(delete_btn_pattern, user_row):
                print("✅ 找到刪除按鈕")
            else:
                print("❌ 未找到刪除按鈕")
                
            # 檢查切換狀態按鈕
            toggle_btn_pattern = f'toggle-status.*?data-user-id="{user.id}"'
            if re.search(toggle_btn_pattern, user_row):
                print("✅ 找到切換狀態按鈕")
            else:
                print("❌ 未找到切換狀態按鈕")
                
            # 檢查權限按鈕
            perm_btn_pattern = f'change-permissions.*?data-user-id="{user.id}"'
            if re.search(perm_btn_pattern, user_row):
                print("✅ 找到權限管理按鈕")
            else:
                print("❌ 未找到權限管理按鈕")
                
        else:
            print("❌ 用戶不在表格中")
    
    # 4. 檢查 JavaScript 函數
    print(f"\n=== 檢查 JavaScript 功能 ===")
    
    if "$('.delete-user').click(" in html_content:
        print("✅ 找到刪除用戶JavaScript函數")
    else:
        print("❌ 未找到刪除用戶JavaScript函數")
        
    if "confirmDeleteModal" in html_content:
        print("✅ 找到確認刪除模態框")
    else:
        print("❌ 未找到確認刪除模態框")
        
    if "$('#confirmDeleteBtn').click(" in html_content:
        print("✅ 找到確認刪除按鈕JavaScript")
    else:
        print("❌ 未找到確認刪除按鈕JavaScript")
    
    # 5. 檢查 CSRF token
    csrf_pattern = r'name="csrfmiddlewaretoken" value="([^"]*)"'
    csrf_match = re.search(csrf_pattern, html_content)
    if csrf_match:
        print("✅ 找到 CSRF token")
    else:
        print("❌ 未找到 CSRF token")
    
    # 6. 輸出部分HTML內容供檢視
    print(f"\n=== 部分HTML內容 ===")
    
    # 找到第一個一般用戶的操作按鈕部分
    if regular_users.exists():
        first_user = regular_users.first()
        user_row_pattern = f'<tr[^>]*>.*?{first_user.username}.*?</tr>'
        user_match = re.search(user_row_pattern, html_content, re.DOTALL)
        if user_match:
            user_row = user_match.group(0)
            print("用戶操作部分HTML:")
            print(user_row[-500:])  # 最後500字符，通常包含操作按鈕

if __name__ == "__main__":
    check_page_content()
