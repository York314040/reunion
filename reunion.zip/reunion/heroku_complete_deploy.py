#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
完整版 Heroku 部署腳本 - PAPA COLLEGE B2B聚會派對媒合平台
專門解決 pre-receive hook 錯誤，確保朋友可以正常使用
"""

import subprocess
import sys
import os
import time
from datetime import datetime
import json

def run_command(command, description, check_output=False, ignore_errors=False):
    """執行命令並處理結果"""
    print(f"\n🔧 {description}")
    print(f"📝 執行命令: {command}")
    
    try:
        if check_output:
            result = subprocess.run(command, shell=True, capture_output=True, text=True, cwd=os.getcwd())
            if result.returncode == 0:
                print(f"✅ 成功: {description}")
                return result.stdout.strip()
            else:
                if ignore_errors:
                    print(f"⚠️ 警告: {description} - {result.stderr}")
                    return result.stdout.strip() if result.stdout else ""
                else:
                    print(f"❌ 失敗: {description}")
                    print(f"錯誤信息: {result.stderr}")
                    return None
        else:
            result = subprocess.run(command, shell=True, cwd=os.getcwd())
            if result.returncode == 0:
                print(f"✅ 成功: {description}")
                return True
            else:
                if ignore_errors:
                    print(f"⚠️ 警告: {description}")
                    return True
                else:
                    print(f"❌ 失敗: {description}")
                    return False
    except Exception as e:
        print(f"❌ 執行錯誤: {str(e)}")
        return False if not ignore_errors else True

def check_heroku_login():
    """檢查 Heroku 登入狀態"""
    print("🔐 檢查 Heroku 登入狀態...")
    result = run_command("heroku auth:whoami", "檢查登入狀態", check_output=True)
    if result:
        print(f"✅ 已登入 Heroku: {result}")
        return True
    else:
        print("❌ 未登入 Heroku，請先執行: heroku login")
        return False

def fix_git_issues():
    """修復 Git 相關問題"""
    print("\n🔧 修復 Git 相關問題...")
    
    # 檢查並設置 Git 配置
    run_command('git config user.email "your-email@example.com"', "設置 Git 郵箱", ignore_errors=True)
    run_command('git config user.name "Your Name"', "設置 Git 用戶名", ignore_errors=True)
    
    # 檢查是否有 .gitignore
    if not os.path.exists('.gitignore'):
        print("📝 創建 .gitignore 文件...")
        gitignore_content = """
# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
env/
venv/
ENV/
env.bak/
venv.bak/

# Django
*.log
local_settings.py
db.sqlite3
db.sqlite3-journal
media/

# Static files
staticfiles/
static/

# Environment variables
.env
.env.local
.env.production

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Heroku
.heroku/
"""
        with open('.gitignore', 'w', encoding='utf-8') as f:
            f.write(gitignore_content.strip())
    
    return True

def reset_heroku_git():
    """重置 Heroku Git 連接"""
    print("\n🔄 重置 Heroku Git 連接...")
    
    app_name = "papa-college-b2b"
    
    # 移除現有的 heroku remote
    run_command("git remote remove heroku", "移除現有 Heroku remote", ignore_errors=True)
    
    # 重新添加 heroku remote
    success = run_command(f"heroku git:remote --app {app_name}", "重新添加 Heroku remote")
    
    if success:
        print("✅ Heroku Git 連接重置成功")
        return True
    else:
        print("❌ Heroku Git 連接重置失敗")
        return False

def prepare_for_deployment():
    """準備部署"""
    print("\n📦 準備部署文件...")
    
    # 清理緩存
    run_command("find . -name '*.pyc' -delete", "清理 Python 緩存", ignore_errors=True)
    run_command("find . -name '__pycache__' -type d -exec rm -rf {} +", "清理 __pycache__", ignore_errors=True)
    
    # 確保必要文件存在
    required_files = [
        'requirements.txt',
        'Procfile',
        'party_platform/settings.py',
        'manage.py'
    ]
    
    missing_files = []
    for file in required_files:
        if not os.path.exists(file):
            missing_files.append(file)
    
    if missing_files:
        print(f"❌ 缺少必要文件: {missing_files}")
        return False
    
    print("✅ 所有必要文件都存在")
    return True

def deploy_with_force(app_name):
    """強制部署到 Heroku"""
    print(f"\n🚀 強制部署到 Heroku...")
    
    # 1. 添加所有文件
    run_command("git add .", "添加所有文件到 Git")
    
    # 2. 提交變更
    commit_message = f"Complete Production Deploy - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    commit_success = run_command(f'git commit -m "{commit_message}"', "提交變更", ignore_errors=True)
    
    # 3. 強制推送到 Heroku
    print("\n🔄 強制推送到 Heroku (這可能需要幾分鐘)...")
    
    # 嘗試多種推送方式
    push_commands = [
        "git push heroku main --force",
        "git push heroku HEAD:main --force",
        "git push heroku main --force-with-lease"
    ]
    
    for cmd in push_commands:
        print(f"\n嘗試: {cmd}")
        success = run_command(cmd, f"推送到 Heroku - {cmd}")
        if success:
            print("✅ 代碼推送成功！")
            return True
        print(f"⚠️ {cmd} 失敗，嘗試下一個方法...")
    
    print("❌ 所有推送方法都失敗")
    return False

def setup_production_environment(app_name):
    """設置生產環境變數"""
    print(f"\n⚙️ 設置生產環境變數...")
    
    # 生成安全的 SECRET_KEY
    import secrets
    import string
    alphabet = string.ascii_letters + string.digits + '!@#$%^&*(-_=+)'
    secret_key = ''.join(secrets.choice(alphabet) for i in range(50))
    
    env_vars = {
        'SECRET_KEY': secret_key,
        'DEBUG': 'False',
        'ALLOWED_HOSTS': f'{app_name}.herokuapp.com,*.herokuapp.com,localhost,127.0.0.1',
        'DJANGO_SETTINGS_MODULE': 'party_platform.settings',
        'WEB_CONCURRENCY': '2',
        'PYTHONPATH': '/app',
        'PORT': '8000'
    }
    
    success_count = 0
    for key, value in env_vars.items():
        success = run_command(f'heroku config:set {key}="{value}" --app {app_name}', f"設置 {key}")
        if success:
            success_count += 1
    
    print(f"📊 環境變數設置: {success_count}/{len(env_vars)} 成功")
    return success_count > 0

def run_post_deployment_tasks(app_name):
    """執行部署後任務"""
    print(f"\n⚙️ 執行部署後任務...")
    
    # 等待應用啟動
    print("⏳ 等待應用啟動...")
    time.sleep(30)
    
    tasks = {}
    
    # 1. 檢查應用狀態
    print("🔍 檢查應用狀態...")
    status = run_command(f"heroku ps --app {app_name}", "檢查應用狀態", check_output=True)
    tasks['app_status'] = status is not None
    
    # 2. 執行資料庫遷移
    print("📊 執行資料庫遷移...")
    migration_success = run_command(f"heroku run python manage.py migrate --app {app_name}", "執行資料庫遷移")
    tasks['migration'] = migration_success
    
    # 3. 收集靜態文件
    print("🎨 收集靜態文件...")
    static_success = run_command(f"heroku run python manage.py collectstatic --noinput --app {app_name}", "收集靜態文件")
    tasks['static_files'] = static_success
    
    # 4. 創建初始數據
    print("📦 創建初始數據...")
    init_data_success = run_command(f"heroku run python manage.py shell -c \"from django.contrib.auth.models import User; User.objects.filter(is_superuser=True).exists() or print('No admin user')\" --app {app_name}", "檢查管理員用戶", ignore_errors=True)
    tasks['init_data'] = init_data_success
    
    return tasks

def validate_deployment(app_name):
    """驗證部署是否成功"""
    print(f"\n🔍 驗證部署...")
    
    url = f"https://{app_name}.herokuapp.com"
    
    try:
        import urllib.request
        response = urllib.request.urlopen(url)
        if response.getcode() == 200:
            print(f"✅ 應用可以正常訪問: {url}")
            return True
        else:
            print(f"⚠️ 應用響應代碼: {response.getcode()}")
            return False
    except Exception as e:
        print(f"❌ 無法訪問應用: {str(e)}")
        return False

def main():
    """主函數"""
    print("="*70)
    print("🎉 PAPA COLLEGE - 完整版 Heroku 部署工具")
    print("🚀 專為朋友共享使用而設計")
    print("="*70)
    print(f"⏰ 開始時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    app_name = "papa-college-b2b"
    
    try:
        # 1. 檢查 Heroku 登入
        if not check_heroku_login():
            print("\n❌ 請先登入 Heroku:")
            print("   heroku login")
            return
        
        # 2. 修復 Git 問題
        fix_git_issues()
        
        # 3. 準備部署
        if not prepare_for_deployment():
            print("❌ 部署準備失敗")
            return
        
        # 4. 重置 Heroku Git
        if not reset_heroku_git():
            print("❌ Heroku Git 重置失敗")
            return
        
        # 5. 設置生產環境
        setup_production_environment(app_name)
        
        # 6. 執行強制部署
        if not deploy_with_force(app_name):
            print("❌ 部署失敗")
            return
        
        # 7. 執行部署後任務
        tasks = run_post_deployment_tasks(app_name)
        
        # 8. 驗證部署
        deployment_valid = validate_deployment(app_name)
        
        # 9. 顯示結果
        print("\n" + "="*70)
        print("🎊 部署完成！")
        print("="*70)
        print(f"🌐 應用網址: https://{app_name}.herokuapp.com")
        print(f"⚙️ 管理後台: https://{app_name}.herokuapp.com/admin")
        print(f"📱 手機友好: 響應式設計，支持手機訪問")
        
        print("\n📊 部署後任務結果:")
        for task, result in tasks.items():
            status = "✅ 成功" if result else "❌ 失敗"
            print(f"   {task}: {status}")
        
        print(f"\n🔍 部署驗證: {'✅ 通過' if deployment_valid else '❌ 失敗'}")
        
        print("\n👥 分享給朋友:")
        print(f"   🔗 直接分享網址: https://{app_name}.herokuapp.com")
        print("   📱 手機也可以正常使用")
        print("   🎯 功能完整，包含所有B2B派對媒合功能")
        
        print("\n📋 管理命令:")
        print(f"   查看日誌: heroku logs --tail --app {app_name}")
        print(f"   重啟應用: heroku restart --app {app_name}")
        print(f"   查看配置: heroku config --app {app_name}")
        print(f"   執行命令: heroku run python manage.py <command> --app {app_name}")
        
        # 10. 詢問是否打開應用
        print("\n🌐 是否要在瀏覽器中打開應用？")
        open_browser = input("輸入 y 打開應用，或按 Enter 跳過: ").lower()
        if open_browser == 'y':
            run_command(f"heroku open --app {app_name}", "打開應用")
        
        # 11. 詢問是否創建管理員帳戶
        print("\n👤 是否要創建管理員帳戶？")
        create_admin = input("輸入 y 創建管理員，或按 Enter 跳過: ").lower()
        if create_admin == 'y':
            print("請按照提示輸入管理員資訊：")
            run_command(f"heroku run python manage.py createsuperuser --app {app_name}", "創建管理員帳戶")
        
        print(f"\n⏰ 完成時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("🎉 恭喜！您的 PAPA COLLEGE 平台已成功部署到 Heroku！")
        print("👥 現在您的朋友可以通過網址訪問和使用了！")
        
    except KeyboardInterrupt:
        print("\n⏹️ 用戶中斷部署")
    except Exception as e:
        print(f"\n❌ 部署過程中發生錯誤: {str(e)}")
        print("💡 建議檢查網絡連接和 Heroku 服務狀態")

if __name__ == "__main__":
    main()
