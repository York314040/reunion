#!/usr/bin/env python3
"""
PAPA COLLEGE - 深度手動功能測試
模擬真實用戶完整流程測試
"""

import requests
import time
import json
import re
from datetime import datetime
from urllib.parse import urljoin
from bs4 import BeautifulSoup

class DetailedUserTest:
    def __init__(self, base_url="http://127.0.0.1:8080"):
        self.base_url = base_url
        self.session = requests.Session()
        self.test_results = []
        
    def log_test(self, test_name, status, message="", details=""):
        """記錄測試結果"""
        result = {
            'test_name': test_name,
            'status': status,
            'message': message,
            'details': details,
            'timestamp': datetime.now().strftime('%H:%M:%S')
        }
        self.test_results.append(result)
        
        icon = "✅" if status == "PASS" else "❌" if status == "FAIL" else "⚠️"
        print(f"{icon} {test_name}: {message}")
        if details:
            print(f"   詳細: {details}")
    
    def get_csrf_token(self, html_content):
        """從頁面中提取 CSRF token"""
        soup = BeautifulSoup(html_content, 'html.parser')
        csrf_input = soup.find('input', {'name': 'csrfmiddlewaretoken'})
        if csrf_input:
            return csrf_input.get('value')
        return None
    
    def test_homepage_features(self):
        """測試首頁功能特性"""
        try:
            response = self.session.get(self.base_url)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 檢查精選活動
            featured_events = soup.find_all(class_=re.compile('event.*card|card.*event'))
            if featured_events:
                self.log_test("首頁-精選活動", "PASS", f"找到 {len(featured_events)} 個活動卡片")
            else:
                self.log_test("首頁-精選活動", "WARN", "未找到活動卡片")
            
            # 檢查導航欄
            navbar = soup.find('nav', class_='navbar')
            if navbar:
                nav_links = navbar.find_all('a', class_='nav-link')
                self.log_test("首頁-導航欄", "PASS", f"找到 {len(nav_links)} 個導航連結")
            else:
                self.log_test("首頁-導航欄", "FAIL", "未找到導航欄")
            
            # 檢查響應式元素
            viewport_meta = soup.find('meta', {'name': 'viewport'})
            if viewport_meta:
                self.log_test("首頁-響應式設計", "PASS", "包含 viewport meta 標籤")
            else:
                self.log_test("首頁-響應式設計", "WARN", "缺少 viewport meta 標籤")
                
        except Exception as e:
            self.log_test("首頁功能檢查", "FAIL", f"檢查失敗: {str(e)}")
    
    def test_supplier_page_functionality(self):
        """測試供應商頁面功能"""
        try:
            url = urljoin(self.base_url, '/suppliers/')
            response = self.session.get(url)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 檢查供應商卡片
            supplier_cards = soup.find_all(class_=re.compile('card|supplier'))
            if supplier_cards:
                self.log_test("供應商頁面-卡片顯示", "PASS", f"找到 {len(supplier_cards)} 個供應商項目")
            else:
                self.log_test("供應商頁面-卡片顯示", "WARN", "未找到供應商卡片")
            
            # 檢查搜尋框
            search_input = soup.find('input', {'type': ['search', 'text'], 'name': re.compile('search|query')})
            if search_input:
                self.log_test("供應商頁面-搜尋功能", "PASS", "找到搜尋輸入框")
            else:
                self.log_test("供應商頁面-搜尋功能", "WARN", "未找到搜尋功能")
            
            # 測試搜尋功能
            search_params = {'search': '音響'}
            search_response = self.session.get(url, params=search_params)
            if search_response.status_code == 200:
                self.log_test("供應商頁面-搜尋測試", "PASS", "搜尋請求成功")
            else:
                self.log_test("供應商頁面-搜尋測試", "FAIL", f"搜尋失敗: {search_response.status_code}")
                
        except Exception as e:
            self.log_test("供應商頁面測試", "FAIL", f"測試失敗: {str(e)}")
    
    def test_dj_pages(self):
        """測試 DJ 相關頁面"""
        dj_urls = [
            ('/dj/', 'DJ列表'),
            ('/dj/popular/', '熱門DJ')
        ]
        
        for url_path, page_name in dj_urls:
            try:
                url = urljoin(self.base_url, url_path)
                response = self.session.get(url)
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # 檢查 DJ 卡片或列表項目
                dj_items = soup.find_all(class_=re.compile('dj|card'))
                if dj_items:
                    self.log_test(f"{page_name}-內容顯示", "PASS", f"找到 {len(dj_items)} 個 DJ 項目")
                else:
                    self.log_test(f"{page_name}-內容顯示", "WARN", "未找到 DJ 項目")
                
                # 檢查頁面載入時間
                start_time = time.time()
                self.session.get(url)
                end_time = time.time()
                load_time = (end_time - start_time) * 1000
                
                if load_time < 500:
                    self.log_test(f"{page_name}-載入性能", "PASS", f"載入時間: {load_time:.0f}ms")
                else:
                    self.log_test(f"{page_name}-載入性能", "WARN", f"載入較慢: {load_time:.0f}ms")
                    
            except Exception as e:
                self.log_test(f"{page_name}測試", "FAIL", f"測試失敗: {str(e)}")
    
    def test_user_authentication_flow(self):
        """測試用戶認證流程"""
        try:
            # 測試註冊頁面
            register_url = urljoin(self.base_url, '/users/register/')
            response = self.session.get(register_url)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 檢查註冊表單
            register_form = soup.find('form')
            if register_form:
                form_fields = register_form.find_all(['input', 'select', 'textarea'])
                self.log_test("註冊頁面-表單結構", "PASS", f"找到 {len(form_fields)} 個表單欄位")
                
                # 檢查必要欄位
                required_fields = ['username', 'email', 'password1', 'password2']
                found_fields = []
                for field in form_fields:
                    field_name = field.get('name', '')
                    if field_name in required_fields:
                        found_fields.append(field_name)
                
                if len(found_fields) >= 3:
                    self.log_test("註冊頁面-必要欄位", "PASS", f"找到必要欄位: {', '.join(found_fields)}")
                else:
                    self.log_test("註冊頁面-必要欄位", "WARN", f"可能缺少必要欄位")
            else:
                self.log_test("註冊頁面-表單結構", "FAIL", "未找到註冊表單")
            
            # 測試登入頁面
            login_url = urljoin(self.base_url, '/login/')
            response = self.session.get(login_url)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            login_form = soup.find('form')
            if login_form:
                self.log_test("登入頁面-表單結構", "PASS", "找到登入表單")
            else:
                self.log_test("登入頁面-表單結構", "FAIL", "未找到登入表單")
                
        except Exception as e:
            self.log_test("用戶認證測試", "FAIL", f"測試失敗: {str(e)}")
    
    def test_form_validation(self):
        """測試表單驗證功能"""
        try:
            # 測試註冊表單驗證
            register_url = urljoin(self.base_url, '/users/register/')
            response = self.session.get(register_url)
            csrf_token = self.get_csrf_token(response.text)
            
            if csrf_token:
                # 提交不完整的表單
                invalid_data = {
                    'csrfmiddlewaretoken': csrf_token,
                    'username': '',  # 空用戶名
                    'email': 'invalid-email',  # 無效郵件
                    'password1': '123',  # 弱密碼
                    'password2': '456',  # 不匹配密碼
                }
                
                response = self.session.post(register_url, data=invalid_data)
                
                # 檢查是否有錯誤訊息
                if 'error' in response.text.lower() or 'invalid' in response.text.lower():
                    self.log_test("表單驗證-錯誤處理", "PASS", "系統正確顯示驗證錯誤")
                else:
                    self.log_test("表單驗證-錯誤處理", "WARN", "可能缺少表單驗證")
            else:
                self.log_test("表單驗證-CSRF", "FAIL", "無法獲取 CSRF token")
                
        except Exception as e:
            self.log_test("表單驗證測試", "FAIL", f"測試失敗: {str(e)}")
    
    def test_css_and_styling(self):
        """測試 CSS 和樣式"""
        try:
            response = self.session.get(self.base_url)
            
            # 檢查外部 CSS 資源
            css_links = [
                'bootstrap',
                'font-awesome',
                'googleapis'
            ]
            
            found_css = []
            for css_name in css_links:
                if css_name in response.text:
                    found_css.append(css_name)
            
            if len(found_css) >= 2:
                self.log_test("CSS資源-外部載入", "PASS", f"找到 CSS: {', '.join(found_css)}")
            else:
                self.log_test("CSS資源-外部載入", "WARN", "可能缺少重要 CSS 資源")
            
            # 檢查自定義樣式
            if '<style>' in response.text:
                self.log_test("CSS資源-自定義樣式", "PASS", "包含自定義 CSS 樣式")
            else:
                self.log_test("CSS資源-自定義樣式", "WARN", "未找到自定義樣式")
                
        except Exception as e:
            self.log_test("CSS樣式測試", "FAIL", f"測試失敗: {str(e)}")
    
    def test_javascript_functionality(self):
        """測試 JavaScript 功能"""
        try:
            response = self.session.get(self.base_url)
            
            # 檢查 JavaScript 資源
            js_libraries = [
                'jquery',
                'bootstrap'
            ]
            
            found_js = []
            for js_name in js_libraries:
                if js_name in response.text.lower():
                    found_js.append(js_name)
            
            if len(found_js) >= 2:
                self.log_test("JavaScript-外部資源", "PASS", f"找到 JS: {', '.join(found_js)}")
            else:
                self.log_test("JavaScript-外部資源", "WARN", "可能缺少重要 JS 資源")
            
            # 檢查自定義 JavaScript
            if 'addEventListener' in response.text or 'document.ready' in response.text:
                self.log_test("JavaScript-自定義功能", "PASS", "包含自定義 JavaScript")
            else:
                self.log_test("JavaScript-自定義功能", "WARN", "未找到自定義 JavaScript")
                
        except Exception as e:
            self.log_test("JavaScript測試", "FAIL", f"測試失敗: {str(e)}")
    
    def test_mobile_responsiveness(self):
        """測試手機響應式設計"""
        mobile_headers = {
            'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15'
        }
        
        try:
            response = self.session.get(self.base_url, headers=mobile_headers)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 檢查 Bootstrap 響應式類別
            responsive_classes = ['col-sm', 'col-md', 'col-lg', 'd-none', 'd-block']
            found_responsive = []
            
            for cls in responsive_classes:
                if cls in response.text:
                    found_responsive.append(cls)
            
            if len(found_responsive) >= 3:
                self.log_test("響應式設計-Bootstrap類別", "PASS", f"找到響應式類別: {', '.join(found_responsive)}")
            else:
                self.log_test("響應式設計-Bootstrap類別", "WARN", "可能缺少響應式設計類別")
            
            # 檢查媒體查詢
            if '@media' in response.text:
                self.log_test("響應式設計-媒體查詢", "PASS", "包含 CSS 媒體查詢")
            else:
                self.log_test("響應式設計-媒體查詢", "WARN", "未找到媒體查詢")
                
        except Exception as e:
            self.log_test("響應式設計測試", "FAIL", f"測試失敗: {str(e)}")
    
    def test_error_handling(self):
        """測試錯誤處理"""
        error_urls = [
            '/nonexistent-page/',
            '/events/99999/',
            '/suppliers/99999/'
        ]
        
        for url_path in error_urls:
            try:
                url = urljoin(self.base_url, url_path)
                response = self.session.get(url)
                
                if response.status_code == 404:
                    self.log_test(f"錯誤處理-404頁面", "PASS", f"正確返回 404 狀態")
                elif response.status_code in [200, 302]:
                    self.log_test(f"錯誤處理-404頁面", "WARN", f"可能缺少 404 處理")
                else:
                    self.log_test(f"錯誤處理-404頁面", "FAIL", f"異常狀態碼: {response.status_code}")
                    
            except Exception as e:
                self.log_test("錯誤處理測試", "FAIL", f"測試失敗: {str(e)}")
    
    def run_comprehensive_test(self):
        """執行全面測試"""
        print("🔍 PAPA COLLEGE - 深度功能測試開始")
        print("詳細檢查所有用戶功能和界面元素")
        print("=" * 60)
        
        print("\n🏠 首頁功能測試:")
        self.test_homepage_features()
        
        print("\n🏪 供應商功能測試:")
        self.test_supplier_page_functionality()
        
        print("\n🎵 DJ功能測試:")
        self.test_dj_pages()
        
        print("\n👤 用戶認證測試:")
        self.test_user_authentication_flow()
        
        print("\n📝 表單驗證測試:")
        self.test_form_validation()
        
        print("\n🎨 樣式和資源測試:")
        self.test_css_and_styling()
        self.test_javascript_functionality()
        
        print("\n📱 響應式設計測試:")
        self.test_mobile_responsiveness()
        
        print("\n❌ 錯誤處理測試:")
        self.test_error_handling()
    
    def generate_detailed_report(self):
        """生成詳細報告"""
        print("\n" + "=" * 60)
        print("📊 詳細測試報告")
        print("=" * 60)
        
        passed = len([r for r in self.test_results if r['status'] == 'PASS'])
        failed = len([r for r in self.test_results if r['status'] == 'FAIL'])
        warnings = len([r for r in self.test_results if r['status'] == 'WARN'])
        total = len(self.test_results)
        
        print(f"✅ 通過測試: {passed} 個 ({passed/total*100:.1f}%)")
        print(f"❌ 失敗測試: {failed} 個 ({failed/total*100:.1f}%)")
        print(f"⚠️  警告項目: {warnings} 個 ({warnings/total*100:.1f}%)")
        print(f"📈 總測試數: {total} 個")
        
        # 系統健康度評估
        if failed == 0 and warnings <= 2:
            health_score = "🌟 優秀"
            health_message = "系統功能完善，用戶體驗優良"
        elif failed <= 1 and warnings <= 5:
            health_score = "👍 良好"
            health_message = "系統基本功能正常，有少量需要改進的項目"
        elif failed <= 3:
            health_score = "⚠️ 普通"
            health_message = "系統可用但需要修復一些問題"
        else:
            health_score = "🚫 需要修復"
            health_message = "發現多個嚴重問題，建議立即修復"
        
        print(f"\n🏥 系統健康度: {health_score}")
        print(f"💭 評估: {health_message}")
        
        # 詳細問題列表
        if failed > 0:
            print(f"\n❌ 需要立即修復的問題:")
            for result in self.test_results:
                if result['status'] == 'FAIL':
                    print(f"   • {result['test_name']}: {result['message']}")
        
        if warnings > 0:
            print(f"\n⚠️  建議改進的項目:")
            for result in self.test_results:
                if result['status'] == 'WARN':
                    print(f"   • {result['test_name']}: {result['message']}")
        
        # 優化建議
        print(f"\n💡 優化建議:")
        if warnings > 0:
            print(f"   1. 優先修復警告項目以提升用戶體驗")
        if failed == 0:
            print(f"   2. 系統運行良好，可考慮添加更多功能")
        print(f"   3. 定期執行此測試以確保系統穩定性")
        print(f"   4. 收集用戶回饋以發現更多潛在問題")

def main():
    print("🧪 PAPA COLLEGE - 深度功能測試工具")
    print("時間:", datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    
    tester = DetailedUserTest()
    tester.run_comprehensive_test()
    tester.generate_detailed_report()

if __name__ == "__main__":
    main()
