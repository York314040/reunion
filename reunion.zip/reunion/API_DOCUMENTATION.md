# PAPA COLLEGE B2B聚會派對媒合平台 API 文檔

**版本**: 1.0.0  
**生成時間**: 2025-07-15T10:59:53.570855  
**基礎URL**: http://localhost:8000

---

## 📋 目錄

1. [項目概覽](#項目概覽)
2. [認證系統](#認證系統)
3. [API 端點](#api-端點)
4. [數據模型](#數據模型)
5. [視圖分析](#視圖分析)
6. [URL 路由](#url-路由)

---

## 📖 項目概覽

PAPA COLLEGE 是一個 B2B 聚會派對媒合平台，連接活動主辦方、供應商和DJ，提供完整的活動策劃解決方案。

### 主要功能
- 👥 多角色用戶系統 (客戶、供應商、DJ、管理員)
- 🎉 活動需求發布和管理
- 🏪 供應商服務展示
- 🎵 DJ 檔案管理
- 💬 即時訊息系統
- 📊 數據分析和報告

---

## 🔐 認證系統

### 用戶類型
- **客戶 (Client)**: 發布活動需求，尋找供應商和DJ
- **供應商 (Supplier)**: 提供活動相關服務和產品
- **DJ**: 提供音樂表演服務
- **管理員 (Admin)**: 系統管理和監控

### 認證流程
1. 用戶註冊並選擇角色
2. 系統驗證用戶信息
3. 完善個人或企業檔案
4. 開始使用平台功能

---

## 🚀 API 端點

### AUTHENTICATION

#### 用戶登入

**URL**: `/accounts/login/`  
**方法**: `POST`  

**參數**:
- `username`: 用戶名
- `password`: 密碼

**響應**: 登入成功返回用戶信息

---

#### 用戶登出

**URL**: `/accounts/logout/`  
**方法**: `POST`  

**響應**: 登出成功

---

#### 用戶註冊

**URL**: `/register/`  
**方法**: `POST`  

**參數**:
- `username`: 用戶名
- `email`: 電子郵件
- `password`: 密碼
- `user_type`: 用戶類型 (client/supplier/dj)

**響應**: 註冊成功返回用戶信息

---

### EVENTS

#### 獲取活動列表

**URL**: `/events/`  
**方法**: `GET`  

**參數**:
- `page`: 頁碼 (可選)
- `search`: 搜索關鍵字 (可選)

**響應**: 活動列表和分頁信息

---

#### 創建新活動

**URL**: `/events/create/`  
**方法**: `POST`  

**參數**:
- `title`: 活動標題
- `description`: 活動描述
- `event_date`: 活動日期
- `location`: 活動地點
- `budget`: 預算

**響應**: 創建的活動信息

---

#### 獲取活動詳情

**URL**: `/events/<id>/`  
**方法**: `GET`  

**參數**:
- `id`: 活動ID

**響應**: 活動詳細信息

---

### SUPPLIERS

#### 獲取供應商列表

**URL**: `/suppliers/`  
**方法**: `GET`  

**參數**:
- `page`: 頁碼 (可選)
- `category`: 分類 (可選)

**響應**: 供應商列表和分頁信息

---

#### 獲取供應商詳情

**URL**: `/suppliers/<id>/`  
**方法**: `GET`  

**參數**:
- `id`: 供應商ID

**響應**: 供應商詳細信息

---

### DJ_MANAGEMENT

#### 獲取DJ列表

**URL**: `/dj/`  
**方法**: `GET`  

**參數**:
- `page`: 頁碼 (可選)
- `genre`: 音樂類型 (可選)

**響應**: DJ列表和分頁信息

---

#### 獲取DJ詳情

**URL**: `/dj/<id>/`  
**方法**: `GET`  

**參數**:
- `id`: DJ ID

**響應**: DJ詳細信息

---

### MESSAGING

#### 獲取對話列表

**URL**: `/messaging/`  
**方法**: `GET`  

**響應**: 用戶的對話列表

---

#### 發送訊息

**URL**: `/messaging/send/`  
**方法**: `POST`  

**參數**:
- `recipient_id`: 收件人ID
- `message`: 訊息內容

**響應**: 發送成功確認

---

## 📊 數據模型

### EVENTS 應用

#### EventType

**說明**: 活動類型

**字段**:
- `id` (BigAutoField)
- `name` (CharField)
- `description` (TextField)

**關聯**:
- `event` (ManyToOneRel) → Event

---

#### Event

**說明**: 活動需求

**字段**:
- `id` (BigAutoField)
- `title` (CharField)
- `description` (TextField)
- `event_type` (ForeignKey)
- `organizer` (ForeignKey)
- `event_date` (DateTimeField)
- `location` (CharField)
- `expected_attendees` (PositiveIntegerField)
- `budget_min` (PositiveIntegerField): 新台幣
- `budget_max` (PositiveIntegerField): 新台幣
- `requirements` (TextField)
- `duration_hours` (PositiveIntegerField)
- `contact_person` (CharField)
- `contact_phone` (CharField)
- `contact_email` (EmailField)
- `status` (CharField)
- `created_at` (DateTimeField)
- `updated_at` (DateTimeField)

**關聯**:
- `conversation` (ManyToOneRel) → Conversation
- `quote` (ManyToOneRel) → Quote

---

### SUPPLIERS 應用

#### ServiceCategory

**說明**: 服務類別

**字段**:
- `id` (BigAutoField)
- `name` (CharField)
- `description` (TextField)

**關聯**:
- `supplier` (ManyToManyRel) → Supplier

---

#### Supplier

**說明**: 供應商

**字段**:
- `id` (BigAutoField)
- `user` (OneToOneField)
- `company_name` (CharField)
- `description` (TextField)
- `experience_years` (PositiveIntegerField)
- `service_area` (CharField)
- `contact_person` (CharField)
- `contact_phone` (CharField)
- `contact_email` (EmailField)
- `website` (URLField)
- `price_range_min` (PositiveIntegerField): 新台幣
- `price_range_max` (PositiveIntegerField): 新台幣
- `logo` (ImageField)
- `portfolio_images` (TextField): 多個URL用逗號分隔
- `status` (CharField)
- `featured` (BooleanField)
- `created_at` (DateTimeField)
- `updated_at` (DateTimeField)

**關聯**:
- `service_categories` (ManyToManyField) → ServiceCategory
- `conversation` (ManyToOneRel) → Conversation
- `quote` (ManyToOneRel) → Quote

---

### MESSAGING 應用

#### Conversation

**說明**: 對話

**字段**:
- `id` (BigAutoField)
- `event` (ForeignKey)
- `supplier` (ForeignKey)
- `created_at` (DateTimeField)
- `updated_at` (DateTimeField)

**關聯**:
- `participants` (ManyToManyField) → User
- `messages` (ManyToOneRel) → Message

---

#### Message

**說明**: 訊息

**字段**:
- `id` (BigAutoField)
- `conversation` (ForeignKey)
- `sender` (ForeignKey)
- `content` (TextField)
- `is_read` (BooleanField)
- `created_at` (DateTimeField)

---

#### Quote

**說明**: 報價

**字段**:
- `id` (BigAutoField)
- `event` (ForeignKey)
- `supplier` (ForeignKey)
- `price` (PositiveIntegerField)
- `description` (TextField)
- `status` (CharField)
- `valid_until` (DateTimeField)
- `created_at` (DateTimeField)
- `updated_at` (DateTimeField)

---

#### Notification

**說明**: 通知

**字段**:
- `id` (BigAutoField)
- `recipient` (ForeignKey)
- `notification_type` (CharField)
- `title` (CharField)
- `message` (TextField)
- `is_read` (BooleanField)
- `related_url` (URLField)
- `created_at` (DateTimeField)

---

### DJ_MANAGEMENT 應用

#### DJCategory

**說明**: DJ類別

**字段**:
- `id` (BigAutoField)
- `name` (CharField)
- `description` (TextField)

**關聯**:
- `dj` (ManyToOneRel) → DJ

---

#### DJ

**說明**: DJ

**字段**:
- `id` (BigAutoField)
- `stage_name` (CharField)
- `real_name` (CharField)
- `user` (OneToOneField)
- `category` (ForeignKey)
- `description` (TextField)
- `experience_level` (CharField)
- `specialties` (TextField): 例如：House, Techno, Hip-Hop等
- `contact_phone` (CharField)
- `contact_email` (EmailField)
- `instagram` (URLField)
- `facebook` (URLField)
- `youtube` (URLField)
- `price_per_hour` (PositiveIntegerField): 新台幣
- `minimum_hours` (PositiveIntegerField)
- `profile_image` (ImageField)
- `demo_audio` (FileField)
- `portfolio_images` (TextField): 多個URL用逗號分隔
- `service_areas` (TextField): 例如：台北市, 新北市
- `status` (CharField)
- `is_featured` (BooleanField)
- `is_available` (BooleanField)
- `total_gigs` (PositiveIntegerField)
- `total_hours` (PositiveIntegerField)
- `created_at` (DateTimeField)
- `updated_at` (DateTimeField)

**關聯**:
- `djrating` (ManyToOneRel) → DJRating
- `djbooking` (ManyToOneRel) → DJBooking
- `djplaylist` (ManyToOneRel) → DJPlaylist

---

#### DJRating

**說明**: DJ評分

**字段**:
- `id` (BigAutoField)
- `dj` (ForeignKey)
- `user` (ForeignKey)
- `rating` (PositiveIntegerField)
- `comment` (TextField)
- `music_quality` (PositiveIntegerField)
- `performance` (PositiveIntegerField)
- `professionalism` (PositiveIntegerField)
- `crowd_interaction` (PositiveIntegerField)
- `created_at` (DateTimeField)

---

#### DJBooking

**說明**: DJ預約

**字段**:
- `id` (BigAutoField)
- `dj` (ForeignKey)
- `client` (ForeignKey)
- `event_title` (CharField)
- `event_date` (DateTimeField)
- `event_location` (CharField)
- `duration_hours` (PositiveIntegerField)
- `total_price` (PositiveIntegerField)
- `special_requirements` (TextField)
- `status` (CharField)
- `created_at` (DateTimeField)
- `updated_at` (DateTimeField)

---

#### DJPlaylist

**說明**: DJ播放清單

**字段**:
- `id` (BigAutoField)
- `dj` (ForeignKey)
- `title` (CharField)
- `description` (TextField)
- `genre` (CharField)
- `duration_minutes` (PositiveIntegerField)
- `audio_file` (FileField)
- `external_url` (URLField): SoundCloud, MixCloud等
- `play_count` (PositiveIntegerField)
- `like_count` (PositiveIntegerField)
- `created_at` (DateTimeField)

---

## 💡 使用示例

### 創建活動需求

```bash
curl -X POST http://localhost:8000/events/create/ \
  -H "Content-Type: application/json" \
  -d '{
    "title": "公司年會",
    "description": "需要場地、餐飲和音響設備",
    "event_date": "2025-12-31",
    "location": "台北市信義區",
    "budget": 100000
  }'
```

### 搜索供應商

```bash
curl "http://localhost:8000/suppliers/?category=餐飲&page=1"
```

### 發送訊息

```bash
curl -X POST http://localhost:8000/messaging/send/ \
  -H "Content-Type: application/json" \
  -d '{
    "recipient_id": 123,
    "message": "您好，我想詢問關於音響設備租賃的問題。"
  }'
```

---

## 📞 技術支援

如有任何問題或建議，請聯繫開發團隊。

**文檔更新時間**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
