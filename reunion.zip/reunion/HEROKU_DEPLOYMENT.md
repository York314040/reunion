# PAPA COLLEGE - B2B聚會派對媒合平台 Heroku 部署指南

## 前置準備

1. **安裝 Heroku CLI**
   - 下載：https://devcenter.heroku.com/articles/heroku-cli
   - 安裝後重啟命令提示字元

2. **安裝 Git**（如果還沒有）
   - 下載：https://git-scm.com/downloads

## 部署步驟

### 第一步：準備 Git 倉庫

```bash
# 進入專案目錄
cd c:\Users\NM6101103\Desktop\reunion

# 初始化 Git（如果還沒有）
git init

# 添加所有文件
git add .

# 提交
git commit -m "Initial commit for Heroku deployment"
```

### 第二步：登入 Heroku

```bash
# 登入 Heroku 帳號
heroku login
```

### 第三步：創建 Heroku 應用

```bash
# 創建新的 Heroku 應用（app-name 請改成您想要的名稱）
heroku create your-app-name

# 或者讓 Heroku 自動生成名稱
heroku create
```

### 第四步：設置環境變量

```bash
# 設置 SECRET_KEY（生產環境用）
heroku config:set SECRET_KEY="your-secret-key-here"

# 設置 DEBUG=False（生產環境）
heroku config:set DEBUG=False

# 添加您的 Heroku 應用域名到 ALLOWED_HOSTS
heroku config:set ALLOWED_HOSTS="your-app-name.herokuapp.com"
```

### 第五步：部署應用

```bash
# 推送到 Heroku
git push heroku main

# 如果您的分支是 master
git push heroku master
```

### 第六步：運行初始設置

```bash
# 運行數據庫遷移
heroku run python manage.py migrate

# 創建超級用戶
heroku run python manage.py createsuperuser

# 收集靜態文件
heroku run python manage.py collectstatic --noinput
```

### 第七步：打開應用

```bash
# 在瀏覽器中打開您的應用
heroku open
```

## 預設帳號

部署完成後，您可以使用以下帳號登入：

- **用戶名**: admin
- **密碼**: admin123456

## 管理命令

```bash
# 查看應用日誌
heroku logs --tail

# 重啟應用
heroku restart

# 進入 Heroku 終端
heroku run bash

# 運行 Django 命令
heroku run python manage.py [command]
```

## 功能說明

部署的網站包含以下功能：

1. **用戶管理系統**
   - 用戶註冊/登入
   - 超級用戶管理介面
   - 用戶權限管理

2. **活動管理**
   - 活動發布
   - 活動瀏覽
   - 活動詳情

3. **供應商系統**
   - 供應商管理
   - 服務展示

4. **DJ管理系統**
   - DJ檔案管理
   - 評分系統
   - 播放清單

5. **訊息系統**
   - 內部訊息
   - 通知功能

## 網站訪問

部署完成後，您的朋友可以通過以下方式訪問：

```
https://your-app-name.herokuapp.com
```

## 故障排除

如果遇到問題：

1. **檢查日誌**：`heroku logs --tail`
2. **重啟應用**：`heroku restart`
3. **檢查環境變量**：`heroku config`
4. **運行遷移**：`heroku run python manage.py migrate`

## 注意事項

1. **免費方案限制**：Heroku 免費方案有使用時間限制
2. **數據庫**：使用 PostgreSQL，數據會定期重置
3. **媒體文件**：上傳的圖片可能會丟失，建議使用雲端儲存
4. **SSL**：Heroku 提供免費 HTTPS

## 更新部署

當您修改代碼後：

```bash
git add .
git commit -m "Update description"
git push heroku main
```

## 初始化應用數據

為了讓朋友們更好地體驗您的網站，我們提供了初始化腳本：

```bash
# 初始化示例數據和演示用戶
heroku run python init_heroku_data.py
```

這個腳本會創建：
- 活動類型（生日派對、婚禮、企業活動等）
- 服務類型（餐飲、裝飾、攝影等）
- DJ 音樂類型
- 演示用戶帳號

## 演示帳號

初始化後可用的帳號：

1. **超級用戶**: `admin` / `admin123456`
2. **管理員**: `manager` / `manager123456`
3. **一般用戶**: `zhang_ming` / `demo123456`
4. **一般用戶**: `li_hua` / `demo123456`
5. **一般用戶**: `wang_mei` / `demo123456`

## 快速設置工具

我們提供了設置助手腳本來簡化過程：

```bash
# 設置本地開發環境
python setup_helper.py local

# 檢查 Heroku 部署要求
python setup_helper.py check

# 顯示 Heroku 部署步驟指南
python setup_helper.py heroku
```

## 分享給朋友

部署成功後，您可以這樣告訴朋友：

**"我做了一個聚會活動平台，來試試看！"**

- **網站**: `https://your-app-name.herokuapp.com`
- **功能**: 活動管理、DJ 評分、供應商系統、用戶管理
- **試用帳號**: `zhang_ming` / `demo123456`

## 更多資源

- [詳細部署檢查清單](DEPLOYMENT_CHECKLIST.md) - 完整的部署指南
- [初始化數據腳本](init_heroku_data.py) - 創建示例數據
- [設置助手](setup_helper.py) - 自動化設置工具

## 技術支持

如果在部署過程中遇到問題：

1. 查看 [DEPLOYMENT_CHECKLIST.md](DEPLOYMENT_CHECKLIST.md) 中的常見問題解決方案
2. 使用 `heroku logs --tail` 查看詳細錯誤信息
3. 確保所有環境變量都已正確設置

**🎉 現在您可以和朋友一起享受這個聚會平台了！**
