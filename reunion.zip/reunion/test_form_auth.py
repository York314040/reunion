#!/usr/bin/env python
"""
檢查實際的活動表單提交流程
"""

import os
import sys
import django

# 設置Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.test import Client, RequestFactory
from django.contrib.auth import get_user_model
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from events.views import create_event
from events.models import EventType

User = get_user_model()

def test_authentication():
    """測試認證要求"""
    print("🔍 測試認證要求...")
    
    client = Client()
    create_url = reverse('events:create_event')
    
    # 1. 測試未登入訪問
    response = client.get(create_url)
    print(f"未登入GET請求: 狀態碼 {response.status_code}")
    
    if response.status_code == 302:
        print(f"✅ 未登入被重定向到: {response.url}")
        if 'login' in response.url:
            print("✅ 正確重定向到登入頁面")
        else:
            print("❌ 重定向目標不是登入頁面")
    elif response.status_code == 200:
        print("⚠️ 未登入可以訪問表單（可能沒有login_required裝飾器）")
    
    # 2. 測試未登入POST請求
    event_data = {
        'title': '測試活動',
        'description': '測試描述',
        'event_type': 1,
        'event_date': '2024-12-31T18:00',
        'location': '台北',
        'expected_attendees': 50,
        'budget_min': 5000,
        'budget_max': 10000,
        'contact_person': '測試人',
        'contact_phone': '0912345678',
        'contact_email': 'test@example.com'
    }
    
    response = client.post(create_url, event_data)
    print(f"未登入POST請求: 狀態碼 {response.status_code}")
    
    if response.status_code == 302:
        print(f"✅ 未登入POST被重定向到: {response.url}")
    elif response.status_code == 200:
        print("⚠️ 未登入可以提交表單")
    
    return create_url

def test_logged_in_access():
    """測試登入後的訪問"""
    print("\n🔍 測試登入後的訪問...")
    
    client = Client()
    create_url = reverse('events:create_event')
    
    # 確保有測試用戶
    try:
        user = User.objects.get(username='testuser_debug')
    except User.DoesNotExist:
        user = User.objects.create_user(
            username='testuser_debug',
            email='test@example.com',
            password='testpass123'
        )
        print(f"✅ 創建測試用戶: {user.username}")
    
    # 登入
    login_success = client.login(username='testuser_debug', password='testpass123')
    if not login_success:
        print("❌ 登入失敗")
        return
    print("✅ 登入成功")
    
    # 測試GET請求
    response = client.get(create_url)
    print(f"登入後GET請求: 狀態碼 {response.status_code}")
    
    if response.status_code == 200:
        print("✅ 可以訪問表單")
        
        # 檢查表單是否包含CSRF token
        content = response.content.decode()
        if 'csrfmiddlewaretoken' in content:
            print("✅ 表單包含CSRF token")
        else:
            print("❌ 表單缺少CSRF token")
            
        # 檢查表單字段
        if 'name="title"' in content:
            print("✅ 表單包含title字段")
        if 'name="event_type"' in content:
            print("✅ 表單包含event_type字段")
            
    else:
        print(f"❌ 無法訪問表單: {response.status_code}")

def test_form_submission_step_by_step():
    """逐步測試表單提交"""
    print("\n🔍 逐步測試表單提交...")
    
    client = Client()
    create_url = reverse('events:create_event')
    
    # 登入
    user = User.objects.get(username='testuser_debug')
    client.force_login(user)
    print("✅ 強制登入成功")
    
    # 先GET表單獲取CSRF token
    get_response = client.get(create_url)
    print(f"GET表單: 狀態碼 {get_response.status_code}")
    
    if get_response.status_code != 200:
        print(f"❌ 無法獲取表單: {get_response.status_code}")
        return
    
    # 獲取EventType
    event_type = EventType.objects.first()
    if not event_type:
        print("❌ 沒有EventType數據")
        return
    
    print(f"✅ 使用EventType: {event_type.name} (ID: {event_type.id})")
    
    # 準備表單數據
    event_data = {
        'title': '實際測試活動需求',
        'description': '這是一個實際的測試活動需求',
        'event_type': event_type.id,
        'event_date': '2024-12-31T18:00',
        'location': '台北市中正區',
        'expected_attendees': 80,
        'budget_min': 15000,
        'budget_max': 30000,
        'contact_person': '張三',
        'contact_phone': '0987654321',
        'contact_email': 'zhang@example.com'
    }
    
    print(f"📝 提交數據: {event_data}")
    
    # POST提交
    post_response = client.post(create_url, event_data)
    print(f"POST提交: 狀態碼 {post_response.status_code}")
    
    if post_response.status_code == 302:
        print(f"✅ 提交成功，重定向到: {post_response.url}")
        
        # 檢查Event是否創建
        from events.models import Event
        events = Event.objects.filter(title='實際測試活動需求')
        if events.exists():
            event = events.first()
            print(f"✅ Event創建成功:")
            print(f"   - 標題: {event.title}")
            print(f"   - 主辦方: {event.organizer.username}")
            print(f"   - 狀態: {event.status}")
        else:
            print("❌ Event未創建")
            
    elif post_response.status_code == 200:
        print("⚠️ 表單返回200，可能有驗證錯誤")
        
        # 嘗試解析錯誤
        content = post_response.content.decode()
        
        # 檢查context中的form錯誤
        if hasattr(post_response, 'context') and post_response.context:
            form = post_response.context.get('form')
            if form and hasattr(form, 'errors') and form.errors:
                print(f"❌ 表單驗證錯誤: {form.errors}")
                for field, errors in form.errors.items():
                    print(f"   - {field}: {errors}")
                    
            if form and hasattr(form, 'non_field_errors') and form.non_field_errors():
                print(f"❌ 非字段錯誤: {form.non_field_errors()}")
        
        # 檢查HTML中的錯誤信息
        if 'alert-danger' in content or 'is-invalid' in content:
            print("❌ HTML中發現錯誤樣式")
            
    else:
        print(f"❌ 意外狀態碼: {post_response.status_code}")
        print(f"響應內容: {post_response.content.decode()[:200]}")

def main():
    """主函數"""
    print("🚀 檢查活動表單認證和提交流程...")
    print("=" * 60)
    
    # 1. 測試認證要求
    create_url = test_authentication()
    
    # 2. 測試登入後訪問
    test_logged_in_access()
    
    # 3. 逐步測試表單提交
    test_form_submission_step_by_step()
    
    print("\n" + "=" * 60)
    print("🏁 檢查完成")
    
    print("\n💡 解決方案建議:")
    print("1. 確保用戶已登入再訪問表單")
    print("2. 檢查所有必需字段是否正確填寫")
    print("3. 確認event_type字段使用有效的EventType ID")
    print("4. 檢查日期時間格式是否正確")

if __name__ == '__main__':
    main()
