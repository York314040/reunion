#!/usr/bin/env python
"""
工具集管理系統 - OOP架構
整合所有實用工具和輔助功能
"""

import os
import sys
import json
import csv
import shutil
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Union
from pathlib import Path
from datetime import datetime, timedelta

# 設定 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')

import django
django.setup()

from django.core.management import call_command
from django.core.mail import send_mail
from django.contrib.auth.models import User
from django.utils import timezone
from django.db import transaction
from django.conf import settings

from data_manager_oop import DataService
from project_manager_oop import TestManager, DeploymentManager, AnalysisManager


class BaseTool(ABC):
    """基礎工具類別"""
    
    def __init__(self, name: str):
        self.name = name
        self.logs = []
    
    def log(self, message: str, level: str = "INFO"):
        """記錄日誌"""
        icons = {"INFO": "ℹ️", "SUCCESS": "✅", "ERROR": "❌", "WARNING": "⚠️"}
        formatted_message = f"{icons.get(level, 'ℹ️')} {message}"
        print(formatted_message)
        
        self.logs.append({
            'timestamp': datetime.now().isoformat(),
            'level': level,
            'message': message
        })
    
    @abstractmethod
    def execute(self, **kwargs) -> Dict[str, Any]:
        """執行工具功能"""
        pass
    
    def get_logs(self) -> List[Dict[str, Any]]:
        """獲取執行日誌"""
        return self.logs
    
    def clear_logs(self):
        """清理日誌"""
        self.logs.clear()


class DatabaseTool(BaseTool):
    """數據庫工具"""
    
    def __init__(self):
        super().__init__("數據庫工具")
        self.data_service = DataService()
    
    def backup_database(self, backup_path: str = None) -> Dict[str, Any]:
        """備份數據庫"""
        if not backup_path:
            backup_path = f"db_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        try:
            self.log("開始備份數據庫...")
            
            # 調用Django的dumpdata命令
            with open(backup_path, 'w', encoding='utf-8') as f:
                call_command('dumpdata', stdout=f, indent=2)
            
            file_size = os.path.getsize(backup_path)
            self.log(f"數據庫備份完成: {backup_path} ({file_size} bytes)", "SUCCESS")
            
            return {
                'success': True,
                'backup_file': backup_path,
                'size': file_size
            }
            
        except Exception as e:
            self.log(f"備份失敗: {str(e)}", "ERROR")
            return {'success': False, 'error': str(e)}
    
    def restore_database(self, backup_path: str) -> Dict[str, Any]:
        """恢復數據庫"""
        try:
            if not os.path.exists(backup_path):
                raise FileNotFoundError(f"備份文件不存在: {backup_path}")
            
            self.log("開始恢復數據庫...")
            
            # 先清空數據庫
            call_command('flush', '--noinput')
            
            # 恢復數據
            call_command('loaddata', backup_path)
            
            self.log("數據庫恢復完成", "SUCCESS")
            
            return {'success': True}
            
        except Exception as e:
            self.log(f"恢復失敗: {str(e)}", "ERROR")
            return {'success': False, 'error': str(e)}
    
    def optimize_database(self) -> Dict[str, Any]:
        """優化數據庫"""
        try:
            self.log("開始數據庫優化...")
            
            # 清理孤立數據
            cleanup_results = self.data_service.cleanup_orphaned_data()
            
            # 運行數據庫優化命令
            from django.db import connection
            cursor = connection.cursor()
            
            # SQLite優化命令
            if 'sqlite' in settings.DATABASES['default']['ENGINE']:
                cursor.execute("VACUUM;")
                cursor.execute("ANALYZE;")
                self.log("SQLite數據庫優化完成", "SUCCESS")
            
            return {
                'success': True,
                'cleanup_results': cleanup_results
            }
            
        except Exception as e:
            self.log(f"優化失敗: {str(e)}", "ERROR")
            return {'success': False, 'error': str(e)}
    
    def get_database_info(self) -> Dict[str, Any]:
        """獲取數據庫信息"""
        try:
            from django.db import connection
            
            db_config = settings.DATABASES['default']
            stats = self.data_service.get_system_stats()
            
            # 計算數據庫大小（SQLite）
            db_size = 0
            if 'sqlite' in db_config['ENGINE'] and os.path.exists(db_config['NAME']):
                db_size = os.path.getsize(db_config['NAME'])
            
            return {
                'engine': db_config['ENGINE'],
                'name': db_config['NAME'],
                'size': db_size,
                'tables_stats': stats
            }
            
        except Exception as e:
            self.log(f"獲取數據庫信息失敗: {str(e)}", "ERROR")
            return {'error': str(e)}
    
    def execute(self, action: str = "info", **kwargs) -> Dict[str, Any]:
        """執行數據庫操作"""
        actions = {
            'backup': self.backup_database,
            'restore': self.restore_database,
            'optimize': self.optimize_database,
            'info': self.get_database_info
        }
        
        if action not in actions:
            return {'error': f"未知操作: {action}"}
        
        return actions[action](**kwargs)


class FileManagerTool(BaseTool):
    """文件管理工具"""
    
    def __init__(self):
        super().__init__("文件管理工具")
    
    def clean_project_files(self) -> Dict[str, Any]:
        """清理專案文件"""
        try:
            self.log("開始清理專案文件...")
            
            # 要清理的文件模式
            cleanup_patterns = [
                '*.pyc',
                '__pycache__',
                '.pytest_cache',
                '*.log',
                'temp_*.py',
                '*_backup_*.py',
                'test_*.json'
            ]
            
            removed_files = []
            removed_dirs = []
            
            for pattern in cleanup_patterns:
                if pattern.startswith('*') and pattern.endswith('.pyc'):
                    # 清理.pyc文件
                    for pyc_file in Path('.').rglob('*.pyc'):
                        pyc_file.unlink()
                        removed_files.append(str(pyc_file))
                
                elif pattern == '__pycache__':
                    # 清理__pycache__目錄
                    for cache_dir in Path('.').rglob('__pycache__'):
                        shutil.rmtree(cache_dir)
                        removed_dirs.append(str(cache_dir))
                
                elif pattern.startswith('temp_') or pattern.startswith('*_backup_'):
                    # 清理臨時文件和備份文件
                    for temp_file in Path('.').glob(pattern):
                        if temp_file.is_file():
                            temp_file.unlink()
                            removed_files.append(str(temp_file))
            
            self.log(f"清理完成: {len(removed_files)} 個文件, {len(removed_dirs)} 個目錄", "SUCCESS")
            
            return {
                'success': True,
                'removed_files': removed_files,
                'removed_dirs': removed_dirs
            }
            
        except Exception as e:
            self.log(f"清理失敗: {str(e)}", "ERROR")
            return {'success': False, 'error': str(e)}
    
    def organize_scripts(self) -> Dict[str, Any]:
        """整理腳本文件"""
        try:
            self.log("開始整理腳本文件...")
            
            # 創建腳本目錄
            scripts_dir = Path('scripts')
            scripts_dir.mkdir(exist_ok=True)
            
            # 子目錄
            subdirs = ['tests', 'analysis', 'deployment', 'utils']
            for subdir in subdirs:
                (scripts_dir / subdir).mkdir(exist_ok=True)
            
            moved_files = []
            
            # 移動測試腳本
            for test_file in Path('.').glob('*test*.py'):
                if test_file.name not in ['manage.py', 'project_manager_oop.py', 'data_manager_oop.py']:
                    new_path = scripts_dir / 'tests' / test_file.name
                    shutil.move(str(test_file), str(new_path))
                    moved_files.append(f"{test_file.name} -> scripts/tests/")
            
            # 移動分析腳本
            analysis_patterns = ['*analysis*.py', '*audit*.py', '*report*.py']
            for pattern in analysis_patterns:
                for file in Path('.').glob(pattern):
                    if file.name not in ['project_manager_oop.py', 'data_manager_oop.py']:
                        new_path = scripts_dir / 'analysis' / file.name
                        shutil.move(str(file), str(new_path))
                        moved_files.append(f"{file.name} -> scripts/analysis/")
            
            # 移動部署腳本
            deploy_patterns = ['*deploy*.py', '*setup*.py', '*config*.py']
            for pattern in deploy_patterns:
                for file in Path('.').glob(pattern):
                    if file.name not in ['project_manager_oop.py', 'data_manager_oop.py', 'manage.py']:
                        new_path = scripts_dir / 'deployment' / file.name
                        shutil.move(str(file), str(new_path))
                        moved_files.append(f"{file.name} -> scripts/deployment/")
            
            # 移動其他工具腳本
            util_patterns = ['*helper*.py', '*manager*.py', '*util*.py']
            for pattern in util_patterns:
                for file in Path('.').glob(pattern):
                    if file.name not in ['project_manager_oop.py', 'data_manager_oop.py', 'user_manager.py']:
                        new_path = scripts_dir / 'utils' / file.name
                        shutil.move(str(file), str(new_path))
                        moved_files.append(f"{file.name} -> scripts/utils/")
            
            self.log(f"腳本整理完成: 移動了 {len(moved_files)} 個文件", "SUCCESS")
            
            return {
                'success': True,
                'moved_files': moved_files
            }
            
        except Exception as e:
            self.log(f"整理失敗: {str(e)}", "ERROR")
            return {'success': False, 'error': str(e)}
    
    def create_project_structure_doc(self) -> Dict[str, Any]:
        """創建專案結構文檔"""
        try:
            self.log("生成專案結構文檔...")
            
            def get_directory_tree(path: Path, prefix: str = "", max_depth: int = 3, current_depth: int = 0) -> str:
                if current_depth > max_depth:
                    return ""
                
                items = []
                if path.is_dir():
                    try:
                        children = sorted(path.iterdir(), key=lambda x: (x.is_file(), x.name.lower()))
                        for i, child in enumerate(children):
                            if child.name.startswith('.'):
                                continue
                            
                            is_last = i == len(children) - 1
                            current_prefix = "└── " if is_last else "├── "
                            items.append(f"{prefix}{current_prefix}{child.name}")
                            
                            if child.is_dir() and current_depth < max_depth:
                                next_prefix = prefix + ("    " if is_last else "│   ")
                                items.append(get_directory_tree(child, next_prefix, max_depth, current_depth + 1))
                    except PermissionError:
                        pass
                
                return "\n".join(filter(None, items))
            
            structure = f"""# 派對平台專案結構

## 📁 專案目錄結構
```
{get_directory_tree(Path('.'))}
```

## 🎯 核心模組說明

### 主要應用
- **events/**: 活動管理模組
- **suppliers/**: 供應商管理模組
- **dj_management/**: DJ管理模組
- **messaging/**: 訊息系統模組
- **dashboards/**: 儀表板模組

### OOP管理系統
- **project_manager_oop.py**: 專案主管理器
  - TestManager: 測試管理
  - DeploymentManager: 部署管理
  - AnalysisManager: 分析管理

- **data_manager_oop.py**: 數據管理系統
  - UserManager: 用戶管理
  - EventManager: 活動管理
  - SupplierManager: 供應商管理
  - DJManager: DJ管理
  - MessageManager: 訊息管理

- **toolkit_manager_oop.py**: 工具集管理
  - DatabaseTool: 數據庫工具
  - FileManagerTool: 文件管理
  - NotificationTool: 通知工具
  - ReportTool: 報告工具

### 腳本目錄 (scripts/)
- **tests/**: 測試腳本
- **analysis/**: 分析腳本
- **deployment/**: 部署腳本
- **utils/**: 工具腳本

## 🚀 使用方式

### 運行完整測試
```bash
python project_manager_oop.py --manager all
```

### 運行特定管理器
```bash
python project_manager_oop.py --manager test
python project_manager_oop.py --manager deployment
python project_manager_oop.py --manager analysis
```

### 數據管理
```python
from data_manager_oop import DataService

# 創建數據服務
data_service = DataService()

# 獲取用戶管理器
user_mgr = data_service.get_manager('user')

# 創建用戶
user = user_mgr.create_user('username', 'email@test.com', 'password')
```

### 工具集使用
```python
from toolkit_manager_oop import ToolkitManager

# 創建工具管理器
toolkit = ToolkitManager()

# 數據庫備份
toolkit.execute_tool('database', 'backup')

# 清理項目文件
toolkit.execute_tool('file_manager', 'clean')
```

---
*生成時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*
*OOP專案管理系統*
"""
            
            with open('PROJECT_STRUCTURE.md', 'w', encoding='utf-8') as f:
                f.write(structure)
            
            self.log("專案結構文檔生成完成: PROJECT_STRUCTURE.md", "SUCCESS")
            
            return {'success': True, 'file': 'PROJECT_STRUCTURE.md'}
            
        except Exception as e:
            self.log(f"生成文檔失敗: {str(e)}", "ERROR")
            return {'success': False, 'error': str(e)}
    
    def execute(self, action: str = "clean", **kwargs) -> Dict[str, Any]:
        """執行文件管理操作"""
        actions = {
            'clean': self.clean_project_files,
            'organize': self.organize_scripts,
            'structure_doc': self.create_project_structure_doc
        }
        
        if action not in actions:
            return {'error': f"未知操作: {action}"}
        
        return actions[action](**kwargs)


class NotificationTool(BaseTool):
    """通知工具"""
    
    def __init__(self):
        super().__init__("通知工具")
    
    def send_email_notification(self, subject: str, message: str, 
                              recipient_list: List[str]) -> Dict[str, Any]:
        """發送郵件通知"""
        try:
            send_mail(
                subject=subject,
                message=message,
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=recipient_list,
                fail_silently=False
            )
            
            self.log(f"郵件發送成功: {len(recipient_list)} 位收件人", "SUCCESS")
            
            return {
                'success': True,
                'recipients': len(recipient_list)
            }
            
        except Exception as e:
            self.log(f"郵件發送失敗: {str(e)}", "ERROR")
            return {'success': False, 'error': str(e)}
    
    def send_system_alert(self, alert_type: str, message: str) -> Dict[str, Any]:
        """發送系統警報"""
        try:
            # 獲取管理員用戶
            admin_users = User.objects.filter(is_superuser=True)
            admin_emails = [user.email for user in admin_users if user.email]
            
            if admin_emails:
                subject = f"[系統警報] {alert_type}"
                full_message = f"""
系統警報通知

警報類型: {alert_type}
時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
訊息: {message}

請檢查系統狀態。
                """
                
                return self.send_email_notification(subject, full_message, admin_emails)
            else:
                self.log("沒有找到管理員郵箱", "WARNING")
                return {'success': False, 'error': '沒有管理員郵箱'}
                
        except Exception as e:
            self.log(f"發送系統警報失敗: {str(e)}", "ERROR")
            return {'success': False, 'error': str(e)}
    
    def execute(self, action: str = "alert", **kwargs) -> Dict[str, Any]:
        """執行通知操作"""
        actions = {
            'email': self.send_email_notification,
            'alert': self.send_system_alert
        }
        
        if action not in actions:
            return {'error': f"未知操作: {action}"}
        
        return actions[action](**kwargs)


class ReportTool(BaseTool):
    """報告工具"""
    
    def __init__(self):
        super().__init__("報告工具")
        self.data_service = DataService()
    
    def generate_system_health_report(self) -> Dict[str, Any]:
        """生成系統健康報告"""
        try:
            self.log("生成系統健康報告...")
            
            # 獲取統計數據
            stats = self.data_service.get_system_stats()
            
            # 運行基本測試
            test_manager = TestManager()
            test_results = test_manager.execute()
            
            # 生成報告
            report = f"""# 系統健康報告

## 📊 系統統計
"""
            
            for category, data in stats.items():
                report += f"\n### {category.upper()}\n"
                if isinstance(data, dict) and 'error' not in data:
                    for key, value in data.items():
                        report += f"- {key}: {value}\n"
                else:
                    report += f"- 錯誤: {data.get('error', '未知錯誤')}\n"
            
            report += f"""
## 🧪 系統測試結果
- 測試狀態: {'✅ 通過' if test_results else '❌ 失敗'}
- 測試時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 📈 健康評分
"""
            
            # 計算健康評分
            health_score = self._calculate_health_score(stats, test_results)
            report += f"- 整體健康評分: {health_score}/100\n"
            
            if health_score >= 90:
                report += "- 評級: 🌟 優秀\n"
            elif health_score >= 70:
                report += "- 評級: ✅ 良好\n"
            elif health_score >= 50:
                report += "- 評級: ⚠️ 一般\n"
            else:
                report += "- 評級: ❌ 需要改善\n"
            
            report += f"""
---
*生成時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*
"""
            
            # 保存報告
            report_file = f"system_health_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
            with open(report_file, 'w', encoding='utf-8') as f:
                f.write(report)
            
            self.log(f"系統健康報告生成完成: {report_file}", "SUCCESS")
            
            return {
                'success': True,
                'report_file': report_file,
                'health_score': health_score
            }
            
        except Exception as e:
            self.log(f"生成報告失敗: {str(e)}", "ERROR")
            return {'success': False, 'error': str(e)}
    
    def _calculate_health_score(self, stats: Dict[str, Any], test_results: bool) -> int:
        """計算系統健康評分"""
        score = 0
        
        # 測試結果 (40分)
        if test_results:
            score += 40
        
        # 數據完整性 (30分)
        try:
            user_stats = stats.get('user', {})
            if user_stats.get('total_users', 0) > 0:
                score += 10
            if user_stats.get('active_users', 0) > 0:
                score += 10
            if user_stats.get('staff_users', 0) > 0:
                score += 10
        except:
            pass
        
        # 功能模組 (30分)
        modules = ['event', 'supplier', 'dj', 'message']
        for module in modules:
            if module in stats and 'error' not in stats[module]:
                score += 7.5
        
        return min(100, int(score))
    
    def export_data_to_csv(self, model_type: str) -> Dict[str, Any]:
        """導出數據到CSV"""
        try:
            self.log(f"導出{model_type}數據到CSV...")
            
            manager = self.data_service.get_manager(model_type)
            if not manager:
                raise ValueError(f"未知的模型類型: {model_type}")
            
            data = manager.get_all()
            
            if not data:
                self.log(f"沒有{model_type}數據可導出", "WARNING")
                return {'success': False, 'error': '沒有數據'}
            
            # 生成CSV文件
            csv_file = f"{model_type}_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            
            with open(csv_file, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                
                # 寫入標題
                if data:
                    first_obj = data[0]
                    headers = [field.name for field in first_obj._meta.fields]
                    writer.writerow(headers)
                    
                    # 寫入數據
                    for obj in data:
                        row = []
                        for field in obj._meta.fields:
                            value = getattr(obj, field.name)
                            if value is None:
                                value = ''
                            row.append(str(value))
                        writer.writerow(row)
            
            self.log(f"數據導出完成: {csv_file} ({len(data)} 條記錄)", "SUCCESS")
            
            return {
                'success': True,
                'csv_file': csv_file,
                'records_count': len(data)
            }
            
        except Exception as e:
            self.log(f"導出失敗: {str(e)}", "ERROR")
            return {'success': False, 'error': str(e)}
    
    def execute(self, action: str = "health", **kwargs) -> Dict[str, Any]:
        """執行報告操作"""
        actions = {
            'health': self.generate_system_health_report,
            'export_csv': self.export_data_to_csv
        }
        
        if action not in actions:
            return {'error': f"未知操作: {action}"}
        
        return actions[action](**kwargs)


class ToolkitManager:
    """工具集主管理器"""
    
    def __init__(self):
        self.tools = {
            'database': DatabaseTool(),
            'file_manager': FileManagerTool(),
            'notification': NotificationTool(),
            'report': ReportTool()
        }
    
    def list_tools(self) -> Dict[str, str]:
        """列出所有可用工具"""
        return {name: tool.name for name, tool in self.tools.items()}
    
    def execute_tool(self, tool_name: str, action: str, **kwargs) -> Dict[str, Any]:
        """執行指定工具"""
        if tool_name not in self.tools:
            return {'error': f"未知工具: {tool_name}"}
        
        tool = self.tools[tool_name]
        
        print(f"🔧 執行工具: {tool.name} - {action}")
        print("-" * 50)
        
        result = tool.execute(action, **kwargs)
        
        print("\n📋 執行日誌:")
        for log in tool.get_logs():
            print(f"[{log['timestamp']}] {log['level']}: {log['message']}")
        
        return result
    
    def run_full_maintenance(self) -> Dict[str, Any]:
        """運行完整維護"""
        print("🎯" + "="*60 + "🎯")
        print("                    完整系統維護")
        print("🎯" + "="*60 + "🎯")
        
        maintenance_results = {}
        
        # 1. 數據庫優化
        print("\n🗄️ 執行數據庫優化...")
        maintenance_results['database'] = self.execute_tool('database', 'optimize')
        
        # 2. 文件清理
        print("\n🧹 執行文件清理...")
        maintenance_results['file_clean'] = self.execute_tool('file_manager', 'clean')
        
        # 3. 腳本整理
        print("\n📁 執行腳本整理...")
        maintenance_results['file_organize'] = self.execute_tool('file_manager', 'organize')
        
        # 4. 生成健康報告
        print("\n📊 生成系統健康報告...")
        maintenance_results['health_report'] = self.execute_tool('report', 'health')
        
        # 5. 創建結構文檔
        print("\n📄 創建專案結構文檔...")
        maintenance_results['structure_doc'] = self.execute_tool('file_manager', 'structure_doc')
        
        print(f"\n🎉 完整維護完成!")
        
        return maintenance_results


def main():
    """主函數"""
    import argparse
    
    parser = argparse.ArgumentParser(description='工具集管理系統')
    parser.add_argument('--tool', '-t', 
                       choices=['database', 'file_manager', 'notification', 'report', 'maintenance'], 
                       default='maintenance',
                       help='指定要使用的工具')
    parser.add_argument('--action', '-a', default='',
                       help='指定要執行的操作')
    
    args = parser.parse_args()
    
    toolkit = ToolkitManager()
    
    if args.tool == 'maintenance':
        toolkit.run_full_maintenance()
    else:
        if not args.action:
            print(f"❌ 請指定操作 (--action)")
            return
        
        result = toolkit.execute_tool(args.tool, args.action)
        print(f"\n📋 執行結果: {result}")


if __name__ == "__main__":
    main()
