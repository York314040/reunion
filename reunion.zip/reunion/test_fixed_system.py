#!/usr/bin/env python
"""
修復後的系統測試 - 驗證Bug修復效果
"""

import os
import sys
import django
from datetime import datetime

# 設置Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.test import Client
from django.contrib.auth.models import User
from django.urls import reverse
from events.models import Event, EventType
from dj_management.models import DJ
from suppliers.models import Supplier
from messaging.models import Quote
from users.models import Profile

def test_fixed_system():
    """測試修復後的系統"""
    print("🚀 測試修復後的系統...")
    print("=" * 60)
    
    client = Client()
    
    # 1. 測試用戶註冊功能
    print("\n👤 測試用戶註冊功能:")
    try:
        # 創建一般用戶
        user = User.objects.create_user(
            username=f'test_user_{int(datetime.now().timestamp())}',
            email='test@example.com',
            password='testpass123'
        )
        profile = Profile.objects.get(user=user)
        print(f"✅ 用戶創建成功，Profile自動創建: {profile.user_type}")
        
        # 測試登入
        login_success = client.login(username=user.username, password='testpass123')
        print(f"✅ 登入成功: {login_success}")
        
    except Exception as e:
        print(f"❌ 用戶功能測試失敗: {e}")
    
    # 2. 測試DJ功能
    print("\n🎵 測試DJ功能:")
    try:
        dj_user = User.objects.create_user(
            username=f'test_dj_{int(datetime.now().timestamp())}',
            email='dj@test.com',
            password='testpass123'
        )
        
        # 設置用戶類型為DJ
        profile = Profile.objects.get(user=dj_user)
        profile.user_type = 'dj'
        profile.save()
        
        # 創建DJ資料
        dj = DJ.objects.create(
            user=dj_user,
            stage_name='測試DJ',
            experience_years=5,
            music_styles='Electronic, Pop',
            hourly_rate=3000,
            bio='專業DJ介紹'
        )
        print(f"✅ DJ資料創建成功: {dj.stage_name}")
        
        # 測試DJ頁面訪問
        client.login(username=dj_user.username, password='testpass123')
        response = client.get('/dj/')  # 使用實際URL路徑
        print(f"✅ DJ頁面訪問成功，狀態碼: {response.status_code}")
        
    except Exception as e:
        print(f"❌ DJ功能測試失敗: {e}")
    
    # 3. 測試供應商功能
    print("\n🏢 測試供應商功能:")
    try:
        supplier_user = User.objects.create_user(
            username=f'test_supplier_{int(datetime.now().timestamp())}',
            email='supplier@test.com',
            password='testpass123'
        )
        
        # 設置用戶類型為供應商
        profile = Profile.objects.get(user=supplier_user)
        profile.user_type = 'supplier'
        profile.save()
        
        # 創建供應商資料
        supplier = Supplier.objects.create(
            user=supplier_user,
            company_name='測試供應商公司',
            service_type='catering',
            description='專業餐飲服務',
            contact_phone='0987654321',
            address='台北市中正區'
        )
        print(f"✅ 供應商資料創建成功: {supplier.company_name}")
        
        # 測試供應商頁面訪問
        client.login(username=supplier_user.username, password='testpass123')
        response = client.get('/suppliers/')
        print(f"✅ 供應商頁面訪問成功，狀態碼: {response.status_code}")
        
    except Exception as e:
        print(f"❌ 供應商功能測試失敗: {e}")
    
    # 4. 測試活動創建和表單驗證
    print("\n📅 測試活動功能:")
    try:
        # 使用一般用戶登入
        client.login(username=user.username, password='testpass123')
        
        # 測試有效的活動數據
        event_type = EventType.objects.first()
        valid_event_data = {
            'title': '測試活動需求',
            'description': '這是一個測試活動需求的詳細描述',
            'event_type': event_type.id,
            'budget_min': 10000,
            'budget_max': 50000,
            'expected_attendees': 100,
            'event_date': '2024-12-31T18:00',
            'location': '台北市信義區',
            'contact_person': '測試聯絡人',
            'contact_phone': '0912345678',
            'contact_email': 'test@example.com'
        }
        
        response = client.post(reverse('events:create_event'), valid_event_data)
        if response.status_code == 302:
            print("✅ 有效活動數據創建成功")
        else:
            print(f"❌ 活動創建失敗，狀態碼: {response.status_code}")
        
        # 測試無效的活動數據 (表單驗證)
        invalid_event_data = {
            'title': '',  # 空標題
            'description': '',
            'event_type': event_type.id,
            'budget_min': 50000,  # 最小值大於最大值
            'budget_max': 10000,
            'expected_attendees': 0,  # 無效人數
            'event_date': '2024-12-31T18:00',
            'location': '',  # 空地點
            'contact_person': '',
            'contact_phone': '123',  # 無效電話
            'contact_email': 'invalid-email'  # 無效郵箱
        }
        
        response = client.post(reverse('events:create_event'), invalid_event_data)
        if response.status_code == 200:  # 返回表單頁面，說明驗證生效
            print("✅ 表單驗證正常工作，無效數據被拒絕")
        else:
            print(f"❌ 表單驗證可能有問題，狀態碼: {response.status_code}")
            
    except Exception as e:
        print(f"❌ 活動功能測試失敗: {e}")
    
    # 5. 測試報價功能
    print("\n💰 測試報價功能:")
    try:
        # 創建一個活動供報價
        event = Event.objects.create(
            organizer=user,
            title='測試報價活動',
            description='測試報價描述',
            event_type=event_type,
            budget_min=10000,
            budget_max=50000,
            expected_attendees=100,
            event_date='2024-12-31 18:00:00+00:00',
            location='台北市',
            contact_person='測試',
            contact_phone='0912345678',
            contact_email='test@test.com'
        )
        
        # 供應商登入並創建報價
        client.login(username=supplier_user.username, password='testpass123')
        
        quote_data = {
            'price': 25000,
            'description': '專業餐飲服務報價',
            'valid_until': '2024-12-30'
        }
        
        response = client.post(f'/messaging/quotes/create/{event.id}/', quote_data)
        if response.status_code in [200, 302]:
            print("✅ 報價功能正常工作")
        else:
            print(f"❌ 報價創建失敗，狀態碼: {response.status_code}")
            
    except Exception as e:
        print(f"❌ 報價功能測試失敗: {e}")
    
    # 6. 測試權限控制
    print("\n🔒 測試權限控制:")
    try:
        # 登出用戶
        client.logout()
        
        # 測試未登入用戶訪問受保護頁面
        protected_urls = [
            '/events/create/',
            '/messaging/',
        ]
        
        for url in protected_urls:
            response = client.get(url)
            if response.status_code == 302:  # 重定向到登入頁面
                print(f"✅ {url} 正確保護")
            else:
                print(f"❌ {url} 權限漏洞")
                
    except Exception as e:
        print(f"❌ 權限測試失敗: {e}")
    
    print("\n" + "=" * 60)
    print("🎉 系統測試完成！")
    print("=" * 60)

if __name__ == '__main__':
    test_fixed_system()
