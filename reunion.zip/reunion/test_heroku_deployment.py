#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Heroku 部署驗證腳本 - 測試網站是否正常運行
"""

import urllib.request
import urllib.error
import time

def test_heroku_app():
    """測試 Heroku 應用是否正常運行"""
    app_url = "https://papa-college-b2b-ee7db6fb42bd.herokuapp.com/"
    
    print("🔍 測試 PAPA COLLEGE B2B 平台...")
    print(f"📍 網址: {app_url}")
    print("⏳ 正在測試連接...")
    
    try:
        # 設置請求頭，模擬瀏覽器
        req = urllib.request.Request(
            app_url,
            headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
        )
        
        # 發送請求
        with urllib.request.urlopen(req, timeout=30) as response:
            status_code = response.getcode()
            content = response.read().decode('utf-8')
            
            print(f"✅ 連接成功！")
            print(f"📊 HTTP 狀態碼: {status_code}")
            
            if status_code == 200:
                print("🎉 網站正常運行！")
                
                # 檢查關鍵內容
                if "PAPA COLLEGE" in content:
                    print("✅ 找到網站標題")
                if "派對" in content or "party" in content.lower():
                    print("✅ 找到派對相關內容")
                if "B2B" in content:
                    print("✅ 找到B2B相關內容")
                
                print("\n🌐 您的朋友現在可以通過以下網址訪問：")
                print(f"   {app_url}")
                print("\n📱 功能包括：")
                print("   ✅ 供應商管理")
                print("   ✅ 活動發布")
                print("   ✅ DJ 管理")
                print("   ✅ 用戶註冊")
                print("   ✅ 響應式設計（手機友好）")
                
                return True
            else:
                print(f"⚠️ 網站回應異常，狀態碼: {status_code}")
                return False
                
    except urllib.error.HTTPError as e:
        print(f"❌ HTTP 錯誤: {e.code} - {e.reason}")
        if e.code == 400:
            print("💡 這可能是 ALLOWED_HOSTS 配置問題")
            print("💡 或者應用需要更多時間啟動")
        return False
        
    except urllib.error.URLError as e:
        print(f"❌ 連接錯誤: {e.reason}")
        return False
        
    except Exception as e:
        print(f"❌ 未知錯誤: {str(e)}")
        return False

def main():
    """主函數"""
    print("="*60)
    print("🎯 PAPA COLLEGE - Heroku 部署驗證")
    print("="*60)
    
    # 等待應用完全啟動
    print("⏳ 等待應用完全啟動...")
    time.sleep(10)
    
    success = test_heroku_app()
    
    if success:
        print("\n🎊 恭喜！您的 PAPA COLLEGE 平台已成功部署並運行！")
        print("👥 您可以將網址分享給朋友使用了！")
    else:
        print("\n⚠️ 部署可能有問題，建議檢查 Heroku 日誌：")
        print("   heroku logs --tail --app papa-college-b2b")

if __name__ == "__main__":
    main()
