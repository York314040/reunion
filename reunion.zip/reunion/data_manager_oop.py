#!/usr/bin/env python
"""
數據管理系統 - OOP架構
統一管理所有模型操作和數據處理
"""

import os
import sys
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Type
from datetime import datetime, timedelta

# 設定 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')

import django
django.setup()

from django.db import transaction, models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.utils import timezone
from events.models import Event, EventType
from suppliers.models import Supplier, ServiceCategory
from messaging.models import Conversation, Message
from dj_management.models import DJ, DJCategory


class BaseDataManager(ABC):
    """基礎數據管理器"""
    
    def __init__(self, model_class: Type[models.Model]):
        self.model_class = model_class
        self.model_name = model_class.__name__
    
    def create(self, **kwargs) -> models.Model:
        """創建新對象"""
        try:
            with transaction.atomic():
                instance = self.model_class.objects.create(**kwargs)
                print(f"✅ 創建{self.model_name}: {instance}")
                return instance
        except Exception as e:
            print(f"❌ 創建{self.model_name}失敗: {str(e)}")
            raise
    
    def get_by_id(self, obj_id: int) -> Optional[models.Model]:
        """根據ID獲取對象"""
        try:
            return self.model_class.objects.get(id=obj_id)
        except self.model_class.DoesNotExist:
            print(f"⚠️ {self.model_name} ID {obj_id} 不存在")
            return None
    
    def get_all(self) -> List[models.Model]:
        """獲取所有對象"""
        return self.model_class.objects.all()
    
    def update(self, obj_id: int, **kwargs) -> Optional[models.Model]:
        """更新對象"""
        try:
            with transaction.atomic():
                instance = self.get_by_id(obj_id)
                if instance:
                    for key, value in kwargs.items():
                        setattr(instance, key, value)
                    instance.save()
                    print(f"✅ 更新{self.model_name}: {instance}")
                    return instance
                return None
        except Exception as e:
            print(f"❌ 更新{self.model_name}失敗: {str(e)}")
            raise
    
    def delete(self, obj_id: int) -> bool:
        """刪除對象"""
        try:
            with transaction.atomic():
                instance = self.get_by_id(obj_id)
                if instance:
                    instance.delete()
                    print(f"✅ 刪除{self.model_name} ID {obj_id}")
                    return True
                return False
        except Exception as e:
            print(f"❌ 刪除{self.model_name}失敗: {str(e)}")
            return False
    
    def count(self) -> int:
        """計算對象數量"""
        return self.model_class.objects.count()
    
    def exists(self, **kwargs) -> bool:
        """檢查對象是否存在"""
        return self.model_class.objects.filter(**kwargs).exists()
    
    @abstractmethod
    def get_stats(self) -> Dict[str, Any]:
        """獲取統計信息"""
        pass


class UserManager(BaseDataManager):
    """用戶管理器"""
    
    def __init__(self):
        super().__init__(User)
    
    def create_user(self, username: str, email: str, password: str, **kwargs) -> User:
        """創建普通用戶"""
        return self.create(
            username=username,
            email=email,
            password=password,
            **kwargs
        )
    
    def create_staff_user(self, username: str, email: str, password: str) -> User:
        """創建員工用戶"""
        return self.create(
            username=username,
            email=email,
            password=password,
            is_staff=True
        )
    
    def create_superuser(self, username: str, email: str, password: str) -> User:
        """創建超級用戶"""
        return User.objects.create_superuser(
            username=username,
            email=email,
            password=password
        )
    
    def get_by_username(self, username: str) -> Optional[User]:
        """根據用戶名獲取用戶"""
        try:
            return User.objects.get(username=username)
        except User.DoesNotExist:
            return None
    
    def get_by_email(self, email: str) -> Optional[User]:
        """根據郵箱獲取用戶"""
        try:
            return User.objects.get(email=email)
        except User.DoesNotExist:
            return None
    
    def get_active_users(self) -> List[User]:
        """獲取活躍用戶"""
        return User.objects.filter(is_active=True)
    
    def get_staff_users(self) -> List[User]:
        """獲取員工用戶"""
        return User.objects.filter(is_staff=True)
    
    def get_stats(self) -> Dict[str, Any]:
        """獲取用戶統計"""
        return {
            'total_users': self.count(),
            'active_users': User.objects.filter(is_active=True).count(),
            'staff_users': User.objects.filter(is_staff=True).count(),
            'superusers': User.objects.filter(is_superuser=True).count(),
            'recent_users': User.objects.filter(
                date_joined__gte=timezone.now() - timedelta(days=30)
            ).count()
        }


class EventManager(BaseDataManager):
    """活動管理器"""
    
    def __init__(self):
        super().__init__(Event)
    
    def create_event(self, title: str, description: str, organizer: User, 
                    event_type: EventType, event_date: datetime, location: str,
                    expected_attendees: int = 100, **kwargs) -> Event:
        """創建活動"""
        return self.create(
            title=title,
            description=description,
            organizer=organizer,
            event_type=event_type,
            event_date=event_date,
            location=location,
            expected_attendees=expected_attendees,
            **kwargs
        )
    
    def get_upcoming_events(self) -> List[Event]:
        """獲取即將到來的活動"""
        return Event.objects.filter(event_date__gt=timezone.now()).order_by('event_date')
    
    def get_past_events(self) -> List[Event]:
        """獲取過去的活動"""
        return Event.objects.filter(event_date__lt=timezone.now()).order_by('-event_date')
    
    def get_events_by_organizer(self, organizer: User) -> List[Event]:
        """根據主辦方獲取活動"""
        return Event.objects.filter(organizer=organizer)
    
    def get_events_by_type(self, event_type: EventType) -> List[Event]:
        """根據類型獲取活動"""
        return Event.objects.filter(event_type=event_type)
    
    def get_event_participants_count(self, event_id: int) -> int:
        """獲取活動參與人數（簡化版本）"""
        try:
            event = self.get_by_id(event_id)
            if event:
                # 這裡可以根據實際需求實現
                # 目前返回0，因為沒有註冊系統
                return 0
            return 0
        except Exception:
            return 0
    
    def get_stats(self) -> Dict[str, Any]:
        """獲取活動統計"""
        now = timezone.now()
        return {
            'total_events': self.count(),
            'upcoming_events': Event.objects.filter(event_date__gt=now).count(),
            'past_events': Event.objects.filter(event_date__lt=now).count(),
            'this_month_events': Event.objects.filter(
                event_date__year=now.year,
                event_date__month=now.month
            ).count(),
            'approved_events': Event.objects.filter(status='approved').count()
        }


class SupplierManager(BaseDataManager):
    """供應商管理器"""
    
    def __init__(self):
        super().__init__(Supplier)
    
    def create_supplier(self, user: User, company_name: str, description: str,
                       service_categories: List[ServiceCategory], **kwargs) -> Supplier:
        """創建供應商"""
        supplier = self.create(
            user=user,
            company_name=company_name,
            description=description,
            **kwargs
        )
        supplier.service_categories.set(service_categories)
        return supplier
    
    def approve_supplier(self, supplier_id: int) -> bool:
        """批准供應商"""
        return self.update(supplier_id, status='approved') is not None
    
    def reject_supplier(self, supplier_id: int) -> bool:
        """拒絕供應商"""
        return self.update(supplier_id, status='rejected') is not None
    
    def get_approved_suppliers(self) -> List[Supplier]:
        """獲取已批准的供應商"""
        return Supplier.objects.filter(status='approved')
    
    def get_pending_suppliers(self) -> List[Supplier]:
        """獲取待審核的供應商"""
        return Supplier.objects.filter(status='pending')
    
    def get_suppliers_by_category(self, category: ServiceCategory) -> List[Supplier]:
        """根據服務類別獲取供應商"""
        return Supplier.objects.filter(service_categories=category)
    
    def get_suppliers_by_area(self, area: str) -> List[Supplier]:
        """根據服務區域獲取供應商"""
        return Supplier.objects.filter(service_area__icontains=area)
    
    def get_stats(self) -> Dict[str, Any]:
        """獲取供應商統計"""
        return {
            'total_suppliers': self.count(),
            'approved_suppliers': Supplier.objects.filter(status='approved').count(),
            'pending_suppliers': Supplier.objects.filter(status='pending').count(),
            'rejected_suppliers': Supplier.objects.filter(status='rejected').count(),
            'avg_experience': Supplier.objects.aggregate(
                avg_exp=models.Avg('experience_years')
            )['avg_exp'] or 0
        }


class DJManager(BaseDataManager):
    """DJ管理器"""
    
    def __init__(self):
        super().__init__(DJ)
    
    def create_dj(self, user: User, stage_name: str, real_name: str,
                 category: DJCategory, **kwargs) -> DJ:
        """創建DJ"""
        return self.create(
            user=user,
            stage_name=stage_name,
            real_name=real_name,
            category=category,
            **kwargs
        )
    
    def approve_dj(self, dj_id: int) -> bool:
        """批准DJ"""
        return self.update(dj_id, status='approved') is not None
    
    def reject_dj(self, dj_id: int) -> bool:
        """拒絕DJ"""
        return self.update(dj_id, status='rejected') is not None
    
    def get_available_djs(self) -> List[DJ]:
        """獲取可用的DJ"""
        return DJ.objects.filter(is_available=True, status='approved')
    
    def get_djs_by_category(self, category: DJCategory) -> List[DJ]:
        """根據類別獲取DJ"""
        return DJ.objects.filter(category=category)
    
    def get_djs_by_experience(self, level: str) -> List[DJ]:
        """根據經驗等級獲取DJ"""
        return DJ.objects.filter(experience_level=level)
    
    def check_dj_availability(self, dj_id: int, event_date: datetime) -> bool:
        """檢查DJ可用性（簡化版本）"""
        try:
            dj = self.get_by_id(dj_id)
            if not dj or not dj.is_available:
                print(f"⚠️ DJ不可用")
                return False
            
            # 這裡可以根據實際需求實現預訂衝突檢查
            # 目前簡化處理
            print(f"✅ DJ {dj.stage_name} 在指定時間可用")
            return True
            
        except Exception as e:
            print(f"❌ 檢查可用性失敗: {str(e)}")
            return False
    
    def get_stats(self) -> Dict[str, Any]:
        """獲取DJ統計"""
        return {
            'total_djs': self.count(),
            'approved_djs': DJ.objects.filter(status='approved').count(),
            'available_djs': DJ.objects.filter(is_available=True).count(),
            'pending_djs': DJ.objects.filter(status='pending').count(),
            'avg_price': DJ.objects.aggregate(
                avg_price=models.Avg('price_per_hour')
            )['avg_price'] or 0
        }


class MessageManager(BaseDataManager):
    """訊息管理器"""
    
    def __init__(self):
        super().__init__(Message)
    
    def create_conversation(self, title: str, participants: List[User]) -> Conversation:
        """創建對話"""
        conversation = Conversation.objects.create(title=title)
        conversation.participants.set(participants)
        return conversation
    
    def send_message(self, conversation: Conversation, sender: User, content: str) -> Message:
        """發送訊息"""
        return self.create(
            conversation=conversation,
            sender=sender,
            content=content
        )
    
    def get_user_conversations(self, user: User) -> List[Conversation]:
        """獲取用戶的對話"""
        return Conversation.objects.filter(participants=user)
    
    def get_conversation_messages(self, conversation: Conversation) -> List[Message]:
        """獲取對話的訊息"""
        return Message.objects.filter(conversation=conversation).order_by('created_at')
    
    def mark_as_read(self, message_id: int, user: User) -> bool:
        """標記為已讀"""
        try:
            message = self.get_by_id(message_id)
            if message and user in message.conversation.participants.all():
                message.is_read = True
                message.save()
                return True
            return False
        except Exception:
            return False
    
    def get_unread_count(self, user: User) -> int:
        """獲取未讀訊息數量"""
        return Message.objects.filter(
            conversation__participants=user,
            is_read=False
        ).exclude(sender=user).count()
    
    def get_stats(self) -> Dict[str, Any]:
        """獲取訊息統計"""
        return {
            'total_conversations': Conversation.objects.count(),
            'total_messages': self.count(),
            'today_messages': Message.objects.filter(
                created_at__date=timezone.now().date()
            ).count(),
            'active_conversations': Conversation.objects.filter(
                messages__created_at__gte=timezone.now() - timedelta(days=7)
            ).distinct().count()
        }


class DataManagerFactory:
    """數據管理器工廠"""
    
    _managers = {
        'user': UserManager,
        'event': EventManager,
        'supplier': SupplierManager,
        'dj': DJManager,
        'message': MessageManager
    }
    
    @classmethod
    def get_manager(cls, manager_type: str) -> BaseDataManager:
        """獲取管理器實例"""
        if manager_type not in cls._managers:
            raise ValueError(f"未知的管理器類型: {manager_type}")
        
        return cls._managers[manager_type]()
    
    @classmethod
    def get_all_managers(cls) -> Dict[str, BaseDataManager]:
        """獲取所有管理器實例"""
        return {name: manager_class() for name, manager_class in cls._managers.items()}


class DataService:
    """數據服務主控制器"""
    
    def __init__(self):
        self.managers = DataManagerFactory.get_all_managers()
    
    def get_manager(self, manager_type: str) -> BaseDataManager:
        """獲取指定管理器"""
        return self.managers.get(manager_type)
    
    def get_system_stats(self) -> Dict[str, Any]:
        """獲取系統統計信息"""
        stats = {}
        for name, manager in self.managers.items():
            try:
                stats[name] = manager.get_stats()
            except Exception as e:
                stats[name] = {'error': str(e)}
        
        return stats
    
    def print_system_report(self):
        """打印系統報告"""
        print("🎯" + "="*60 + "🎯")
        print("                    系統數據報告")
        print("🎯" + "="*60 + "🎯")
        
        stats = self.get_system_stats()
        
        for manager_name, data in stats.items():
            print(f"\n📊 {manager_name.upper()} 統計:")
            print("-" * 40)
            
            if 'error' in data:
                print(f"❌ 錯誤: {data['error']}")
            else:
                for key, value in data.items():
                    print(f"• {key}: {value}")
    
    def cleanup_orphaned_data(self) -> Dict[str, int]:
        """清理孤立數據"""
        print("🧹 開始清理孤立數據...")
        
        cleanup_results = {}
        
        # 清理沒有用戶的供應商
        orphaned_suppliers = Supplier.objects.filter(user__isnull=True)
        count = orphaned_suppliers.count()
        if count > 0:
            orphaned_suppliers.delete()
            print(f"✅ 清理了 {count} 個孤立供應商")
        cleanup_results['suppliers'] = count
        
        # 清理沒有用戶的DJ
        orphaned_djs = DJ.objects.filter(user__isnull=True)
        count = orphaned_djs.count()
        if count > 0:
            orphaned_djs.delete()
            print(f"✅ 清理了 {count} 個孤立DJ")
        cleanup_results['djs'] = count
        
        # 清理空的對話
        empty_conversations = Conversation.objects.filter(participants__isnull=True)
        count = empty_conversations.count()
        if count > 0:
            empty_conversations.delete()
            print(f"✅ 清理了 {count} 個空對話")
        cleanup_results['conversations'] = count
        
        return cleanup_results


def main():
    """主函數示例"""
    # 創建數據服務
    data_service = DataService()
    
    # 打印系統報告
    data_service.print_system_report()
    
    # 清理孤立數據
    cleanup_results = data_service.cleanup_orphaned_data()
    
    print(f"\n🎯 清理完成，共處理 {sum(cleanup_results.values())} 個孤立對象")


if __name__ == "__main__":
    main()
