#!/usr/bin/env python
"""
模擬用戶提交表單的真實測試
"""

import os
import sys
import django
from django.test import Client
from django.contrib.auth import get_user_model

# 設置Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from events.models import Event, EventType

User = get_user_model()

def test_exact_form_submission():
    """使用用戶填寫的確切數據測試表單提交"""
    print("🔍 模擬用戶實際填寫的表單數據...")
    
    # 創建測試客戶端
    client = Client()
    
    # 獲取或創建測試用戶
    try:
        user, created = User.objects.get_or_create(
            username='form_test_user',
            defaults={
                'email': 'test@example.com',
                'first_name': '表單測試用戶'
            }
        )
        if created:
            user.set_password('testpass123')
            user.save()
            print(f"✅ 創建測試用戶: {user.username}")
        else:
            print(f"✅ 使用現有用戶: {user.username}")
    except Exception as e:
        print(f"❌ 用戶創建失敗: {e}")
        return
    
    # 登入用戶
    login_success = client.login(username='form_test_user', password='testpass123')
    if not login_success:
        print("❌ 用戶登入失敗")
        return
    print("✅ 用戶登入成功")
    
    # 先測試GET請求
    from django.urls import reverse
    try:
        create_url = reverse('events:create_event')
        print(f"✅ URL解析成功: {create_url}")
    except Exception as e:
        print(f"❌ URL解析失敗: {e}")
        return
    
    # 測試GET請求
    get_response = client.get(create_url)
    print(f"GET請求狀態: {get_response.status_code}")
    
    if get_response.status_code != 200:
        print(f"❌ GET請求失敗: {get_response.status_code}")
        print(f"響應內容: {get_response.content.decode()[:500]}")
        return
    
    # 獲取餐會活動類型 (從圖片看是"餐會")
    try:
        # 先檢查是否有"餐會"類型
        event_type = EventType.objects.filter(name__icontains='餐會').first()
        if not event_type:
            # 如果沒有，使用其他類型
            event_type = EventType.objects.first()
        print(f"✅ 使用活動類型: {event_type.name} (ID: {event_type.id})")
    except Exception as e:
        print(f"❌ 無法獲取活動類型: {e}")
        return
    
    # 使用用戶實際填寫的數據（根據圖片）
    form_data = {
        'title': '混搭台指期貨對課計議許',  # 從圖片中的活動標題
        'description': '一起吃香蕉',  # 從圖片中的活動描述
        'event_type': event_type.id,  # 餐會類型
        'event_date': '2025-07-15T15:00',  # 從圖片中的日期時間
        'location': '混搭動物園',  # 從圖片中的活動地點
        'expected_attendees': 185,  # 從圖片中的預計參與人數
        'budget_min': 100,  # 從圖片中的預算下限
        'budget_max': 10000,  # 從圖片中的預算上限
        'contact_person': '得準',  # 從圖片中的聯絡人
        'contact_phone': '110',  # 從圖片中的聯絡電話
        'contact_email': '9487945@gmail.com'  # 從圖片中的聯絡信箱
    }
    
    print(f"📝 提交的表單數據:")
    for key, value in form_data.items():
        print(f"   {key}: {value}")
    
    # 提交表單
    try:
        response = client.post(create_url, form_data, follow=True)
        print(f"\n✅ POST請求完成: 狀態碼 {response.status_code}")
        
        if response.status_code == 200:
            # 檢查是否有表單錯誤
            if hasattr(response, 'context') and response.context and 'form' in response.context:
                form = response.context['form']
                if form.errors:
                    print("❌ 表單驗證錯誤:")
                    for field, errors in form.errors.items():
                        print(f"   {field}: {errors}")
                else:
                    print("✅ 表單驗證通過，但未重定向")
            else:
                print("⚠️ 無法獲取表單上下文")
            
            # 檢查響應內容中的錯誤信息
            content = response.content.decode()
            if 'Not Found' in content:
                print("❌ 響應中包含'Not Found'錯誤")
                print(f"錯誤詳情: {content[:1000]}")
            elif 'error' in content.lower():
                print("⚠️ 響應中可能包含錯誤信息")
            else:
                print("ℹ️ 檢查響應內容...")
                # 查找可能的錯誤信息
                if 'invalid' in content.lower():
                    print("發現'invalid'字樣")
                if 'form' in content.lower():
                    print("頁面包含表單")
                print(f"響應前200字符: {content[:200]}")
            
        elif response.status_code == 302:
            print(f"✅ 表單提交成功，重定向到: {response.url}")
            
            # 檢查是否創建了Event
            events = Event.objects.filter(title='混搭台指期貨對課計議許')
            if events.exists():
                event = events.first()
                print(f"✅ Event創建成功: {event.title} (ID: {event.id})")
            else:
                print("❌ Event未創建")
        else:
            print(f"❌ 意外的狀態碼: {response.status_code}")
            print(f"響應內容前500字符: {response.content.decode()[:500]}")
            
    except Exception as e:
        print(f"❌ 請求失敗: {e}")
        import traceback
        traceback.print_exc()

def check_url_routing():
    """檢查URL路由"""
    print("\n🔍 檢查URL路由配置...")
    
    try:
        from django.urls import reverse
        create_url = reverse('events:create_event')
        print(f"✅ events:create_event URL: {create_url}")
        
        # 檢查是否能正確解析
        from django.urls import resolve
        resolver_match = resolve(create_url)
        print(f"✅ URL解析到視圖: {resolver_match.func.__name__}")
        print(f"✅ 視圖模組: {resolver_match.func.__module__}")
        
    except Exception as e:
        print(f"❌ URL路由檢查失敗: {e}")

def main():
    """主函數"""
    print("🚀 測試用戶實際提交的表單數據...")
    print("=" * 60)
    
    check_url_routing()
    test_exact_form_submission()
    
    print("\n" + "=" * 60)
    print("🏁 測試完成")

if __name__ == '__main__':
    main()
