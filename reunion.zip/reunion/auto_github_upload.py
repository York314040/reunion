#!/usr/bin/env python
"""
GitHub倉庫創建和上傳腳本
"""

import subprocess
import sys
import os
import json
import requests
from getpass import getpass

def run_command(command, cwd=None):
    """執行命令並返回結果"""
    try:
        result = subprocess.run(
            command, 
            shell=True, 
            capture_output=True, 
            text=True, 
            cwd=cwd
        )
        return result.returncode == 0, result.stdout, result.stderr
    except Exception as e:
        return False, "", str(e)

def create_github_repo(username, repo_name, token, description="", private=True):
    """使用GitHub API創建倉庫"""
    url = "https://api.github.com/user/repos"
    
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
        "Content-Type": "application/json"
    }
    
    data = {
        "name": repo_name,
        "description": description,
        "private": private,
        "has_issues": True,
        "has_projects": True,
        "has_wiki": True
    }
    
    try:
        response = requests.post(url, headers=headers, data=json.dumps(data))
        
        if response.status_code == 201:
            repo_info = response.json()
            return True, repo_info["clone_url"]
        elif response.status_code == 422:
            return False, "倉庫已存在或名稱無效"
        else:
            return False, f"創建失敗: {response.status_code} - {response.text}"
            
    except Exception as e:
        return False, f"請求失敗: {str(e)}"

def main():
    """主函數"""
    print("🚀 GitHub倉庫自動創建和上傳工具")
    print("=" * 50)
    
    # 用戶輸入
    username = input("請輸入您的GitHub用戶名 (預設: York314040): ").strip()
    if not username:
        username = "York314040"
    
    repo_name = input("請輸入倉庫名稱 (預設: reunion): ").strip()
    if not repo_name:
        repo_name = "reunion"
    
    description = input("請輸入倉庫描述 (預設: B2B聚會派對媒合平台): ").strip()
    if not description:
        description = "B2B聚會派對媒合平台"
    
    print("\n🔐 需要GitHub個人訪問令牌（Personal Access Token）")
    print("如果您沒有，請前往：https://github.com/settings/tokens")
    print("創建一個具有 'repo' 權限的令牌")
    
    token = getpass("請輸入您的GitHub Personal Access Token: ").strip()
    
    if not token:
        print("❌ 未提供Access Token，使用手動方法...")
        print_manual_instructions(username, repo_name)
        return
    
    # 創建倉庫
    print(f"\n🔄 正在創建倉庫 {username}/{repo_name}...")
    
    success, result = create_github_repo(username, repo_name, token, description)
    
    if success:
        print(f"✅ 倉庫創建成功！")
        clone_url = result
    else:
        print(f"⚠️ 倉庫創建問題: {result}")
        clone_url = f"https://github.com/{username}/{repo_name}.git"
        print(f"嘗試使用預設URL: {clone_url}")
    
    # 配置Git
    print("\n📝 配置Git...")
    
    # 移除現有的origin
    run_command("git remote remove origin")
    
    # 添加新的origin
    success, stdout, stderr = run_command(f"git remote add origin {clone_url}")
    if success:
        print("✅ 遠程倉庫配置成功")
    else:
        print(f"❌ 遠程配置失敗: {stderr}")
        return
    
    # 推送到GitHub
    print("\n📤 推送代碼到GitHub...")
    
    # 嘗試推送
    success, stdout, stderr = run_command("git push -u origin main")
    
    if success:
        print("🎉 成功上傳到GitHub！")
        print(f"🌐 倉庫URL: https://github.com/{username}/{repo_name}")
    else:
        print(f"❌ 推送失敗: {stderr}")
        print("\n使用手動方法...")
        print_manual_instructions(username, repo_name)

def print_manual_instructions(username, repo_name):
    """打印手動上傳指南"""
    print("\n" + "=" * 50)
    print("📋 手動上傳指南")
    print("=" * 50)
    
    print("1. 前往 GitHub 創建倉庫:")
    print(f"   https://github.com/new")
    print(f"   倉庫名稱: {repo_name}")
    print("   設置: Private/Public (您的選擇)")
    print("   不要勾選任何初始化選項")
    
    print("\n2. 創建完成後，執行以下命令:")
    print(f"   git remote add origin https://github.com/{username}/{repo_name}.git")
    print("   git branch -M main")
    print("   git push -u origin main")
    
    print("\n3. 或使用ZIP上傳:")
    print("   - 壓縮整個專案資料夾")
    print("   - 在GitHub倉庫頁面上傳ZIP文件")

if __name__ == "__main__":
    main()
