#!/usr/bin/env python
import os
import sys
import django

# 設置 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.contrib.auth.models import User

def batch_delete_users():
    """批量刪除除了 York 之外的所有用戶"""
    print("=== 批量刪除用戶操作 ===")
    
    # 獲取所有用戶
    all_users = User.objects.all()
    print(f"當前總用戶數: {all_users.count()}")
    
    # 要保留的用戶
    keep_user = "York"
    
    # 找到要刪除的用戶
    users_to_delete = all_users.exclude(username=keep_user)
    
    print(f"\n要保留的用戶: {keep_user}")
    print(f"要刪除的用戶數量: {users_to_delete.count()}")
    
    if users_to_delete.count() == 0:
        print("沒有用戶需要刪除。")
        return
    
    print("\n要刪除的用戶列表:")
    for user in users_to_delete:
        print(f"  - ID: {user.id}, 用戶名: {user.username}, 超級用戶: {user.is_superuser}, 職員: {user.is_staff}")
    
    # 確認操作
    confirm = input(f"\n確定要刪除以上 {users_to_delete.count()} 個用戶嗎？(輸入 'YES' 確認): ")
    
    if confirm != 'YES':
        print("操作已取消。")
        return
    
    # 執行刪除
    print("\n開始刪除用戶...")
    deleted_count = 0
    failed_deletions = []
    
    for user in users_to_delete:
        try:
            username = user.username
            user_id = user.id
            user.delete()
            print(f"✅ 已刪除: {username} (ID: {user_id})")
            deleted_count += 1
        except Exception as e:
            print(f"❌ 刪除失敗: {username} (ID: {user_id}) - 錯誤: {e}")
            failed_deletions.append(username)
    
    print(f"\n=== 刪除完成 ===")
    print(f"成功刪除: {deleted_count} 個用戶")
    print(f"刪除失敗: {len(failed_deletions)} 個用戶")
    
    if failed_deletions:
        print("刪除失敗的用戶:")
        for username in failed_deletions:
            print(f"  - {username}")
    
    # 顯示剩餘用戶
    remaining_users = User.objects.all()
    print(f"\n剩餘用戶數: {remaining_users.count()}")
    print("剩餘用戶列表:")
    for user in remaining_users:
        print(f"  - ID: {user.id}, 用戶名: {user.username}, 超級用戶: {user.is_superuser}")

if __name__ == "__main__":
    batch_delete_users()
