# 🚀 Heroku 部署執行指南

## 當前狀態 ✅
- [x] 項目文件已準備完成
- [x] Git 倉庫已初始化
- [x] 代碼已提交到 Git
- [ ] Heroku CLI 需要安裝

## 📥 第一步：安裝 Heroku CLI

### 方法 1：直接下載安裝（推薦）
1. 前往 https://devcenter.heroku.com/articles/heroku-cli
2. 下載 Windows 64-bit 安裝程序
3. 運行安裝程序，按照提示完成安裝
4. 重啟 PowerShell 或命令提示符

### 方法 2：使用 Chocolatey（如果已安裝）
```powershell
choco install heroku-cli
```

### 方法 3：使用 npm（如果已安裝 Node.js）
```powershell
npm install -g heroku
```

## 🔐 第二步：登錄 Heroku（安裝完成後執行）

```powershell
# 登錄 Heroku（會打開瀏覽器）
heroku login

# 驗證登錄狀態
heroku auth:whoami
```

## 🚀 第三步：創建和部署應用

安裝並登錄 Heroku 後，在項目目錄中執行：

```powershell
# 創建 Heroku 應用（替換為您想要的名稱）
heroku create reunion-party-platform

# 添加 PostgreSQL 數據庫
heroku addons:create heroku-postgresql:mini

# 設置環境變量
heroku config:set SECRET_KEY="your-secret-key-here"
heroku config:set DEBUG=False
heroku config:set ALLOWED_HOSTS="reunion-party-platform.herokuapp.com,localhost,127.0.0.1"

# 部署到 Heroku
git push heroku master

# 運行數據庫遷移
heroku run python manage.py migrate

# 創建超級用戶
heroku run python manage.py createsuperuser

# 初始化示例數據
heroku run python init_heroku_data.py

# 打開應用
heroku open
```

## 📝 注意事項

1. **應用名稱**：`reunion-party-platform` 需要是唯一的，如果被占用請換其他名稱
2. **SECRET_KEY**：建議生成一個新的密鑰
3. **免費方案**：Heroku 免費方案有使用限制
4. **域名**：應用將可通過 `https://your-app-name.herokuapp.com` 訪問

## 🎯 完成後的分享信息

成功部署後，您可以分享給朋友：

- **網站地址**：https://reunion-party-platform.herokuapp.com
- **演示帳號**：
  - 一般用戶：`zhang_ming` / `demo123456`
  - 管理員：`manager` / `manager123456`

## ❓ 需要協助？

如果在安裝 Heroku CLI 過程中遇到問題，請告訴我具體的錯誤信息，我會幫您解決！
