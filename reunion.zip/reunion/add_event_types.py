#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
添加活動類型初始數據腳本 - PAPA COLLEGE B2B聚會派對媒合平台
"""

import os
import sys
import django

# 設置 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from events.models import EventType

def create_event_types():
    """創建活動類型初始數據"""
    
    # 定義活動類型
    event_types = [
        {
            'name': '生日派對',
            'description': '慶祝生日的聚會活動，包含生日蛋糕、遊戲和音樂'
        },
        {
            'name': '公司聚會',
            'description': '企業內部團建或慶祝活動，適合同事間交流'
        },
        {
            'name': '婚禮派對',
            'description': '婚禮慶祝活動，包含婚宴、音樂和舞蹈'
        },
        {
            'name': '畢業派對',
            'description': '慶祝畢業的聚會，適合同學朋友聚會'
        },
        {
            'name': '節慶派對',
            'description': '各種節日慶祝活動，如聖誕節、新年等'
        },
        {
            'name': '主題派對',
            'description': '特定主題的聚會活動，如化妝舞會、復古派對等'
        },
        {
            'name': '商務酒會',
            'description': '商務場合的社交活動，適合商務人士networking'
        },
        {
            'name': '音樂派對',
            'description': '以音樂為主的聚會活動，包含DJ表演和舞蹈'
        },
        {
            'name': '戶外派對',
            'description': '在戶外舉辦的聚會活動，如野餐、BBQ等'
        },
        {
            'name': '歡送派對',
            'description': '為離職或搬家的朋友舉辦的歡送聚會'
        }
    ]
    
    print("🎉 開始創建活動類型...")
    created_count = 0
    
    for event_type_data in event_types:
        event_type, created = EventType.objects.get_or_create(
            name=event_type_data['name'],
            defaults={'description': event_type_data['description']}
        )
        
        if created:
            print(f"✅ 創建活動類型: {event_type.name}")
            created_count += 1
        else:
            print(f"⏭️ 活動類型已存在: {event_type.name}")
    
    print(f"\n📊 總計創建了 {created_count} 個新的活動類型")
    print(f"📋 資料庫中現有 {EventType.objects.count()} 個活動類型")
    
    # 顯示所有活動類型
    print("\n📝 目前所有活動類型:")
    for i, event_type in enumerate(EventType.objects.all(), 1):
        print(f"   {i}. {event_type.name} - {event_type.description}")

if __name__ == "__main__":
    try:
        create_event_types()
        print("\n🎊 活動類型數據創建完成！")
        print("現在您可以在網站上選擇活動類型了！")
    except Exception as e:
        print(f"❌ 創建活動類型時發生錯誤: {str(e)}")
        sys.exit(1)
