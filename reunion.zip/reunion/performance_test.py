#!/usr/bin/env python3
"""
性能測試腳本 - 檢測系統卡頓問題
"""

import time
import requests
import statistics
from datetime import datetime

class PerformanceTest:
    def __init__(self, base_url="http://127.0.0.1:8080"):
        self.base_url = base_url
        self.test_results = []
        
    def test_page_load_time(self, url_path, test_name):
        """測試頁面載入時間"""
        url = f"{self.base_url}{url_path}"
        
        try:
            start_time = time.time()
            response = requests.get(url, timeout=10)
            end_time = time.time()
            
            load_time = (end_time - start_time) * 1000  # 轉換為毫秒
            
            result = {
                'test_name': test_name,
                'url': url,
                'status_code': response.status_code,
                'load_time_ms': round(load_time, 2),
                'response_size': len(response.content),
                'timestamp': datetime.now().strftime('%H:%M:%S')
            }
            
            self.test_results.append(result)
            
            # 即時輸出結果
            status = "✅" if response.status_code == 200 else "❌"
            speed = "🚀" if load_time < 500 else "⚠️" if load_time < 1000 else "🐌"
            
            print(f"{status} {speed} {test_name}: {load_time:.0f}ms ({response.status_code}) - {len(response.content)} bytes")
            
            return result
            
        except requests.exceptions.RequestException as e:
            error_result = {
                'test_name': test_name,
                'url': url,
                'error': str(e),
                'timestamp': datetime.now().strftime('%H:%M:%S')
            }
            self.test_results.append(error_result)
            print(f"❌ {test_name}: 連接失敗 - {e}")
            return error_result
    
    def run_comprehensive_test(self):
        """執行全面性能測試"""
        print("🔍 開始系統性能測試...")
        print("=" * 50)
        
        # 測試主要頁面
        test_pages = [
            ('/', '首頁'),
            ('/suppliers/', '供應商列表'),
            ('/dj/', 'DJ列表'),
            ('/dj/popular/', '熱門DJ'),
        ]
        
        # 執行多輪測試以檢測一致性
        for round_num in range(1, 4):
            print(f"\n📊 第 {round_num} 輪測試:")
            round_results = []
            
            for url_path, test_name in test_pages:
                result = self.test_page_load_time(url_path, f"{test_name} (第{round_num}輪)")
                if 'load_time_ms' in result:
                    round_results.append(result['load_time_ms'])
                    
                # 短暫間隔避免過度請求
                time.sleep(0.5)
            
            if round_results:
                avg_time = statistics.mean(round_results)
                print(f"   平均響應時間: {avg_time:.0f}ms")
    
    def generate_report(self):
        """生成性能報告"""
        print("\n" + "=" * 50)
        print("📋 性能測試報告")
        print("=" * 50)
        
        successful_tests = [r for r in self.test_results if 'load_time_ms' in r]
        failed_tests = [r for r in self.test_results if 'error' in r]
        
        if successful_tests:
            load_times = [r['load_time_ms'] for r in successful_tests]
            
            print(f"✅ 成功測試: {len(successful_tests)} 個")
            print(f"❌ 失敗測試: {len(failed_tests)} 個")
            print(f"⚡ 平均響應時間: {statistics.mean(load_times):.0f}ms")
            print(f"🚀 最快響應時間: {min(load_times):.0f}ms")
            print(f"🐌 最慢響應時間: {max(load_times):.0f}ms")
            
            # 性能評級
            avg_time = statistics.mean(load_times)
            if avg_time < 300:
                grade = "🌟 優秀"
            elif avg_time < 600:
                grade = "👍 良好"
            elif avg_time < 1000:
                grade = "⚠️ 普通"
            else:
                grade = "🚫 需要優化"
                
            print(f"📈 系統性能評級: {grade}")
            
            # 詳細結果
            print(f"\n📊 詳細測試結果:")
            for result in successful_tests:
                print(f"   {result['test_name']}: {result['load_time_ms']}ms")
        
        if failed_tests:
            print(f"\n❌ 失敗的測試:")
            for result in failed_tests:
                print(f"   {result['test_name']}: {result.get('error', '未知錯誤')}")

def main():
    print("🎯 PAPA COLLEGE - 系統性能檢測工具")
    print("檢測系統卡頓和性能問題")
    print("時間:", datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    
    tester = PerformanceTest()
    tester.run_comprehensive_test()
    tester.generate_report()
    
    print("\n🔧 如果發現性能問題，建議:")
    print("   1. 檢查數據庫查詢效率")
    print("   2. 優化靜態資源載入")
    print("   3. 檢查伺服器資源使用情況")
    print("   4. 減少不必要的 JavaScript 執行")

if __name__ == "__main__":
    main()
