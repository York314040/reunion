from django.apps import AppConfig


class DjManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dj_management'
    verbose_name = 'DJ管理'
