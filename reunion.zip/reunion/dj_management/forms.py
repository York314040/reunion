from django import forms
from django.contrib.auth.models import User
from .models import DJ, DJRating, DJBooking, DJCategory


class DJForm(forms.ModelForm):
    """DJ註冊表單"""
    
    class Meta:
        model = DJ
        fields = [
            'stage_name', 'real_name', 'category', 'description', 
            'experience_level', 'specialties', 'contact_phone', 
            'contact_email', 'instagram', 'facebook', 'youtube',
            'price_per_hour', 'minimum_hours', 'profile_image', 
            'demo_audio', 'portfolio_images', 'service_areas'
        ]
        
        widgets = {
            'stage_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '請輸入您的藝名'
            }),
            'real_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '請輸入真實姓名'
            }),
            'category': forms.Select(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 4,
                'placeholder': '請簡介您的DJ經歷和風格...'
            }),
            'experience_level': forms.Select(attrs={'class': 'form-control'}),
            'specialties': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': '例如：House, Techno, Hip-Hop, R&B...'
            }),
            'contact_phone': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '09XX-XXX-XXX'
            }),
            'contact_email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'your.email@example.com'
            }),
            'instagram': forms.URLInput(attrs={
                'class': 'form-control',
                'placeholder': 'https://instagram.com/your_account'
            }),
            'facebook': forms.URLInput(attrs={
                'class': 'form-control',
                'placeholder': 'https://facebook.com/your_page'
            }),
            'youtube': forms.URLInput(attrs={
                'class': 'form-control',
                'placeholder': 'https://youtube.com/your_channel'
            }),
            'price_per_hour': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': '每小時收費(台幣)'
            }),
            'minimum_hours': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '1',
                'value': '2'
            }),
            'profile_image': forms.FileInput(attrs={
                'class': 'form-control',
                'accept': 'image/*'
            }),
            'demo_audio': forms.FileInput(attrs={
                'class': 'form-control',
                'accept': 'audio/*'
            }),
            'portfolio_images': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': '多個圖片URL用逗號分隔'
            }),
            'service_areas': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 2,
                'placeholder': '例如：台北市, 新北市, 桃園市...'
            }),
        }
    
    def clean_price_per_hour(self):
        price = self.cleaned_data.get('price_per_hour')
        if price and price < 500:
            raise forms.ValidationError('每小時收費不能低於500元')
        return price
    
    def clean_minimum_hours(self):
        hours = self.cleaned_data.get('minimum_hours')
        if hours and hours < 1:
            raise forms.ValidationError('最少演出時數不能少於1小時')
        return hours


class DJRatingForm(forms.ModelForm):
    """DJ評分表單"""
    
    class Meta:
        model = DJRating
        fields = ['rating', 'music_quality', 'performance', 'professionalism', 'crowd_interaction', 'comment']
        
        widgets = {
            'rating': forms.Select(choices=[(i, f'{i}星') for i in range(1, 6)], attrs={
                'class': 'form-control'
            }),
            'music_quality': forms.Select(choices=[(i, f'{i}星') for i in range(1, 6)], attrs={
                'class': 'form-control'
            }),
            'performance': forms.Select(choices=[(i, f'{i}星') for i in range(1, 6)], attrs={
                'class': 'form-control'
            }),
            'professionalism': forms.Select(choices=[(i, f'{i}星') for i in range(1, 6)], attrs={
                'class': 'form-control'
            }),
            'crowd_interaction': forms.Select(choices=[(i, f'{i}星') for i in range(1, 6)], attrs={
                'class': 'form-control'
            }),
            'comment': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 4,
                'placeholder': '分享您對這位DJ的評價...'
            })
        }


class DJBookingForm(forms.ModelForm):
    """DJ預約表單"""
    
    class Meta:
        model = DJBooking
        fields = ['event_title', 'event_date', 'event_location', 'duration_hours', 'special_requirements']
        
        widgets = {
            'event_title': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '例如：生日派對、婚禮活動...'
            }),
            'event_date': forms.DateTimeInput(attrs={
                'class': 'form-control',
                'type': 'datetime-local'
            }),
            'event_location': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '活動地點'
            }),
            'duration_hours': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '1',
                'value': '2'
            }),
            'special_requirements': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 4,
                'placeholder': '特殊需求或備註...'
            })
        }
    
    def clean_duration_hours(self):
        hours = self.cleaned_data.get('duration_hours')
        if hours and hours < 1:
            raise forms.ValidationError('演出時數不能少於1小時')
        return hours


class DJSearchForm(forms.Form):
    """DJ搜尋表單"""
    search = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '搜尋DJ名稱或音樂類型...'
        })
    )
    
    category = forms.ModelChoiceField(
        queryset=DJCategory.objects.all(),
        required=False,
        empty_label="所有類別",
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    experience = forms.ChoiceField(
        choices=[('', '所有經驗')] + DJ.EXPERIENCE_CHOICES,
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    location = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '服務地區...'
        })
    )
    
    sort_by = forms.ChoiceField(
        choices=[
            ('featured', '精選推薦'),
            ('rating', '評分最高'),
            ('price_low', '價格低到高'),
            ('price_high', '價格高到低'),
            ('newest', '最新加入'),
        ],
        initial='featured',
        widget=forms.Select(attrs={'class': 'form-control'})
    )
