from django.urls import path
from . import views

app_name = 'dj_management'

urlpatterns = [
    # DJ列表和詳情
    path('', views.dj_list, name='dj_list'),
    path('dj/<int:dj_id>/', views.dj_detail, name='dj_detail'),
    path('popular/', views.popular_djs, name='popular_djs'),
    
    # DJ註冊和管理
    path('register/', views.dj_register, name='dj_register'),
    path('dashboard/', views.dj_dashboard, name='dj_dashboard'),
    
    # 評分和預約
    path('dj/<int:dj_id>/rate/', views.rate_dj, name='rate_dj'),
    path('dj/<int:dj_id>/book/', views.book_dj, name='book_dj'),
    path('my-bookings/', views.my_bookings, name='my_bookings'),
    
    # API
    path('api/search/', views.dj_search_api, name='dj_search_api'),
]
