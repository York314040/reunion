from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone


class DJCategory(models.Model):
    """DJ類別"""
    name = models.CharField(max_length=100, verbose_name="DJ類別")
    description = models.TextField(blank=True, verbose_name="描述")
    
    class Meta:
        verbose_name = "DJ類別"
        verbose_name_plural = "DJ類別"
    
    def __str__(self):
        return self.name


class DJ(models.Model):
    """DJ資料"""
    STATUS_CHOICES = [
        ('pending', '待審核'),
        ('approved', '已通過'),
        ('rejected', '已拒絕'),
        ('suspended', '已停權'),
    ]
    
    EXPERIENCE_CHOICES = [
        ('beginner', '新手(1年以下)'),
        ('intermediate', '中級(1-3年)'),
        ('advanced', '高級(3-5年)'),
        ('expert', '專家(5年以上)'),
    ]
    
    # 基本資訊
    stage_name = models.CharField(max_length=200, verbose_name="藝名")
    real_name = models.CharField(max_length=100, verbose_name="真實姓名")
    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name="使用者帳號", null=True, blank=True)
    
    # DJ詳情
    category = models.ForeignKey(DJCategory, on_delete=models.CASCADE, verbose_name="DJ類別")
    description = models.TextField(verbose_name="個人簡介")
    experience_level = models.CharField(max_length=20, choices=EXPERIENCE_CHOICES, verbose_name="經驗等級")
    specialties = models.TextField(verbose_name="專長音樂類型", help_text="例如：House, Techno, Hip-Hop等")
    
    # 聯絡資訊
    contact_phone = models.CharField(max_length=20, verbose_name="聯絡電話")
    contact_email = models.EmailField(verbose_name="聯絡信箱")
    instagram = models.URLField(blank=True, verbose_name="Instagram")
    facebook = models.URLField(blank=True, verbose_name="Facebook")
    youtube = models.URLField(blank=True, verbose_name="YouTube")
    
    # 價格資訊
    price_per_hour = models.PositiveIntegerField(verbose_name="每小時收費", help_text="新台幣")
    minimum_hours = models.PositiveIntegerField(default=2, verbose_name="最少演出時數")
    
    # 多媒體
    profile_image = models.ImageField(upload_to='dj_profiles/', verbose_name="個人照片")
    demo_audio = models.FileField(upload_to='dj_demos/', blank=True, verbose_name="Demo音檔")
    portfolio_images = models.TextField(blank=True, verbose_name="作品集圖片", help_text="多個URL用逗號分隔")
    
    # 可服務區域
    service_areas = models.TextField(verbose_name="服務區域", help_text="例如：台北市, 新北市")
    
    # 狀態管理
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending', verbose_name="狀態")
    is_featured = models.BooleanField(default=False, verbose_name="精選DJ")
    is_available = models.BooleanField(default=True, verbose_name="目前可接案")
    
    # 統計資料
    total_gigs = models.PositiveIntegerField(default=0, verbose_name="總演出次數")
    total_hours = models.PositiveIntegerField(default=0, verbose_name="總演出時數")
    
    # 時間戳記
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="建立時間")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="更新時間")
    
    class Meta:
        verbose_name = "DJ"
        verbose_name_plural = "DJ"
        ordering = ['-is_featured', '-created_at']
    
    def __str__(self):
        return self.stage_name
    
    @property
    def average_rating(self):
        """計算平均評分"""
        ratings = self.djrating_set.all()
        if ratings:
            return round(sum(r.rating for r in ratings) / len(ratings), 1)
        return 0
    
    @property
    def total_ratings(self):
        """總評分數量"""
        return self.djrating_set.count()
    
    @property
    def rating_breakdown(self):
        """評分分布"""
        ratings = self.djrating_set.all()
        breakdown = {i: 0 for i in range(1, 6)}
        for rating in ratings:
            breakdown[rating.rating] += 1
        return breakdown
    
    def get_portfolio_images_list(self):
        """取得作品集圖片列表"""
        if self.portfolio_images:
            return [url.strip() for url in self.portfolio_images.split(',')]
        return []


class DJRating(models.Model):
    """DJ評分"""
    dj = models.ForeignKey(DJ, on_delete=models.CASCADE, verbose_name="DJ")
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="評分者")
    rating = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        verbose_name="評分"
    )
    comment = models.TextField(blank=True, verbose_name="評論")
    
    # 詳細評分項目
    music_quality = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        verbose_name="音樂品質"
    )
    performance = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        verbose_name="表演技巧"
    )
    professionalism = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        verbose_name="專業度"
    )
    crowd_interaction = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        verbose_name="觀眾互動"
    )
    
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="評分時間")
    
    class Meta:
        verbose_name = "DJ評分"
        verbose_name_plural = "DJ評分"
        unique_together = ('dj', 'user')  # 每個用戶只能為同一個DJ評分一次
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} 對 {self.dj.stage_name} 的評分: {self.rating}星"


class DJBooking(models.Model):
    """DJ預約"""
    STATUS_CHOICES = [
        ('pending', '待確認'),
        ('confirmed', '已確認'),
        ('completed', '已完成'),
        ('cancelled', '已取消'),
    ]
    
    dj = models.ForeignKey(DJ, on_delete=models.CASCADE, verbose_name="DJ")
    client = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="客戶")
    event_title = models.CharField(max_length=200, verbose_name="活動名稱")
    event_date = models.DateTimeField(verbose_name="活動日期")
    event_location = models.CharField(max_length=200, verbose_name="活動地點")
    duration_hours = models.PositiveIntegerField(verbose_name="演出時數")
    total_price = models.PositiveIntegerField(verbose_name="總價格")
    
    special_requirements = models.TextField(blank=True, verbose_name="特殊需求")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending', verbose_name="狀態")
    
    # 時間戳記
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="預約時間")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="更新時間")
    
    class Meta:
        verbose_name = "DJ預約"
        verbose_name_plural = "DJ預約"
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.dj.stage_name} - {self.event_title}"


class DJPlaylist(models.Model):
    """DJ播放清單"""
    dj = models.ForeignKey(DJ, on_delete=models.CASCADE, verbose_name="DJ")
    title = models.CharField(max_length=200, verbose_name="清單標題")
    description = models.TextField(blank=True, verbose_name="清單描述")
    genre = models.CharField(max_length=100, verbose_name="音樂類型")
    duration_minutes = models.PositiveIntegerField(verbose_name="總時長(分鐘)")
    
    # 音檔或連結
    audio_file = models.FileField(upload_to='dj_playlists/', blank=True, verbose_name="音檔")
    external_url = models.URLField(blank=True, verbose_name="外部連結", help_text="SoundCloud, MixCloud等")
    
    # 統計
    play_count = models.PositiveIntegerField(default=0, verbose_name="播放次數")
    like_count = models.PositiveIntegerField(default=0, verbose_name="按讚數")
    
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="建立時間")
    
    class Meta:
        verbose_name = "DJ播放清單"
        verbose_name_plural = "DJ播放清單"
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.dj.stage_name} - {self.title}"
