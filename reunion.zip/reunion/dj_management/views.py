from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.core.paginator import Paginator
from django.db.models import Q, Avg, Count
from django.views.decorators.http import require_POST
from django.contrib.auth.models import User

from .models import DJ, DJCategory, DJRating, DJBooking, DJPlaylist
from .forms import DJForm, DJRatingForm, DJBookingForm


def dj_list(request):
    """DJ列表頁面"""
    djs = DJ.objects.filter(status='approved').select_related('category')
    
    # 搜尋
    search = request.GET.get('search')
    if search:
        djs = djs.filter(
            Q(stage_name__icontains=search) |
            Q(specialties__icontains=search) |
            Q(description__icontains=search)
        )
    
    # 篩選
    category = request.GET.get('category')
    if category:
        djs = djs.filter(category_id=category)
    
    experience = request.GET.get('experience')
    if experience:
        djs = djs.filter(experience_level=experience)
    
    location = request.GET.get('location')
    if location:
        djs = djs.filter(service_areas__icontains=location)
    
    # 排序
    sort_by = request.GET.get('sort', 'featured')
    if sort_by == 'rating':
        djs = djs.annotate(avg_rating=Avg('djrating__rating')).order_by('-avg_rating', '-is_featured')
    elif sort_by == 'price_low':
        djs = djs.order_by('price_per_hour')
    elif sort_by == 'price_high':
        djs = djs.order_by('-price_per_hour')
    elif sort_by == 'newest':
        djs = djs.order_by('-created_at')
    else:  # featured
        djs = djs.order_by('-is_featured', '-created_at')
    
    # 分頁
    paginator = Paginator(djs, 12)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    # 取得篩選選項
    categories = DJCategory.objects.all()
    experience_choices = DJ.EXPERIENCE_CHOICES
    
    context = {
        'page_obj': page_obj,
        'categories': categories,
        'experience_choices': experience_choices,
        'current_search': search,
        'current_category': category,
        'current_experience': experience,
        'current_location': location,
        'current_sort': sort_by,
    }
    
    return render(request, 'dj_management/dj_list.html', context)


def dj_detail(request, dj_id):
    """DJ詳情頁面"""
    dj = get_object_or_404(DJ, id=dj_id, status='approved')
    
    # 評分資料
    ratings = DJRating.objects.filter(dj=dj).select_related('user').order_by('-created_at')
    user_rating = None
    if request.user.is_authenticated:
        try:
            user_rating = DJRating.objects.get(dj=dj, user=request.user)
        except DJRating.DoesNotExist:
            pass
    
    # 播放清單
    playlists = DJPlaylist.objects.filter(dj=dj).order_by('-created_at')[:5]
    
    # 相關DJ
    related_djs = DJ.objects.filter(
        category=dj.category, 
        status='approved'
    ).exclude(id=dj.id)[:4]
    
    context = {
        'dj': dj,
        'ratings': ratings[:10],  # 顯示最新10個評分
        'user_rating': user_rating,
        'playlists': playlists,
        'related_djs': related_djs,
        'can_rate': request.user.is_authenticated and not user_rating,
    }
    
    return render(request, 'dj_management/dj_detail.html', context)


def popular_djs(request):
    """最受歡迎DJ頁面"""
    try:
        # 按評分排序的DJ (安全處理)
        top_rated_djs = DJ.objects.filter(status='approved').annotate(
            avg_rating=Avg('djrating__rating'),
            rating_count=Count('djrating')
        ).filter(rating_count__gte=3, avg_rating__isnull=False).order_by('-avg_rating')[:10]
        
        # 精選DJ (安全處理)
        featured_djs = DJ.objects.filter(status='approved', is_featured=True).order_by('-created_at')[:8]
        
        # 最新加入的DJ (安全處理)
        newest_djs = DJ.objects.filter(status='approved').order_by('-created_at')[:6]
        
        # 統計資料 (安全處理)
        total_djs = DJ.objects.filter(status='approved').count()
        total_bookings = DJBooking.objects.filter(status='completed').count()
        total_ratings = DJRating.objects.count()
        
        # 如果沒有資料，提供默認值
        if total_djs == 0:
            # 創建空的查詢集，避免模板錯誤
            top_rated_djs = DJ.objects.none()
            featured_djs = DJ.objects.none()
            newest_djs = DJ.objects.none()
        
        context = {
            'top_rated_djs': top_rated_djs,
            'featured_djs': featured_djs,
            'newest_djs': newest_djs,
            'total_djs': total_djs,
            'total_bookings': total_bookings,
            'total_ratings': total_ratings,
        }
        
        return render(request, 'dj_management/popular_djs.html', context)
        
    except Exception as e:
        # 錯誤處理 - 記錄錯誤並返回安全的頁面
        import logging
        logger = logging.getLogger(__name__)
        logger.error(f"Popular DJs view error: {str(e)}")
        
        # 返回安全的空資料
        context = {
            'top_rated_djs': DJ.objects.none(),
            'featured_djs': DJ.objects.none(),
            'newest_djs': DJ.objects.none(),
            'total_djs': 0,
            'total_bookings': 0,
            'total_ratings': 0,
            'error_message': '暫時無法載入DJ資料，請稍後再試。'
        }
        
        return render(request, 'dj_management/popular_djs.html', context)


@login_required
def dj_register(request):
    """DJ註冊頁面"""
    if request.method == 'POST':
        form = DJForm(request.POST, request.FILES)
        if form.is_valid():
            dj = form.save(commit=False)
            dj.user = request.user
            dj.save()
            messages.success(request, 'DJ資料已提交，等待審核中！')
            return redirect('dj_management:dj_detail', dj_id=dj.id)
    else:
        form = DJForm()
    
    return render(request, 'dj_management/dj_register.html', {'form': form})


@login_required
@require_POST
def rate_dj(request, dj_id):
    """為DJ評分"""
    dj = get_object_or_404(DJ, id=dj_id)
    
    # 檢查是否已經評分過
    if DJRating.objects.filter(dj=dj, user=request.user).exists():
        return JsonResponse({'success': False, 'message': '您已經為此DJ評分過了'})
    
    try:
        rating_value = int(request.POST.get('rating'))
        music_quality = int(request.POST.get('music_quality'))
        performance = int(request.POST.get('performance'))
        professionalism = int(request.POST.get('professionalism'))
        crowd_interaction = int(request.POST.get('crowd_interaction'))
        comment = request.POST.get('comment', '')
        
        # 驗證評分範圍
        if not all(1 <= x <= 5 for x in [rating_value, music_quality, performance, professionalism, crowd_interaction]):
            return JsonResponse({'success': False, 'message': '評分必須在1-5之間'})
        
        # 創建評分
        DJRating.objects.create(
            dj=dj,
            user=request.user,
            rating=rating_value,
            music_quality=music_quality,
            performance=performance,
            professionalism=professionalism,
            crowd_interaction=crowd_interaction,
            comment=comment
        )
        
        return JsonResponse({
            'success': True, 
            'message': '評分成功！',
            'new_average': dj.average_rating,
            'total_ratings': dj.total_ratings
        })
        
    except (ValueError, TypeError):
        return JsonResponse({'success': False, 'message': '評分資料格式錯誤'})


@login_required
def book_dj(request, dj_id):
    """預約DJ"""
    dj = get_object_or_404(DJ, id=dj_id, status='approved')
    
    if request.method == 'POST':
        form = DJBookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.dj = dj
            booking.client = request.user
            booking.total_price = booking.duration_hours * dj.price_per_hour
            booking.save()
            
            messages.success(request, f'已成功提交預約申請給 {dj.stage_name}！')
            return redirect('dj_management:booking_detail', booking_id=booking.id)
    else:
        form = DJBookingForm()
    
    context = {
        'dj': dj,
        'form': form,
    }
    
    return render(request, 'dj_management/book_dj.html', context)


@login_required
def my_bookings(request):
    """我的預約"""
    bookings = DJBooking.objects.filter(client=request.user).select_related('dj').order_by('-created_at')
    
    paginator = Paginator(bookings, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    return render(request, 'dj_management/my_bookings.html', {'page_obj': page_obj})


@login_required
def dj_dashboard(request):
    """DJ控制台"""
    try:
        dj = DJ.objects.get(user=request.user)
    except DJ.DoesNotExist:
        messages.info(request, '請先註冊成為DJ')
        return redirect('dj_management:dj_register')
    
    # 統計資料
    pending_bookings = DJBooking.objects.filter(dj=dj, status='pending').count()
    total_bookings = DJBooking.objects.filter(dj=dj).count()
    total_earnings = sum(
        booking.total_price for booking in 
        DJBooking.objects.filter(dj=dj, status='completed')
    )
    recent_ratings = DJRating.objects.filter(dj=dj).order_by('-created_at')[:5]
    
    context = {
        'dj': dj,
        'pending_bookings': pending_bookings,
        'total_bookings': total_bookings,
        'total_earnings': total_earnings,
        'recent_ratings': recent_ratings,
    }
    
    return render(request, 'dj_management/dj_dashboard.html', context)


def dj_search_api(request):
    """DJ搜尋API"""
    query = request.GET.get('q', '')
    if len(query) < 2:
        return JsonResponse({'results': []})
    
    djs = DJ.objects.filter(
        Q(stage_name__icontains=query) | Q(specialties__icontains=query),
        status='approved'
    ).values('id', 'stage_name', 'specialties', 'average_rating')[:10]
    
    results = [{
        'id': dj['id'],
        'name': dj['stage_name'],
        'specialties': dj['specialties'],
        'rating': dj['average_rating']
    } for dj in djs]
    
    return JsonResponse({'results': results})
