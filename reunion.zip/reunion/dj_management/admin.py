from django.contrib import admin
from .models import DJCategory, DJ, DJRating, DJBooking, DJPlaylist


@admin.register(DJCategory)
class DJCategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')
    search_fields = ('name',)


@admin.register(DJ)
class DJAdmin(admin.ModelAdmin):
    list_display = ('stage_name', 'real_name', 'category', 'status', 'is_featured', 'average_rating', 'total_ratings', 'created_at')
    list_filter = ('status', 'is_featured', 'category', 'experience_level')
    search_fields = ('stage_name', 'real_name', 'specialties')
    readonly_fields = ('average_rating', 'total_ratings', 'created_at', 'updated_at')
    
    fieldsets = (
        ('基本資訊', {
            'fields': ('stage_name', 'real_name', 'user', 'category', 'profile_image')
        }),
        ('DJ詳情', {
            'fields': ('description', 'experience_level', 'specialties', 'service_areas')
        }),
        ('聯絡資訊', {
            'fields': ('contact_phone', 'contact_email', 'instagram', 'facebook', 'youtube')
        }),
        ('價格資訊', {
            'fields': ('price_per_hour', 'minimum_hours')
        }),
        ('多媒體', {
            'fields': ('demo_audio', 'portfolio_images')
        }),
        ('狀態管理', {
            'fields': ('status', 'is_featured', 'is_available')
        }),
        ('統計資料', {
            'fields': ('total_gigs', 'total_hours', 'average_rating', 'total_ratings')
        }),
        ('時間戳記', {
            'fields': ('created_at', 'updated_at')
        }),
    )


@admin.register(DJRating)
class DJRatingAdmin(admin.ModelAdmin):
    list_display = ('dj', 'user', 'rating', 'music_quality', 'performance', 'professionalism', 'created_at')
    list_filter = ('rating', 'created_at')
    search_fields = ('dj__stage_name', 'user__username', 'comment')
    readonly_fields = ('created_at',)


@admin.register(DJBooking)
class DJBookingAdmin(admin.ModelAdmin):
    list_display = ('dj', 'client', 'event_title', 'event_date', 'duration_hours', 'total_price', 'status', 'created_at')
    list_filter = ('status', 'event_date', 'created_at')
    search_fields = ('dj__stage_name', 'client__username', 'event_title', 'event_location')
    readonly_fields = ('created_at', 'updated_at')


@admin.register(DJPlaylist)
class DJPlaylistAdmin(admin.ModelAdmin):
    list_display = ('dj', 'title', 'genre', 'duration_minutes', 'play_count', 'like_count', 'created_at')
    list_filter = ('genre', 'created_at')
    search_fields = ('dj__stage_name', 'title', 'description')
    readonly_fields = ('play_count', 'like_count', 'created_at')
