#!/usr/bin/env python
"""
OOP專案主控制器
統一管理所有OOP模組和功能
"""

import os
import sys
import json
import argparse
from typing import Dict, Any, Optional
from datetime import datetime

# 設定 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')

import django
django.setup()

from project_manager_oop import ProjectManager
from data_manager_oop import DataService
from toolkit_manager_oop import ToolkitManager

# 新增功能模組導入
try:
    from deployment_automation import DeploymentAutomation
    from system_monitor import SystemMonitor
    from api_documentation_generator import APIDocumentationGenerator
    from heroku_deployment import HerokuDeploymentManager
    ADVANCED_FEATURES_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ 部分高級功能不可用: {str(e)}")
    ADVANCED_FEATURES_AVAILABLE = False


class OOPMasterController:
    """OOP主控制器"""
    
    def __init__(self):
        self.project_manager = ProjectManager()
        self.data_service = DataService()
        self.toolkit_manager = ToolkitManager()
        
        # 初始化新功能模組
        if ADVANCED_FEATURES_AVAILABLE:
            self.deployment_automation = DeploymentAutomation()
            self.system_monitor = SystemMonitor()
            self.api_doc_generator = APIDocumentationGenerator()
            self.heroku_deployment_manager = HerokuDeploymentManager()
        
        self.version = "2.0.0"  # 升級版本號
        self.system_name = "OOP派對平台管理系統"
    
    def print_banner(self):
        """打印系統橫幅"""
        banner = f"""
🎯{'='*80}🎯
                        {self.system_name}
                            版本 {self.version}
🎯{'='*80}🎯

📋 可用模組:
• project    - 專案管理 (測試、部署、分析)
• data       - 數據管理 (用戶、活動、供應商、DJ、訊息)
• toolkit    - 工具集 (數據庫、文件、通知、報告)
• deploy     - 自動化部署 (檢查、備份、打包) 🆕
• monitor    - 系統監控 (實時監控、告警) 🆕  
• docs       - API文檔生成 (自動化文檔) 🆕
• status     - 系統狀態檢查
• cleanup    - 全面清理整理
• help       - 幫助信息

🚀 使用範例:
python oop_master.py project --manager all
python oop_master.py data --action stats
python oop_master.py toolkit --tool maintenance
python oop_master.py deploy --action check 🆕
python oop_master.py monitor --action report 🆕
python oop_master.py docs 🆕
python oop_master.py cleanup
"""
        print(banner)
    
    def handle_project_command(self, args) -> Dict[str, Any]:
        """處理專案管理命令"""
        print("🎯 專案管理模組")
        print("="*50)
        
        if hasattr(args, 'manager') and args.manager:
            if args.manager == 'all':
                results = self.project_manager.run_all()
            else:
                results = {args.manager: self.project_manager.run_single(args.manager)}
        else:
            # 默認運行所有管理器
            results = self.project_manager.run_all()
        
        return {'module': 'project', 'results': results}
    
    def handle_data_command(self, args) -> Dict[str, Any]:
        """處理數據管理命令"""
        print("📊 數據管理模組")
        print("="*50)
        
        action = getattr(args, 'action', 'stats')
        
        if action == 'stats':
            self.data_service.print_system_report()
            return {'module': 'data', 'action': 'stats', 'success': True}
        
        elif action == 'cleanup':
            results = self.data_service.cleanup_orphaned_data()
            return {'module': 'data', 'action': 'cleanup', 'results': results}
        
        elif action == 'manager':
            manager_type = getattr(args, 'manager_type', None)
            if manager_type:
                manager = self.data_service.get_manager(manager_type)
                if manager:
                    stats = manager.get_stats()
                    print(f"\n📊 {manager_type.upper()} 管理器統計:")
                    for key, value in stats.items():
                        print(f"• {key}: {value}")
                    return {'module': 'data', 'manager': manager_type, 'stats': stats}
                else:
                    print(f"❌ 未知的管理器類型: {manager_type}")
                    return {'module': 'data', 'error': f'未知管理器: {manager_type}'}
            else:
                print("❌ 請指定管理器類型 (--manager-type)")
                return {'module': 'data', 'error': '缺少管理器類型'}
        
        else:
            print(f"❌ 未知操作: {action}")
            return {'module': 'data', 'error': f'未知操作: {action}'}
    
    def handle_toolkit_command(self, args) -> Dict[str, Any]:
        """處理工具集命令"""
        print("🔧 工具集模組")
        print("="*50)
        
        tool = getattr(args, 'tool', 'maintenance')
        action = getattr(args, 'tool_action', '')
        
        if tool == 'maintenance':
            results = self.toolkit_manager.run_full_maintenance()
            return {'module': 'toolkit', 'tool': 'maintenance', 'results': results}
        
        elif tool in self.toolkit_manager.list_tools():
            if not action:
                print(f"❌ 請指定操作 (--tool-action)")
                return {'module': 'toolkit', 'error': '缺少操作'}
            
            result = self.toolkit_manager.execute_tool(tool, action)
            return {'module': 'toolkit', 'tool': tool, 'action': action, 'result': result}
        
        else:
            print(f"❌ 未知工具: {tool}")
            available_tools = list(self.toolkit_manager.list_tools().keys())
            print(f"可用工具: {', '.join(available_tools)}")
            return {'module': 'toolkit', 'error': f'未知工具: {tool}'}
    
    def handle_status_command(self, args) -> Dict[str, Any]:
        """處理狀態檢查命令"""
        print("📊 系統狀態檢查")
        print("="*50)
        
        # 獲取系統統計
        stats = self.data_service.get_system_stats()
        
        # 簡化的測試
        from project_manager_oop import TestManager
        test_manager = TestManager()
        
        print("🧪 執行快速測試...")
        try:
            # 只測試核心功能，不設置測試環境
            from django.test import Client
            client = Client()
            
            test_urls = [
                ('/', '首頁'),
                ('/events/', '活動列表'),
                ('/suppliers/', '供應商列表')
            ]
            
            test_results = {}
            for url, name in test_urls:
                try:
                    response = client.get(url)
                    test_results[name] = response.status_code in [200, 302]
                    print(f"{'✅' if test_results[name] else '❌'} {name}")
                except Exception as e:
                    test_results[name] = False
                    print(f"❌ {name}: {str(e)}")
            
            overall_health = all(test_results.values())
            
        except Exception as e:
            print(f"❌ 測試失敗: {str(e)}")
            test_results = {}
            overall_health = False
        
        # 打印統計信息
        print(f"\n📊 系統統計:")
        for category, data in stats.items():
            print(f"\n• {category.upper()}:")
            if isinstance(data, dict) and 'error' not in data:
                for key, value in data.items():
                    print(f"  - {key}: {value}")
            else:
                print(f"  - 錯誤: {data.get('error', '未知錯誤')}")
        
        print(f"\n🎯 整體健康狀況: {'✅ 良好' if overall_health else '⚠️ 需要檢查'}")
        
        return {
            'module': 'status',
            'stats': stats,
            'test_results': test_results,
            'overall_health': overall_health
        }
    
    def handle_cleanup_command(self, args) -> Dict[str, Any]:
        """處理全面清理命令"""
        print("🧹 全面清理整理")
        print("="*50)
        
        cleanup_results = {}
        
        # 1. 數據清理
        print("\n1️⃣ 數據清理...")
        cleanup_results['data'] = self.data_service.cleanup_orphaned_data()
        
        # 2. 文件清理
        print("\n2️⃣ 文件清理...")
        cleanup_results['files'] = self.toolkit_manager.execute_tool('file_manager', 'clean')
        
        # 3. 腳本整理
        print("\n3️⃣ 腳本整理...")
        cleanup_results['organize'] = self.toolkit_manager.execute_tool('file_manager', 'organize')
        
        # 4. 數據庫優化
        print("\n4️⃣ 數據庫優化...")
        cleanup_results['database'] = self.toolkit_manager.execute_tool('database', 'optimize')
        
        # 5. 生成文檔
        print("\n5️⃣ 生成文檔...")
        cleanup_results['docs'] = self.toolkit_manager.execute_tool('file_manager', 'structure_doc')
        
        print("\n🎉 全面清理完成!")
        
        return {'module': 'cleanup', 'results': cleanup_results}
    
    def handle_deploy_command(self, args) -> Dict[str, Any]:
        """處理自動化部署命令"""
        if not ADVANCED_FEATURES_AVAILABLE:
            return {'error': '部署功能不可用，請檢查模組安裝'}
        
        print("🚀 自動化部署模組")
        print("="*50)
        
        action = getattr(args, 'deploy_action', 'check')
        
        if action == 'check':
            result = self.deployment_automation.pre_deployment_checks()
            print(f"\n部署檢查: {'✅ 通過' if result['all_passed'] else '❌ 失敗'}")
            return {'module': 'deploy', 'action': 'check', 'result': result}
        
        elif action == 'backup':
            result = self.deployment_automation.backup_before_deployment()
            print(f"\n備份: {'✅ 成功' if result['success'] else '❌ 失敗'}")
            return {'module': 'deploy', 'action': 'backup', 'result': result}
        
        elif action == 'package':
            result = self.deployment_automation.create_deployment_package()
            print(f"\n打包: {'✅ 成功' if result['success'] else '❌ 失敗'}")
            return {'module': 'deploy', 'action': 'package', 'result': result}
        
        elif action == 'full':
            result = self.deployment_automation.run_full_deployment_process()
            print(f"\n完整部署: {'✅ 成功' if result['status'] == 'success' else '❌ 失敗'}")
            return {'module': 'deploy', 'action': 'full', 'result': result}
        
        else:
            return {'module': 'deploy', 'error': f'未知操作: {action}'}
    
    def handle_monitor_command(self, args) -> Dict[str, Any]:
        """處理系統監控命令"""
        if not ADVANCED_FEATURES_AVAILABLE:
            return {'error': '監控功能不可用，請檢查模組安裝'}
        
        print("📊 系統監控模組")
        print("="*50)
        
        action = getattr(args, 'monitor_action', 'report')
        
        if action == 'report':
            result = self.system_monitor.generate_monitoring_report()
            
            # 顯示摘要
            status = result['summary']['overall_status']
            health_score = result['summary']['health_score']
            alert_count = result['summary']['alert_count']
            
            print(f"\n📊 監控摘要:")
            print(f"  • 系統狀態: {status.upper()}")
            print(f"  • 健康分數: {health_score:.1f}%")
            print(f"  • 告警數量: {alert_count}")
            
            if alert_count > 0:
                print(f"\n⚠️ 告警詳情:")
                for alert in result['alerts']:
                    print(f"  • {alert['message']}")
            
            return {'module': 'monitor', 'action': 'report', 'result': result}
        
        elif action == 'continuous':
            interval = getattr(args, 'monitor_interval', 5)
            print(f"開始連續監控 (間隔: {interval} 分鐘)")
            self.system_monitor.run_continuous_monitoring(interval)
            return {'module': 'monitor', 'action': 'continuous', 'interval': interval}
        
        else:
            return {'module': 'monitor', 'error': f'未知操作: {action}'}
    
    def handle_docs_command(self, args) -> Dict[str, Any]:
        """處理API文檔生成命令"""
        if not ADVANCED_FEATURES_AVAILABLE:
            return {'error': 'API文檔功能不可用，請檢查模組安裝'}
        
        print("📚 API文檔生成模組")
        print("="*50)
        
        result = self.api_doc_generator.save_documentation()
        
        if result['success']:
            print("✅ API 文檔生成成功!")
            print(f"📄 Markdown 文檔: {result['markdown_file']}")
            print(f"📊 JSON 數據: {result['json_file']}")
            print(f"📊 統計:")
            print(f"  • 數據模型: {result['models_count']} 個")
            print(f"  • API 端點: {result['endpoints_count']} 個")
        else:
            print(f"❌ 文檔生成失敗: {result['error']}")
        
        return {'module': 'docs', 'result': result}
    
    def show_help(self):
        """顯示幫助信息"""
        help_text = f"""
🎯 {self.system_name} v{self.version} - 幫助信息

📋 主要命令:

🔸 專案管理:
  python oop_master.py project --manager all         # 運行所有管理器
  python oop_master.py project --manager test        # 只運行測試
  python oop_master.py project --manager deployment  # 只運行部署檢查
  python oop_master.py project --manager analysis    # 只運行分析

🔸 數據管理:
  python oop_master.py data --action stats           # 顯示數據統計
  python oop_master.py data --action cleanup         # 清理孤立數據
  python oop_master.py data --action manager --manager-type user  # 特定管理器

🔸 工具集:
  python oop_master.py toolkit --tool maintenance    # 運行完整維護
  python oop_master.py toolkit --tool database --tool-action backup
  python oop_master.py toolkit --tool file_manager --tool-action clean
  python oop_master.py toolkit --tool report --tool-action health

🔸 系統命令:
  python oop_master.py status                        # 檢查系統狀態
  python oop_master.py cleanup                       # 全面清理整理
  python oop_master.py help                          # 顯示此幫助

🔸 數據管理器類型:
  - user: 用戶管理
  - event: 活動管理  
  - supplier: 供應商管理
  - dj: DJ管理
  - message: 訊息管理

🔸 工具類型:
  - database: 數據庫工具 (backup, restore, optimize, info)
  - file_manager: 文件管理 (clean, organize, structure_doc)
  - notification: 通知工具 (email, alert)
  - report: 報告工具 (health, export_csv)

📚 更多信息請查看各模組的文檔文件。
"""
        print(help_text)
    
    def save_execution_log(self, command: str, results: Dict[str, Any]):
        """保存執行日誌"""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'command': command,
            'results': results,
            'version': self.version
        }
        
        # 讀取現有日誌
        log_file = 'oop_execution_log.json'
        logs = []
        
        if os.path.exists(log_file):
            try:
                with open(log_file, 'r', encoding='utf-8') as f:
                    logs = json.load(f)
            except:
                logs = []
        
        # 添加新日誌
        logs.append(log_entry)
        
        # 保持最近100條記錄
        logs = logs[-100:]
        
        # 保存日誌
        with open(log_file, 'w', encoding='utf-8') as f:
            json.dump(logs, f, ensure_ascii=False, indent=2)
    
    def run(self, command: str, args) -> Dict[str, Any]:
        """運行指定命令"""
        start_time = datetime.now()
        
        try:
            if command == 'project':
                results = self.handle_project_command(args)
            elif command == 'data':
                results = self.handle_data_command(args)
            elif command == 'toolkit':
                results = self.handle_toolkit_command(args)
            elif command == 'deploy':
                results = self.handle_deploy_command(args)
            elif command == 'monitor':
                results = self.handle_monitor_command(args)
            elif command == 'docs':
                results = self.handle_docs_command(args)
            elif command == 'status':
                results = self.handle_status_command(args)
            elif command == 'cleanup':
                results = self.handle_cleanup_command(args)
            elif command == 'help':
                self.show_help()
                return {'module': 'help', 'success': True}
            else:
                print(f"❌ 未知命令: {command}")
                self.show_help()
                return {'error': f'未知命令: {command}'}
            
            # 計算執行時間
            execution_time = (datetime.now() - start_time).total_seconds()
            results['execution_time'] = execution_time
            
            # 保存執行日誌
            self.save_execution_log(command, results)
            
            print(f"\n⏱️ 執行時間: {execution_time:.2f} 秒")
            
            return results
            
        except Exception as e:
            error_result = {
                'error': str(e),
                'command': command,
                'execution_time': (datetime.now() - start_time).total_seconds()
            }
            
            print(f"❌ 執行失敗: {str(e)}")
            
            # 保存錯誤日誌
            self.save_execution_log(command, error_result)
            
            return error_result


def main():
    """主函數"""
    parser = argparse.ArgumentParser(description='OOP派對平台管理系統')
    
    # 主命令
    parser.add_argument('command', 
                       choices=['project', 'data', 'toolkit', 'deploy', 'monitor', 'docs', 'status', 'cleanup', 'help'],
                       help='要執行的主命令')
    
    # 專案管理參數
    parser.add_argument('--manager', '-m',
                       choices=['test', 'deployment', 'analysis', 'all'],
                       help='專案管理器類型')
    
    # 數據管理參數
    parser.add_argument('--action', '-a',
                       choices=['stats', 'cleanup', 'manager'],
                       help='數據管理操作')
    parser.add_argument('--manager-type',
                       choices=['user', 'event', 'supplier', 'dj', 'message'],
                       help='數據管理器類型')
    
    # 工具集參數
    parser.add_argument('--tool', '-t',
                       choices=['database', 'file_manager', 'notification', 'report', 'maintenance'],
                       help='工具類型')
    parser.add_argument('--tool-action',
                       help='工具操作')
    
    # 部署參數
    parser.add_argument('--deploy-action',
                       choices=['check', 'backup', 'package', 'full'],
                       default='check',
                       help='部署操作')
    
    # 監控參數
    parser.add_argument('--monitor-action',
                       choices=['report', 'continuous'],
                       default='report',
                       help='監控操作')
    parser.add_argument('--monitor-interval', type=int, default=5,
                       help='監控間隔 (分鐘)')
    
    # 通用參數
    parser.add_argument('--version', action='version', version='OOP派對平台管理系統 v2.0.0')
    parser.add_argument('--verbose', '-v', action='store_true',
                       help='詳細輸出')
    
    args = parser.parse_args()
    
    # 創建主控制器
    controller = OOPMasterController()
    
    # 顯示橫幅
    controller.print_banner()
    
    # 運行命令
    results = controller.run(args.command, args)
    
    # 詳細輸出
    if args.verbose and 'error' not in results:
        print(f"\n📋 詳細結果:")
        print(json.dumps(results, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
