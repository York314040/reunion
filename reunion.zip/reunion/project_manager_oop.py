#!/usr/bin/env python
"""
專案管理系統 - OOP重構版本
統一管理所有測試、部署、分析功能
"""

import os
import sys
import time
import json
from abc import ABC, abstractmethod
from pathlib import Path
from typing import List, Dict, Any, Optional

# 設定 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')

import django
django.setup()

from django.test import Client
from django.contrib.auth.models import User
from django.db import transaction
from django.core.management import call_command
from events.models import Event, EventType
from suppliers.models import Supplier, ServiceCategory
from messaging.models import Conversation, Message
from dj_management.models import DJ, DJCategory


class BaseManager(ABC):
    """基礎管理器類別"""
    
    def __init__(self, name: str):
        self.name = name
        self.client = Client()
        self.results = {
            'passed': 0,
            'failed': 0,
            'warnings': 0,
            'errors': [],
            'actions': []
        }
    
    def log_action(self, action: str, status: str = "INFO"):
        """記錄操作"""
        icons = {"INFO": "ℹ️", "SUCCESS": "✅", "ERROR": "❌", "WARNING": "⚠️"}
        message = f"{icons.get(status, 'ℹ️')} {action}"
        print(message)
        
        self.results['actions'].append({
            'action': action,
            'status': status,
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S')
        })
        
        if status == "SUCCESS":
            self.results['passed'] += 1
        elif status == "ERROR":
            self.results['failed'] += 1
            self.results['errors'].append(action)
        elif status == "WARNING":
            self.results['warnings'] += 1
    
    def print_header(self, title: str):
        """打印標題"""
        print(f"\n{'='*80}")
        print(f"🎯 {self.name} - {title}")
        print(f"{'='*80}")
    
    def print_section(self, section: str):
        """打印區段"""
        print(f"\n📋 {section}")
        print("-" * 60)
    
    @abstractmethod
    def execute(self) -> bool:
        """執行主要功能"""
        pass
    
    def generate_report(self) -> str:
        """生成報告"""
        total = self.results['passed'] + self.results['failed']
        success_rate = (self.results['passed'] / total * 100) if total > 0 else 0
        
        report = f"""# {self.name} 執行報告

## 📊 統計資訊
- 總操作數: {total}
- ✅ 成功: {self.results['passed']}
- ❌ 失敗: {self.results['failed']}
- ⚠️ 警告: {self.results['warnings']}
- 📈 成功率: {success_rate:.1f}%

## 📝 執行記錄
"""
        
        for action in self.results['actions']:
            report += f"- [{action['timestamp']}] {action['action']}\n"
        
        if self.results['errors']:
            report += "\n## ❌ 錯誤列表\n"
            for i, error in enumerate(self.results['errors'], 1):
                report += f"{i}. {error}\n"
        
        return report


class TestManager(BaseManager):
    """測試管理器"""
    
    def __init__(self):
        super().__init__("測試管理器")
        self.test_users = {}
        self.test_data = {}
    
    def setup_test_environment(self) -> bool:
        """設置測試環境"""
        self.print_header("設置測試環境")
        
        try:
            # 創建測試用戶
            self.test_users = {
                'admin': self._create_test_user('test_admin_oop', 'admin@test.com', is_staff=True, is_superuser=True),
                'client': self._create_test_user('test_client_oop', 'client@test.com'),
                'supplier_user': self._create_test_user('test_supplier_oop', 'supplier@test.com'),
                'dj_user': self._create_test_user('test_dj_oop', 'dj@test.com')
            }
            
            # 創建測試數據
            self.test_data = {
                'event_type': EventType.objects.create(name='OOP測試活動', description='OOP重構測試'),
                'service_category': ServiceCategory.objects.create(name='OOP測試服務', description='OOP重構測試'),
                'dj_category': DJCategory.objects.create(name='OOP測試DJ', description='OOP重構測試')
            }
            
            # 創建供應商和DJ
            supplier = Supplier.objects.create(
                user=self.test_users['supplier_user'],
                company_name='OOP測試供應商',
                description='OOP重構測試供應商',
                experience_years=5,
                service_area='台北市',
                contact_person='測試聯絡人',
                contact_phone='0912345678',
                contact_email='supplier@test.com',
                price_range_min=10000,
                price_range_max=50000,
                status='approved'
            )
            supplier.service_categories.add(self.test_data['service_category'])
            self.test_data['supplier'] = supplier
            
            dj = DJ.objects.create(
                user=self.test_users['dj_user'],
                stage_name='OOP測試DJ',
                real_name='OOP測試DJ真名',
                category=self.test_data['dj_category'],
                description='OOP重構測試DJ',
                experience_level='intermediate',
                specialties='House, Techno',
                contact_phone='0987654321',
                contact_email='dj@test.com',
                price_per_hour=3000,
                minimum_hours=4,
                is_available=True,
                status='approved'
            )
            self.test_data['dj'] = dj
            
            self.log_action("測試環境設置完成", "SUCCESS")
            return True
            
        except Exception as e:
            self.log_action(f"測試環境設置失敗: {str(e)}", "ERROR")
            return False
    
    def _create_test_user(self, username: str, email: str, **kwargs) -> User:
        """創建測試用戶"""
        user = User.objects.create_user(
            username=username,
            email=email,
            password='test123456',
            **kwargs
        )
        return user
    
    def test_core_functionality(self) -> bool:
        """測試核心功能"""
        self.print_header("測試核心功能")
        
        # 測試主要頁面
        test_urls = [
            ('/', '首頁'),
            ('/events/', '活動列表'),
            ('/suppliers/', '供應商列表'),
            ('/dj/', 'DJ列表'),
            ('/messaging/', '訊息系統'),
            ('/admin/', '管理後台')
        ]
        
        for url, name in test_urls:
            try:
                response = self.client.get(url)
                if response.status_code in [200, 302]:
                    self.log_action(f"{name}頁面正常", "SUCCESS")
                else:
                    self.log_action(f"{name}頁面異常 (狀態碼: {response.status_code})", "ERROR")
            except Exception as e:
                self.log_action(f"{name}頁面測試失敗: {str(e)}", "ERROR")
        
        return True
    
    def test_dashboard_functionality(self) -> bool:
        """測試Dashboard功能"""
        self.print_header("測試Dashboard功能")
        
        dashboard_tests = [
            ('admin', '/dashboards/admin/', '管理員Dashboard'),
            ('client', '/dashboards/client/', '客戶Dashboard'),
            ('supplier_user', '/dashboards/supplier/', '供應商Dashboard'),
            ('dj_user', '/dashboards/dj/', 'DJ Dashboard')
        ]
        
        for user_type, url, description in dashboard_tests:
            try:
                self.client.force_login(self.test_users[user_type])
                response = self.client.get(url)
                
                if response.status_code == 200:
                    self.log_action(f"{description}正常", "SUCCESS")
                elif response.status_code == 302:
                    self.log_action(f"{description}重定向（可能需要額外設置）", "WARNING")
                else:
                    self.log_action(f"{description}異常 (狀態碼: {response.status_code})", "ERROR")
                
                self.client.logout()
                
            except Exception as e:
                self.log_action(f"{description}測試失敗: {str(e)}", "ERROR")
        
        return True
    
    def cleanup_test_environment(self) -> bool:
        """清理測試環境"""
        self.print_header("清理測試環境")
        
        try:
            # 刪除測試用戶
            for user in self.test_users.values():
                user.delete()
            
            # 刪除測試數據
            for data in self.test_data.values():
                if hasattr(data, 'delete'):
                    data.delete()
            
            self.log_action("測試環境清理完成", "SUCCESS")
            return True
            
        except Exception as e:
            self.log_action(f"測試環境清理失敗: {str(e)}", "ERROR")
            return False
    
    def execute(self) -> bool:
        """執行測試"""
        self.print_header("開始執行測試")
        
        success = True
        success &= self.setup_test_environment()
        success &= self.test_core_functionality()
        success &= self.test_dashboard_functionality()
        success &= self.cleanup_test_environment()
        
        return success


class DeploymentManager(BaseManager):
    """部署管理器"""
    
    def __init__(self):
        super().__init__("部署管理器")
    
    def check_system_requirements(self) -> bool:
        """檢查系統需求"""
        self.print_header("檢查系統需求")
        
        requirements = [
            ('Django版本', self._check_django_version),
            ('數據庫連接', self._check_database),
            ('靜態文件', self._check_static_files),
            ('模板文件', self._check_templates),
            ('必要設置', self._check_settings)
        ]
        
        for name, check_func in requirements:
            try:
                if check_func():
                    self.log_action(f"{name}檢查通過", "SUCCESS")
                else:
                    self.log_action(f"{name}檢查失敗", "ERROR")
            except Exception as e:
                self.log_action(f"{name}檢查錯誤: {str(e)}", "ERROR")
        
        return True
    
    def _check_django_version(self) -> bool:
        """檢查Django版本"""
        import django
        version = django.get_version()
        return version.startswith('4.2')
    
    def _check_database(self) -> bool:
        """檢查數據庫連接"""
        from django.db import connection
        try:
            connection.ensure_connection()
            return True
        except:
            return False
    
    def _check_static_files(self) -> bool:
        """檢查靜態文件"""
        static_dirs = ['static', 'staticfiles']
        return any(Path(d).exists() for d in static_dirs)
    
    def _check_templates(self) -> bool:
        """檢查模板文件"""
        return Path('templates').exists()
    
    def _check_settings(self) -> bool:
        """檢查設置文件"""
        return Path('party_platform/settings.py').exists()
    
    def prepare_production(self) -> bool:
        """準備生產環境"""
        self.print_header("準備生產環境")
        
        tasks = [
            ('收集靜態文件', self._collect_static),
            ('運行遷移', self._run_migrations),
            ('檢查部署配置', self._check_deployment_config)
        ]
        
        for name, task_func in tasks:
            try:
                if task_func():
                    self.log_action(f"{name}完成", "SUCCESS")
                else:
                    self.log_action(f"{name}失敗", "ERROR")
            except Exception as e:
                self.log_action(f"{name}錯誤: {str(e)}", "ERROR")
        
        return True
    
    def _collect_static(self) -> bool:
        """收集靜態文件"""
        try:
            call_command('collectstatic', '--noinput', verbosity=0)
            return True
        except:
            return False
    
    def _run_migrations(self) -> bool:
        """運行遷移"""
        try:
            call_command('migrate', verbosity=0)
            return True
        except:
            return False
    
    def _check_deployment_config(self) -> bool:
        """檢查部署配置"""
        config_files = ['Procfile', 'requirements.txt', 'runtime.txt']
        return all(Path(f).exists() for f in config_files)
    
    def execute(self) -> bool:
        """執行部署檢查"""
        self.print_header("開始部署檢查")
        
        success = True
        success &= self.check_system_requirements()
        success &= self.prepare_production()
        
        return success


class AnalysisManager(BaseManager):
    """分析管理器"""
    
    def __init__(self):
        super().__init__("分析管理器")
        self.analysis_data = {}
    
    def analyze_codebase(self) -> bool:
        """分析代碼庫"""
        self.print_header("分析代碼庫")
        
        # 統計項目文件
        python_files = list(Path('.').rglob('*.py'))
        html_files = list(Path('.').rglob('*.html'))
        
        self.analysis_data['files'] = {
            'python': len(python_files),
            'html': len(html_files),
            'total': len(python_files) + len(html_files)
        }
        
        self.log_action(f"發現 {len(python_files)} 個Python文件", "INFO")
        self.log_action(f"發現 {len(html_files)} 個HTML文件", "INFO")
        
        return True
    
    def analyze_database(self) -> bool:
        """分析數據庫"""
        self.print_header("分析數據庫")
        
        models_stats = {
            'users': User.objects.count(),
            'events': Event.objects.count(),
            'suppliers': Supplier.objects.count(),
            'djs': DJ.objects.count(),
            'conversations': Conversation.objects.count()
        }
        
        self.analysis_data['database'] = models_stats
        
        for model, count in models_stats.items():
            self.log_action(f"{model}: {count} 筆記錄", "INFO")
        
        return True
    
    def analyze_system_health(self) -> bool:
        """分析系統健康狀況"""
        self.print_header("分析系統健康狀況")
        
        # 檢查孤立對象
        orphaned_suppliers = Supplier.objects.filter(user__isnull=True).count()
        orphaned_djs = DJ.objects.filter(user__isnull=True).count()
        
        if orphaned_suppliers > 0:
            self.log_action(f"發現 {orphaned_suppliers} 個孤立供應商", "WARNING")
        
        if orphaned_djs > 0:
            self.log_action(f"發現 {orphaned_djs} 個孤立DJ", "WARNING")
        
        if orphaned_suppliers == 0 and orphaned_djs == 0:
            self.log_action("數據完整性良好", "SUCCESS")
        
        return True
    
    def execute(self) -> bool:
        """執行分析"""
        self.print_header("開始系統分析")
        
        success = True
        success &= self.analyze_codebase()
        success &= self.analyze_database()
        success &= self.analyze_system_health()
        
        return success


class ProjectManager:
    """專案主管理器"""
    
    def __init__(self):
        self.managers = {
            'test': TestManager(),
            'deployment': DeploymentManager(),
            'analysis': AnalysisManager()
        }
        
    def print_main_header(self):
        """打印主標題"""
        print("🎯" + "="*78 + "🎯")
        print("                    OOP 專案管理系統")
        print("                  統一管理測試、部署、分析")
        print("🎯" + "="*78 + "🎯")
    
    def run_all(self) -> Dict[str, bool]:
        """運行所有管理器"""
        self.print_main_header()
        
        results = {}
        
        for name, manager in self.managers.items():
            print(f"\n🚀 啟動 {manager.name}...")
            try:
                results[name] = manager.execute()
                
                # 保存報告
                report_file = f"{name.upper()}_REPORT.md"
                with open(report_file, 'w', encoding='utf-8') as f:
                    f.write(manager.generate_report())
                
                print(f"📄 {manager.name}報告已保存: {report_file}")
                
            except Exception as e:
                print(f"❌ {manager.name}執行失敗: {str(e)}")
                results[name] = False
        
        return results
    
    def run_single(self, manager_name: str) -> bool:
        """運行單一管理器"""
        if manager_name not in self.managers:
            print(f"❌ 未知的管理器: {manager_name}")
            return False
        
        self.print_main_header()
        
        manager = self.managers[manager_name]
        print(f"\n🚀 啟動 {manager.name}...")
        
        try:
            result = manager.execute()
            
            # 保存報告
            report_file = f"{manager_name.upper()}_REPORT.md"
            with open(report_file, 'w', encoding='utf-8') as f:
                f.write(manager.generate_report())
            
            print(f"📄 {manager.name}報告已保存: {report_file}")
            return result
            
        except Exception as e:
            print(f"❌ {manager.name}執行失敗: {str(e)}")
            return False
    
    def generate_summary_report(self, results: Dict[str, bool]) -> str:
        """生成總結報告"""
        total = len(results)
        passed = sum(results.values())
        
        report = f"""# 🎯 OOP專案管理系統總結報告

## 📊 執行統計
- 總管理器數: {total}
- ✅ 成功: {passed}
- ❌ 失敗: {total - passed}
- 📈 成功率: {passed/total*100:.1f}%

## 📋 詳細結果
"""
        
        for name, success in results.items():
            status = "✅ 成功" if success else "❌ 失敗"
            report += f"- {self.managers[name].name}: {status}\n"
        
        report += f"""
## 🎯 總結
{"🎉 所有模組運行正常，專案狀態良好！" if all(results.values()) else "⚠️ 部分模組需要注意，請查看詳細報告。"}

---
*生成時間: {time.strftime('%Y-%m-%d %H:%M:%S')}*
*OOP專案管理系統 v1.0*
"""
        
        return report


def main():
    """主函數"""
    import argparse
    
    parser = argparse.ArgumentParser(description='OOP專案管理系統')
    parser.add_argument('--manager', '-m', 
                       choices=['test', 'deployment', 'analysis', 'all'], 
                       default='all',
                       help='指定要運行的管理器')
    
    args = parser.parse_args()
    
    project_manager = ProjectManager()
    
    if args.manager == 'all':
        results = project_manager.run_all()
        
        # 生成總結報告
        summary = project_manager.generate_summary_report(results)
        with open('PROJECT_SUMMARY_REPORT.md', 'w', encoding='utf-8') as f:
            f.write(summary)
        
        print(f"\n📄 總結報告已保存: PROJECT_SUMMARY_REPORT.md")
        
        if all(results.values()):
            print("\n🎉 所有模組運行成功！專案狀態良好！")
        else:
            print("\n⚠️ 部分模組需要注意，請查看詳細報告。")
    
    else:
        success = project_manager.run_single(args.manager)
        if success:
            print(f"\n🎉 {args.manager}管理器運行成功！")
        else:
            print(f"\n❌ {args.manager}管理器運行失敗！")


if __name__ == "__main__":
    main()
