#!/usr/bin/env python3
"""
用戶資料查看工具
"""

import os
import sys
import django
from datetime import datetime

# 設定Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.contrib.auth.models import User
from django.conf import settings

def main():
    print("=" * 80)
    print("                     用戶資料庫管理工具")
    print("=" * 80)
    
    # 資料庫資訊
    db_config = settings.DATABASES['default']
    print(f"📁 資料庫類型: {db_config['ENGINE'].split('.')[-1].upper()}")
    print(f"📁 資料庫位置: {db_config['NAME']}")
    
    if os.path.exists(db_config['NAME']):
        file_size = os.path.getsize(db_config['NAME'])
        print(f"📁 檔案大小: {file_size:,} bytes ({file_size/1024:.1f} KB)")
    
    print("\n" + "=" * 80)
    print("                        所有用戶資料")
    print("=" * 80)
    
    users = User.objects.all().order_by('id')
    
    for i, user in enumerate(users, 1):
        # 權限標籤
        permissions = []
        if user.is_superuser:
            permissions.append("� 超級用戶")
        if user.is_staff:
            permissions.append("🟡 管理員")
        if not user.is_active:
            permissions.append("⚫ 已停用")
        
        permission_str = " | ".join(permissions) if permissions else "🟢 一般用戶"
        
        print(f"\n┌─ 👤 用戶 #{user.id} ──────────────────────────────────────")
        print(f"│ 用戶名稱: {user.username}")
        print(f"│ 真實姓名: {user.get_full_name() or '未設定'}")
        print(f"│ 電子信箱: {user.email or '未設定'}")
        print(f"│ 權限狀態: {permission_str}")
        print(f"│ 註冊時間: {user.date_joined.strftime('%Y年%m月%d日 %H:%M:%S')}")
        
        if user.last_login:
            print(f"│ 最後登入: {user.last_login.strftime('%Y年%m月%d日 %H:%M:%S')}")
        else:
            print(f"│ 最後登入: 從未登入")
        
        # 用戶相關的資料
        events_count = user.event_set.count() if hasattr(user, 'event_set') else 0
        print(f"│ 發布活動: {events_count} 個")
        
        print(f"└──────────────────────────────────────────────────────────")
        
        # 每5個用戶後加一個分隔
        if i % 5 == 0 and i < len(users):
            print()
    
    # 統計資訊
    print(f"\n" + "=" * 80)
    print("                          統計摘要")
    print("=" * 80)
    
    total_users = User.objects.count()
    superusers = User.objects.filter(is_superuser=True).count()
    staff_users = User.objects.filter(is_staff=True).count()
    active_users = User.objects.filter(is_active=True).count()
    
    print(f"📊 總用戶數量: {total_users:>3} 人")
    print(f"🔴 超級用戶數: {superusers:>3} 人 ({superusers/total_users*100:.1f}%)")
    print(f"🟡 管理員數量: {staff_users:>3} 人 ({staff_users/total_users*100:.1f}%)")
    print(f"🟢 啟用用戶數: {active_users:>3} 人 ({active_users/total_users*100:.1f}%)")
    print(f"⚫ 停用用戶數: {total_users-active_users:>3} 人 ({(total_users-active_users)/total_users*100:.1f}%)")
    
    print(f"\n" + "=" * 80)
    print("                     快速操作指南")
    print("=" * 80)
    print("🔧 用戶管理頁面: http://127.0.0.1:8000/management/users/")
    print("⚙️  Django管理後台: http://127.0.0.1:8000/admin/")
    print("🏠 前台首頁: http://127.0.0.1:8000/")
    print("=" * 80)

if __name__ == "__main__":
    main()
