#!/usr/bin/env python
"""
創建真實的精選活動數據
"""

import os
import sys
import django
from datetime import datetime, timedelta
from django.utils import timezone

# 設置Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from events.models import Event, EventType
from django.contrib.auth.models import User

def create_real_featured_events():
    """創建真實的精選活動數據"""
    print("🎉 開始創建精選活動數據...")
    print("=" * 50)
    
    # 確保有 EventType
    event_types = []
    for type_name, description in [
        ('企業聚會', '公司聚會、團建活動、年會等'),
        ('生日派對', '生日慶祝、週年慶等'),
        ('婚禮', '婚禮慶典、訂婚派對等'),
        ('尾牙', '公司尾牙、春酒等'),
        ('其他', '其他各類聚會活動'),
    ]:
        event_type, created = EventType.objects.get_or_create(
            name=type_name,
            defaults={'description': description}
        )
        event_types.append(event_type)
        if created:
            print(f"✅ 創建活動類型: {event_type.name}")
    
    # 獲取或創建示範用戶
    demo_users = []
    for username, email, first_name in [
        ('demo_organizer1', 'organizer1@example.com', '王小明'),
        ('demo_organizer2', 'organizer2@example.com', '李小華'),
        ('demo_organizer3', 'organizer3@example.com', '張小美'),
        ('demo_organizer4', 'organizer4@example.com', '陳大偉'),
    ]:
        user, created = User.objects.get_or_create(
            username=username,
            defaults={
                'email': email,
                'first_name': first_name,
                'is_active': True
            }
        )
        demo_users.append(user)
        if created:
            print(f"✅ 創建示範用戶: {user.first_name}")
    
    # 精選活動數據
    featured_events_data = [
        {
            'title': '台北101跨年企業包場派對',
            'description': '在台北最高的摩天大樓舉辦專屬企業跨年活動，享受360度城市夜景，包含專業燈光音響、頂級餐飲服務、專屬攝影團隊記錄每個精彩瞬間。活動將邀請知名DJ現場演出，提供多元化的娛樂節目，讓您的團隊在年末享受最難忘的慶祝時光。',
            'event_type': event_types[0],  # 企業聚會
            'organizer': demo_users[0],
            'event_date': timezone.now() + timedelta(days=45),
            'location': '台北市信義區台北101大樓88樓',
            'expected_attendees': 150,
            'budget_min': 800000,
            'budget_max': 1200000,
            'requirements': '需要專業燈光音響設備、頂級餐飲服務、專屬攝影師、安全保全服務',
            'duration_hours': 6,
            'contact_person': '王小明',
            'contact_phone': '02-2345-6789',
            'contact_email': 'organizer1@example.com',
            'is_featured': True,
        },
        {
            'title': '高雄港灣豪華遊艇生日派對',
            'description': '在高雄美麗的港灣租借豪華遊艇，為重要的人舉辦海上生日派對。遊艇配備完整的娛樂設施，包含海鮮BBQ、調酒師現場調製特色雞尾酒、專業DJ播放音樂。在海風輕拂下欣賞高雄港的美麗夜景，創造獨一無二的生日回憶。',
            'event_type': event_types[1],  # 生日派對
            'organizer': demo_users[1],
            'event_date': timezone.now() + timedelta(days=30),
            'location': '高雄市鼓山區高雄港遊艇碼頭',
            'expected_attendees': 80,
            'budget_min': 300000,
            'budget_max': 500000,
            'requirements': '豪華遊艇租借、海鮮BBQ、專業調酒師、DJ音響設備、安全救生設備',
            'duration_hours': 5,
            'contact_person': '李小華',
            'contact_phone': '07-3456-7890',
            'contact_email': 'organizer2@example.com',
            'is_featured': True,
        },
        {
            'title': '台中歌劇院戶外花園婚禮',
            'description': '在台中國家歌劇院的戶外花園舉辦浪漫的戶外婚禮典禮。典雅的建築背景搭配精心設計的花藝布置，專業婚禮樂團現場演奏，提供頂級法式料理招待賓客。專業婚禮攝影師全程記錄，讓這個特別的日子永遠珍藏在心中。',
            'event_type': event_types[2],  # 婚禮
            'organizer': demo_users[2],
            'event_date': timezone.now() + timedelta(days=60),
            'location': '台中市西屯區台中國家歌劇院戶外花園',
            'expected_attendees': 120,
            'budget_min': 600000,
            'budget_max': 900000,
            'requirements': '戶外花藝布置、專業婚禮樂團、法式料理餐飲、婚禮攝影攝影師、音響燈光設備',
            'duration_hours': 8,
            'contact_person': '張小美',
            'contact_phone': '04-2345-6789',
            'contact_email': 'organizer3@example.com',
            'is_featured': True,
        },
        {
            'title': '新竹科學園區年終尾牙晚會',
            'description': '為科技公司員工舉辦盛大的年終尾牙晚會，包含豪華自助晚餐、專業表演節目、抽獎活動、團隊競賽遊戲。邀請知名藝人表演，提供豐富的獎品抽獎，讓辛苦工作一年的員工們享受歡樂的慶祝時光，增進同事間的感情。',
            'event_type': event_types[3],  # 尾牙
            'organizer': demo_users[3],
            'event_date': timezone.now() + timedelta(days=15),
            'location': '新竹市東區新竹喜來登大飯店國際會議廳',
            'expected_attendees': 300,
            'budget_min': 500000,
            'budget_max': 800000,
            'requirements': '豪華自助晚餐、專業表演節目、音響燈光設備、抽獎獎品、主持人、攝影師',
            'duration_hours': 4,
            'contact_person': '陳大偉',
            'contact_phone': '03-5678-9012',
            'contact_email': 'organizer4@example.com',
            'is_featured': True,
        },
        {
            'title': '台南古蹟文化主題聚會',
            'description': '在台南歷史悠久的古蹟場地舉辦獨特的文化主題聚會，結合傳統與現代元素。提供在地特色小吃、傳統音樂表演、文化導覽解說、手作體驗活動。讓參與者在品味台南美食的同時，深度體驗台灣豐富的歷史文化。',
            'event_type': event_types[4],  # 其他
            'organizer': demo_users[0],
            'event_date': timezone.now() + timedelta(days=25),
            'location': '台南市中西區赤崁樓文化園區',
            'expected_attendees': 60,
            'budget_min': 150000,
            'budget_max': 250000,
            'requirements': '古蹟場地租借、在地特色餐飲、傳統音樂表演、文化導覽員、手作體驗材料',
            'duration_hours': 4,
            'contact_person': '王小明',
            'contact_phone': '06-2345-6789',
            'contact_email': 'organizer1@example.com',
            'is_featured': True,
        },
        {
            'title': '桃園機場附近國際商務晚宴',
            'description': '為國際商務人士舉辦的高端晚宴活動，地點選在桃園機場附近的五星級飯店。提供多國料理、專業翻譯服務、商務交流環節、精緻的餐具擺設。適合企業招待國外客戶或舉辦國際商務會議後的社交聚會。',
            'event_type': event_types[0],  # 企業聚會
            'organizer': demo_users[1],
            'event_date': timezone.now() + timedelta(days=40),
            'location': '桃園市大園區桃園諾富特華航桃園機場飯店',
            'expected_attendees': 100,
            'budget_min': 400000,
            'budget_max': 600000,
            'requirements': '多國料理餐飲、專業翻譯服務、商務簡報設備、迎賓服務、交通接駁',
            'duration_hours': 3,
            'contact_person': '李小華',
            'contact_phone': '03-3456-7890',
            'contact_email': 'organizer2@example.com',
            'is_featured': True,
        }
    ]
    
    # 創建精選活動
    created_count = 0
    for event_data in featured_events_data:
        # 檢查是否已存在相同標題的活動
        if not Event.objects.filter(title=event_data['title']).exists():
            event = Event.objects.create(
                title=event_data['title'],
                description=event_data['description'],
                event_type=event_data['event_type'],
                organizer=event_data['organizer'],
                event_date=event_data['event_date'],
                location=event_data['location'],
                expected_attendees=event_data['expected_attendees'],
                budget_min=event_data['budget_min'],
                budget_max=event_data['budget_max'],
                requirements=event_data['requirements'],
                duration_hours=event_data['duration_hours'],
                contact_person=event_data['contact_person'],
                contact_phone=event_data['contact_phone'],
                contact_email=event_data['contact_email'],
                status='approved',  # 直接設為已通過
                is_featured=event_data['is_featured'],
            )
            print(f"✅ 創建精選活動: {event.title}")
            created_count += 1
        else:
            print(f"⚠️ 活動已存在: {event_data['title']}")
    
    print(f"\n🎉 完成！共創建了 {created_count} 個精選活動")
    print("=" * 50)
    
    # 顯示統計資訊
    total_events = Event.objects.count()
    featured_events = Event.objects.filter(is_featured=True).count()
    approved_events = Event.objects.filter(status='approved').count()
    
    print(f"📊 活動統計:")
    print(f"   總活動數: {total_events}")
    print(f"   精選活動: {featured_events}")
    print(f"   已通過活動: {approved_events}")

def main():
    """主函數"""
    create_real_featured_events()

if __name__ == '__main__':
    main()
