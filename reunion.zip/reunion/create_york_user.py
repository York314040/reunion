#!/usr/bin/env python
"""
創建York超級用戶
"""
import os
import sys
import django

# 設置 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.contrib.auth.models import User

def create_york_user():
    """創建York超級用戶"""
    print("正在創建York超級用戶...")
    
    # 檢查用戶是否已存在
    if User.objects.filter(username='York').exists():
        print("York用戶已存在！")
        user = User.objects.get(username='York')
        print(f"用戶名: {user.username}")
        print(f"信箱: {user.email}")
        print(f"超級用戶: {user.is_superuser}")
        print(f"管理員: {user.is_staff}")
        print(f"啟用: {user.is_active}")
        return
    
    # 創建York超級用戶
    york_user = User.objects.create_user(
        username='York',
        email='wssd314040@gmail.com',
        password='123456',
        first_name='York',
        last_name='User',
        is_superuser=True,
        is_staff=True,
        is_active=True
    )
    
    print("York超級用戶創建成功！")
    print(f"用戶名: {york_user.username}")
    print(f"信箱: {york_user.email}")
    print(f"密碼: 123456")
    print(f"超級用戶: {york_user.is_superuser}")
    print(f"管理員: {york_user.is_staff}")
    print(f"啟用: {york_user.is_active}")

if __name__ == "__main__":
    create_york_user()
