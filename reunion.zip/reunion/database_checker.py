#!/usr/bin/env python
"""
數據庫完整性檢查器 - 全面檢查數據庫結構、數據一致性和性能
"""

import os
import sys
import time
from datetime import datetime
from typing import Dict, Any, List

# 設定 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')

import django
django.setup()

from django.db import connection, transaction
from django.contrib.auth.models import User
from django.core.management import call_command
from django.db.models import Count, Q, F
from django.utils import timezone
from datetime import timedelta
from events.models import Event, EventType
from suppliers.models import Supplier, ServiceCategory
from dj_management.models import DJ, DJCategory, DJRating, DJBooking
from messaging.models import Conversation, Message, Quote, Notification


class DatabaseIntegrityChecker:
    """數據庫完整性檢查器"""
    
    def __init__(self):
        self.results = {
            'timestamp': datetime.now().isoformat(),
            'structure': {},
            'data_integrity': {},
            'performance': {},
            'statistics': {},
            'issues': [],
            'recommendations': []
        }
    
    def check_database_structure(self) -> Dict[str, Any]:
        """檢查數據庫結構"""
        print("🏗️ 檢查數據庫結構...")
        
        structure_info = {}
        
        try:
            with connection.cursor() as cursor:
                # 獲取所有表
                tables = connection.introspection.table_names()
                structure_info['total_tables'] = len(tables)
                structure_info['tables'] = tables
                
                # 檢查關鍵表是否存在
                required_tables = [
                    'auth_user', 'events_event', 'events_eventtype',
                    'suppliers_supplier', 'suppliers_servicecategory',
                    'dj_management_dj', 'dj_management_djcategory',
                    'messaging_conversation', 'messaging_message'
                ]
                
                missing_tables = [table for table in required_tables if table not in tables]
                structure_info['missing_required_tables'] = missing_tables
                structure_info['required_tables_present'] = len(missing_tables) == 0
                
                # 檢查索引
                indexes_info = {}
                for table in ['auth_user', 'events_event', 'suppliers_supplier', 'dj_management_dj']:
                    if table in tables:
                        try:
                            indexes = connection.introspection.get_indexes(cursor, table)
                            indexes_info[table] = len(indexes)
                        except:
                            indexes_info[table] = 0
                
                structure_info['indexes'] = indexes_info
                
        except Exception as e:
            structure_info['error'] = str(e)
        
        return structure_info
    
    def check_data_integrity(self) -> Dict[str, Any]:
        """檢查數據一致性"""
        print("🔍 檢查數據一致性...")
        
        integrity_info = {}
        
        try:
            # 檢查孤立記錄
            orphan_checks = {}
            
            # 檢查供應商是否有對應的用戶
            suppliers_without_users = Supplier.objects.filter(user__isnull=True).count()
            orphan_checks['suppliers_without_users'] = suppliers_without_users
            
            # 檢查DJ是否有對應的用戶
            djs_without_users = DJ.objects.filter(user__isnull=True).count()
            orphan_checks['djs_without_users'] = djs_without_users
            
            # 檢查事件是否有有效的建立者
            events_without_creators = Event.objects.filter(created_by__isnull=True).count()
            orphan_checks['events_without_creators'] = events_without_creators
            
            # 檢查消息是否有有效的會話
            messages_without_conversations = Message.objects.filter(conversation__isnull=True).count()
            orphan_checks['messages_without_conversations'] = messages_without_conversations
            
            integrity_info['orphan_records'] = orphan_checks
            integrity_info['has_orphan_records'] = any(count > 0 for count in orphan_checks.values())
            
            # 檢查外鍵約束
            foreign_key_checks = {}
            
            # 檢查用戶相關的外鍵
            try:
                # 檢查是否有無效的用戶引用
                invalid_supplier_users = Supplier.objects.exclude(user__in=User.objects.all()).count()
                foreign_key_checks['invalid_supplier_users'] = invalid_supplier_users
                
                invalid_dj_users = DJ.objects.exclude(user__in=User.objects.all()).count()
                foreign_key_checks['invalid_dj_users'] = invalid_dj_users
                
                invalid_event_creators = Event.objects.exclude(created_by__in=User.objects.all()).count()
                foreign_key_checks['invalid_event_creators'] = invalid_event_creators
                
            except Exception as e:
                foreign_key_checks['error'] = str(e)
            
            integrity_info['foreign_key_integrity'] = foreign_key_checks
            
            # 檢查數據範圍
            range_checks = {}
            
            # 檢查DJ評分範圍
            invalid_ratings = DJRating.objects.filter(Q(rating__lt=1) | Q(rating__gt=5)).count()
            range_checks['invalid_dj_ratings'] = invalid_ratings
            
            # 檢查價格範圍
            invalid_supplier_prices = Supplier.objects.filter(
                price_range_min__gt=F('price_range_max')
            ).count() if hasattr(Supplier, 'price_range_min') else 0
            range_checks['invalid_supplier_prices'] = invalid_supplier_prices
            
            integrity_info['data_ranges'] = range_checks
            
        except Exception as e:
            integrity_info['error'] = str(e)
        
        return integrity_info
    
    def check_performance(self) -> Dict[str, Any]:
        """檢查數據庫性能"""
        print("⚡ 檢查數據庫性能...")
        
        performance_info = {}
        
        try:
            # 測試查詢性能
            query_times = {}
            
            # 測試用戶查詢
            start_time = time.time()
            user_count = User.objects.count()
            query_times['user_count_query'] = (time.time() - start_time) * 1000
            
            # 測試事件查詢
            start_time = time.time()
            event_count = Event.objects.count()
            query_times['event_count_query'] = (time.time() - start_time) * 1000
            
            # 測試複雜查詢
            start_time = time.time()
            active_suppliers = Supplier.objects.filter(status='approved').count()
            query_times['filtered_supplier_query'] = (time.time() - start_time) * 1000
            
            # 測試聯接查詢
            start_time = time.time()
            users_with_suppliers = User.objects.filter(supplier__isnull=False).count()
            query_times['join_query'] = (time.time() - start_time) * 1000
            
            performance_info['query_times_ms'] = query_times
            performance_info['avg_query_time_ms'] = sum(query_times.values()) / len(query_times)
            performance_info['slow_queries'] = [name for name, time in query_times.items() if time > 100]
            
            # 檢查數據庫大小
            try:
                with connection.cursor() as cursor:
                    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
                    tables = cursor.fetchall()
                    
                    table_sizes = {}
                    for table in tables:
                        table_name = table[0]
                        cursor.execute(f"SELECT COUNT(*) FROM {table_name};")
                        row_count = cursor.fetchone()[0]
                        table_sizes[table_name] = row_count
                    
                    performance_info['table_sizes'] = table_sizes
                    performance_info['total_records'] = sum(table_sizes.values())
                    
            except Exception as e:
                performance_info['size_check_error'] = str(e)
            
        except Exception as e:
            performance_info['error'] = str(e)
        
        return performance_info
    
    def get_database_statistics(self) -> Dict[str, Any]:
        """獲取數據庫統計信息"""
        print("📊 收集數據庫統計信息...")
        
        stats = {}
        
        try:
            # 基本統計
            stats['users'] = {
                'total': User.objects.count(),
                'active': User.objects.filter(is_active=True).count(),
                'staff': User.objects.filter(is_staff=True).count(),
                'superusers': User.objects.filter(is_superuser=True).count()
            }
            
            stats['events'] = {
                'total': Event.objects.count(),
                'by_status': dict(Event.objects.values('status').annotate(count=Count('id')).values_list('status', 'count')),
                'event_types': EventType.objects.count()
            }
            
            stats['suppliers'] = {
                'total': Supplier.objects.count(),
                'approved': Supplier.objects.filter(status='approved').count(),
                'pending': Supplier.objects.filter(status='pending').count(),
                'featured': Supplier.objects.filter(featured=True).count(),
                'service_categories': ServiceCategory.objects.count()
            }
            
            stats['djs'] = {
                'total': DJ.objects.count(),
                'approved': DJ.objects.filter(status='approved').count(),
                'bookings': DJBooking.objects.count(),
                'ratings': DJRating.objects.count(),
                'categories': DJCategory.objects.count()
            }
            
            stats['messaging'] = {
                'conversations': Conversation.objects.count(),
                'messages': Message.objects.count(),
                'quotes': Quote.objects.count(),
                'notifications': Notification.objects.count()
            }
            
            # 計算活躍度
            recent_conversations = Conversation.objects.filter(
                updated_at__gte=timezone.now() - timedelta(days=30)
            ).count() if hasattr(Conversation, 'updated_at') else 0
            
            stats['activity'] = {
                'recent_conversations': recent_conversations,
                'total_content_items': (
                    stats['events']['total'] + 
                    stats['suppliers']['total'] + 
                    stats['djs']['total']
                )
            }
            
        except Exception as e:
            stats['error'] = str(e)
        
        return stats
    
    def identify_issues(self):
        """識別問題"""
        print("🔎 識別潛在問題...")
        
        issues = []
        recommendations = []
        
        # 檢查結構問題
        if 'structure' in self.results:
            structure = self.results['structure']
            if not structure.get('required_tables_present', True):
                issues.append("缺少必要的數據庫表")
                recommendations.append("運行 python manage.py migrate 來創建缺少的表")
        
        # 檢查數據完整性問題
        if 'data_integrity' in self.results:
            integrity = self.results['data_integrity']
            if integrity.get('has_orphan_records', False):
                issues.append("發現孤立記錄")
                recommendations.append("清理無效的數據引用")
            
            orphans = integrity.get('orphan_records', {})
            for record_type, count in orphans.items():
                if count > 0:
                    issues.append(f"發現 {count} 個 {record_type}")
        
        # 檢查性能問題
        if 'performance' in self.results:
            performance = self.results['performance']
            slow_queries = performance.get('slow_queries', [])
            if slow_queries:
                issues.append(f"檢測到 {len(slow_queries)} 個慢查詢")
                recommendations.append("考慮為常用查詢字段添加索引")
            
            avg_time = performance.get('avg_query_time_ms', 0)
            if avg_time > 50:
                issues.append("平均查詢時間較慢")
                recommendations.append("優化數據庫查詢和添加適當的索引")
        
        # 檢查數據量
        if 'statistics' in self.results:
            stats = self.results['statistics']
            total_records = sum([
                stats.get('users', {}).get('total', 0),
                stats.get('events', {}).get('total', 0),
                stats.get('suppliers', {}).get('total', 0),
                stats.get('djs', {}).get('total', 0)
            ])
            
            if total_records == 0:
                issues.append("數據庫中沒有任何數據")
                recommendations.append("使用管理界面或fixtures加載測試數據")
            elif total_records < 10:
                issues.append("數據量較少，可能需要更多測試數據")
                recommendations.append("添加更多測試數據以進行全面測試")
        
        self.results['issues'] = issues
        self.results['recommendations'] = recommendations
    
    def run_comprehensive_check(self) -> Dict[str, Any]:
        """運行全面檢查"""
        print("🔍 開始數據庫完整性檢查")
        print("="*60)
        
        # 執行各項檢查
        self.results['structure'] = self.check_database_structure()
        self.results['data_integrity'] = self.check_data_integrity()
        self.results['performance'] = self.check_performance()
        self.results['statistics'] = self.get_database_statistics()
        
        # 識別問題
        self.identify_issues()
        
        return self.results
    
    def generate_report(self) -> str:
        """生成報告"""
        report = f"""# 🗄️ 數據庫完整性檢查報告

**檢查時間**: {self.results['timestamp']}

---

## 📊 數據庫統計

"""
        
        if 'statistics' in self.results:
            stats = self.results['statistics']
            
            if 'users' in stats:
                users = stats['users']
                report += f"""### 👥 用戶統計
- **總用戶數**: {users.get('total', 0)}
- **活躍用戶**: {users.get('active', 0)}
- **管理員**: {users.get('staff', 0)}
- **超級用戶**: {users.get('superusers', 0)}

"""
            
            if 'events' in stats:
                events = stats['events']
                report += f"""### 🎉 事件統計
- **總事件數**: {events.get('total', 0)}
- **事件類型**: {events.get('event_types', 0)}

"""
            
            if 'suppliers' in stats:
                suppliers = stats['suppliers']
                report += f"""### 🏢 供應商統計
- **總供應商數**: {suppliers.get('total', 0)}
- **已審核**: {suppliers.get('approved', 0)}
- **待審核**: {suppliers.get('pending', 0)}
- **推薦供應商**: {suppliers.get('featured', 0)}

"""
            
            if 'djs' in stats:
                djs = stats['djs']
                report += f"""### 🎵 DJ統計
- **總DJ數**: {djs.get('total', 0)}
- **已審核**: {djs.get('approved', 0)}
- **預訂數**: {djs.get('bookings', 0)}
- **評價數**: {djs.get('ratings', 0)}

"""
        
        report += "---\n\n## 🏗️ 結構檢查\n\n"
        
        if 'structure' in self.results:
            structure = self.results['structure']
            status = "✅" if structure.get('required_tables_present', True) else "❌"
            report += f"**數據庫結構**: {status}\n"
            report += f"- **總表數**: {structure.get('total_tables', 0)}\n"
            
            if structure.get('missing_required_tables'):
                report += f"- **缺少的表**: {', '.join(structure['missing_required_tables'])}\n"
        
        report += "\n---\n\n## 🔍 完整性檢查\n\n"
        
        if 'data_integrity' in self.results:
            integrity = self.results['data_integrity']
            status = "✅" if not integrity.get('has_orphan_records', True) else "❌"
            report += f"**數據完整性**: {status}\n"
            
            orphans = integrity.get('orphan_records', {})
            for record_type, count in orphans.items():
                if count > 0:
                    report += f"- **{record_type}**: {count} 個問題\n"
        
        report += "\n---\n\n## ⚡ 性能檢查\n\n"
        
        if 'performance' in self.results:
            performance = self.results['performance']
            avg_time = performance.get('avg_query_time_ms', 0)
            status = "✅" if avg_time < 50 else "⚠️" if avg_time < 100 else "❌"
            report += f"**查詢性能**: {status}\n"
            report += f"- **平均查詢時間**: {avg_time:.2f}ms\n"
            
            slow_queries = performance.get('slow_queries', [])
            if slow_queries:
                report += f"- **慢查詢**: {len(slow_queries)} 個\n"
        
        report += "\n---\n\n## ⚠️ 發現的問題\n\n"
        
        issues = self.results.get('issues', [])
        if issues:
            for issue in issues:
                report += f"- {issue}\n"
        else:
            report += "🎉 未發現重大問題！\n"
        
        report += "\n---\n\n## 💡 建議改進\n\n"
        
        recommendations = self.results.get('recommendations', [])
        if recommendations:
            for rec in recommendations:
                report += f"- {rec}\n"
        else:
            report += "數據庫狀態良好，無需特別改進。\n"
        
        return report
    
    def save_results(self):
        """保存結果"""
        import json
        
        # 保存JSON格式
        with open('database_integrity_results.json', 'w', encoding='utf-8') as f:
            json.dump(self.results, f, ensure_ascii=False, indent=2, default=str)
        
        # 保存報告
        report = self.generate_report()
        with open('DATABASE_INTEGRITY_REPORT.md', 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"\n📄 檢查結果已保存:")
        print(f"- 詳細結果: database_integrity_results.json")
        print(f"- 檢查報告: DATABASE_INTEGRITY_REPORT.md")


def main():
    """主函數"""
    checker = DatabaseIntegrityChecker()
    
    print("🗄️ 數據庫完整性檢查工具")
    print("="*60)
    
    # 運行檢查
    results = checker.run_comprehensive_check()
    
    # 顯示摘要
    print("\n" + "="*60)
    print("📊 檢查完成摘要")
    print("="*60)
    
    structure_ok = results.get('structure', {}).get('required_tables_present', True)
    integrity_ok = not results.get('data_integrity', {}).get('has_orphan_records', False)
    performance_ok = results.get('performance', {}).get('avg_query_time_ms', 0) < 100
    
    print(f"🏗️ 結構檢查: {'✅' if structure_ok else '❌'}")
    print(f"🔍 完整性檢查: {'✅' if integrity_ok else '❌'}")
    print(f"⚡ 性能檢查: {'✅' if performance_ok else '❌'}")
    
    issues_count = len(results.get('issues', []))
    print(f"⚠️ 發現問題: {issues_count} 個")
    
    if issues_count == 0:
        print("🎉 數據庫狀態良好！")
    else:
        print("💡 請查看詳細報告以了解改進建議")
    
    # 保存結果
    checker.save_results()
    
    return results


if __name__ == "__main__":
    main()
