#!/usr/bin/env python
"""
最終系統驗證測試
"""

import os
import sys
import django

# 設置Django環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')
django.setup()

from django.test import Client
from django.contrib.auth.models import User
from django.urls import reverse
from datetime import datetime
from django.core.files.uploadedfile import SimpleUploadedFile
from events.models import Event, EventType
from dj_management.models import DJ, DJCategory
from suppliers.models import Supplier, ServiceCategory
from users.models import Profile

def main():
    print("🎯 最終系統驗證測試")
    print("=" * 60)
    
    client = Client()
    results = []
    
    try:
        # 測試1: DJ創建（包含所有必需字段）
        print("\n1. 測試DJ創建...")
        
        dj_user = User.objects.create_user(
            username=f'final_dj_{int(datetime.now().timestamp())}',
            email='final_dj@test.com',
            password='test123'
        )
        
        profile = Profile.objects.get(user=dj_user)
        profile.user_type = 'dj'
        profile.save()
        
        category, created = DJCategory.objects.get_or_create(
            name='最終測試類別',
            defaults={'description': '測試用DJ類別'}
        )
        
        image_file = SimpleUploadedFile(
            "test.jpg", 
            b"test_image", 
            content_type="image/jpeg"
        )
        
        dj = DJ.objects.create(
            user=dj_user,
            stage_name='最終測試DJ',
            real_name='測試DJ姓名',
            category=category,
            description='專業DJ服務',
            experience_level='intermediate',
            specialties='Electronic Music',
            contact_phone='0912345678',
            contact_email='final_dj@test.com',
            price_per_hour=3000,  # 必需字段
            minimum_hours=2,
            profile_image=image_file,  # 必需字段
            service_areas='台北市',
            status='approved',
            is_available=True
        )
        
        results.append(("DJ創建", True, f"成功創建DJ: {dj.stage_name}"))
        print("✅ DJ創建成功")
        
    except Exception as e:
        results.append(("DJ創建", False, str(e)))
        print(f"❌ DJ創建失敗: {e}")
    
    try:
        # 測試2: 供應商創建（包含所有必需字段）
        print("\n2. 測試供應商創建...")
        
        supplier_user = User.objects.create_user(
            username=f'final_supplier_{int(datetime.now().timestamp())}',
            email='final_supplier@test.com',
            password='test123'
        )
        
        profile = Profile.objects.get(user=supplier_user)
        profile.user_type = 'supplier'
        profile.save()
        
        service_cat, created = ServiceCategory.objects.get_or_create(
            name='最終測試服務',
            defaults={'description': '測試用服務類別'}
        )
        
        supplier = Supplier.objects.create(
            user=supplier_user,
            company_name='最終測試供應商',
            description='專業供應商服務',
            experience_years=5,  # 必需字段
            service_area='台北市',
            contact_person='供應商聯絡人',  # 必需字段
            contact_phone='0987654321',
            contact_email='final_supplier@test.com',
            price_range_min=10000,  # 必需字段
            price_range_max=50000,  # 必需字段
            status='approved'
        )
        
        supplier.service_categories.add(service_cat)
        
        results.append(("供應商創建", True, f"成功創建供應商: {supplier.company_name}"))
        print("✅ 供應商創建成功")
        
    except Exception as e:
        results.append(("供應商創建", False, str(e)))
        print(f"❌ 供應商創建失敗: {e}")
    
    try:
        # 測試3: 一般用戶活動創建
        print("\n3. 測試活動創建...")
        
        normal_user = User.objects.create_user(
            username=f'final_user_{int(datetime.now().timestamp())}',
            email='final_user@test.com',
            password='test123'
        )
        
        profile = Profile.objects.get(user=normal_user)
        assert profile.user_type == 'normal'
        
        client.login(username=normal_user.username, password='test123')
        
        event_type, created = EventType.objects.get_or_create(
            name='最終測試活動',
            defaults={'description': '測試用活動類型'}
        )
        
        event_data = {
            'title': '最終系統測試活動',
            'description': '這是最終系統測試活動，用來驗證所有功能正常運作。',
            'event_type': event_type.id,
            'budget_min': 20000,
            'budget_max': 40000,
            'expected_attendees': 100,
            'event_date': '2024-12-31T19:00',
            'location': '台北市測試地點',
            'contact_person': '測試負責人',
            'contact_phone': '0911222333',
            'contact_email': 'final_user@test.com'
        }
        
        response = client.post(reverse('events:create_event'), event_data)
        
        if response.status_code == 302:
            event = Event.objects.filter(title='最終系統測試活動').first()
            if event:
                results.append(("活動創建", True, f"成功創建活動: {event.title}"))
                print("✅ 活動創建成功")
            else:
                results.append(("活動創建", False, "活動創建後未找到"))
                print("❌ 活動創建失敗: 未找到創建的活動")
        else:
            results.append(("活動創建", False, f"HTTP狀態碼: {response.status_code}"))
            print(f"❌ 活動創建失敗: 狀態碼 {response.status_code}")
        
    except Exception as e:
        results.append(("活動創建", False, str(e)))
        print(f"❌ 活動創建失敗: {e}")
    
    try:
        # 測試4: 權限控制
        print("\n4. 測試權限控制...")
        
        client.logout()
        
        protected_urls = ['/events/create/', '/messaging/']
        all_redirected = True
        
        for url in protected_urls:
            response = client.get(url)
            if response.status_code != 302:
                all_redirected = False
                break
        
        if all_redirected:
            results.append(("權限控制", True, "未登入用戶正確被重定向"))
            print("✅ 權限控制正常")
        else:
            results.append(("權限控制", False, "某些受保護頁面可以被未登入用戶訪問"))
            print("❌ 權限控制有問題")
        
    except Exception as e:
        results.append(("權限控制", False, str(e)))
        print(f"❌ 權限控制測試失敗: {e}")
    
    try:
        # 測試5: 頁面訪問
        print("\n5. 測試主要頁面...")
        
        pages = [
            ('/', '首頁'),
            ('/events/', '活動列表'),
            ('/suppliers/', '供應商列表'),
            ('/dj/', 'DJ列表'),
        ]
        
        all_accessible = True
        for url, name in pages:
            response = client.get(url)
            if response.status_code != 200:
                all_accessible = False
                print(f"  ❌ {name} 無法訪問 (狀態碼: {response.status_code})")
            else:
                print(f"  ✅ {name} 正常")
        
        if all_accessible:
            results.append(("頁面訪問", True, "所有主要頁面都可正常訪問"))
        else:
            results.append(("頁面訪問", False, "某些主要頁面無法正常訪問"))
        
    except Exception as e:
        results.append(("頁面訪問", False, str(e)))
        print(f"❌ 頁面訪問測試失敗: {e}")
    
    # 生成最終報告
    print("\n" + "=" * 60)
    print("📊 最終系統驗證報告")
    print("=" * 60)
    
    total_tests = len(results)
    passed_tests = sum(1 for _, success, _ in results if success)
    failed_tests = total_tests - passed_tests
    success_rate = (passed_tests / total_tests) * 100 if total_tests > 0 else 0
    
    print(f"總測試數: {total_tests}")
    print(f"通過測試: {passed_tests}")
    print(f"失敗測試: {failed_tests}")
    print(f"成功率: {success_rate:.1f}%")
    
    print(f"\n📋 詳細結果:")
    for test_name, success, details in results:
        status = "✅" if success else "❌"
        print(f"  {status} {test_name}: {details}")
    
    if success_rate == 100:
        print(f"\n🎉 完美！所有測試都通過了！")
        print(f"🎯 系統已準備好投入使用")
    elif success_rate >= 80:
        print(f"\n🎊 優秀！大部分功能正常")
        print(f"🔧 建議修復剩餘問題")
    elif success_rate >= 60:
        print(f"\n⚠️ 良好，但需要改進")
        print(f"🛠️ 請修復失敗的測試")
    else:
        print(f"\n🔴 需要重大改進")
        print(f"🚨 建議重新檢查系統")
    
    print(f"\n🏆 後端修復工作總結:")
    fixes = [
        "✅ 創建完整的users應用和Profile模型",
        "✅ 修復所有import和模型字段問題",
        "✅ 實現三種用戶角色（一般用戶、DJ、供應商）",
        "✅ 加強表單驗證和安全控制",
        "✅ 修復權限控制和頁面訪問",
        "✅ 確保核心功能正常運作",
        "✅ 完成綜合系統測試驗證"
    ]
    
    for fix in fixes:
        print(f"  {fix}")
    
    print("\n" + "=" * 60)
    print("🎊 B2B派對平台後端修復工作完成！")
    print("=" * 60)

if __name__ == '__main__':
    main()
