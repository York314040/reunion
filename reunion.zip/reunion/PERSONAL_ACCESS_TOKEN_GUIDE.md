# 🔑 Personal Access Token 使用指南

## 📋 完整步驟

### 第一步：獲取Personal Access Token

1. **前往GitHub Token設定頁面**
   - 點擊此連結：[https://github.com/settings/tokens](https://github.com/settings/tokens)
   - 或者：GitHub首頁 → 右上角頭像 → Settings → Developer settings → Personal access tokens → Tokens (classic)

2. **創建新Token**
   - 點擊 `Generate new token` → `Generate new token (classic)`
   - **Token名稱**：`Reunion Project Upload`
   - **過期時間**：選擇 `30 days` 或 `60 days`
   - **權限範圍**：勾選 `repo` (這會自動包含所有倉庫相關權限)

3. **複製Token**
   - 點擊 `Generate token`
   - 🚨 **立即複製Token** - 離開頁面後就看不到了！
   - Token格式類似：`ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

### 第二步：使用Token推送代碼

一旦您有了Token，執行以下命令之一：

#### 方法A：直接使用Token URL
```powershell
git push https://YOUR_TOKEN@github.com/York314040/reunion.git main
```

#### 方法B：設定遠程倉庫
```powershell
git remote set-url origin https://YOUR_TOKEN@github.com/York314040/reunion.git
git push -u origin main
```

#### 方法C：互動式輸入
```powershell
git push -u origin main
# 當提示輸入用戶名時：輸入 York314040
# 當提示輸入密碼時：輸入您的Token（不是GitHub密碼）
```

### 第三步：驗證推送成功

推送成功後您會看到：
```
Enumerating objects: xxx, done.
Counting objects: 100% (xxx/xxx), done.
Delta compression using up to x threads
Compressing objects: 100% (xxx/xxx), done.
Writing objects: 100% (xxx/xxx), xxxx KiB | xxxx.00 KiB/s, done.
Total xxx (delta xxx), reused xxx (delta xxx), pack-reused 0
remote: Resolving deltas: 100% (xxx/xxx), done.
To https://github.com/York314040/reunion.git
 * [new branch]      main -> main
Branch 'main' set up to track remote branch 'main' from 'origin'.
```

然後前往 https://github.com/York314040/reunion 確認文件已上傳。

## 🔧 故障排除

### 問題1：403 Forbidden
- 檢查Token是否正確複製
- 確認Token有 `repo` 權限
- 檢查GitHub用戶名是否正確

### 問題2：Token不工作
- 確認Token未過期
- 重新生成新的Token
- 檢查倉庫是否真的存在

### 問題3：用戶名錯誤
```powershell
git config user.name "York314040"
git config user.email "您的郵箱"
```

## ⚡ 快速命令

將下面的命令中的 `YOUR_TOKEN` 替換為您的實際Token：

```powershell
# 一條命令完成推送
git push https://YOUR_TOKEN@github.com/York314040/reunion.git main
```

## 🎯 重要提醒

1. **Token安全性**：
   - 不要將Token分享給他人
   - 不要將Token提交到代碼中
   - 定期更新Token

2. **Token權限**：
   - 只給予必要的權限
   - `repo` 權限足夠用於推送代碼

3. **備用方案**：
   - 如果Token方法失敗，可以使用ZIP上傳
   - 或者使用GitHub Desktop應用程式

---

**準備好Token後，請告訴我，我會幫您執行推送命令！** 🚀
