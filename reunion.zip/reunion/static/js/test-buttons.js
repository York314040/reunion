console.log('測試按鈕點擊功能');

// 當頁面載入完成後
$(document).ready(function() {
    console.log('頁面載入完成');
    console.log('Toggle superuser buttons:', $('.toggle-superuser').length);
    console.log('Toggle staff buttons:', $('.toggle-staff').length);
    console.log('Toggle active buttons:', $('.toggle-active').length);
    console.log('Delete buttons:', $('.delete-user').length);
    
    // 為所有按鈕添加點擊事件監聽器
    $('.toggle-superuser, .toggle-staff, .toggle-active, .delete-user').click(function() {
        console.log('按鈕被點擊了:', $(this).attr('class'));
        alert('按鈕點擊測試成功！');
    });
});
