#!/usr/bin/env python
"""
API端點全面測試器 - 測試所有API端點的功能性和性能
"""

import os
import sys
import time
import json
import requests
from datetime import datetime
from typing import Dict, Any, List

# 設定 Django 環境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'party_platform.settings')

import django
django.setup()

from django.test import Client
from django.contrib.auth.models import User
from django.urls import reverse, resolve, get_resolver
from django.conf import settings


class APITester:
    """API測試器"""
    
    def __init__(self, base_url: str = 'http://localhost:8000'):
        self.base_url = base_url
        self.client = Client()
        self.session = requests.Session()
        self.test_results = {
            'timestamp': datetime.now().isoformat(),
            'base_url': base_url,
            'endpoints': {},
            'performance': {},
            'security': {},
            'summary': {}
        }
        
    def discover_endpoints(self) -> List[Dict[str, str]]:
        """自動發現所有URL端點"""
        print("🔍 自動發現API端點...")
        
        endpoints = []
        resolver = get_resolver()
        
        def extract_urls(urlpatterns, prefix=''):
            for pattern in urlpatterns:
                try:
                    if hasattr(pattern, 'url_patterns'):
                        # 這是一個include()
                        extract_urls(pattern.url_patterns, prefix + str(pattern.pattern))
                    else:
                        # 這是一個實際的URL
                        url = prefix + str(pattern.pattern)
                        # 清理URL格式
                        url = url.replace('^', '').replace('$', '')
                        if not url.startswith('/'):
                            url = '/' + url
                            
                        # 跳過包含參數的URL
                        if '<' not in url and '(' not in url:
                            name = getattr(pattern, 'name', None)
                            endpoints.append({
                                'url': url,
                                'name': name or 'unnamed',
                                'pattern': str(pattern.pattern)
                            })
                except Exception as e:
                    continue
        
        try:
            extract_urls(resolver.url_patterns)
        except Exception as e:
            print(f"⚠️ URL發現過程中出現錯誤: {str(e)}")
        
        # 添加一些已知的重要端點
        known_endpoints = [
            {'url': '/', 'name': 'home', 'pattern': '^$'},
            {'url': '/events/', 'name': 'events_list', 'pattern': '^events/$'},
            {'url': '/suppliers/', 'name': 'suppliers_list', 'pattern': '^suppliers/$'},
            {'url': '/dj/', 'name': 'dj_list', 'pattern': '^dj/$'},
            {'url': '/accounts/login/', 'name': 'login', 'pattern': '^accounts/login/$'},
            {'url': '/register/', 'name': 'register', 'pattern': '^register/$'},
            {'url': '/admin/', 'name': 'admin', 'pattern': '^admin/'},
        ]
        
        # 合併並去重
        all_endpoints = endpoints + known_endpoints
        seen_urls = set()
        unique_endpoints = []
        
        for endpoint in all_endpoints:
            if endpoint['url'] not in seen_urls:
                seen_urls.add(endpoint['url'])
                unique_endpoints.append(endpoint)
        
        print(f"✅ 發現 {len(unique_endpoints)} 個端點")
        return unique_endpoints
    
    def test_endpoint_accessibility(self, endpoint: Dict[str, str]) -> Dict[str, Any]:
        """測試端點可訪問性"""
        url = endpoint['url']
        name = endpoint['name']
        
        try:
            start_time = time.time()
            response = self.client.get(url)
            end_time = time.time()
            
            response_time = (end_time - start_time) * 1000  # 轉換為毫秒
            
            result = {
                'url': url,
                'name': name,
                'status_code': response.status_code,
                'response_time_ms': round(response_time, 2),
                'content_length': len(response.content),
                'content_type': response.get('Content-Type', ''),
                'accessible': response.status_code in [200, 301, 302],
                'success': response.status_code == 200,
                'redirect': response.status_code in [301, 302, 303, 307, 308],
                'error': response.status_code >= 400
            }
            
            # 檢查響應內容
            if response.status_code == 200:
                try:
                    content = response.content.decode('utf-8', errors='ignore')
                    result['has_html'] = '<html' in content.lower()
                    result['has_title'] = '<title>' in content.lower()
                    result['has_navigation'] = 'nav' in content.lower() or 'navbar' in content.lower()
                    result['has_bootstrap'] = 'bootstrap' in content.lower()
                    result['has_jquery'] = 'jquery' in content.lower()
                except:
                    pass
            
            return result
            
        except Exception as e:
            return {
                'url': url,
                'name': name,
                'error': str(e),
                'accessible': False,
                'success': False
            }
    
    def test_http_methods(self, endpoint: Dict[str, str]) -> Dict[str, Any]:
        """測試HTTP方法支持"""
        url = endpoint['url']
        methods_to_test = ['GET', 'POST', 'PUT', 'DELETE', 'HEAD', 'OPTIONS']
        
        method_results = {}
        
        for method in methods_to_test:
            try:
                if method == 'GET':
                    response = self.client.get(url)
                elif method == 'POST':
                    response = self.client.post(url)
                elif method == 'PUT':
                    response = self.client.put(url)
                elif method == 'DELETE':
                    response = self.client.delete(url)
                elif method == 'HEAD':
                    response = self.client.head(url)
                elif method == 'OPTIONS':
                    response = self.client.options(url)
                
                method_results[method] = {
                    'status_code': response.status_code,
                    'allowed': response.status_code not in [405, 501]
                }
                
            except Exception as e:
                method_results[method] = {
                    'error': str(e),
                    'allowed': False
                }
        
        return method_results
    
    def test_security_headers(self, endpoint: Dict[str, str]) -> Dict[str, Any]:
        """測試安全標頭"""
        url = endpoint['url']
        
        try:
            response = self.client.get(url)
            headers = dict(response.items())
            
            security_headers = {
                'X-Content-Type-Options': headers.get('X-Content-Type-Options'),
                'X-Frame-Options': headers.get('X-Frame-Options'),
                'X-XSS-Protection': headers.get('X-XSS-Protection'),
                'Strict-Transport-Security': headers.get('Strict-Transport-Security'),
                'Content-Security-Policy': headers.get('Content-Security-Policy'),
                'Referrer-Policy': headers.get('Referrer-Policy')
            }
            
            security_score = sum(1 for header, value in security_headers.items() if value is not None)
            
            return {
                'headers': security_headers,
                'security_score': security_score,
                'max_score': len(security_headers),
                'security_percentage': round((security_score / len(security_headers)) * 100, 1)
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def run_comprehensive_test(self) -> Dict[str, Any]:
        """運行全面API測試"""
        print("🚀 開始全面API測試")
        print("="*60)
        
        # 發現端點
        endpoints = self.discover_endpoints()
        
        total_endpoints = len(endpoints)
        successful_tests = 0
        accessible_endpoints = 0
        
        print(f"📊 測試進度:")
        
        for i, endpoint in enumerate(endpoints, 1):
            print(f"  [{i:2d}/{total_endpoints}] 測試 {endpoint['url']} ... ", end="", flush=True)
            
            try:
                # 測試可訪問性
                access_result = self.test_endpoint_accessibility(endpoint)
                
                # 測試HTTP方法
                methods_result = self.test_http_methods(endpoint)
                
                # 測試安全標頭
                security_result = self.test_security_headers(endpoint)
                
                # 合併結果
                endpoint_result = {
                    'accessibility': access_result,
                    'methods': methods_result,
                    'security': security_result
                }
                
                self.test_results['endpoints'][endpoint['url']] = endpoint_result
                
                if access_result.get('accessible', False):
                    accessible_endpoints += 1
                    print("✅")
                else:
                    print("❌")
                    
                successful_tests += 1
                
            except Exception as e:
                print(f"💥 {str(e)[:50]}")
                self.test_results['endpoints'][endpoint['url']] = {
                    'error': str(e)
                }
        
        # 計算性能統計
        self.calculate_performance_stats()
        
        # 計算安全統計
        self.calculate_security_stats()
        
        # 生成摘要
        self.generate_summary(total_endpoints, accessible_endpoints, successful_tests)
        
        return self.test_results
    
    def calculate_performance_stats(self):
        """計算性能統計"""
        response_times = []
        content_sizes = []
        
        for url, result in self.test_results['endpoints'].items():
            if 'accessibility' in result:
                access = result['accessibility']
                if 'response_time_ms' in access:
                    response_times.append(access['response_time_ms'])
                if 'content_length' in access:
                    content_sizes.append(access['content_length'])
        
        if response_times:
            self.test_results['performance'] = {
                'avg_response_time_ms': round(sum(response_times) / len(response_times), 2),
                'min_response_time_ms': min(response_times),
                'max_response_time_ms': max(response_times),
                'total_endpoints_tested': len(response_times),
                'fast_endpoints': len([t for t in response_times if t < 100]),  # <100ms
                'slow_endpoints': len([t for t in response_times if t > 1000])  # >1s
            }
        
        if content_sizes:
            self.test_results['performance']['avg_content_size_bytes'] = round(sum(content_sizes) / len(content_sizes))
            self.test_results['performance']['total_content_size_bytes'] = sum(content_sizes)
    
    def calculate_security_stats(self):
        """計算安全統計"""
        security_scores = []
        
        for url, result in self.test_results['endpoints'].items():
            if 'security' in result and 'security_score' in result['security']:
                security_scores.append(result['security']['security_score'])
        
        if security_scores:
            self.test_results['security'] = {
                'avg_security_score': round(sum(security_scores) / len(security_scores), 1),
                'max_possible_score': 6,  # 6個安全標頭
                'endpoints_with_security': len([s for s in security_scores if s > 0]),
                'endpoints_without_security': len([s for s in security_scores if s == 0]),
                'security_percentage': round((sum(security_scores) / (len(security_scores) * 6)) * 100, 1)
            }
    
    def generate_summary(self, total: int, accessible: int, successful: int):
        """生成測試摘要"""
        self.test_results['summary'] = {
            'total_endpoints': total,
            'accessible_endpoints': accessible,
            'successful_tests': successful,
            'accessibility_rate': round((accessible / total) * 100, 1) if total > 0 else 0,
            'test_success_rate': round((successful / total) * 100, 1) if total > 0 else 0,
            'overall_grade': self.calculate_grade(accessible, total)
        }
    
    def calculate_grade(self, accessible: int, total: int) -> str:
        """計算整體評級"""
        if total == 0:
            return 'N/A'
        
        percentage = (accessible / total) * 100
        
        if percentage >= 95:
            return 'A+'
        elif percentage >= 90:
            return 'A'
        elif percentage >= 85:
            return 'B+'
        elif percentage >= 80:
            return 'B'
        elif percentage >= 75:
            return 'C+'
        elif percentage >= 70:
            return 'C'
        else:
            return 'D'
    
    def save_results(self):
        """保存測試結果"""
        # 保存JSON格式
        with open('api_test_results.json', 'w', encoding='utf-8') as f:
            json.dump(self.test_results, f, ensure_ascii=False, indent=2)
        
        # 生成報告
        report = self.generate_report()
        with open('API_TEST_REPORT.md', 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"\n📄 測試結果已保存:")
        print(f"- 詳細結果: api_test_results.json")
        print(f"- 測試報告: API_TEST_REPORT.md")
    
    def generate_report(self) -> str:
        """生成測試報告"""
        summary = self.test_results['summary']
        performance = self.test_results.get('performance', {})
        security = self.test_results.get('security', {})
        
        report = f"""# 🔌 API端點全面測試報告

**測試時間**: {self.test_results['timestamp']}
**基礎URL**: {self.test_results['base_url']}
**整體評級**: {summary['overall_grade']}

---

## 📊 測試摘要

- **總端點數**: {summary['total_endpoints']}
- **可訪問端點**: {summary['accessible_endpoints']}
- **測試成功率**: {summary['test_success_rate']}%
- **可訪問率**: {summary['accessibility_rate']}%

---

## ⚡ 性能統計

"""
        
        if performance:
            report += f"""- **平均響應時間**: {performance.get('avg_response_time_ms', 0):.2f}ms
- **最快響應**: {performance.get('min_response_time_ms', 0):.2f}ms
- **最慢響應**: {performance.get('max_response_time_ms', 0):.2f}ms
- **快速端點** (<100ms): {performance.get('fast_endpoints', 0)}
- **慢速端點** (>1s): {performance.get('slow_endpoints', 0)}
"""
        else:
            report += "無性能數據\n"
        
        report += "\n---\n\n## 🔒 安全統計\n\n"
        
        if security:
            report += f"""- **平均安全分數**: {security.get('avg_security_score', 0)}/6
- **安全性百分比**: {security.get('security_percentage', 0)}%
- **有安全標頭的端點**: {security.get('endpoints_with_security', 0)}
- **無安全標頭的端點**: {security.get('endpoints_without_security', 0)}
"""
        else:
            report += "無安全數據\n"
        
        report += "\n---\n\n## 📋 詳細端點測試結果\n\n"
        
        for url, result in self.test_results['endpoints'].items():
            if 'accessibility' in result:
                access = result['accessibility']
                status = "✅" if access.get('accessible') else "❌"
                status_code = access.get('status_code', 'N/A')
                response_time = access.get('response_time_ms', 0)
                
                report += f"### {url}\n\n"
                report += f"- **狀態**: {status} ({status_code})\n"
                report += f"- **響應時間**: {response_time:.2f}ms\n"
                
                if 'methods' in result:
                    allowed_methods = [method for method, data in result['methods'].items() 
                                     if data.get('allowed', False)]
                    report += f"- **支持的HTTP方法**: {', '.join(allowed_methods)}\n"
                
                if 'security' in result and 'security_percentage' in result['security']:
                    security_pct = result['security']['security_percentage']
                    report += f"- **安全標頭覆蓋率**: {security_pct}%\n"
                
                report += "\n"
        
        report += "---\n\n## 💡 建議改進\n\n"
        
        if summary['accessibility_rate'] < 90:
            report += "- 修復無法訪問的端點\n"
        
        if performance and performance.get('slow_endpoints', 0) > 0:
            report += "- 優化響應時間超過1秒的端點\n"
        
        if security and security.get('security_percentage', 0) < 80:
            report += "- 加強安全標頭配置\n"
            report += "- 建議添加Content-Security-Policy標頭\n"
            report += "- 建議添加X-Frame-Options標頭\n"
        
        return report


def main():
    """主函數"""
    print("🔌 API端點全面測試工具")
    print("="*60)
    
    # 檢查服務器是否運行
    try:
        response = requests.get('http://localhost:8000', timeout=5)
        print("✅ 檢測到本地服務器運行中")
    except:
        print("⚠️ 本地服務器未運行，將使用Django測試客戶端")
    
    # 創建測試器並運行測試
    tester = APITester()
    results = tester.run_comprehensive_test()
    
    # 顯示結果摘要
    print("\n" + "="*60)
    print("📊 測試完成摘要")
    print("="*60)
    
    summary = results['summary']
    print(f"🎯 整體評級: {summary['overall_grade']}")
    print(f"📈 可訪問率: {summary['accessibility_rate']}%")
    print(f"⚡ 測試成功率: {summary['test_success_rate']}%")
    
    if 'performance' in results:
        perf = results['performance']
        print(f"🏃 平均響應時間: {perf.get('avg_response_time_ms', 0):.2f}ms")
    
    if 'security' in results:
        sec = results['security']
        print(f"🔒 安全性: {sec.get('security_percentage', 0)}%")
    
    # 保存結果
    tester.save_results()
    
    return results


if __name__ == "__main__":
    main()
