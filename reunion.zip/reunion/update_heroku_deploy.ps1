# 🚀 Heroku 更新部署腳本 - 2024版本
Write-Host "================================" -ForegroundColor Cyan
Write-Host "    B2B派對平台 Heroku 更新部署" -ForegroundColor Cyan  
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""

# 檢查是否在正確的目錄
if (-not (Test-Path "manage.py")) {
    Write-Host "❌ 錯誤：請在項目根目錄運行此腳本" -ForegroundColor Red
    Read-Host "按任意鍵退出"
    exit 1
}

Write-Host "🔍 檢查項目狀態..." -ForegroundColor Yellow

# 檢查 Heroku CLI
try {
    $herokuVersion = heroku --version 2>$null
    Write-Host "✅ Heroku CLI 已安裝: $herokuVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ 錯誤：未找到 Heroku CLI" -ForegroundColor Red
    Write-Host "請先安裝 Heroku CLI：https://devcenter.heroku.com/articles/heroku-cli" -ForegroundColor Yellow
    exit 1
}

# 檢查登錄狀態
try {
    $whoami = heroku auth:whoami 2>$null
    Write-Host "✅ 已登錄 Heroku: $whoami" -ForegroundColor Green
} catch {
    Write-Host "⚠️ 需要登錄 Heroku" -ForegroundColor Yellow
    Write-Host "正在打開登錄頁面..." -ForegroundColor Blue
    heroku login
}

# 檢查 Git 狀態
if (-not (Test-Path ".git")) {
    Write-Host "⚠️ Git 尚未初始化，正在初始化..." -ForegroundColor Yellow
    git init
    git add .
    git commit -m "Initial commit"
}

# 收集靜態文件
Write-Host "📦 收集靜態文件..." -ForegroundColor Yellow
try {
    python manage.py collectstatic --noinput
    Write-Host "✅ 靜態文件收集完成" -ForegroundColor Green
} catch {
    Write-Host "⚠️ 靜態文件收集失敗，繼續部署..." -ForegroundColor Yellow
}

# 提交更改
Write-Host "📝 提交最新更改..." -ForegroundColor Yellow
git add .
$commitMessage = "Update: $(Get-Date -Format 'yyyy-MM-dd HH:mm') - 後端修復完成版本"
git commit -m $commitMessage

# 部署到 Heroku (假設已有應用)
Write-Host "🚀 開始部署到 Heroku..." -ForegroundColor Blue
Write-Host "這可能需要幾分鐘時間，請耐心等待..." -ForegroundColor Yellow

try {
    git push heroku main
    Write-Host "✅ 代碼推送成功" -ForegroundColor Green
} catch {
    Write-Host "❌ 代碼推送失敗，嘗試強制推送..." -ForegroundColor Yellow
    git push heroku main --force
    Write-Host "✅ 強制推送完成" -ForegroundColor Green
}

Write-Host ""
Write-Host "🎊 Heroku 更新部署完成！" -ForegroundColor Green
Write-Host "您的B2B派對平台現在已經更新到線上！" -ForegroundColor Green
Read-Host "按任意鍵退出"
