#!/usr/bin/env python
"""
全端工程師最終測試報告生成器
整合所有測試結果並生成綜合評估報告
"""

import json
import os
from datetime import datetime
from typing import Dict, Any


class ComprehensiveReportGenerator:
    """綜合報告生成器"""
    
    def __init__(self):
        self.timestamp = datetime.now().isoformat()
        self.reports = {}
        self.load_all_test_results()
    
    def load_all_test_results(self):
        """載入所有測試結果"""
        test_files = {
            'fullstack': 'fullstack_test_results.json',
            'api': 'api_test_results.json',
            'database': 'database_integrity_results.json'
        }
        
        for test_type, filename in test_files.items():
            if os.path.exists(filename):
                try:
                    with open(filename, 'r', encoding='utf-8') as f:
                        self.reports[test_type] = json.load(f)
                except Exception as e:
                    self.reports[test_type] = {'error': f'無法載入 {filename}: {str(e)}'}
            else:
                self.reports[test_type] = {'error': f'測試結果文件 {filename} 不存在'}
    
    def calculate_overall_score(self) -> Dict[str, Any]:
        """計算整體評分"""
        scores = {}
        
        # 前端評分
        if 'fullstack' in self.reports and 'overall' in self.reports['fullstack']:
            fullstack_overall = self.reports['fullstack']['overall']
            scores['frontend'] = fullstack_overall.get('category_scores', {}).get('frontend', 0)
            scores['backend'] = fullstack_overall.get('category_scores', {}).get('backend', 0)
            scores['security'] = fullstack_overall.get('category_scores', {}).get('security', 0)
            scores['performance'] = fullstack_overall.get('category_scores', {}).get('performance', 0)
        
        # API評分
        if 'api' in self.reports and 'summary' in self.reports['api']:
            api_summary = self.reports['api']['summary']
            accessibility_rate = api_summary.get('accessibility_rate', 0)
            scores['api'] = accessibility_rate
        
        # 數據庫評分
        database_score = 100  # 基礎分數
        if 'database' in self.reports:
            db_results = self.reports['database']
            
            # 根據發現的問題扣分
            issues_count = len(db_results.get('issues', []))
            database_score -= (issues_count * 10)  # 每個問題扣10分
            
            # 根據性能調整
            if 'performance' in db_results:
                avg_time = db_results['performance'].get('avg_query_time_ms', 0)
                if avg_time > 100:
                    database_score -= 20
                elif avg_time > 50:
                    database_score -= 10
            
            database_score = max(0, database_score)
        
        scores['database'] = database_score
        
        # 計算整體分數
        if scores:
            overall_score = sum(scores.values()) / len(scores)
        else:
            overall_score = 0
        
        return {
            'category_scores': scores,
            'overall_score': overall_score,
            'grade': self.get_grade(overall_score),
            'status': self.get_status(overall_score)
        }
    
    def get_grade(self, score: float) -> str:
        """獲取等級"""
        if score >= 95:
            return 'A+'
        elif score >= 90:
            return 'A'
        elif score >= 85:
            return 'B+'
        elif score >= 80:
            return 'B'
        elif score >= 75:
            return 'C+'
        elif score >= 70:
            return 'C'
        else:
            return 'D'
    
    def get_status(self, score: float) -> str:
        """獲取狀態"""
        if score >= 90:
            return 'EXCELLENT'
        elif score >= 80:
            return 'GOOD'
        elif score >= 70:
            return 'SATISFACTORY'
        else:
            return 'NEEDS_IMPROVEMENT'
    
    def extract_key_metrics(self) -> Dict[str, Any]:
        """提取關鍵指標"""
        metrics = {}
        
        # 前端指標
        if 'fullstack' in self.reports:
            fullstack = self.reports['fullstack']
            if 'frontend' in fullstack:
                frontend = fullstack['frontend']
                if 'page_accessibility' in frontend:
                    total_pages = len(frontend['page_accessibility'])
                    accessible_pages = sum(1 for page in frontend['page_accessibility'].values() 
                                         if page.get('accessible', False))
                    metrics['page_accessibility_rate'] = (accessible_pages / total_pages * 100) if total_pages > 0 else 0
        
        # API指標
        if 'api' in self.reports:
            api = self.reports['api']
            if 'summary' in api:
                metrics['api_accessibility_rate'] = api['summary'].get('accessibility_rate', 0)
                metrics['total_api_endpoints'] = api['summary'].get('total_endpoints', 0)
            
            if 'performance' in api:
                metrics['avg_api_response_time'] = api['performance'].get('avg_response_time_ms', 0)
            
            if 'security' in api:
                metrics['api_security_percentage'] = api['security'].get('security_percentage', 0)
        
        # 數據庫指標
        if 'database' in self.reports:
            db = self.reports['database']
            if 'statistics' in db:
                stats = db['statistics']
                metrics['total_users'] = stats.get('users', {}).get('total', 0)
                metrics['total_events'] = stats.get('events', {}).get('total', 0)
                metrics['total_suppliers'] = stats.get('suppliers', {}).get('total', 0)
                metrics['total_djs'] = stats.get('djs', {}).get('total', 0)
            
            if 'performance' in db:
                metrics['avg_db_query_time'] = db['performance'].get('avg_query_time_ms', 0)
            
            metrics['database_issues'] = len(db.get('issues', []))
        
        return metrics
    
    def identify_critical_issues(self) -> list:
        """識別關鍵問題"""
        critical_issues = []
        
        # 檢查前端問題
        if 'fullstack' in self.reports and 'overall' in self.reports['fullstack']:
            overall = self.reports['fullstack']['overall']
            if overall.get('overall_score', 0) < 80:
                critical_issues.append("前端測試評分低於80分，需要關注")
        
        # 檢查API問題
        if 'api' in self.reports and 'summary' in self.reports['api']:
            api_summary = self.reports['api']['summary']
            if api_summary.get('accessibility_rate', 0) < 90:
                critical_issues.append("API端點可訪問率低於90%")
        
        # 檢查數據庫問題
        if 'database' in self.reports:
            db = self.reports['database']
            issues_count = len(db.get('issues', []))
            if issues_count > 0:
                critical_issues.append(f"數據庫檢查發現 {issues_count} 個問題")
            
            if 'performance' in db:
                avg_time = db['performance'].get('avg_query_time_ms', 0)
                if avg_time > 100:
                    critical_issues.append("數據庫查詢性能較慢 (>100ms)")
        
        # 檢查安全問題
        if 'api' in self.reports and 'security' in self.reports['api']:
            security_pct = self.reports['api']['security'].get('security_percentage', 0)
            if security_pct < 50:
                critical_issues.append("API安全標頭覆蓋率不足50%")
        
        return critical_issues
    
    def generate_recommendations(self) -> list:
        """生成改進建議"""
        recommendations = []
        metrics = self.extract_key_metrics()
        
        # 性能建議
        if metrics.get('avg_api_response_time', 0) > 100:
            recommendations.append("優化API響應時間，考慮使用緩存機制")
        
        if metrics.get('avg_db_query_time', 0) > 50:
            recommendations.append("優化數據庫查詢，添加適當的索引")
        
        # 安全建議
        if metrics.get('api_security_percentage', 0) < 80:
            recommendations.append("加強API安全標頭配置，特別是CSP和X-Frame-Options")
        
        # 數據建議
        if metrics.get('total_users', 0) < 10:
            recommendations.append("添加更多測試數據以進行全面測試")
        
        # 數據庫問題建議
        if metrics.get('database_issues', 0) > 0:
            recommendations.append("解決數據庫完整性問題，確保數據一致性")
        
        # 通用建議
        overall_score = self.calculate_overall_score()['overall_score']
        if overall_score < 90:
            recommendations.append("建議定期運行全面測試以監控系統健康狀態")
        
        return recommendations
    
    def generate_comprehensive_report(self) -> str:
        """生成綜合報告"""
        overall_assessment = self.calculate_overall_score()
        key_metrics = self.extract_key_metrics()
        critical_issues = self.identify_critical_issues()
        recommendations = self.generate_recommendations()
        
        report = f"""# 🎯 全端工程師綜合測試報告

**測試時間**: {self.timestamp}
**整體評分**: {overall_assessment['overall_score']:.1f}/100 ({overall_assessment['grade']})
**系統狀態**: {overall_assessment['status']}

---

## 🏆 執行摘要

這是一份從全端工程師視角對Django B2B派對平台進行的全面測試報告。測試涵蓋了前端功能、後端邏輯、API端點、數據庫完整性、安全性和性能等各個層面。

### 🎯 整體評估

"""
        
        status_emoji = {
            'EXCELLENT': '🌟',
            'GOOD': '✅',
            'SATISFACTORY': '⚠️',
            'NEEDS_IMPROVEMENT': '❌'
        }
        
        emoji = status_emoji.get(overall_assessment['status'], '❓')
        report += f"{emoji} **系統狀態**: {overall_assessment['status']}\n"
        report += f"📊 **整體評分**: {overall_assessment['overall_score']:.1f}/100\n"
        report += f"🏅 **等級**: {overall_assessment['grade']}\n\n"
        
        report += "---\n\n## 📊 各項目評分\n\n"
        
        for category, score in overall_assessment['category_scores'].items():
            status = "✅" if score >= 80 else "⚠️" if score >= 60 else "❌"
            report += f"- **{category.upper()}**: {score:.1f}/100 {status}\n"
        
        report += "\n---\n\n## 📈 關鍵指標\n\n"
        
        if key_metrics:
            report += "### 🔌 API性能\n"
            if 'total_api_endpoints' in key_metrics:
                report += f"- **總端點數**: {key_metrics['total_api_endpoints']}\n"
            if 'api_accessibility_rate' in key_metrics:
                report += f"- **可訪問率**: {key_metrics['api_accessibility_rate']:.1f}%\n"
            if 'avg_api_response_time' in key_metrics:
                report += f"- **平均響應時間**: {key_metrics['avg_api_response_time']:.2f}ms\n"
            
            report += "\n### 🗄️ 數據庫狀態\n"
            if 'total_users' in key_metrics:
                report += f"- **用戶數**: {key_metrics['total_users']}\n"
            if 'total_events' in key_metrics:
                report += f"- **事件數**: {key_metrics['total_events']}\n"
            if 'total_suppliers' in key_metrics:
                report += f"- **供應商數**: {key_metrics['total_suppliers']}\n"
            if 'total_djs' in key_metrics:
                report += f"- **DJ數**: {key_metrics['total_djs']}\n"
            if 'avg_db_query_time' in key_metrics:
                report += f"- **平均查詢時間**: {key_metrics['avg_db_query_time']:.2f}ms\n"
            
            report += "\n### 🔒 安全性指標\n"
            if 'api_security_percentage' in key_metrics:
                report += f"- **API安全標頭覆蓋率**: {key_metrics['api_security_percentage']:.1f}%\n"
            if 'page_accessibility_rate' in key_metrics:
                report += f"- **頁面可訪問率**: {key_metrics['page_accessibility_rate']:.1f}%\n"
        
        report += "\n---\n\n## ⚠️ 關鍵問題\n\n"
        
        if critical_issues:
            for issue in critical_issues:
                report += f"- ❌ {issue}\n"
        else:
            report += "🎉 未發現關鍵問題！系統狀態良好。\n"
        
        report += "\n---\n\n## 💡 改進建議\n\n"
        
        if recommendations:
            for i, rec in enumerate(recommendations, 1):
                report += f"{i}. {rec}\n"
        else:
            report += "系統表現優秀，暫無特別改進建議。\n"
        
        report += "\n---\n\n## 📋 詳細測試結果\n\n"
        
        # 各項測試結果摘要
        if 'fullstack' in self.reports:
            report += "### 🎨 前端測試\n"
            fullstack = self.reports['fullstack']
            if 'overall' in fullstack:
                overall = fullstack['overall']
                report += f"- **評分**: {overall.get('overall_score', 0):.1f}/100\n"
                report += f"- **狀態**: {overall.get('status', 'unknown').upper()}\n"
        
        if 'api' in self.reports:
            report += "\n### 🔌 API測試\n"
            api = self.reports['api']
            if 'summary' in api:
                summary = api['summary']
                report += f"- **端點總數**: {summary.get('total_endpoints', 0)}\n"
                report += f"- **可訪問端點**: {summary.get('accessible_endpoints', 0)}\n"
                report += f"- **成功率**: {summary.get('test_success_rate', 0):.1f}%\n"
                report += f"- **整體評級**: {summary.get('overall_grade', 'N/A')}\n"
        
        if 'database' in self.reports:
            report += "\n### 🗄️ 數據庫測試\n"
            db = self.reports['database']
            structure_ok = db.get('structure', {}).get('required_tables_present', True)
            integrity_ok = not db.get('data_integrity', {}).get('has_orphan_records', False)
            issues_count = len(db.get('issues', []))
            
            report += f"- **結構檢查**: {'✅ 通過' if structure_ok else '❌ 失敗'}\n"
            report += f"- **完整性檢查**: {'✅ 通過' if integrity_ok else '❌ 失敗'}\n"
            report += f"- **發現問題**: {issues_count} 個\n"
        
        report += "\n---\n\n## 🚀 部署建議\n\n"
        
        overall_score = overall_assessment['overall_score']
        if overall_score >= 90:
            report += "✅ **系統可以部署到生產環境**\n"
            report += "- 所有關鍵測試通過\n"
            report += "- 性能和安全性符合要求\n"
            report += "- 建議進行最終的用戶驗收測試\n"
        elif overall_score >= 80:
            report += "⚠️ **系統基本可以部署，但建議先修復已發現的問題**\n"
            report += "- 核心功能運行正常\n"
            report += "- 建議解決上述關鍵問題後部署\n"
            report += "- 加強監控和日誌記錄\n"
        else:
            report += "❌ **不建議部署到生產環境**\n"
            report += "- 存在關鍵問題需要修復\n"
            report += "- 建議進行更多測試和修復工作\n"
            report += "- 重新運行測試確認修復效果\n"
        
        report += "\n---\n\n## 📞 測試總結\n\n"
        
        report += f"""本次全面測試評估了Django B2B派對平台的各個層面，包括：

1. **前端功能測試** - 頁面可訪問性、響應式設計、用戶體驗
2. **後端邏輯測試** - 數據處理、業務邏輯、中介軟體
3. **API端點測試** - 所有REST端點的功能性和性能
4. **數據庫完整性** - 結構檢查、數據一致性、查詢性能
5. **安全性測試** - CSRF保護、認證授權、安全標頭
6. **性能測試** - 響應時間、查詢效率、資源使用

**測試結論**: 系統整體評分 {overall_assessment['overall_score']:.1f}/100，評級 {overall_assessment['grade']}，狀態 {overall_assessment['status']}。

**建議**: {"立即可以部署" if overall_score >= 90 else "修復問題後部署" if overall_score >= 80 else "需要更多改進工作"}。

---

*報告由全端工程師測試套件自動生成 - {self.timestamp}*
"""
        
        return report
    
    def save_comprehensive_report(self):
        """保存綜合報告"""
        report = self.generate_comprehensive_report()
        
        with open('COMPREHENSIVE_FULLSTACK_REPORT.md', 'w', encoding='utf-8') as f:
            f.write(report)
        
        # 也保存JSON格式的摘要
        summary_data = {
            'timestamp': self.timestamp,
            'overall_assessment': self.calculate_overall_score(),
            'key_metrics': self.extract_key_metrics(),
            'critical_issues': self.identify_critical_issues(),
            'recommendations': self.generate_recommendations()
        }
        
        with open('comprehensive_test_summary.json', 'w', encoding='utf-8') as f:
            json.dump(summary_data, f, ensure_ascii=False, indent=2)
        
        print(f"📄 綜合報告已生成:")
        print(f"- 完整報告: COMPREHENSIVE_FULLSTACK_REPORT.md")
        print(f"- 摘要數據: comprehensive_test_summary.json")


def main():
    """主函數"""
    print("📋 全端工程師綜合測試報告生成器")
    print("="*60)
    
    generator = ComprehensiveReportGenerator()
    
    # 生成報告
    generator.save_comprehensive_report()
    
    # 顯示摘要
    overall_assessment = generator.calculate_overall_score()
    
    print("\n" + "="*60)
    print("🎯 最終測試結果")
    print("="*60)
    
    print(f"🏆 整體評分: {overall_assessment['overall_score']:.1f}/100")
    print(f"🏅 評級: {overall_assessment['grade']}")
    print(f"📊 狀態: {overall_assessment['status']}")
    
    print(f"\n📋 各項評分:")
    for category, score in overall_assessment['category_scores'].items():
        status = "✅" if score >= 80 else "⚠️" if score >= 60 else "❌"
        print(f"  • {category.upper()}: {score:.1f}/100 {status}")
    
    critical_issues = generator.identify_critical_issues()
    if critical_issues:
        print(f"\n⚠️ 關鍵問題: {len(critical_issues)} 個")
        for issue in critical_issues[:3]:  # 顯示前3個
            print(f"  • {issue}")
    else:
        print(f"\n🎉 無關鍵問題發現！")
    
    # 部署建議
    score = overall_assessment['overall_score']
    if score >= 90:
        print("\n✅ 建議: 可以部署到生產環境")
    elif score >= 80:
        print("\n⚠️ 建議: 修復問題後部署")
    else:
        print("\n❌ 建議: 需要更多改進工作")


if __name__ == "__main__":
    main()
