#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
強化版 Heroku 部署腳本 - PAPA COLLEGE B2B聚會派對媒合平台
包含錯誤處理、數據初始化和完整測試
"""

import subprocess
import sys
import os
import time
from datetime import datetime
import json

def run_command(command, description, check_output=False, ignore_errors=False):
    """執行命令並處理結果"""
    print(f"\n🔧 {description}")
    print(f"📝 執行命令: {command}")
    
    try:
        if check_output:
            result = subprocess.run(command, shell=True, capture_output=True, text=True, cwd=os.getcwd())
            if result.returncode == 0:
                print(f"✅ 成功: {description}")
                return result.stdout.strip()
            else:
                if ignore_errors:
                    print(f"⚠️ 警告: {description} - {result.stderr}")
                    return result.stdout.strip() if result.stdout else ""
                else:
                    print(f"❌ 失敗: {description}")
                    print(f"錯誤信息: {result.stderr}")
                    return None
        else:
            result = subprocess.run(command, shell=True, cwd=os.getcwd())
            if result.returncode == 0:
                print(f"✅ 成功: {description}")
                return True
            else:
                if ignore_errors:
                    print(f"⚠️ 警告: {description}")
                    return True
                else:
                    print(f"❌ 失敗: {description}")
                    return False
    except Exception as e:
        print(f"❌ 執行錯誤: {str(e)}")
        return False if not ignore_errors else True

def check_heroku_login():
    """檢查 Heroku 登入狀態"""
    print("🔐 檢查 Heroku 登入狀態...")
    result = run_command("heroku auth:whoami", "檢查登入狀態", check_output=True)
    if result:
        print(f"✅ 已登入 Heroku: {result}")
        return True
    else:
        print("❌ 未登入 Heroku，請先執行: heroku login")
        return False

def setup_environment_variables(app_name):
    """設置環境變數"""
    print(f"\n⚙️ 設置 Heroku 環境變數...")
    
    # 生成更安全的 SECRET_KEY
    import secrets
    secret_key = secrets.token_urlsafe(50)
    
    env_vars = {
        'SECRET_KEY': secret_key,
        'DEBUG': 'False',
        'ALLOWED_HOSTS': f'{app_name}.herokuapp.com,*.herokuapp.com',
        'DJANGO_SETTINGS_MODULE': 'party_platform.settings'
    }
    
    success_count = 0
    for key, value in env_vars.items():
        success = run_command(f'heroku config:set {key}="{value}" --app {app_name}', f"設置 {key}")
        if success:
            success_count += 1
    
    print(f"📊 環境變數設置完成: {success_count}/{len(env_vars)}")
    return success_count > 0

def deploy_to_heroku(app_name):
    """部署到 Heroku"""
    print(f"\n🚀 開始完整部署到 Heroku...")
    
    # 1. 添加 Heroku remote
    run_command(f"heroku git:remote --app {app_name}", f"添加 Heroku remote")
    
    # 2. 添加所有文件
    run_command("git add .", "添加所有文件到 Git")
    
    # 3. 提交變更
    commit_message = f"Complete Deploy - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    run_command(f'git commit -m "{commit_message}"', "提交變更", ignore_errors=True)
    
    # 4. 推送到 Heroku
    print("\n🔄 推送到 Heroku (這可能需要幾分鐘)...")
    success = run_command("git push heroku main --force", "強制推送到 Heroku")
    
    if success:
        print("✅ 代碼推送成功！")
        return True
    else:
        print("❌ 代碼推送失敗")
        return False

def run_post_deployment(app_name):
    """執行部署後任務"""
    print(f"\n⚙️ 執行部署後任務...")
    
    # 等待應用啟動
    print("⏳ 等待應用啟動...")
    time.sleep(20)
    
    # 1. 執行資料庫遷移
    print("📊 執行資料庫遷移...")
    migration_success = run_command(f"heroku run python manage.py migrate --app {app_name}", "執行資料庫遷移")
    
    # 2. 收集靜態文件
    print("🎨 收集靜態文件...")
    static_success = run_command(f"heroku run python manage.py collectstatic --noinput --app {app_name}", "收集靜態文件", ignore_errors=True)
    
    return {
        'migration': migration_success,
        'static': static_success
    }

def create_superuser_interactive(app_name):
    """互動式創建超級用戶"""
    print(f"\n👤 創建管理員帳戶...")
    
    create_admin = input("是否要創建管理員帳戶？(y/N): ").lower()
    
    if create_admin == 'y':
        print("請按照提示輸入管理員資訊：")
        success = run_command(f"heroku run python manage.py createsuperuser --app {app_name}", "創建超級用戶")
        return success
    else:
        print("⏭️ 跳過創建管理員帳戶")
        return True

def open_app(app_name):
    """打開應用"""
    print(f"\n🌐 打開應用...")
    run_command(f"heroku open --app {app_name}", "打開應用")

def main():
    """主函數"""
    print("="*70)
    print("🎉 PAPA COLLEGE - 強化版 Heroku 部署工具")
    print("="*70)
    print(f"⏰ 開始時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # 設置應用名稱
    app_name = "papa-college-b2b"
    
    try:
        # 1. 檢查 Heroku 登入
        if not check_heroku_login():
            print("❌ 請先登入 Heroku: heroku login")
            return
        
        # 2. 確認應用存在
        result = run_command(f"heroku apps:info {app_name}", f"檢查應用 {app_name}", check_output=True, ignore_errors=True)
        if not result or "=== " not in result:
            print(f"❌ 應用 {app_name} 不存在，請先創建應用")
            return
        else:
            print(f"✅ 應用 {app_name} 存在，繼續部署")
        
        # 3. 設置環境變數
        setup_environment_variables(app_name)
        
        # 4. 部署應用
        if not deploy_to_heroku(app_name):
            print("❌ 部署失敗，請檢查錯誤信息")
            return
        
        # 5. 執行部署後任務
        post_results = run_post_deployment(app_name)
        
        # 6. 創建管理員帳戶
        create_superuser_interactive(app_name)
        
        # 7. 完成部署
        print("\n" + "="*70)
        print("🎊 部署完成！")
        print("="*70)
        print(f"🌐 應用網址: https://{app_name}.herokuapp.com")
        print(f"⚙️ 管理後台: https://{app_name}.herokuapp.com/admin")
        print("\n📋 常用命令:")
        print(f"   查看日誌: heroku logs --tail --app {app_name}")
        print(f"   執行命令: heroku run python manage.py <command> --app {app_name}")
        print(f"   重啟應用: heroku restart --app {app_name}")
        print(f"   查看配置: heroku config --app {app_name}")
        
        # 8. 部署後任務結果
        print("\n📊 部署後任務結果:")
        for task, result in post_results.items():
            status = "✅ 成功" if result else "❌ 失敗"
            print(f"   {task}: {status}")
        
        # 9. 詢問是否打開應用
        open_browser = input("\n是否要在瀏覽器中打開應用？(y/N): ").lower()
        if open_browser == 'y':
            open_app(app_name)
        
        print(f"\n⏰ 完成時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("🎉 恭喜！您的 PAPA COLLEGE 平台已成功重新部署到 Heroku！")
        
    except KeyboardInterrupt:
        print("\n⏹️ 用戶中斷部署")
    except Exception as e:
        print(f"\n❌ 部署過程中發生錯誤: {str(e)}")

if __name__ == "__main__":
    main()
